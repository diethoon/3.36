import * as fs from 'node:fs'
import * as path from 'node:path'
import * as crypto from 'node:crypto'
import { CacheStore, type CacheEntry } from './cacheStore.ts'
import type { WorkflowType } from '../config.ts'
import { safeJoin, toPosix } from './paths.ts'
import { knownImageSize, saveKnownImageSizes, sizeMatches } from './imageSize.ts'

export interface OutfitPackTarget {
  character: string
  outfit: string
  name?: string
  presetName?: string
  styleName?: string
  /**
   * Wayward Faith: the definition of a tailor-made outfit (the game's 의상 주문 — id wfc_…) when this is its outfit pack.
   * Written into pack.js as wfImagePack.outfitDefs so a player who loads the pack gets the outfit too (game: faith/image/pack.js).
   */
  outfitDef?: Record<string, unknown>
  /**
   * Wayward Faith: the basic pack's optional part ('extension' — 기본팩의 추가 그림). It is a pack of its own in
   * <name>-<character>/extension beside the essential part (<name>-<character>/base); the game folds it into the base pack.
   */
  part?: 'extension' | 'mod'
  /** Wayward Faith: with part 'mod', the mod whose scenes this pack holds (<name>-<character>/mods/<mod>, game: tools/ext-mods.mjs). */
  mod?: string
}

export class OutfitPackError extends Error {}

/**
 * Which image keys may live in a pack. A character's pack holds only that
 * character. The supporting-cast pack (outfit 'extra', character 'extra') holds
 * the scenes where someone other than a clergy member takes the portrait: the
 * tavern wife (whichever original wife was not chosen) and the tavern husband
 * (game: src/faith/image/pack.js wfPackKeyAllowed), and the helmeted knight at the
 * door before her face is known (wfPackCastScene).
 */
export const EXTRA_PACK = 'extra'
export function packKeyAllowed(key: string, character: string, outfit: string): boolean {
  // The tavern back room (game: image/scene-place.js wfTavernRoomImage): the wife in the ordinary sex scene, place tavern_room.
  // The secret shop's witch (game: core/secret-shop.js wfSecretShopImageRequest): the shop (v-0) and her licking her fingers (v-1, cult/lewd-crest.js).
  if (outfit === EXTRA_PACK) return character === EXTRA_PACK && /^(?:(elena|mara|pippa|tavern_husband)__s-wfo_tavern_|wf_knight_visitor__(?:.*__)?o-wf_knight_helm__|(elena|mara|pippa)__(?:.*__)?p-vl__ru-tavern_room(?:__|$)|wf_secret_shop__v-[01]$)/.test(key)
  return key.startsWith(character + '__')
}

export function validateOutfitPackTarget(opts: OutfitPackTarget): void {
  if (!opts || typeof opts.character !== 'string' || !/^[a-zA-Z0-9_~.-]+$/.test(opts.character) ||
      typeof opts.outfit !== 'string' || !/^[a-zA-Z0-9_-]+$/.test(opts.outfit) ||
      (opts.name !== undefined && (typeof opts.name !== 'string' || opts.name.length > 100)) ||
      [opts.presetName, opts.styleName].some(x => x !== undefined && typeof x !== 'string') ||
      (opts.outfitDef !== undefined && (!opts.outfitDef || typeof opts.outfitDef !== 'object' || Array.isArray(opts.outfitDef) || JSON.stringify(opts.outfitDef).length > 20000)) ||
      (opts.part !== undefined && !((opts.part === 'extension' || opts.part === 'mod') && opts.outfit === 'basic')) ||
      (opts.part === 'mod') !== (opts.mod !== undefined) || (opts.mod !== undefined && (typeof opts.mod !== 'string' || !MOD_ID.test(opts.mod))))
    throw new OutfitPackError('Invalid outfit pack target')
}

const CATALOGUE = /\]\s*=\s*(\{[\s\S]*\})\s*;?\s*$/
/** A WML mod id (wml/docs/SDK.md: lowercase first, then lowercase, digits, . - _) */
const MOD_ID = /^[a-z][a-z0-9._-]{0,63}$/

function packName(opts: OutfitPackTarget): string {
  const name = opts.name?.trim() || `${opts.character}-${opts.outfit}`
  if (/[<>:"/\\|?*\u0000-\u001f]/.test(name) || /[. ]$/.test(name) || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(name) || name === '.' || name === '..')
    throw new OutfitPackError('Pack name cannot be used as a folder name')
  return name
}
// 팩 폴더: <이름>-<캐릭터>/<종류> — 종류는 base(기본팩 필수)·extension(기본팩 추가)·outfits/<옷>(의상팩)·mods/<모드>(모드팩). 조연팩은 <이름>-extra/base.
// image-packs 바로 아래에 팩마다 폴더가 생겨 너무 많아졌다 (사용자 결정 2026-10-26: 제작자-캐릭터까지 한 단계, 팩 종류는 그 안,
// 의상팩·모드팩은 outfits/·mods/ 아래로 한 단계 더 — 늘어나도 캐릭터 폴더에는 넷만 보인다).
// mods/<id>: 모드팩 — 모드가 더하는 장면의 그림(기본팩에서 뺀다). 게임은 인물마다 따로 고른다 (image/pack.js).
export function packKindFolder(outfit: string, part?: string, mod?: string): string {
  if (part === 'mod' && mod) return 'mods/' + mod
  return outfit === EXTRA_PACK || outfit === 'basic' ? (part === 'extension' ? 'extension' : 'base') : 'outfits/' + outfit
}
/** 그 종류의 이번 세션 중간 이름(outfit-<옷>·mod-<모드>) — 있으면 옮긴다 */
function midKindFolder(outfit: string, part?: string, mod?: string): string | null {
  if (part === 'mod' && mod) return 'mod-' + mod
  return outfit === EXTRA_PACK || outfit === 'basic' ? null : 'outfit-' + outfit
}
function packFolderName(opts: OutfitPackTarget, name: string): string {
  return `${name}-${opts.outfit === EXTRA_PACK ? EXTRA_PACK : opts.character}/${packKindFolder(opts.outfit, opts.part, opts.mod)}`
}
/** 예전(한 단계) 폴더 이름. 그 자리에 이 팩이 있으면 새 자리로 옮긴다 (legacyPackFolder → movePackFolder). 기본팩 추가는 예전에 따로 없었다. */
function oldPackFolderName(opts: OutfitPackTarget, name: string): string[] {
  const mid = midKindFolder(opts.outfit, opts.part, opts.mod), who = opts.outfit === EXTRA_PACK ? EXTRA_PACK : opts.character
  const out = mid ? [`${name}-${who}/${mid}`] : []
  if (opts.part) return out
  return [...out, opts.outfit === EXTRA_PACK ? `${name}-${EXTRA_PACK}` : `${name}-${opts.character}-${opts.outfit}`]
}
/** 팩 폴더를 새 자리로. 새 자리가 옛 폴더 안이면(faith-extra → faith-extra/basic) 잠깐 다른 이름을 거쳐 옮긴다. */
// 윈도는 탐색기 창·그림 뷰어·미리보기·검색 색인·백신이 폴더를 잡고 있으면 옮기기가 EPERM/EBUSY로 실패한다 — 잠깐이면 몇 번 다시 해 본다
function renameRetry(from: string, to: string): void {
  for (let i = 0; ; i++) {
    try { return fs.renameSync(from, to) } catch (error) {
      const code = (error as NodeJS.ErrnoException).code
      if (i >= 5 || !['EPERM', 'EBUSY', 'EACCES'].includes(code ?? '')) throw error
      Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 200 * (i + 1))
    }
  }
}
function movePackFolder(from: string, to: string): void {
  fs.mkdirSync(path.dirname(to), { recursive: true })
  if (to.startsWith(from + path.sep)) {
    const tmp = from + '.moving-' + process.pid
    renameRetry(from, tmp)
    try {
      fs.mkdirSync(path.dirname(to), { recursive: true })
      renameRetry(tmp, to)
    } catch (error) {
      try { fs.rmSync(from, { recursive: true, force: true }); renameRetry(tmp, from) } catch { /* 임시 이름으로 남는다 — 다음에 켤 때 옮긴다 */ }
      throw error
    }
  } else {
    try { renameRetry(from, to) } catch (error) {
      // 폴더 자체만 잠긴 경우(탐색기가 그 폴더를 열어 둠 등): 안의 것(images·pack.js …)을 하나씩 옮기고 빈 옛 폴더는 남긴다(지울 수 있으면 지운다)
      if (!['EPERM', 'EBUSY', 'EACCES'].includes((error as NodeJS.ErrnoException).code ?? '')) throw error
      fs.mkdirSync(to, { recursive: true })
      const names = fs.readdirSync(from)
      for (const name of names.filter((n) => n !== 'pack.js')) renameRetry(path.join(from, name), path.join(to, name))
      if (names.includes('pack.js')) renameRetry(path.join(from, 'pack.js'), path.join(to, 'pack.js')) // 다 옮긴 뒤에 — 도중에 멈추면 옛 자리가 그대로 팩이다
      try { fs.rmdirSync(from) } catch { /* 잠긴 빈 폴더 — 그림이 없으니 다음부터는 건너뛴다 */ }
    }
  }
}
function packIdentity(opts: OutfitPackTarget, name: string): string {
  return JSON.stringify([opts.character, opts.outfit, opts.presetName ?? '', opts.styleName ?? '', name, ...(opts.part ? [opts.part] : []), ...(opts.mod ? [opts.mod] : [])])
}
function readCatalogue(file: string): { packId?: unknown; entries?: Record<string, { imagePath: string }> } | null {
  const match = fs.readFileSync(file, 'utf8').match(CATALOGUE)
  return match ? JSON.parse(match[1]) : null
}

/**
 * A folder that holds no art: missing, or only an empty catalogue left by a run
 * that did not find the earlier folder. false when it holds art; otherwise the
 * empty catalogue's pack ID, if any.
 */
function emptyPackFolder(dir: string): string | undefined | false {
  if (!fs.existsSync(dir)) return undefined
  if (fs.readdirSync(dir).some(n => !['pack.js', 'pack.js.tmp', 'images'].includes(n))) return false
  const images = path.join(dir, 'images')
  if (fs.existsSync(images) && fs.readdirSync(images).length) return false
  const catalogue = path.join(dir, 'pack.js')
  if (!fs.existsSync(catalogue)) return undefined
  try {
    const pack = readCatalogue(catalogue)
    if (!pack || Object.keys(pack.entries ?? {}).length) return false
    return typeof pack.packId === 'string' ? pack.packId : undefined
  } catch { return false }
}

/** An earlier folder of this pack (named by its old rule or its ID) whose catalogue carries one of these IDs. */
function legacyPackFolder(stateDir: string, root: string, directory: string, parts: string[], ids: Set<string>): { dir: string; packId: string } | null {
  for (const legacyRoot of new Set([root, path.join(path.resolve(stateDir), 'image-packs'), path.join(path.resolve(stateDir), 'outfit-packs')])) {
    for (const part of parts) {
      let dir: string
      try { dir = safeJoin(legacyRoot, part) } catch { continue }
      const file = path.join(dir, 'pack.js')
      if (dir === directory || !fs.existsSync(file)) continue
      try {
        const id = readCatalogue(file)?.packId
        if (typeof id === 'string' && ids.has(id)) return { dir, packId: id }
      } catch { /* not a pack */ }
    }
  }
  return null
}

/**
 * The keys a pack already holds, with their files present — what an enqueue
 * would keep. Reads only: no folder is made, moved or registered, so checking
 * a name the user then drops leaves nothing behind.
 */
export function packExistingKeys(stateDir: string, opts: OutfitPackTarget, outputRoot?: string, size?: { width?: number; height?: number }): string[] {
  validateOutfitPackTarget(opts)
  const name = packName(opts)
  const root = outputRoot ? path.resolve(outputRoot) : path.join(path.resolve(stateDir), 'image-packs')
  const folderName = packFolderName(opts, name)
  let directory = safeJoin(root, folderName)
  const empty = emptyPackFolder(directory)
  if (empty !== false) {
    const registry = path.join(stateDir, 'outfit-pack-ids.json')
    let ids: Record<string, string> = {}
    try { ids = fs.existsSync(registry) ? JSON.parse(fs.readFileSync(registry, 'utf8')) : {} } catch { /* none */ }
    const known = new Set([ids[packIdentity(opts, name)], empty].filter((x): x is string => typeof x === 'string'))
    const legacy = known.size ? legacyPackFolder(stateDir, root, directory, [folderName, ...oldPackFolderName(opts, name), name, ...known], known) : null
    if (!legacy) return []
    directory = legacy.dir
  }
  const file = path.join(directory, 'pack.js')
  if (!fs.existsSync(file)) return []
  let entries: Record<string, { imagePath: string }> = {}
  try { entries = readCatalogue(file)?.entries ?? {} } catch { return [] }
  const keys = Object.entries(entries).filter(([key, entry]) => packKeyAllowed(key, opts.character, opts.outfit) &&
    typeof entry?.imagePath === 'string' && entry.imagePath.startsWith('images/') && fs.existsSync(safeJoin(directory, entry.imagePath)) &&
    // Wayward Faith: a picture of the wrong size (old 1024x1024 renders) counts as one to draw again (cache/imageSize.ts — remembered, not reopened)
    (!size || ((s) => !s || sizeMatches(s, size))(knownImageSize(stateDir, safeJoin(directory, entry.imagePath))))).map(([key]) => key)
  saveKnownImageSizes(stateDir)
  return keys
}

/** Incrementally maintain a distributable folder while the cache renders. */
export class OutfitPackWriter {
  readonly packId: string
  readonly name: string
  readonly directory: string
  private root: string
  readonly cache: CacheStore
  private entries: Record<string, { imagePath: string; talentName: string; imageType?: string; promptHash?: string }> = {}
  private dirty = true

  constructor(private stateDir: string, private imagesDir: string, private opts: OutfitPackTarget, reset = false, private outputRoot?: string) {
    validateOutfitPackTarget(opts)
    this.name = packName(opts)
    fs.mkdirSync(stateDir, { recursive: true })
    const registry = path.join(stateDir, 'outfit-pack-ids.json')
    const ids: Record<string, string> = fs.existsSync(registry) ? JSON.parse(fs.readFileSync(registry, 'utf8')) : {}
    const identity = packIdentity(opts, this.name)
    this.packId = Object.hasOwn(ids, identity) ? ids[identity] : `${opts.character}-${opts.outfit}${opts.part ? '-' + opts.part : ''}${opts.mod ? '-' + opts.mod : ''}-${crypto.randomUUID()}`
    if (typeof this.packId !== 'string' || !/^[a-zA-Z0-9_~.-]+$/.test(this.packId) || ['.','..'].includes(this.packId)) throw new Error('Invalid stored pack ID')
    const root = outputRoot ? path.resolve(outputRoot) : path.join(path.resolve(stateDir), 'image-packs')
    const folderName = packFolderName(opts, this.name)
    this.directory = safeJoin(root, folderName)
    this.root = root
    fs.mkdirSync(root, { recursive: true })
    // Verify the ID before moving a legacy folder; never overwrite a destination that holds art.
    // An empty folder of the new name (left by a run that missed the old folder) gives way to it.
    const empty = emptyPackFolder(this.directory)
    if (empty !== false) {
      const known = new Set([this.packId, empty].filter((x): x is string => typeof x === 'string'))
      const legacy = legacyPackFolder(stateDir, root, this.directory, [folderName, ...oldPackFolderName(opts, this.name), this.name, ...known], known)
      if (legacy) {
        if (!this.directory.startsWith(legacy.dir + path.sep)) fs.rmSync(this.directory, { recursive: true, force: true })
        movePackFolder(legacy.dir, this.directory)
        this.packId = legacy.packId
      }
    }
    fs.mkdirSync(this.directory, { recursive: true })
    const catalogue = path.join(this.directory, 'pack.js')
    if (fs.existsSync(catalogue)) {
      const match = fs.readFileSync(catalogue, 'utf8').match(/\]\s*=\s*(\{[\s\S]*\})\s*;?\s*$/)
      if (!match) throw new Error('Invalid existing outfit pack catalogue')
      const pack = JSON.parse(match[1])
      const meta = pack.wfImagePack
      const compatible = pack.packFormat === 1 && [1, 2].includes(meta?.version) && meta.character === opts.character &&
        !!meta.extra === (opts.outfit === EXTRA_PACK) &&
        meta.basic === (opts.outfit === 'basic') && Array.isArray(meta.outfits) &&
        (meta.basic || meta.extra || meta.outfits.length === 1 && meta.outfits[0] === opts.outfit) &&
        (meta.part ?? undefined) === opts.part && (meta.mod ?? undefined) === opts.mod &&
        typeof pack.packId === 'string' && /^[a-zA-Z0-9_~.-]+$/.test(pack.packId) && !['.', '..'].includes(pack.packId) &&
        pack.entries && typeof pack.entries === 'object' && !Array.isArray(pack.entries)
      if (!compatible || reset && pack.packId !== this.packId) throw new OutfitPackError('Another image pack already uses this folder name')
      // The explicitly named installed folder is the project being continued.
      // Its ID survives a rename, a copied pack, or a lost/stale server registry.
      this.packId = pack.packId
      if (!reset) this.entries = pack.entries
    }
    this.cache = new CacheStore({ imagesDir: path.join(this.directory, 'images') }).load()
    ids[identity] = this.packId
    fs.writeFileSync(registry + '.tmp', JSON.stringify(ids, null, 2), 'utf8')
    fs.renameSync(registry + '.tmp', registry)
  }

  add(key: string, entry: Pick<CacheEntry, 'imagePath' | 'imageType'>): void {
    if (!packKeyAllowed(key, this.opts.character, this.opts.outfit)) throw new Error('Outfit pack character mismatch')
    // Files sit directly in images/ — a pack is one preset and style already (a copy from the shared cache drops its folders)
    const rel = toPosix(path.join('images', path.basename(entry.imagePath)))
    const target = safeJoin(this.directory, rel)
    fs.mkdirSync(path.dirname(target), { recursive: true })
    fs.copyFileSync(safeJoin(this.imagesDir, entry.imagePath), target)
    this.entries[key] = { imagePath: rel, talentName: key, imageType: entry.imageType }
    this.dirty = true
  }

  /** The distributed file is authoritative, including for older copied packs. */
  get(key: string, imageType: string, promptHash: string, workflow: WorkflowType): CacheEntry | null {
    const entry = this.entries[key]
    if (!entry) return this.cache.get(key, imageType, promptHash, workflow)
    if (!fs.existsSync(safeJoin(this.directory, entry.imagePath))) {
      delete this.entries[key]
      this.dirty = true
      return null
    }
    if (!entry.imagePath.startsWith('images/')) return null
    const imagePath = entry.imagePath.slice(7), cached = this.cache.get(key, imageType, promptHash, workflow)
    if (cached?.imagePath === imagePath) return cached
    // A pack is edited by keeping/deleting its originals, independently of current generation settings.
    return { talentName: key, imageType: entry.imageType ?? imageType, promptHash: entry.promptHash ?? promptHash,
      imagePath, prompt: '', createdAt: fs.statSync(safeJoin(this.directory, entry.imagePath)).mtimeMs }
  }

  /**
   * Wayward Faith: drop a picture so it is drawn again (wrong size — batch/queue.ts cached). The file is moved
   * out of the pack, not deleted, to <stateDir>/replaced-pack-images/<folder>/ so the shipped folder stays clean.
   */
  retire(key: string): void {
    const entry = this.entries[key]
    if (!entry) return
    const from = safeJoin(this.directory, entry.imagePath)
    if (fs.existsSync(from)) {
      const away = path.join(path.resolve(this.stateDir), 'replaced-pack-images', path.basename(this.directory))
      fs.mkdirSync(away, { recursive: true })
      fs.renameSync(from, path.join(away, path.basename(from)))
    }
    delete this.entries[key]
    this.dirty = true
  }

  record(key: string, entry: CacheEntry): void {
    this.entries[key] = { imagePath: 'images/' + entry.imagePath, talentName: key, imageType: entry.imageType, promptHash: entry.promptHash }
    this.dirty = true
  }

  flush(): void {
    if (!this.dirty) return
    const pack = { packFormat: 1, packId: this.packId, name: this.name, folderName: toPosix(path.relative(this.root, this.directory)), generatedAt: new Date().toISOString(),
      characters: [this.opts.character], entries: this.entries, entryCount: Object.keys(this.entries).length,
      wfImagePack: { version: 2, character: this.opts.character, basic: this.opts.outfit === 'basic',
        ...(this.opts.outfit === EXTRA_PACK ? { extra: true } : {}),
        ...(this.opts.part ? { part: this.opts.part } : {}),
        ...(this.opts.mod ? { mod: this.opts.mod } : {}),
        ...(this.opts.outfitDef ? { outfitDefs: { [this.opts.outfit]: this.opts.outfitDef } } : {}),
        outfits: this.opts.outfit === 'basic' ? ['modest', 'naked', 'panties_only', 'nightshift', 'wf_rags'] : this.opts.outfit === EXTRA_PACK ? [] : [this.opts.outfit] } }
    const file = path.join(this.directory, 'pack.js')
    fs.writeFileSync(file + '.tmp', `/* WAYWARD_FAITH_IMAGE_PACK */\n(window.__WF_OUTFIT_PACKS__=window.__WF_OUTFIT_PACKS__||Object.create(null))[${JSON.stringify(this.packId)}]=${JSON.stringify(pack)};\n`, 'utf8')
    fs.renameSync(file + '.tmp', file)
    this.dirty = false
  }

  result() {
    return { directory: this.outputRoot ? this.directory : path.relative(path.resolve(this.stateDir), this.directory), packId: this.packId, name: this.name, images: Object.keys(this.entries).length }
  }
}

/**
 * image-packs 바로 아래에 있는 예전(한 단계) 팩 폴더를 새 자리(<이름>-<캐릭터>/<종류>)로 옮긴다 — 서버를 켤 때 (사용자 결정 2026-10-26, 하위 호환).
 * 폴더 이름이 예전 규칙(<이름>-<캐릭터>-<종류>, 조연팩 <이름>-extra)이면 그 앞부분을 이름으로 쓰고, 아니면 pack.js의 name을 쓴다.
 * 새 자리에 이미 팩(pack.js)이 있으면 옮기지 않는다. 옮긴 목록을 돌려준다 [옛 폴더, 새 폴더].
 */
export function migratePackFolders(root: string, onError?: (dir: string, error: unknown) => void): [string, string][] {
  const moved: [string, string][] = []
  if (!fs.existsSync(root)) return moved
  // 옮길 것: 옛 한 단계 폴더(<이름>-<캐릭터>-<종류>)와, 캐릭터 폴더 안의 중간 이름(outfit-<옷>·mod-<모드> → outfits/<옷>·mods/<모드>)
  const found: { dir: string; name: string; parent: string | null }[] = []
  for (const d of fs.readdirSync(root, { withFileTypes: true })) {
    if (!d.isDirectory()) continue
    found.push({ dir: path.join(root, d.name), name: d.name, parent: null })
    try {
      for (const k of fs.readdirSync(path.join(root, d.name), { withFileTypes: true }))
        if (k.isDirectory() && /^(?:outfit|mod)-/.test(k.name)) found.push({ dir: path.join(root, d.name, k.name), name: k.name, parent: d.name })
    } catch { /* 읽지 못한 폴더 */ }
  }
  for (const d of found) {
    const dir = d.dir, file = path.join(dir, 'pack.js')
    if (!fs.existsSync(file)) continue
    let pack: { name?: unknown; wfImagePack?: { character?: unknown; basic?: unknown; extra?: unknown; outfits?: unknown; part?: unknown; mod?: unknown } } | null = null
    try { pack = readCatalogue(file) as typeof pack } catch { continue }
    const m = pack?.wfImagePack
    if (!m || typeof m.character !== 'string') continue
    const outfit = m.extra ? EXTRA_PACK : m.basic ? 'basic' : Array.isArray(m.outfits) && typeof m.outfits[0] === 'string' ? m.outfits[0] : ''
    if (!outfit) continue
    const who = m.extra ? EXTRA_PACK : m.character
    const suffix = m.extra ? `-${EXTRA_PACK}` : `-${m.character}-${outfit}`
    const plain = d.name.replace(/\.moving-\d+$/, '')
    const prefix = plain.endsWith(suffix) && plain.length > suffix.length ? plain.slice(0, -suffix.length) : typeof pack?.name === 'string' && pack.name ? pack.name : plain
    const part = m.part === 'extension' || m.part === 'mod' ? m.part : undefined, mod = part === 'mod' && typeof m.mod === 'string' && MOD_ID.test(m.mod) ? m.mod : undefined
    if (part === 'mod' && !mod) continue
    let to: string
    try { to = safeJoin(root, d.parent ? `${d.parent}/${packKindFolder(outfit, part, mod)}` : `${prefix}-${who}/${packKindFolder(outfit, part, mod)}`) } catch { continue }
    if (to === dir || fs.existsSync(path.join(to, 'pack.js'))) continue
    try {
      if (fs.existsSync(to)) fs.rmSync(to, { recursive: true, force: true }) // 그림 없는 빈 자리
      movePackFolder(dir, to)
    } catch (error) {
      // 이 폴더만 건너뛴다 — 다른 폴더는 계속 옮기고, 다음에 켤 때 다시 해 본다
      onError?.(dir, error)
      continue
    }
    // pack.js의 folderName도 새 자리로
    try {
      const js = path.join(to, 'pack.js'), text = fs.readFileSync(js, 'utf8')
      fs.writeFileSync(js, text.replace(/"folderName":"[^"]*"/, `"folderName":${JSON.stringify(toPosix(path.relative(root, to)))}`), 'utf8')
    } catch { /* 이름만 못 고침 */ }
    moved.push([dir, to])
  }
  return moved
}

/**
 * 모드 그림 뽑아 옮기기 (사용자 결정 2026-10-26): 기본팩(<이름>-<캐릭터>/base·extension)에 든 모드 장면의 그림을 그 모드의 부록팩
 * <이름>-<캐릭터>/mods/<id>로 옮긴다. 모드의 장면 목록은 모드 폴더의 pack-keys.json { id, scenes: [장면 id…] } (tools/make-ext-mod.mjs가 만든다).
 * 그림 키의 장면 칸(__s-<장면>__)으로 가른다. 파일은 지우지 않고 옮기며, 옮긴 칸은 기본팩 pack.js에서 뺀다. 모드가 꺼져 있어도 옮긴다(기본팩에 모드 그림이 섞이지 않게).
 * 옮긴 그림 수를 돌려준다 { "<폴더>/mods/<id>": 장수 }.
 */
export function splitModPacks(root: string, modsDir: string): Record<string, number> {
  const out: Record<string, number> = {}
  if (!fs.existsSync(root) || !fs.existsSync(modsDir)) return out
  type Rename = { from: { scene: string; variant: number }; to: { scene: string; variant: number } }
  const mods: { id: string; scenes: Set<string>; renames: Rename[] }[] = []
  for (const d of fs.readdirSync(modsDir, { withFileTypes: true })) {
    if (!d.isDirectory()) continue
    const file = path.join(modsDir, d.name, 'pack-keys.json')
    if (!fs.existsSync(file)) continue
    try {
      const j = JSON.parse(fs.readFileSync(file, 'utf8'))
      const renames: Rename[] = (Array.isArray(j.renames) ? j.renames : []).filter((x: any) =>
        typeof x?.from?.scene === 'string' && Number.isInteger(x.from.variant) && typeof x?.to?.scene === 'string' && Number.isInteger(x.to.variant))
      if (typeof j.id === 'string' && MOD_ID.test(j.id) && Array.isArray(j.scenes) && j.scenes.length) mods.push({ id: j.id, scenes: new Set(j.scenes.filter((x: unknown) => typeof x === 'string')), renames })
    } catch { /* 읽지 못한 목록은 건너뛴다 */ }
  }
  if (!mods.length) return out
  const sceneOf = (key: string) => key.split('__').find((x) => x.startsWith('s-'))?.slice(2) ?? ''
  for (const top of fs.readdirSync(root, { withFileTypes: true })) {
    if (!top.isDirectory()) continue
    for (const kind of ['base', 'extension']) {
      const dir = path.join(root, top.name, kind), file = path.join(dir, 'pack.js')
      if (!fs.existsSync(file)) continue
      let text: string, pack: any
      try { text = fs.readFileSync(file, 'utf8'); pack = JSON.parse(text.match(CATALOGUE)![1]) } catch { continue }
      const meta = pack?.wfImagePack
      if (!meta?.basic || meta.extra || !pack.entries) continue
      let changed = false
      for (const mod of mods) {
        // [옛 키, 모드팩의 키]: 그 모드의 장면이거나, 이름 바꾸기(renames)에 걸리는 예전 키(장면 칸 s-…·변형 칸 v-…)
        const variantOf = (key: string) => Number(key.split('__').find((x) => /^v-\d+$/.test(x))?.slice(2) ?? NaN)
        const renamed = (key: string): string | null => {
          for (const { from, to } of mod.renames)
            if (sceneOf(key) === from.scene && variantOf(key) === from.variant)
              return key.split('__').map((x) => (x === 's-' + from.scene ? 's-' + to.scene : x === 'v-' + from.variant ? 'v-' + to.variant : x)).join('__')
          return null
        }
        const keys = Object.keys(pack.entries).map((k): [string, string] | null => (mod.scenes.has(sceneOf(k)) ? [k, k] : ((n) => (n ? [k, n] : null))(renamed(k)))).filter((x): x is [string, string] => !!x)
        if (!keys.length) continue
        const toDir = path.join(root, top.name, 'mods', mod.id), toFile = path.join(toDir, 'pack.js')
        let target: any = null
        if (fs.existsSync(toFile)) try { target = JSON.parse(fs.readFileSync(toFile, 'utf8').match(CATALOGUE)![1]) } catch { continue }
        const packId = target?.packId ?? `${String(pack.packId).replace(/-?(?:base|extension)?$/, '')}-mod-${mod.id}`.replace(/[^a-zA-Z0-9_~.-]/g, '-')
        target ??= { packFormat: 1, packId, name: pack.name, folderName: toPosix(path.relative(root, toDir)), generatedAt: new Date().toISOString(),
          characters: pack.characters ?? [meta.character], entries: {}, entryCount: 0,
          wfImagePack: { version: 2, character: meta.character, basic: true, part: 'mod', mod: mod.id, outfits: meta.outfits ?? [] } }
        fs.mkdirSync(path.join(toDir, 'images'), { recursive: true })
        for (const [k, nk] of keys) {
          const e = pack.entries[k], from = safeJoin(dir, e.imagePath), to = safeJoin(toDir, e.imagePath)
          if (fs.existsSync(from)) { if (fs.existsSync(to)) fs.rmSync(from); else fs.renameSync(from, to) }
          target.entries[nk] ??= { ...e, talentName: nk }
          delete pack.entries[k]
        }
        target.entryCount = Object.keys(target.entries).length
        fs.writeFileSync(toFile, `/* WAYWARD_FAITH_IMAGE_PACK */\n(window.__WF_OUTFIT_PACKS__=window.__WF_OUTFIT_PACKS__||Object.create(null))[${JSON.stringify(target.packId)}]=${JSON.stringify(target)};\n`, 'utf8')
        const at = toPosix(path.relative(root, toDir))
        out[at] = (out[at] ?? 0) + keys.length
        changed = true
      }
      if (changed) {
        pack.entryCount = Object.keys(pack.entries).length
        fs.writeFileSync(file + '.tmp', `/* WAYWARD_FAITH_IMAGE_PACK */\n(window.__WF_OUTFIT_PACKS__=window.__WF_OUTFIT_PACKS__||Object.create(null))[${JSON.stringify(pack.packId)}]=${JSON.stringify(pack)};\n`, 'utf8')
        fs.renameSync(file + '.tmp', file)
      }
    }
  }
  return out
}
