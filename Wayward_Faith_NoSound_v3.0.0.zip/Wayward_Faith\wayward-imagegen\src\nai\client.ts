/**
 * NovelAI image generation — the second backend, beside ComfyUI.
 *
 * The game sends the same prompt it sends ComfyUI. Two things differ on the
 * NovelAI side and are translated here rather than in the game:
 *  - weights: SD-style `(tag:1.2)` becomes NovelAI's `1.2::tag ::` — the space before the closing `::` keeps a tag
 *    that ends in a digit (an artist name like `8d2suga9`) from running into the weight syntax;
 *  - escaped parentheses (`tag \(series\)`) are plain parentheses to NovelAI.
 * LoRAs, checkpoints and clip skip do not exist there and are ignored.
 *
 * Adapted from Wayward EasyGen (mods/Wayward_EasyGen_Vanilla.zip, nai/client.ts).
 */

import { inflateRawSync } from 'node:zlib'

const ENDPOINT = 'https://image.novelai.net/ai/generate-image'

export const NAI_MODELS = ['nai-diffusion-4-5-full', 'nai-diffusion-4-5-curated', 'nai-diffusion-4-full', 'nai-diffusion-5-full'] as const
export const NAI_SAMPLERS = ['k_euler_ancestral', 'k_euler', 'k_dpmpp_2s_ancestral', 'k_dpmpp_2m_sde', 'k_dpmpp_2m', 'k_dpmpp_sde'] as const
export const NAI_NOISE_SCHEDULES = ['karras', 'exponential', 'polyexponential', 'native'] as const

export interface NaiParams {
  token: string
  model: string
  prompt: string
  negativePrompt: string
  width: number
  height: number
  steps: number
  scale: number
  sampler: string
  noiseSchedule: string
  seed?: number
}

function u16(buffer: Buffer, offset: number): number { return buffer.readUInt16LE(offset) }
function u32(buffer: Buffer, offset: number): number { return buffer.readUInt32LE(offset) }

/** Extract the first PNG from NovelAI's ZIP response without an extra package. */
export function extractFirstPngFromZip(buffer: Buffer): Buffer {
  const eocdSignature = 0x06054b50
  const centralSignature = 0x02014b50
  const localSignature = 0x04034b50
  let eocd = -1
  for (let offset = buffer.length - 22; offset >= Math.max(0, buffer.length - 65_557); offset--) {
    if (u32(buffer, offset) === eocdSignature) { eocd = offset; break }
  }
  if (eocd < 0) throw new Error('NovelAI response ZIP has no end record')

  const entryCount = u16(buffer, eocd + 10)
  let offset = u32(buffer, eocd + 16)
  for (let index = 0; index < entryCount; index++) {
    if (u32(buffer, offset) !== centralSignature) throw new Error('NovelAI response ZIP directory is damaged')
    const method = u16(buffer, offset + 10)
    const compressedSize = u32(buffer, offset + 20)
    const nameLength = u16(buffer, offset + 28)
    const extraLength = u16(buffer, offset + 30)
    const commentLength = u16(buffer, offset + 32)
    const localOffset = u32(buffer, offset + 42)
    const name = buffer.subarray(offset + 46, offset + 46 + nameLength).toString('utf8')
    if (/\.png$/i.test(name)) {
      if (u32(buffer, localOffset) !== localSignature) throw new Error('NovelAI response ZIP points at a bad image offset')
      const localNameLength = u16(buffer, localOffset + 26)
      const localExtraLength = u16(buffer, localOffset + 28)
      const dataOffset = localOffset + 30 + localNameLength + localExtraLength
      const compressed = buffer.subarray(dataOffset, dataOffset + compressedSize)
      if (method === 0) return Buffer.from(compressed)
      if (method === 8) return inflateRawSync(compressed)
      throw new Error(`NovelAI response ZIP uses an unsupported compression method (${method})`)
    }
    offset += 46 + nameLength + extraLength + commentLength
  }
  throw new Error('NovelAI response ZIP holds no PNG')
}

/** SD prompt syntax → NovelAI prompt syntax. */
export function toNaiPrompt(prompt: string): string {
  return String(prompt ?? '')
    .split(',')
    .map(part => {
      const tag = part.trim()
      if (!tag) return ''
      const weighted = /^\((.+):\s*(-?[\d.]+)\)$/.exec(tag)
      const body = (weighted ? weighted[1] : tag).replace(/\\([()])/g, '$1').trim()
      if (!weighted) return body
      const w = Number(weighted[2])
      return !Number.isFinite(w) || w === 1 ? body : `${w}::${body} ::`
    })
    .filter(Boolean)
    .join(', ')
}

/** NovelAI wants both sides as multiples of 64. */
function snap64(n: number, fallback: number): number {
  const v = Number.isFinite(n) && n > 0 ? n : fallback
  return Math.max(64, Math.round(v / 64) * 64)
}

export async function generateNovelAIImage(p: NaiParams, fetchImpl: typeof fetch = fetch): Promise<{ bytes: Buffer; seed: number }> {
  const token = p.token.trim()
  if (!token) throw new Error('NovelAI API token is not set')
  const prompt = toNaiPrompt(p.prompt)
  const negativePrompt = toNaiPrompt(p.negativePrompt)
  const seed = Number.isFinite(p.seed) ? Number(p.seed) : Math.floor(Math.random() * 0xffffffff)
  const isV5 = p.model.includes('diffusion-5')
  const caption = { base_caption: prompt, char_captions: [] as unknown[] }
  const negativeCaption = { base_caption: negativePrompt, char_captions: [] as unknown[] }
  const payload = {
    input: prompt,
    model: p.model,
    action: 'generate',
    parameters: {
      params_version: isV5 ? 4 : 3,
      width: snap64(p.width, 832),
      height: snap64(p.height, 1216),
      scale: p.scale,
      sampler: p.sampler,
      steps: p.steps,
      n_samples: 1,
      seed,
      negative_prompt: negativePrompt,
      noise_schedule: p.noiseSchedule,
      qualityToggle: true,
      ucPreset: 0,
      legacy: false,
      legacy_v3_extend: false,
      v4_prompt: { caption, use_coords: false, use_order: true },
      v4_negative_prompt: { caption: negativeCaption, legacy_uc: false },
    },
  }

  const response = await fetchImpl(ENDPOINT, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json', Accept: 'application/octet-stream' },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(180_000),
  })
  if (!response.ok) {
    const detail = (await response.text()).slice(0, 800)
    throw new Error(`NovelAI API ${response.status}: ${detail || response.statusText}`)
  }
  const responseBytes = Buffer.from(await response.arrayBuffer())
  const contentType = response.headers.get('content-type') || ''
  if (contentType.includes('json')) {
    const result = JSON.parse(responseBytes.toString('utf8')) as { images?: Array<{ image?: string; seed?: number }> }
    const image = result.images?.[0]
    if (!image?.image) throw new Error('NovelAI API returned no image data')
    return { bytes: Buffer.from(image.image, 'base64'), seed: image.seed ?? seed }
  }
  return { bytes: extractFirstPngFromZip(responseBytes), seed }
}
