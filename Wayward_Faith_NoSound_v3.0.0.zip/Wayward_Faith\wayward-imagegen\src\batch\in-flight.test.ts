import { test, expect } from 'bun:test'
import * as fs from 'node:fs'
import * as os from 'node:os'
import * as path from 'node:path'
import { BatchQueue, BATCH_IN_FLIGHT } from './queue.ts'
import { CacheStore } from '../cache/cacheStore.ts'
import type { Config } from '../config.ts'
import type { JobRunner, GenerationJob } from '../comfy/jobRunner.ts'

// The batch keeps the next render waiting in ComfyUI (user request 2026-10-21): the GPU sat idle about 0.7s
// between 2.6s renders while the server saved one picture and sent the next.
test('the batch keeps two renders in ComfyUI, never sends one twice, and a pause lets the sent ones finish', async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-in-flight-'))
  try {
    const imagesDir = path.join(root, 'cache'), stateDir = path.join(root, 'state')
    const jobs = new Map<string, GenerationJob>(), sent: string[] = []
    let live = 0, most = 0
    const finish = (id: string) => { jobs.get(id)!.status = 'completed'; live-- }
    const runner = {
      submit: async (args: { talentId: string }) => {
        sent.push(args.talentId)
        live++; most = Math.max(most, live)
        const job = { promptId: 'p-' + args.talentId, status: 'queued' } as GenerationJob
        jobs.set(job.promptId, job)
        return job
      },
      get: (id: string) => jobs.get(id),
    } as unknown as JobRunner
    const queue = new BatchQueue({ stateDir, imagesDir } as Config, new CacheStore({ imagesDir }), runner)
    queue.enqueue(['a', 'b', 'c', 'd', 'e'].map(k => ({ talentId: k, prompt: k })))
    queue.start()
    const settle = () => new Promise(r => setTimeout(r, 150))
    await settle()
    expect(BATCH_IN_FLIGHT).toBe(2)
    expect(sent).toEqual(['a', 'b']) // the next one already waits
    finish('p-a'); await settle()
    expect(sent).toEqual(['a', 'b', 'c']) // refilled as soon as one is done
    expect(queue.status().done).toBe(1)
    queue.pause()
    finish('p-b'); finish('p-c'); await settle()
    expect(sent).toEqual(['a', 'b', 'c']) // paused: nothing new
    expect(queue.status().done).toBe(3) // the sent ones finished
    expect(queue.status().running).toBe(false)
    queue.start(); await settle()
    finish('p-d'); finish('p-e'); await settle()
    expect(sent).toEqual(['a', 'b', 'c', 'd', 'e'])
    expect(most).toBe(2)
    expect(queue.status().done).toBe(5)
  } finally { fs.rmSync(root, { recursive: true, force: true }) }
})
