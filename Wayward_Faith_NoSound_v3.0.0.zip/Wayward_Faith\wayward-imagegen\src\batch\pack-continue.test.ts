import { test, expect } from 'bun:test'
import * as fs from 'node:fs'
import * as os from 'node:os'
import * as path from 'node:path'
import { OutfitPackWriter } from '../cache/outfitPack.ts'
import { CacheStore } from '../cache/cacheStore.ts'
import { BatchQueue } from './queue.ts'
import type { Config } from '../config.ts'
import type { JobRunner } from '../comfy/jobRunner.ts'

test('continue a renamed installed pack using its own ID and existing originals despite changed generation settings',()=>{
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'wf-pack-continue-'))
  try {
    const stateDir=path.join(root,'state'), imagesDir=path.join(root,'global'), imagePacksDir=path.join(root,'image-packs')
    const target={character:'elena',outfit:'basic',name:'ameas'}
    const key='elena__t-i__o-modest__p-bd__v-0'
    // The server registry points to an earlier pack, but the user put a different valid pack here.
    const writer=new OutfitPackWriter(stateDir,imagesDir,{...target,presetName:'IL'},false,imagePacksDir)
    writer.flush()
    const catalogue=path.join(writer.directory,'pack.js'), originalId='elena-basic-existing-original'
    const pack={packFormat:1,packId:originalId,name:'old-name',entries:{[key]:{
      talentName:key,imagePath:'images/kept.webp',imageType:'portrait',promptHash:'old-hash',
    }},wfImagePack:{version:2,character:'elena',basic:true,outfits:['modest','naked','nightshift','wf_rags']}}
    const write=()=>fs.writeFileSync(catalogue,'/* WAYWARD_FAITH_IMAGE_PACK */\n(window.__WF_OUTFIT_PACKS__=window.__WF_OUTFIT_PACKS__||{})['+JSON.stringify(pack.packId)+']='+JSON.stringify(pack)+';\n')
    write();fs.mkdirSync(path.join(writer.directory,'images'),{recursive:true});fs.writeFileSync(path.join(writer.directory,'images/kept.webp'),'original bytes')
    const config={stateDir,imagesDir,imagePacksDir} as Config
    const item={talentId:key,prompt:'changed prompt',presetName:'IL',steps:20,outfitPack:target}
    const enqueue=()=>new BatchQueue(config,new CacheStore({imagesDir}),{} as JobRunner).enqueue([item,{...item,talentId:'elena__new'}])
    const result=enqueue()
    expect(result.alreadyCached).toBe(1);expect(result.accepted).toBe(1)
    const saved=JSON.parse(fs.readFileSync(catalogue,'utf8').match(/\]\s*=\s*(\{[\s\S]*\})\s*;?\s*$/)![1])
    expect(saved.packId).toBe(originalId)
    expect(saved.entries[key].promptHash).toBe('old-hash')
    expect(fs.readFileSync(path.join(writer.directory,'images/kept.webp'),'utf8')).toBe('original bytes')
    // A deleted original really is missing, even if it remains in the catalogue.
    fs.unlinkSync(path.join(writer.directory,'images/kept.webp'))
    expect(enqueue().accepted).toBe(2)
    // A folder with incompatible character metadata must still be rejected.
    pack.wfImagePack.character='mara';write()
    expect(enqueue).toThrow()
  } finally {fs.rmSync(root,{recursive:true,force:true})}
})

test('same pack keeps an original even when its prompt hash changes',()=>{
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'wf-pack-hash-'))
  try {
    const opts={character:'elena',outfit:'basic',name:'ameas'}, key='elena__existing'
    const writer=new OutfitPackWriter(root,path.join(root,'global'),opts)
    fs.mkdirSync(writer.cache.imagesDir,{recursive:true});fs.writeFileSync(path.join(writer.cache.imagesDir,'old.webp'),'keep')
    writer.record(key,{talentName:key,imagePath:'old.webp',imageType:'portrait',promptHash:'old',createdAt:1,prompt:'old'})
    writer.flush()
    expect(writer.get(key,'portrait','new','illustrious')?.imagePath).toBe('old.webp')
  }finally{fs.rmSync(root,{recursive:true,force:true})}
})
