/**
 * Overnight pre-generation.
 *
 * The point of this server is that a player can fill in the pictures their own
 * playthrough will ask for, which takes hours. So the queue lives HERE, not in
 * the browser: they submit a list, close the game, and come back to it done.
 *
 * State is a pair of files per job — the work and the results — so a crash, a
 * reboot, or a closed laptop resumes instead of starting over. That shape is
 * borrowed from the CLI runner that already proved it over multi-day runs.
 */

import * as fs from 'node:fs'
import * as path from 'node:path'
import type { Config, WorkflowType } from '../config.ts'
import type { CacheStore } from '../cache/cacheStore.ts'
import type { JobRunner } from '../comfy/jobRunner.ts'
import { derivePromptHash, sanitizeSamplerName } from '../naming.ts'
import { resolveDimensions } from '../routes/image.ts'
import { knownImageSize, saveKnownImageSizes, sizeMatches } from '../cache/imageSize.ts'
import { OutfitPackError, OutfitPackWriter, packExistingKeys, packKeyAllowed, validateOutfitPackTarget, type OutfitPackTarget } from '../cache/outfitPack.ts'

export interface BatchItem {
  outfitPack?: OutfitPackTarget
  talentId: string
  prompt: string
  negativePrompt?: string
  workflow?: WorkflowType
  imageType?: string
  steps?: number
  cfg?: number
  loraStrength?: number
  clipSkip?: number | null
  modelType?: 'illustrious' | 'anima' | 'nai'
  sampler?: string
  noiseSchedule?: string
  checkpoint?: string
  characterId?: string
  presetName?: string
  styleName?: string
  characterLoras?: { name: string; strength?: number }[]
  textEncoder?: string
  vae?: string
  qualityLoras?: { name: string; strength?: number; clipStrength?: number }[]
  width?: number
  height?: number
  /** How often play is expected to want this. Higher goes first. */
  weight?: number
  /** An image pack needs this one before it can be shared (game: src/faith/image/pack.js wfPackOrder). */
  essential?: boolean
}

/** One pack folder's progress, counting what it already held when queued. */
export interface PackProgress {
  directory: string
  name: string
  total: number
  done: number
  essentialTotal: number
  essentialDone: number
  /**
   * Seconds until this pack's last remaining picture is drawn. The queue runs every pack's essentials before the extras,
   * pack by pack (byQueueOrder), so this counts every unfinished item up to that one. null until there is a rate.
   */
  etaSeconds?: number | null
  /** The pack of the picture being drawn now. */
  current?: boolean
}

export type ItemOutcome = 'completed' | 'cached' | 'error'

interface ResultLine {
  talentId: string
  outcome: ItemOutcome
  at: number
  error?: string
}

export interface BatchStatus {
  packDirectory: string | null
  jobId: string | null
  running: boolean
  paused: boolean
  total: number
  done: number
  completed: number
  cached: number
  errored: number
  currentKey: string | null
  startedAt: number | null
  /** Seconds remaining, from the observed rate. Null until enough has finished. */
  etaSeconds: number | null
  /** Seconds until every essential item is done (they go first). 0 when done, null while unknown. */
  essentialEtaSeconds: number | null
  packs: PackProgress[]
  lastError: string | null
}

/**
 * Consecutive failures that mean something is broken rather than one bad item —
 * ComfyUI gone, out of disk, a wrong checkpoint name. Stopping beats burning
 * hours failing thousands of times.
 */
const CIRCUIT_BREAK_AFTER = 10
/**
 * Batch renders kept in ComfyUI at once. With one, the GPU sat idle while the server collected,
 * saved and converted each finished picture and sent the next (about 0.7s against a 2.6s render).
 * With two the next one is already waiting. Foreground requests still go to the front of
 * ComfyUI's queue (jobRunner submit), so the player waits only for the render in progress.
 */
export const BATCH_IN_FLIGHT = 2

export class BatchQueue {
  private readonly dir: string
  private items: BatchItem[] = []
  private results = new Map<string, ResultLine>()
  private jobId: string | null = null
  private running = false
  private paused = false
  private currentKey: string | null = null
  /** Items submitted and not finished yet (run loop) — oldest first. */
  private inFlight = new Set<string>()
  private startedAt: number | null = null
  private lastError: string | null = null
  private consecutiveFailures = 0
  private stopRequested = false
  private packWriters = new Map<string, OutfitPackWriter>()
  /** Items a pack already held at enqueue time (dropped from the queue but part of its progress). */
  private packCached = new Map<string, { all: number; essential: number }>()
  private doneAtStart = 0
  /** Pack (or "" for plain items) -> the order it first joined this job. */
  private packRank = new Map<string, number>()

  /**
   * Queue order: every essential before any extra; within each, pack by pack in the order the packs were added;
   * within a pack, by weight. A pack added later goes whole after the earlier packs, matching the order of the
   * progress bars (user decision 2026-10-20 — before, its special scenes slipped in among the earlier packs').
   */
  private byQueueOrder = (a: BatchItem, b: BatchItem): number => {
    const rank = (item: BatchItem) => this.packRank.get(this.packKey(item) ?? '') ?? 0
    return Number(!a.essential) - Number(!b.essential) || rank(a) - rank(b) || (b.weight ?? 0) - (a.weight ?? 0)
  }

  private packKey(item: BatchItem): string | undefined {
    return item.outfitPack ? JSON.stringify({ ...item.outfitPack, presetName: item.presetName, styleName: item.styleName }) : undefined
  }

  private packWriter(item: BatchItem): OutfitPackWriter | undefined {
    const key = this.packKey(item)
    if (!key) return undefined
    if (!this.packWriters.has(key)) this.packWriters.set(key, new OutfitPackWriter(this.config.stateDir, this.cache.imagesDir, JSON.parse(key), false, this.config.imagePacksDir))
    return this.packWriters.get(key)
  }

  private syncPack(item: BatchItem): void {
    const writer = this.packWriter(item)
    if (!writer) return
    const entry = this.cached(item)
    if (!entry) throw new Error('Rendered image missing from cache while updating image pack')
    writer.record(item.talentId, entry)
  }

  private cached(item: BatchItem) {
    const writer = this.packWriter(item), cache = writer ?? this.cache
    const hit = cache.get(item.talentId, item.imageType ?? 'portrait', derivePromptHash(item.prompt, item.negativePrompt ?? '', item), item.workflow ?? 'illustrious')
    // Wayward Faith: a pack picture of the wrong size (old 1024x1024 renders) is drawn again; the old file leaves the pack (OutfitPackWriter.retire)
    if (hit && writer && item.width && item.height) {
      const size = knownImageSize(this.config.stateDir, path.join(writer.directory, 'images', hit.imagePath))
      if (size && !sizeMatches(size, item)) { writer.retire(item.talentId); return null }
    }
    return hit
  }

  private flushPacks(): void {
    for (const writer of this.packWriters.values()) writer.flush()
    saveKnownImageSizes(this.config.stateDir)
  }

  constructor(
    private readonly config: Config,
    private readonly cache: CacheStore,
    private readonly jobs: JobRunner,
    private readonly now: () => number = Date.now,
  ) {
    this.dir = path.join(path.resolve(config.stateDir), 'batch')
  }

  private workFile(id: string): string { return path.join(this.dir, `${id}.jsonl`) }
  private resultFile(id: string): string { return path.join(this.dir, `${id}.results.jsonl`) }

  /** Pick up an unfinished job left by a previous run. */
  resume(): this {
    let names: string[]
    try {
      names = fs.readdirSync(this.dir)
    } catch {
      return this
    }
    const jobs = names.filter(n => n.endsWith('.jsonl') && !n.endsWith('.results.jsonl'))
      .map(n => n.replace(/\.jsonl$/, ''))
      .sort()
    const latest = jobs[jobs.length - 1]
    if (!latest) return this

    try {
      this.items = fs.readFileSync(this.workFile(latest), 'utf-8')
        .split('\n').filter(Boolean).map(l => JSON.parse(l) as BatchItem)
      this.jobId = latest
      this.loadResults(latest)
      // Recover the pack's own cache. A deleted distributed file must be rendered again.
      for (const item of this.items) {
        this.packWriter(item)
        if (item.outfitPack) {
          if (this.cached(item)) this.syncPack(item)
          else this.results.delete(item.talentId)
        }
      }
      this.flushPacks()
      const left = this.items.length - this.results.size
      if (left > 0) {
        console.log(`[batch] resuming ${latest}: ${left} of ${this.items.length} left`)
        // Paused on resume: an overnight run that restarts on its own after a
        // crash is a surprise. The operator restarts it.
        this.paused = true
      }
    } catch (err) {
      console.warn('[batch] could not resume:', (err as Error).message)
    }
    return this
  }

  private loadResults(id: string): void {
    this.results.clear()
    try {
      for (const line of fs.readFileSync(this.resultFile(id), 'utf-8').split('\n')) {
        if (!line) continue
        const parsed = JSON.parse(line) as ResultLine
        this.results.set(parsed.talentId, parsed)
      }
    } catch { /* no results yet */ }
  }

  private recordResult(line: ResultLine): void {
    this.results.set(line.talentId, line)
    if (!this.jobId) return
    try {
      fs.mkdirSync(this.dir, { recursive: true })
      fs.appendFileSync(this.resultFile(this.jobId), JSON.stringify(line) + '\n')
    } catch (err) {
      console.error('[batch] could not record result:', (err as Error).message)
    }
  }

  /** Keys a pack already holds (for the maker's plan, before anything is queued). */
  packExisting(target: OutfitPackTarget, size?: { width?: number; height?: number }): string[] {
    return packExistingKeys(this.config.stateDir, target, this.config.imagePacksDir, size)
  }

  /**
   * Accept a list of work.
   *
   * Anything already rendered is dropped here rather than queued and skipped
   * later, so the reported total is the work that will actually happen — an
   * honest number to show a progress bar against.
   */
  enqueue(items: BatchItem[], jobId?: string) {
    for (const item of items) if (item.outfitPack) {
      validateOutfitPackTarget(item.outfitPack)
      if (!packKeyAllowed(item.talentId, item.outfitPack.character, item.outfitPack.outfit)) throw new OutfitPackError('Outfit pack character mismatch')
      // Wayward Faith: image packs are never rendered through NovelAI — thousands of requests would burn Anlas and risk the account (the game's pack maker hides NovelAI presets too)
      if (item.modelType === 'nai') throw new OutfitPackError('Image packs cannot be rendered with NovelAI')
    }
    // The browser uploads one plan in chunks, reusing the first response's ID.
    // A new plan while the current job still has work left is ADDED to it, not swapped in: starting a second
    // pack (or a pre-generation) used to wipe the first one's remaining queue (user report 2026-10-20).
    // Only a finished (or cleared) job is replaced.
    const unfinished = this.jobId !== null && this.items.some(item => !this.results.has(item.talentId))
    if (jobId === undefined && unfinished) jobId = this.jobId!
    const append = jobId !== undefined && jobId === this.jobId
    if (!append) { this.packWriters.clear(); this.packCached.clear(); this.packRank.clear() }
    for (const item of items) {
      const key = this.packKey(item) ?? ''
      if (!this.packRank.has(key)) this.packRank.set(key, this.packRank.size)
    }
    const seen = new Set(append ? this.items.map(item => item.talentId) : [])
    const fresh: BatchItem[] = []
    let alreadyCached = 0

    for (const item of items) {
      if (seen.has(item.talentId)) continue
      seen.add(item.talentId)
      this.packWriter(item)
      if (this.cached(item)) {
        this.syncPack(item)
        alreadyCached++
        const key = this.packKey(item)
        if (key) {
          const c = this.packCached.get(key) ?? { all: 0, essential: 0 }
          c.all++
          if (item.essential) c.essential++
          this.packCached.set(key, c)
        }
        continue
      }
      fresh.push(item)
    }
    this.flushPacks()

    // Highest demand first: an overnight run rarely finishes the whole space,
    // so what it does get through should be what play actually asks for.
    fresh.sort(this.byQueueOrder)

    const id = jobId ?? new Date(this.now()).toISOString().replace(/[:.]/g, '-')
    this.jobId = id
    // Keep the whole job in queue order (byQueueOrder), not just each chunk — also while it runs: the run loop picks the
    // first unfinished item each time (nextItem), so an added pack's essentials go after the earlier essentials, ahead of the earlier extras.
    const resorted = append
    if (append) {
      this.items.push(...fresh)
      if (resorted) this.items.sort(this.byQueueOrder)
    } else {
      this.items = fresh
      this.results.clear()
      this.stopRequested = false
      this.consecutiveFailures = 0
      this.lastError = null
    }

    try {
      fs.mkdirSync(this.dir, { recursive: true })
      const lines = fresh.map(i => JSON.stringify(i)).join('\n') + (fresh.length ? '\n' : '')
      if (resorted) {
        fs.writeFileSync(this.workFile(id), this.items.map(i => JSON.stringify(i)).join('\n') + (this.items.length ? '\n' : ''))
      } else if (append) {
        fs.appendFileSync(this.workFile(id), lines)
      } else {
        fs.writeFileSync(this.workFile(id), lines)
        // A stale results file from a reused id would make everything look done.
        fs.rmSync(this.resultFile(id), { force: true })
      }
    } catch (err) {
      console.error('[batch] could not persist the queue:', (err as Error).message)
    }

    return { accepted: fresh.length, alreadyCached, jobId: id, packDirectory: this.status().packDirectory }
  }

  start(): void {
    this.paused = false
    this.stopRequested = false
    if (this.running) return
    void this.run()
  }

  pause(): void { this.paused = true }

  clear(): void {
    this.stopRequested = true
    this.paused = true
    this.items = []
    this.packWriters.clear()
    this.packCached.clear()
    this.results.clear()
    this.currentKey = null
    this.inFlight.clear()
    if (this.jobId) {
      try {
        fs.rmSync(this.workFile(this.jobId), { force: true })
        fs.rmSync(this.resultFile(this.jobId), { force: true })
      } catch { /* best effort */ }
    }
    this.jobId = null
  }

  status(): BatchStatus {
    const outcomes = [...this.results.values()]
    const completed = outcomes.filter(r => r.outcome === 'completed').length
    const cached = outcomes.filter(r => r.outcome === 'cached').length
    const errored = outcomes.filter(r => r.outcome === 'error').length
    const done = outcomes.length

    let etaSeconds: number | null = null, essentialEtaSeconds: number | null = null, perItem: number | null = null
    const essentialLeft = this.items.filter(i => i.essential && !this.results.has(i.talentId)).length
    // Needs a few items finished in this run before the rate means anything (a resumed job
    // starts with earlier results that took no time now).
    const ran = done - this.doneAtStart
    if (this.running && this.startedAt !== null && ran >= 3 && done < this.items.length) {
      perItem = (this.now() - this.startedAt) / 1000 / ran
      etaSeconds = Math.round(perItem * (this.items.length - done))
      essentialEtaSeconds = Math.round(perItem * essentialLeft)
    }
    if (essentialLeft === 0) essentialEtaSeconds = 0

    const packs = new Map<string, PackProgress>()
    const slot = (key: string) => {
      if (!packs.has(key)) {
        const writer = this.packWriters.get(key)
        packs.set(key, { directory: writer?.result().directory ?? '', name: writer?.name ?? '', total: 0, done: 0, essentialTotal: 0, essentialDone: 0 })
      }
      return packs.get(key)!
    }
    const lastAhead = new Map<string, number>() // pack -> unfinished items up to its last unfinished one (queue order)
    let ahead = 0
    for (const item of this.items) {
      const key = this.packKey(item)
      const unfinished = !this.results.has(item.talentId)
      if (unfinished) ahead++
      if (!key) continue
      const p = slot(key), finished = !!this.results.get(item.talentId) && this.results.get(item.talentId)!.outcome !== 'error'
      p.total++
      if (finished) p.done++
      if (item.essential) { p.essentialTotal++; if (finished) p.essentialDone++ }
      if (unfinished) lastAhead.set(key, ahead)
      if (item.talentId === this.currentKey) p.current = true
    }
    for (const [key, p] of packs) {
      const n = lastAhead.get(key) ?? 0
      p.etaSeconds = n === 0 ? 0 : perItem === null ? null : Math.round(perItem * n)
    }
    for (const [key, c] of this.packCached) {
      const p = slot(key)
      p.total += c.all; p.done += c.all; p.essentialTotal += c.essential; p.essentialDone += c.essential
    }

    return {
      packDirectory: this.packWriters.values().next().value?.result().directory ?? null,
      jobId: this.jobId,
      running: this.running,
      paused: this.paused,
      total: this.items.length,
      done,
      completed,
      cached,
      errored,
      currentKey: this.currentKey,
      startedAt: this.startedAt,
      etaSeconds,
      essentialEtaSeconds,
      packs: [...packs.values()],
      lastError: this.lastError,
    }
  }

  private async run(): Promise<void> {
    this.running = true
    this.startedAt = this.now()
    this.doneAtStart = this.results.size
    // Up to BATCH_IN_FLIGHT items at once, so ComfyUI always has the next one queued.
    // Pausing or stopping stops new submissions; the ones already sent finish first.
    const active = new Set<Promise<void>>()
    try {
      for (;;) {
        while (active.size < BATCH_IN_FLIGHT && !this.stopRequested && !this.paused) {
          const item = this.nextItem()
          if (!item) break
          this.inFlight.add(item.talentId)
          this.currentKey = [...this.inFlight][0] ?? null
          const done: Promise<void> = this.runItem(item).finally(() => {
            this.inFlight.delete(item.talentId)
            this.currentKey = [...this.inFlight][0] ?? null
            active.delete(done)
          })
          active.add(done)
        }
        if (active.size === 0) break
        await Promise.race(active)
      }
    } finally {
      this.running = false
      this.currentKey = null
    }
  }

  /** Render one item and record how it went. Never throws. */
  private async runItem(item: BatchItem): Promise<void> {
    try {
      const outcome = await this.renderOne(item)
      this.syncPack(item)
      this.flushPacks()
      this.recordResult({ talentId: item.talentId, outcome, at: this.now() })
      this.consecutiveFailures = 0
    } catch (err) {
      const message = (err as Error).message
      this.lastError = message
      this.recordResult({ talentId: item.talentId, outcome: 'error', at: this.now(), error: message })
      this.consecutiveFailures++
      if (this.consecutiveFailures >= CIRCUIT_BREAK_AFTER && !this.paused) {
        // Something is broken, not just this item. Stopping beats spending
        // the night failing thousands of times.
        this.paused = true
        this.lastError = `stopped after ${CIRCUIT_BREAK_AFTER} failures in a row: ${message}`
        console.error(`[batch] ${this.lastError}`)
      }
    }
  }

  /** The first item not done yet and not already sent. Read afresh each time: enqueue may add and re-sort while the job runs. */
  private nextItem(): BatchItem | undefined {
    return this.items.find(item => !this.results.has(item.talentId) && !this.inFlight.has(item.talentId))
  }

  private async renderOne(item: BatchItem): Promise<ItemOutcome> {
    const workflow = item.workflow ?? 'illustrious'
    const imageType = item.imageType ?? 'portrait'
    const promptHash = derivePromptHash(item.prompt, item.negativePrompt ?? '', item)

    if (this.cached(item)) return 'cached'

    const job = await this.jobs.submit({
      talentId: item.talentId,
      talentName: item.talentId,
      imageType,
      prompt: item.prompt,
      negativePrompt: item.negativePrompt ?? '',
      workflow,
      promptHash,
      ...(this.packWriter(item) ? { output: { cache: this.packWriter(item)!.cache } } : {}),
      characterId: item.characterId,
      presetName: item.presetName,
      styleName: item.styleName,
      overrides: {
        steps: item.steps,
        cfg: item.cfg,
        loraStrength: item.loraStrength,
        clipSkip: item.clipSkip,
        modelType: item.modelType,
        ...(item.modelType === 'nai' ? {
          sampler: item.sampler,
          noiseSchedule: item.noiseSchedule,
          width: Math.min(item.width ?? 832, item.height ?? 1216),
          height: Math.max(item.width ?? 832, item.height ?? 1216),
        } : {
          // ComfyUI도 게임이 보낸 크기로 (게임 1216x832 = 세로 832x1216 — routes/image.ts와 같은 규칙). 예전에는 넘기지 않아 팩 그림이 워크플로 기본값 1024x1024였다.
          dimensions: resolveDimensions({ width: item.width, height: item.height } as never),
          // 프리셋에서 고른 ComfyUI 샘플러·스케줄러 (없으면 서버 설정, Anima는 euler·simple)
          sampler: sanitizeSamplerName(item.sampler),
          noiseSchedule: sanitizeSamplerName(item.noiseSchedule),
        }),
        checkpoint: item.checkpoint,
        characterLoras: item.characterLoras,
        textEncoder: item.textEncoder,
        vae: item.vae,
        qualityLoras: item.qualityLoras,
        presetName: item.presetName,
        styleName: item.styleName,
      },
      // Always bulk: this must not cancel — or be cancelled by — whatever the
      // player is looking at, and it must not trip the interactive rate caps.
      bulk: true,
    })

    // Wait for the poller to finish it. This only reads the in-memory job, so it
    // checks often: the next item is submitted as soon as this one is done
    // (500ms here plus a 2000ms poller used to leave ComfyUI idle between renders).
    const deadline = this.now() + 15 * 60_000
    while (this.now() < deadline) {
      if (this.stopRequested) throw new Error('cancelled')
      const current = this.jobs.get(job.promptId)
      if (!current) break  // reaped after completing
      if (current.status === 'completed') return 'completed'
      if (current.status === 'error') throw new Error(current.error ?? 'render failed')
      await new Promise(r => setTimeout(r, 100))
    }

    // The job may have completed and been reaped while we waited.
    if (this.cached(item)) return 'completed'
    throw new Error('timed out waiting for the render')
  }
}
