import { test, expect } from 'bun:test'
import * as fs from 'node:fs'
import * as os from 'node:os'
import * as path from 'node:path'
import { buildOutfitPack, type ExportDeps } from './export.ts'
import { OutfitPackWriter } from '../cache/outfitPack.ts'

const readPack = (folder: string) => {
  const source = fs.readFileSync(path.join(folder, 'pack.js'), 'utf8')
  expect(source.startsWith('/* WAYWARD_FAITH_IMAGE_PACK */')).toBe(true)
  return JSON.parse(source.match(/\]\s*=\s*(\{[\s\S]*\})\s*;?\s*$/)![1])
}

test('exports one outfit in the chosen style, including reloadable catalogue and missing count', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-outfit-pack-'))
  try {
    const imagesDir = path.join(root, 'source')
    const selected = 'il/default/characters/elena/a.png', different = 'other/default/characters/elena/b.png'
    for (const p of [selected, different]) {
      fs.mkdirSync(path.dirname(path.join(imagesDir, p)), { recursive: true })
      fs.writeFileSync(path.join(imagesDir, p), p)
    }
    const key = 'elena__t-i__o-serving_dress__p-bd__v-0'
    const deps = { config: { stateDir: root }, cache: {
      imagesDir, entries: {
        a: { imagePath: selected, talentName: key, createdAt: 1 },
        b: { imagePath: different, talentName: key, createdAt: 2 },
      }, existingImagePaths: () => new Set([selected, different]),
    } } as unknown as ExportDeps
    const result = buildOutfitPack(deps, { character: 'elena', outfit: 'serving_dress', keys: [key, key, 'elena__missing'], presetName: 'IL', styleName: 'default' })
    expect(result.images).toBe(1)
    expect(result.missing).toBe(1)
    expect(result.directory).toBe(path.join('image-packs','elena-serving_dress-elena','outfits', 'serving_dress'))
    const folder = path.join(root, result.directory)
    const pack = readPack(folder)
    expect(pack.wfImagePack.version).toBe(2)
    expect(pack.wfImagePack.outfits).toEqual(['serving_dress'])
    expect(pack.entries[key].imagePath.startsWith('images/')).toBe(true)
    expect(fs.readFileSync(path.join(folder, pack.entries[key].imagePath), 'utf8')).toBe(selected)
    expect(fs.existsSync(path.join(folder, 'pack.json'))).toBe(false)
    const opts = { character: 'elena', outfit: 'serving_dress', keys: [key], name: 'Elena A' }
    const a = buildOutfitPack(deps, opts), again = buildOutfitPack(deps, opts)
    expect(again.packId).toBe(a.packId)
    const b = buildOutfitPack(deps, { ...opts, name: 'Elena B' })
    expect(b.packId).not.toBe(a.packId)
    expect(a.directory).toBe(path.join('image-packs','Elena A-elena','outfits', 'serving_dress'))
    expect(b.directory).toBe(path.join('image-packs','Elena B-elena','outfits', 'serving_dress'))
    expect(readPack(path.join(root, a.directory)).name).toBe('Elena A')
    expect(readPack(path.join(root, b.directory)).name).toBe('Elena B')
    const other = buildOutfitPack({ ...deps, config: { ...deps.config, stateDir: path.join(root, 'other-producer') } }, opts)
    expect(other.packId).not.toBe(a.packId)
    expect(() => buildOutfitPack(deps, { character: '../bad', outfit: 'basic', keys: [] })).toThrow()
    expect(() => buildOutfitPack(deps, { character: 'elena', outfit: 'basic', keys: ['mara__other'] })).toThrow()
  } finally { fs.rmSync(root, { recursive: true, force: true }) }
})

test('named pack folders preserve legacy packs and reject collisions and invalid names',()=>{
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'wf-pack-names-'))
  try{
    const opts={character:'mara',outfit:'basic',name:'마라 기본팩 A'}
    const writer=new OutfitPackWriter(root,path.join(root,'cache'),opts)
    writer.flush()
    const old=path.join(root,'outfit-packs',writer.packId)
    fs.mkdirSync(path.dirname(old),{recursive:true})
    fs.renameSync(writer.directory,old)
    const restored=new OutfitPackWriter(root,path.join(root,'cache'),opts)
    expect(restored.packId).toBe(writer.packId)
    expect(fs.existsSync(path.join(restored.directory,'pack.js'))).toBe(true)
    expect(fs.existsSync(old)).toBe(false)
    expect(path.relative(path.join(root,'image-packs'),restored.directory)).toBe(path.join(opts.name+'-mara','base'))
    const nameOnly=path.join(root,'outfit-packs',opts.name)
    fs.renameSync(restored.directory,nameOnly)
    const fromName=new OutfitPackWriter(root,path.join(root,'cache'),opts)
    expect(fromName.packId).toBe(writer.packId)
    expect(fs.existsSync(path.join(fromName.directory,'pack.js'))).toBe(true)
    expect(fs.existsSync(nameOnly)).toBe(false)
    const formerRoot=path.join(root,'outfit-packs',opts.name+'-mara-basic') // 예전 바탕 폴더의 예전(한 단계) 이름
    fs.mkdirSync(path.join(fromName.directory,'images'),{recursive:true})
    fs.writeFileSync(path.join(fromName.directory,'images','original.png'),'original')
    fs.renameSync(fromName.directory,formerRoot)
    const fromOldRoot=new OutfitPackWriter(root,path.join(root,'cache'),opts)
    expect(fromOldRoot.result().directory).toBe(path.join('image-packs',opts.name+'-mara','base'))
    expect(fs.readFileSync(path.join(fromOldRoot.directory,'images','original.png'),'utf8')).toBe('original')
    expect(fs.existsSync(formerRoot)).toBe(false)
    const elena=new OutfitPackWriter(root,'cache',{...opts,character:'elena'})
    expect(path.relative(path.join(root,'image-packs'),elena.directory)).toBe(path.join(opts.name+'-elena','base'))
    const outfit=new OutfitPackWriter(root,'cache',{...opts,outfit:'serving_dress'})
    expect(path.relative(path.join(root,'image-packs'),outfit.directory)).toBe(path.join(opts.name+'-mara','outfits', 'serving_dress'))
    expect(new OutfitPackWriter(root,'cache',{...opts,presetName:'different'}).packId).toBe(fromOldRoot.packId)
    for(const name of ['../bad','bad/name','bad\\name','NUL','pack.'])
      expect(()=>new OutfitPackWriter(root,'cache',{...opts,name})).toThrow()
  }finally{fs.rmSync(root,{recursive:true,force:true})}
})
