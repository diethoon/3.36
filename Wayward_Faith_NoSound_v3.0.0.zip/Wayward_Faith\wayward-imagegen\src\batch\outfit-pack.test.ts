import { test, expect } from 'bun:test'
import { BatchQueue, type BatchItem } from './queue.ts'
import type { Config } from '../config.ts'
import type { CacheStore } from '../cache/cacheStore.ts'
import type { JobRunner, SubmitArgs } from '../comfy/jobRunner.ts'

test('outfit batch forwards character LoRAs and storage identity to the renderer', async () => {
  let submitted: SubmitArgs | undefined
  const jobs = {
    submit: async (args: SubmitArgs) => { submitted = args; return { promptId: 'pack-test' } },
    get: () => ({ status: 'completed' }),
  } as unknown as JobRunner
  const queue = new BatchQueue({ stateDir: '.' } as Config, { get: () => null } as unknown as CacheStore, jobs)
  const run = queue as unknown as { renderOne(item: BatchItem): Promise<string> }
  await run.renderOne({ talentId: 'elena__test', prompt: 'habit', characterId: 'elena', presetName: 'IL', styleName: 'ink', characterLoras: [{ name: 'hero.safetensors', strength: 0.7 }] })
  expect(submitted?.characterId).toBe('elena')
  expect(submitted?.presetName).toBe('IL')
  expect(submitted?.styleName).toBe('ink')
  expect(submitted?.overrides?.characterLoras?.[0].strength).toBe(0.7)
  expect(submitted?.bulk).toBe(true)
  await run.renderOne({ talentId: 'elena__nai', prompt: 'habit', modelType: 'nai', checkpoint: 'nai-diffusion-4-5-full', sampler: 'k_euler', noiseSchedule: 'native', width: 1216, height: 832 })
  expect(submitted?.overrides?.modelType).toBe('nai')
  expect(submitted?.overrides?.sampler).toBe('k_euler')
  expect(submitted?.overrides?.noiseSchedule).toBe('native')
  expect(submitted?.overrides?.width).toBe(832)
  expect(submitted?.overrides?.height).toBe(1216)
  // ComfyUI도 게임이 보낸 크기로 (세로 832x1216). 예전에는 넘기지 않아 팩 그림이 1024x1024였다
  await run.renderOne({ talentId: 'elena__comfy', prompt: 'habit', width: 1216, height: 832 })
  expect(submitted?.overrides?.dimensions).toBe('1216 x 832 (1.46:1)')
})

// Wayward Faith: image packs are never rendered through NovelAI (the game's pack maker hides those presets too)
test('an image pack item with a NovelAI preset is refused', () => {
  const jobs = { submit: async () => ({ promptId: 'x' }), get: () => ({ status: 'completed' }) } as unknown as JobRunner
  const queue = new BatchQueue({ stateDir: '.' } as Config, { get: () => null } as unknown as CacheStore, jobs)
  const outfitPack = { character: 'elena', outfit: 'basic', name: 'faith' }
  expect(() => queue.enqueue([{ talentId: 'elena__t-i__o-modest__p-bd__v-0', prompt: 'habit', modelType: 'nai', outfitPack }])).toThrow(/NovelAI/)
  expect(() => queue.enqueue([{ talentId: 'mara__t-i__o-modest__p-bd__v-0', prompt: 'habit', outfitPack }])).toThrow(/character mismatch/)
})
