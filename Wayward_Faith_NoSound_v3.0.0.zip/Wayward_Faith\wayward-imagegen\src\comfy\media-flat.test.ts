import { test, expect } from 'bun:test'
import * as fs from 'node:fs'
import * as os from 'node:os'
import * as path from 'node:path'
import { saveImage } from './media.ts'

// An image pack's own folder keeps files directly in images/ (jobRunner passes flat for pack outputs).
test('pack images are saved flat, shared-cache images keep preset/style folders', async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-media-flat-'))
  try {
    const base = { bytes: Buffer.from('png'), talentName: 'elena__t-i__o-modest__p-bd__v-0', imageType: 'portrait', workflow: 'illustrious' as const, characters: [], presetName: 'IL', styleName: 'soft', now: () => 1 }
    const flat = await saveImage({ ...base, imagesDir: path.join(root, 'pack'), flat: true })
    expect(flat.relativePath.includes('/')).toBe(false)
    const shared = await saveImage({ ...base, imagesDir: path.join(root, 'shared') })
    expect(shared.relativePath.startsWith('il/soft/characters/')).toBe(true)
  } finally { fs.rmSync(root, { recursive: true, force: true }) }
})
