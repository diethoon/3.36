import { test, expect } from 'bun:test'
import * as fs from 'node:fs'
import * as os from 'node:os'
import * as path from 'node:path'
import { OutfitPackWriter, packExistingKeys } from './outfitPack.ts'

const write = (dir: string, packId: string, entries: Record<string, { imagePath: string }>) => {
  fs.mkdirSync(path.join(dir, 'images'), { recursive: true })
  for (const e of Object.values(entries)) fs.writeFileSync(path.join(dir, e.imagePath), 'art')
  const pack = { packFormat: 1, packId, name: 'n', entries, wfImagePack: { version: 2, character: 'elena', basic: true, outfits: ['modest'] } }
  fs.writeFileSync(path.join(dir, 'pack.js'), `/* WAYWARD_FAITH_IMAGE_PACK */\n(window.__WF_OUTFIT_PACKS__=window.__WF_OUTFIT_PACKS__||{})[${JSON.stringify(packId)}]=${JSON.stringify(pack)};\n`)
}

test('the maker counts what a pack already holds without making a folder', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-pack-existing-'))
  try {
    const state = path.join(root, 'state'), packs = path.join(root, 'image-packs')
    write(path.join(packs, 'ameas-elena', 'base'), 'elena-basic-a', { elena__a: { imagePath: 'images/a.webp' }, elena__b: { imagePath: 'images/missing.webp' } })
    fs.unlinkSync(path.join(packs, 'ameas-elena', 'base', 'images', 'missing.webp'))
    expect(packExistingKeys(state, { character: 'elena', outfit: 'basic', name: 'ameas' }, packs)).toEqual(['elena__a'])
    expect(packExistingKeys(state, { character: 'elena', outfit: 'basic', name: 'other' }, packs)).toEqual([])
    expect(fs.existsSync(path.join(packs, 'other-elena'))).toBe(false)
  } finally { fs.rmSync(root, { recursive: true, force: true }) }
})

test('an empty folder of the new name gives way to the earlier folder of the same pack', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-pack-legacy-'))
  try {
    const state = path.join(root, 'state'), packs = path.join(root, 'image-packs'), id = 'elena-basic-old'
    write(path.join(packs, id), id, { elena__a: { imagePath: 'images/a.webp' } })
    // An earlier run left the new folder with an empty catalogue of the same ID.
    write(path.join(packs, 'mine-elena', 'base'), id, {})
    fs.rmSync(path.join(packs, 'mine-elena', 'base', 'images'), { recursive: true })
    const target = { character: 'elena', outfit: 'basic', name: 'mine' }
    expect(packExistingKeys(state, target, packs)).toEqual(['elena__a'])
    const writer = new OutfitPackWriter(state, path.join(root, 'global'), target, false, packs)
    expect(writer.packId).toBe(id)
    expect(fs.existsSync(path.join(packs, id))).toBe(false)
    expect(writer.get('elena__a', 'portrait', 'any', 'illustrious')?.imagePath).toBe('a.webp')
    // A folder that holds art is never replaced.
    write(path.join(packs, 'keep-elena', 'base'), 'elena-basic-keep', { elena__k: { imagePath: 'images/k.webp' } })
    write(path.join(packs, 'elena-basic-keep2'), 'elena-basic-keep', { elena__z: { imagePath: 'images/z.webp' } })
    const kept = new OutfitPackWriter(state, path.join(root, 'global'), { ...target, name: 'keep' }, false, packs)
    expect(kept.get('elena__k', 'portrait', 'any', 'illustrious')).not.toBeNull()
  } finally { fs.rmSync(root, { recursive: true, force: true }) }
})
