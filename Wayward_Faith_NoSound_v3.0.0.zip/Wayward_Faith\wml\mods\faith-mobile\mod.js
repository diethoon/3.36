// Faith 모바일 화면 — 폰(가로 1024px 미만)에서 Faith 화면을 새로 배치해요.
// Faith의 폰 배치는 행동 버튼을 좁은 옆 칸에 두고, PC 화면의 일부(초상화·성직자·교단 메뉴, PC용 예배당 통계, 행동 설명,
// 당신 상태)를 빼요. 이 모드는 게임 배치 함수(mainLayout)가 PC용으로 이미 만든 패널을 가져다
// 폰 배치에 넣고(게임 코드는 그대로), 상단 줄에 "당신" 상태를 붙이고, 길게 누르면 마우스용 설명(title)을 보여 줘요.
// ("방문객이 올 때까지" 버튼도 폰에서 숨지만, Faith 2.4.1은 방문객 기능이 꺼져 있어 PC에서도 나오지 않아요.)
WML.define({
  id: 'faith-mobile',
  name: { ko: 'Faith 모바일 화면', en: 'Faith mobile view' },
  version: '1.0.1',
  game: 'faith',
  author: 'WML',
  tags: ['util'],
  description: {
    ko: '폰에서 행동·이야기·예배당·성직자 화면을 한 칸씩 넓게 보여 줘요. PC 화면에만 있던 초상화·성직자·교단 메뉴, 예배당 통계, 행동 설명, 당신 상태도 폰에서 써요. 길게 누르면 설명이 떠요.',
    en: 'On a phone, actions, story, chapel and follower screens each get the full width. The PC-only parts (portrait/follower/cult menu, chapel stats, action descriptions, your status) work on the phone too. Long-press shows hover hints.',
  },
  symbols: {
    "mainLayout": {"raw":{"faith-2.4.1":"AOe","faith-2.4.2":"AOe","faith-2.4.3":"AOe"},"find":{"all":[".actionPanelSide"],"len":2864,"any":["actionPanelSide:","\"story\"","\"house\"","story:","house:","\"pane\""]},"doc":"게임 화면 배치 (PC 패널 + 폰 배치)"},
    "topBar": {"raw":{"faith-2.4.1":"kMe","faith-2.4.2":"kMe","faith-2.4.3":"kMe"},"find":{"all":["readouts:","#380"],"len":7414,"any":["#320","plain:","readout:",".robes","tavernCleanliness:","\"below\""]},"doc":"상단 상태 줄 (폰 줄 + PC 줄)"},
    "villageRow": {"raw":{"faith-2.4.1":"wfVillageWithSides","faith-2.4.2":"wfVillageWithSides","faith-2.4.3":"wfVillageWithSides"},"find":{"all":["side:","\"alley\""],"len":284,"any":["\"barn\"",".jsxs","\"div\"","className:","children:",".jsx"]},"doc":"마을 외출 줄 (선술집·헛간·마을·뒷골목·가게)"}
  },

  setup(api) {
    const RT = api.fn('jsx');
    const React = api.fn('React');
    const useStore = api.fn('store');
    const T = (ko, en) => api.t({ ko, en });

    // settings (this browser)
    const SIZES = { large: '45vh', medium: '34vh', small: '22vh', off: '0' };
    const DEFAULTS = { portrait: 'medium', descriptions: true, longPress: true, you: true };
    const opts = () => api.settings.get(DEFAULTS);
    const listeners = new Set();
    const setOpts = patch => { api.settings.set(patch); applyRootFlags(); listeners.forEach(fn => fn()); };

    // ---------------------------------------------------------------- element helpers
    const isEl = x => !!x && typeof x === 'object' && !!x.$$typeof && !!x.props;
    const kids = el => { const c = isEl(el) ? el.props.children : null; return c == null ? [] : Array.isArray(c) ? c : [c]; };
    const cls = x => (isEl(x) && typeof x.props.className === 'string' ? x.props.className : '');
    const withKids = (el, children) => (Array.isArray(children) ? RT.jsxs : RT.jsx)(el.type, { ...el.props, children }, el.key ?? undefined);
    let warned = false;
    const warnOnce = msg => { if (!warned) { warned = true; console.warn(`[faith-mobile] ${msg} — Faith 원래 폰 화면으로 둬요`); } };

    // ---------------------------------------------------------------- the phone layout
    let lastTab = 'actions';
    const tabClass = on => `flex-1 py-3 min-h-[44px] text-[0.6rem] uppercase tracking-widest border-r last:border-r-0 border-stone-700 ${on ? 'text-amber-300 shadow-[inset_0_2px_0_theme(colors.amber.400)]' : 'text-stone-500'}`;

    // what the last action did (this turn's story lines), so the actions tab shows the result without switching tabs
    const faithFn = name => { try { const f = api.fn(name); return typeof f === 'function' ? f : null; } catch { return null; } };
    const speechView = faithFn('wfLogSpeechView'), actionBadge = faithFn('wfLogActionBadge');
    function LastTurn({ onMore }) {
      const log = useStore(s => s.state.log);
      const seq = useStore(s => s.lastTurnSeq);
      const near = api.fn('settingsStore')(s => s.proximityMode);
      if (!seq || !Array.isArray(log)) return null;
      const items = log.filter(e => e && e.seq != null && e.seq >= seq && (!near || e.coLocated !== false)).slice(-4);
      if (!items.length) return null;
      return RT.jsxs('div', {
        className: 'shrink-0 mb-2 rounded border border-stone-800 bg-stone-900/60 px-2 py-1',
        children: [
          ...items.map((e, i) => RT.jsxs('div', {
            className: `py-0.5 leading-snug ${e.important ? 'text-amber-100' : 'text-stone-300'}`,
            children: [actionBadge ? actionBadge(e) : null, speechView ? speechView(e.text) : e.text],
          }, e.seq ?? i)),
          RT.jsx('button', { type: 'button', onClick: onMore, className: 'py-1 text-[0.65rem] text-stone-500', children: T('이야기 전체 ›', 'Full story ›') }, 'more'),
        ],
      });
    }

    function FaithMobile(p) {
      const [tab, setTab] = React.useState(lastTab);
      const [, redraw] = React.useReducer(x => x + 1, 0);
      React.useEffect(() => { listeners.add(redraw); return () => listeners.delete(redraw); }, []);
      const o = opts();
      const keys = ['actions', ...p.tabs.map(t => t.key).filter(k => ['story', 'house', 'focus'].includes(k))];
      const cur = keys.includes(tab) ? tab : 'actions';
      lastTab = cur;
      const label = k => (k === 'actions' ? T('행동', 'Actions') : (p.tabs.find(t => t.key === k) || {}).label);
      const fill = 'flex-1 min-h-0 overflow-y-auto flex flex-col p-2 text-[0.8rem]';
      const body = {
        actions: RT.jsxs('div', { className: fill, 'data-fm-body': '', children: [RT.jsx(LastTurn, { onMore: () => setTab('story') }), p.recent, RT.jsx('div', { className: 'flex-1 min-h-0 flex flex-col', children: p.actions })] }),
        story: RT.jsx('div', { className: 'flex-1 min-h-0 overflow-y-auto p-2 text-[0.8rem]', 'data-fm-body': '', children: p.story }),
        house: RT.jsx('div', { className: fill, 'data-fm-body': '', children: p.house }),
        focus: RT.jsx('div', { className: 'flex-1 min-h-0 overflow-y-auto text-[0.8rem]', 'data-fm-body': '', children: p.focus }),
      }[cur];
      // the follower tab has its own portrait (초상화 menu), so the strip on top is left out there
      const strip = p.portrait && cur !== 'focus' && o.portrait !== 'off';
      return RT.jsxs(RT.Fragment, {
        children: [
          strip && RT.jsx('div', { className: 'shrink-0 border-b border-stone-700', 'data-fm-portrait': '', style: { '--fm-portrait': SIZES[o.portrait] || SIZES.medium }, children: p.portrait }, 'strip'),
          RT.jsx(React.Fragment, { children: body }, cur),
          RT.jsxs('div', {
            className: 'flex shrink-0 border-t border-stone-700 bg-stone-800/80',
            'data-fm-tabs': '',
            children: [
              ...keys.map(k => RT.jsx('button', { type: 'button', onClick: () => setTab(k), className: tabClass(k === cur), children: label(k) }, k)),
              p.portrait && RT.jsx('button', {
                type: 'button',
                title: T('초상화 보이기·숨기기', 'Show or hide the portrait'),
                'aria-label': T('초상화 보이기·숨기기', 'Show or hide the portrait'),
                onClick: () => setOpts({ portrait: o.portrait === 'off' ? (o.lastSize || 'medium') : 'off', lastSize: o.portrait === 'off' ? o.lastSize : o.portrait }),
                className: `shrink-0 px-3 min-h-[44px] text-base border-l border-stone-700 ${o.portrait === 'off' ? 'text-stone-600' : 'text-stone-400'}`,
                children: '🖼',
              }, 'pic'),
            ],
          }, 'tabs'),
        ],
      });
    }

    // Faith's layout = shell > column > [PC panes (hidden below 1024px), phone layout (hidden from 1024px)].
    // The PC panes are built every time, so their parts are taken from there; the phone part is replaced.
    function phoneLayout(el) {
      const col = kids(el).find(isEl);
      const parts = kids(col);
      const desk = parts.find(k => cls(k).includes('hidden lg:flex'));
      const mob = parts.find(k => cls(k).includes('lg:hidden'));
      const panesEl = kids(desk).find(k => isEl(k) && k.props.panes);
      const panes = panesEl && panesEl.props.panes;
      if (!mob || !panes || !panes.actions || !panes.house || !panes.focus || !isEl(panes.focus.body)) return warnOnce('PC 패널을 찾지 못했어요'), null;
      const main = kids(mob).find(k => isEl(k) && cls(k).includes('flex-col'));
      const mainKids = kids(main);
      const top = mainKids.find(k => isEl(k) && cls(k).includes('shrink-0 border-b'));     // missing while her portrait is hidden (distance mode)
      const content = mainKids.find(k => isEl(k) && cls(k).includes('overflow-y-auto'));
      const bar = mainKids.find(k => isEl(k) && cls(k).includes('border-t'));
      const story = kids(content).find(k => isEl(k) && k.type === RT.Fragment);
      const tabs = kids(bar).filter(isEl).map(b => ({ key: b.key, label: b.props.children }));
      if (!content || !story || !tabs.length) return warnOnce('폰 화면 구조가 달라요'), null;
      const focus = panes.focus.body;
      const view = RT.jsx(FaithMobile, {
        portrait: top ? kids(top).find(isEl) || null : null,
        recent: kids(story).find(isEl) || null,
        story,
        house: panes.house.body,
        actions: panes.actions.body,
        focus: RT.jsx(focus.type, { ...focus.props, stats: true }, focus.key ?? undefined),
        tabs,
      });
      const phone = RT.jsx('div', { className: 'lg:hidden flex-1 flex flex-col min-h-0', 'data-faith-mobile': '', children: view }, mob.key ?? undefined);
      return withKids(el, withKids(col, parts.map(k => (k === mob ? phone : k))));
    }

    api.hook('mainLayout', {
      around(next, ...args) {
        const el = next(...args);
        return phoneLayout(el) || el;
      },
    });

    // ---------------------------------------------------------------- top bar: "you" on the phone line
    function YouEnergy() {
      const e = useStore(s => s.state.player.stats.energy);
      const v = Math.round(e);
      return RT.jsxs('span', { className: 'tabular-nums', children: [RT.jsx('span', { className: 'text-stone-500', children: T('기력 ', 'Energy ') }), RT.jsx('span', { className: v < 30 ? 'text-red-400' : v < 60 ? 'text-amber-400' : 'text-green-400', children: v })] });
    }
    api.hook('topBar', {
      around(next, ...args) {
        const el = next(...args);
        if (!opts().you) return el;
        const parts = kids(el);
        const mob = parts.find(k => cls(k).includes('desk:hidden'));
        const desk = parts.find(k => cls(k).includes('hidden desk:flex'));
        const you = kids(desk).filter(k => isEl(k) && isEl(k.props.content)).pop();     // the last tip: you (energy, fatigue, health …)
        const rows = kids(mob);
        const row = rows[1];
        if (!mob || !you || !isEl(row)) return warnOnce('상단 줄 구조가 달라요'), el;
        const rowKids = kids(row);
        const chip = RT.jsx(you.type, { ...you.props, className: 'shrink-0', children: RT.jsxs('span', { className: 'flex items-baseline gap-x-1.5', children: [rowKids[0], RT.jsx(YouEnergy, {})] }) }, 'fm-you');
        return withKids(el, parts.map(k => (k === mob ? withKids(mob, rows.map(r => (r === row ? withKids(row, [chip, ...rowKids.slice(1)]) : r))) : k)));
      },
    });

    // ---------------------------------------------------------------- the village row (any width)
    // [tavern][barn][village][alley][shop] is one row that never wraps: in a narrow chapel pane (a phone held sideways
    // shows the PC layout, about 200px for that pane) the village cell shrinks to nothing and its text stacks letter by
    // letter. The row may wrap, and the village cell keeps the width of a side tile.
    api.hook('villageRow', {
      around(next, ...args) {
        const el = next(...args);
        if (!isEl(el) || !cls(el).includes('flex')) return el;
        const parts = kids(el).map(k => (isEl(k) && cls(k).includes('flex-1')
          ? RT.jsx(k.type, { ...k.props, style: { ...(k.props.style || {}), minWidth: '4.5rem' } }, k.key ?? undefined) : k));
        return RT.jsxs(el.type, { ...el.props, className: `${el.props.className} flex-wrap`, children: parts }, el.key ?? undefined);
      },
    });

    // ---------------------------------------------------------------- styles
    const style = document.createElement('style');
    style.setAttribute('data-wml-ui', '');
    style.textContent = `
@media (max-width:1023px){
  html.fm-desc [data-faith-mobile] .hidden.desk\\:block{display:block}
  html.fm-desc [data-faith-mobile] .hidden.desk\\:flex{display:flex}
  [data-fm-portrait] .max-h-\\[45vh\\],[data-fm-portrait] .wf-art{max-height:var(--fm-portrait,45vh)!important}
  [data-faith-mobile] [data-fm-body]{padding-bottom:calc(var(--fm-dock,0px) + .5rem)!important;overflow-x:hidden}
}
html.fm-lp [title]{-webkit-touch-callout:none;-webkit-user-select:none;user-select:none}
.fm-tip{position:fixed;z-index:2147483060;max-width:min(320px,calc(100vw - 16px));padding:8px 10px;border-radius:8px;border:1px solid #57534e;
  background:#1c1917;color:#e7e5e4;font-size:.8rem;line-height:1.4;box-shadow:0 8px 24px rgba(0,0,0,.6);pointer-events:none;white-space:pre-line}`;
    document.head.appendChild(style);
    function applyRootFlags() {
      const o = opts();
      document.documentElement.classList.toggle('fm-desc', !!o.descriptions);
      document.documentElement.classList.toggle('fm-lp', !!o.longPress);
    }
    applyRootFlags();

    // the WML button bar sits at the bottom left, just above the tabs: leave that much room under each tab's content
    // so its last lines can be scrolled out from under the bar (a bar the player moved elsewhere needs none)
    let dockRoom = -1;
    setInterval(() => {
      const fm = document.querySelector('[data-faith-mobile]');
      const bar = fm && fm.querySelector('[data-fm-tabs]');
      const dock = document.getElementById('wml-dock');
      let room = 0;
      if (bar && dock && !dock.dataset.wmlMoved) {
        const r = dock.getBoundingClientRect();
        if (r.height) room = Math.max(0, Math.round(bar.getBoundingClientRect().top - r.top));
      }
      if (room !== dockRoom) { dockRoom = room; document.documentElement.style.setProperty('--fm-dock', `${room}px`); }
    }, 1000);

    // ---------------------------------------------------------------- long-press: the hover hint (title) on a touch screen
    (() => {
      let timer = null, sx = 0, sy = 0, tip = null, swallowUntil = 0;
      const hide = () => { if (tip) { tip.remove(); tip = null; } };
      const cancel = () => { clearTimeout(timer); timer = null; };
      const show = (text, x, y) => {
        hide();
        tip = api.ui.h('div', { class: 'fm-tip', 'data-wml-ui': '' }, text);
        document.body.appendChild(tip);
        const r = tip.getBoundingClientRect();
        const left = Math.max(8, Math.min(x - r.width / 2, window.innerWidth - r.width - 8));
        const top = y - r.height - 24 >= 8 ? y - r.height - 24 : Math.min(y + 24, window.innerHeight - r.height - 8);
        tip.style.left = `${left}px`;
        tip.style.top = `${top}px`;
      };
      document.addEventListener('pointerdown', e => {
        hide(); cancel();
        if (e.pointerType !== 'touch' || !opts().longPress) return;
        const t = e.target && e.target.closest && e.target.closest('[title]');
        if (!t || t.closest('.wml-ui, [data-wml-ui]')) return;
        const text = (t.getAttribute('title') || '').trim();
        if (!text) return;
        sx = e.clientX; sy = e.clientY;
        timer = setTimeout(() => {
          timer = null;
          try { window.getSelection().removeAllRanges(); } catch { /* nothing selected */ }
          show(text, sx, sy);
          swallowUntil = Date.now() + 1200;
        }, 450);
      }, true);
      document.addEventListener('selectstart', e => { if (timer || tip) e.preventDefault(); }, true);
      document.addEventListener('pointermove', e => { if (timer && Math.hypot(e.clientX - sx, e.clientY - sy) > 10) cancel(); }, true);
      document.addEventListener('pointerup', cancel, true);
      document.addEventListener('pointercancel', cancel, true);
      document.addEventListener('scroll', () => { cancel(); hide(); }, true);
      // the press that showed a hint is not also a tap on that button
      document.addEventListener('click', e => { if (Date.now() < swallowUntil) { swallowUntil = 0; e.preventDefault(); e.stopPropagation(); } }, true);
      document.addEventListener('contextmenu', e => { if (tip || Date.now() < swallowUntil) e.preventDefault(); }, true);
    })();

    // ---------------------------------------------------------------- settings
    const settings = body => {
      const { h } = api.ui;
      const o = opts();
      const sel = h('select', { onchange: e => setOpts({ portrait: e.target.value }) },
        ...[['large', T('크게', 'Large')], ['medium', T('보통', 'Medium')], ['small', T('작게', 'Small')], ['off', T('숨김', 'Hidden')]].map(([v, t]) => h('option', { value: v }, t)));
      sel.value = o.portrait;
      const check = (key, label) => {
        const cb = h('input', { type: 'checkbox', onchange: e => setOpts({ [key]: e.target.checked }) });
        cb.checked = !!o[key];
        return h('label', { style: 'display:flex;gap:8px;align-items:center;margin:6px 0;cursor:pointer' }, cb, label);
      };
      body.append(
        h('label', { style: 'display:flex;gap:8px;align-items:center;margin:6px 0' }, T('초상화 크기', 'Portrait size'), sel),
        check('descriptions', T('행동 설명·숨은 버튼 보이기', 'Show action descriptions and hidden buttons')),
        check('you', T('상단 줄에 당신 상태', 'Your status on the top line')),
        check('longPress', T('길게 눌러 설명 보기', 'Long-press for hints')),
      );
    };
    api.ui.settings(settings);
    api.ui.pauseSettings?.({ label: { ko: '모바일 화면 설정', en: 'Mobile view settings' } });
  },
});
