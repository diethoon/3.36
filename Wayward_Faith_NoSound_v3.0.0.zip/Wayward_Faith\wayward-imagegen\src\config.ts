/**
 * Configuration — the one place that resolves settings.
 *
 * Precedence: CLI flags > environment > config file > defaults.
 *
 * Ordinary art lives under `imagesDir`; distributable packs live beside the game.
 * Nothing
 * here reads `process.cwd()` implicitly — the caller decides.
 */

import * as path from 'node:path'
import * as fs from 'node:fs'

export type WorkflowType = 'z-image' | 'illustrious'

export interface Config {
  /** Interface to bind. Loopback unless the operator explicitly opts out. */
  host: string
  port: number
  /** Root of the art library. Holds `.image-cache.json` and `<checkpoint-preset>/<style-preset>/characters/...`. */
  imagesDir: string
  /** Distributable packs, beside the game's index.html by default. */
  imagePacksDir?: string
  /** Where per-run state lives (hits, batch queues, miss log). */
  stateDir: string
  /** Base URL of the ComfyUI instance. */
  comfyUrl: string
  /** Wan i2v workflow JSON. Video routes 501 without it rather than crashing. */
  wanWorkflowPath: string | null

  /**
   * Origins allowed to call the API, beyond the always-allowed loopback set.
   *
   * Deliberately not `*`: this server writes files and commands a GPU, and
   * Chrome's Local Network Access explicitly exempts `file://` pages, so the
   * browser will not stop a hostile local page on our behalf.
   */
  allowedOrigins: string[]

  /** `DELETE /api/image/delete` is off unless the operator asks for it. */
  allowDelete: boolean

  /** Refuse new writes once the art library passes this size. 0 = no ceiling. */
  maxDiskGb: number
  /** Concurrent ComfyUI submissions for interactive work. */
  concurrency: number
  /** Cap on queued interactive jobs; batch work has its own queue. */
  maxQueued: number
  /** Interactive images per rolling hour. Bounds a drive-by to "GPU was busy". */
  maxImagesPerHour: number

  /** Known character folder names used when an older caller omits characterId. */
  characterDirs: string[]

  /** Illustrious workflow knobs — the ones worth changing without editing source. */
  checkpoint: string
  steps: number
  cfg: number
  sampler: string
  scheduler: string
  /** Optional: the workflow falls back to -2 when unset. */
  clipSkip?: number
  /**
   * Two LoRAs every Illustrious render goes through, loaded on model + CLIP
   * right after the checkpoint (detailer first, then face detailer), before
   * character LoRAs and prompt encoding. An empty name disables that one.
   */
  detailerLora: string
  detailerLoraStrength: number
  faceDetailerLora: string
  faceDetailerLoraStrength: number

  /**
   * Re-encode renders as WebP when possible.
   *
   * Anime-style renders shrink roughly eightfold with no visible loss, which is
   * the difference between a 3 GB art library and a 20 GB one. Needs the
   * optional `sharp` package; without it renders stay PNG and nothing breaks,
   * since every cache entry records the extension it actually wrote.
   */
  webp: boolean

  /**
   * How often to ask ComfyUI whether a job has finished. The default matches
   * how long a render takes; a test drives it far faster.
   */
  pollIntervalMs: number

  /**
   * Exit when this process id is gone.
   *
   * `bun run dev` passes its own pid. Without it, force-killing the parent (or
   * just closing the terminal window — Windows gives a child no interceptable
   * signal for that) leaves this server alive, holding the port and driving the
   * GPU behind a window that looks closed. Orphaned background GPU work is a
   * failure this project has been bitten by before; a liveness check removes
   * the whole class rather than relying on a handler that cannot always run.
   */
  parentPid: number | null

  /** Verbose request logging. */
  verbose: boolean
}

export const DEFAULT_PORT = 8189

/**
 * Character folders shipped with the game.
 *
 * The game's own list lives in `src/data/imageCharacters.ts`. This package is
 * published on its own and must not import across that boundary, so it carries
 * its own default; a test in the private repo asserts the two agree. A player
 * adding their own character overrides it via config.
 */
export const DEFAULT_CHARACTER_DIRS = ['elena', 'mara', 'pippa', 'patron']

function envNumber(name: string, fallback: number): number {
  const raw = process.env[name]
  if (raw == null || raw === '') return fallback
  const n = Number(raw)
  return Number.isFinite(n) ? n : fallback
}

function envBool(name: string, fallback: boolean): boolean {
  const raw = process.env[name]
  if (raw == null || raw === '') return fallback
  return raw === '1' || raw.toLowerCase() === 'true'
}

/** Parse `--flag value`, `--flag=value`, and bare `--bool-flag`. */
/** Whether `host` exposes the server beyond this machine. */
export function boundBeyondLoopback(host: string): boolean {
  return host !== '127.0.0.1' && host !== 'localhost' && host !== '::1'
}

export function parseArgs(argv: string[]): Record<string, string> {
  const out: Record<string, string> = {}
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i]
    if (!arg.startsWith('--')) continue
    const eq = arg.indexOf('=')
    if (eq !== -1) {
      out[arg.slice(2, eq)] = arg.slice(eq + 1)
      continue
    }
    const key = arg.slice(2)
    const next = argv[i + 1]
    if (next != null && !next.startsWith('--')) {
      out[key] = next
      i++
    } else {
      out[key] = 'true'
    }
  }
  return out
}

function readConfigFile(file: string): Record<string, unknown> {
  try {
    if (!fs.existsSync(file)) return {}
    return JSON.parse(fs.readFileSync(file, 'utf-8')) as Record<string, unknown>
  } catch (err) {
    console.warn(`[config] ignoring unreadable ${file}: ${(err as Error).message}`)
    return {}
  }
}

export function resolveConfig(argv: string[] = [], cwd = process.cwd()): Config {
  const flags = parseArgs(argv)
  const file = readConfigFile(path.resolve(cwd, flags['config'] ?? 'wayward-imagegen.config.json'))

  // An env var that is SET BUT EMPTY is an intentional empty value, not an
  // absent one: `COMFYUI_DETAILER_LORA=''` is how you turn a detailer LoRA off even
  // when the config file names one. Falling back to the
  // default there would silently re-enable it.
  const pick = (flag: string, env: string, fileKey: string, fallback: string): string => {
    if (flags[flag] != null) return flags[flag]
    const e = process.env[env]
    if (e != null) return e
    const f = file[fileKey]
    if (typeof f === 'string') return f
    return fallback
  }
  const pickNum = (flag: string, env: string, fileKey: string, fallback: number): number => {
    if (flags[flag] != null) {
      const n = Number(flags[flag])
      if (Number.isFinite(n)) return n
    }
    const f = file[fileKey]
    const base = typeof f === 'number' && Number.isFinite(f) ? f : fallback
    return envNumber(env, base)
  }

  const imagesDir = path.resolve(cwd, pick('images-dir', 'WAYWARD_IMAGES_DIR', 'imagesDir', 'images'))
  const stateDir = path.resolve(cwd, pick('state-dir', 'WAYWARD_STATE_DIR', 'stateDir', path.join(imagesDir, '.state')))
  const imagePacksDir = path.resolve(cwd, pick('image-packs-dir', 'WAYWARD_IMAGE_PACKS_DIR', 'imagePacksDir', path.join('..', 'image-packs')))

  const wanRaw = pick('wan-workflow', 'WAYWARD_WAN_WORKFLOW', 'wanWorkflowPath', '')
  const wanWorkflowPath = wanRaw ? path.resolve(cwd, wanRaw) : null

  const originsRaw = flags['allow-origin']
    ?? process.env.WAYWARD_ALLOW_ORIGIN
    ?? (Array.isArray(file.allowedOrigins) ? (file.allowedOrigins as string[]).join(',') : '')
  const allowedOrigins = originsRaw
    ? originsRaw.split(',').map(s => s.trim()).filter(Boolean)
    : []

  const charsRaw = flags['characters']
    ?? process.env.WAYWARD_CHARACTER_DIRS
    ?? (Array.isArray(file.characterDirs) ? (file.characterDirs as string[]).join(',') : '')
  const characterDirs = charsRaw
    ? charsRaw.split(',').map(s => s.trim()).filter(Boolean)
    : DEFAULT_CHARACTER_DIRS

  return {
    host: pick('host', 'WAYWARD_HOST', 'host', '127.0.0.1'),
    port: pickNum('port', 'WAYWARD_PORT', 'port', DEFAULT_PORT),
    imagesDir,
    imagePacksDir,
    stateDir,
    comfyUrl: pick('comfy-url', 'COMFYUI_URL', 'comfyUrl', 'http://127.0.0.1:8188').replace(/\/+$/, ''),
    wanWorkflowPath,

    allowedOrigins,

    allowDelete: flags['allow-delete'] === 'true' || envBool('WAYWARD_ALLOW_DELETE', file.allowDelete === true),

    maxDiskGb: pickNum('max-disk-gb', 'WAYWARD_MAX_DISK_GB', 'maxDiskGb', 0),
    concurrency: pickNum('concurrency', 'WAYWARD_CONCURRENCY', 'concurrency', 2),
    maxQueued: pickNum('max-queued', 'WAYWARD_MAX_QUEUED', 'maxQueued', 64),
    maxImagesPerHour: pickNum('max-images-per-hour', 'WAYWARD_MAX_IMAGES_PER_HOUR', 'maxImagesPerHour', 400),

    characterDirs,

    // checkpoint: pick('checkpoint', 'COMFYUI_CHECKPOINT', 'checkpoint', '02. IL\\waiIllustriousSDXL_v170.safetensors'),
    // steps: pickNum('steps', 'COMFYUI_STEPS', 'steps', 20),
    // cfg: pickNum('cfg', 'COMFYUI_CFG', 'cfg', 7.0),
    // sampler: pick('sampler', 'COMFYUI_SAMPLER', 'sampler', 'euler'),
    // scheduler: pick('scheduler', 'COMFYUI_SCHEDULER', 'scheduler', 'normal'),
    // // clipSkip: pickNum('clip-skip', 'COMFYUI_CLIP_SKIP', 'clipSkip', -2),
    // detailerLora: pick('detailer-lora', 'COMFYUI_DETAILER_LORA', 'detailerLora', '01. IL\\01 Style\\ILDetailerV2.safetensors'),
    // detailerLoraStrength: pickNum('detailer-lora-strength', 'COMFYUI_DETAILER_LORA_STRENGTH', 'detailerLoraStrength', 0.7),
    // faceDetailerLora: pick('face-detailer-lora', 'COMFYUI_FACE_DETAILER_LORA', 'faceDetailerLora', '01. IL\\01 Style\\Face_Detailed_v2-better eyes&colors.safetensors'),
    // faceDetailerLoraStrength: pickNum('face-detailer-lora-strength', 'COMFYUI_FACE_DETAILER_LORA_STRENGTH', 'faceDetailerLoraStrength', 0.7),

    
    checkpoint: pick('checkpoint', 'COMFYUI_CHECKPOINT', 'checkpoint', '02. IL\\waiIllustriousSDXL_v170.safetensors'),
    steps: pickNum('steps', 'COMFYUI_STEPS', 'steps', 20),
    cfg: pickNum('cfg', 'COMFYUI_CFG', 'cfg', 7.0),
    sampler: pick('sampler', 'COMFYUI_SAMPLER', 'sampler', 'euler'),
    scheduler: pick('scheduler', 'COMFYUI_SCHEDULER', 'scheduler', 'normal'),
    // clipSkip: pickNum('clip-skip', 'COMFYUI_CLIP_SKIP', 'clipSkip', -2),
    detailerLora: pick('detailer-lora', 'COMFYUI_DETAILER_LORA', 'detailerLora', '01. IL\\01 Style\\ILDetailerV2.safetensors'),
    detailerLoraStrength: pickNum('detailer-lora-strength', 'COMFYUI_DETAILER_LORA_STRENGTH', 'detailerLoraStrength', 0.7),
    faceDetailerLora: pick('face-detailer-lora', 'COMFYUI_FACE_DETAILER_LORA', 'faceDetailerLora', '01. IL\\01 Style\\Face_Detailed_v2-better eyes&colors.safetensors'),
    faceDetailerLoraStrength: pickNum('face-detailer-lora-strength', 'COMFYUI_FACE_DETAILER_LORA_STRENGTH', 'faceDetailerLoraStrength', 0.7),

    webp: flags['no-webp'] === 'true' ? false : !envBool('WAYWARD_NO_WEBP', file.webp === false),

    // ComfyUI에 완성 여부를 묻는 간격. 일괄 생성은 완성을 알아챈 뒤에 다음 그림을 넣으므로 길면 그림 사이에 ComfyUI가 논다
    // (2000 → 500, 2026-10-18 플레이어 제보 — 같은 PC의 가벼운 요청이라 줄여도 부담이 거의 없다)
    pollIntervalMs: pickNum('poll-interval-ms', 'WAYWARD_POLL_INTERVAL_MS', 'pollIntervalMs', 500),

    parentPid: (() => {
      const raw = flags['parent-pid'] ?? process.env.WAYWARD_PARENT_PID
      if (!raw) return null
      const n = Number(raw)
      return Number.isFinite(n) && n > 0 ? n : null
    })(),

    verbose: flags['verbose'] === 'true' || envBool('WAYWARD_VERBOSE', false),
  }
}
