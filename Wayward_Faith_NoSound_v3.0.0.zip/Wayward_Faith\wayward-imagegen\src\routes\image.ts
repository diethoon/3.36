/**
 * The image generation routes — the ones the game actually calls.
 *
 * Wire-compatible with what the game already sends, with one deliberate change:
 * responses carry a URL (`imageUrl`) rather than a base64 data URL. The old
 * shape meant 1-3 MB of JSON per image, no browser caching, and an image the
 * client could not address or re-find after a reload. `?inline=1` restores the
 * old behaviour for callers that genuinely want bytes.
 */

import * as fs from 'node:fs'
import type { CharacterLora, QualityLora } from '../comfy/workflows/index.ts'
import * as path from 'node:path'
import type { Config, WorkflowType } from '../config.ts'
import type { CacheStore, CacheEntry } from '../cache/cacheStore.ts'
import type { JobRunner, GenerationJob } from '../comfy/jobRunner.ts'
import { derivePromptHash, jobKey, sanitizeCharacterId, sanitizeName, sanitizeSamplerName } from '../naming.ts'
import { Router, sendJson, HttpError } from '../http/router.ts'
import { readJson, JSON_BODY_LIMIT } from '../http/body.ts'
import { mimeFor } from '../http/static.ts'

const WORKFLOWS: readonly WorkflowType[] = ['illustrious', 'z-image']

/**
 * ComfyUI's dimension presets are matched by exact string, so these cannot be
 * generated from the numbers.
 */
const KNOWN_DIMS: Record<string, string> = {
  '512x512': '512 x 512 (1:1)',
  '768x512': '768 x 512 (1.5:1)',
  '960x512': '960 x 512 (1.875:1)',
  '1024x512': '1024 x 512 (2:1)',
  '1024x576': '1024 x 576 (1.778:1)',
  '1536x640': '1536 x 640 (2.4:1)',
  '1344x768': '1344 x 768 (1.75:1)',
  // EmptyLatentImagePresets only exposes the landscape value; the workflow
  // sets `invert: true` whenever dimensions are overridden.
  '768x1344': '1344 x 768 (1.75:1)',
  '1216x832': '1216 x 832 (1.46:1)',
  '832x1216': '1216 x 832 (1.46:1)',
  '1152x896': '1152 x 896 (1.286:1)',
  '1024x1024': '1024 x 1024 (1:1)',
}

export interface GenerateBody {
  talentId?: string
  talentName?: string
  imageType?: string
  prompt?: string
  negativePrompt?: string
  workflow?: string
  promptHash?: string
  seed?: number
  steps?: number
  cfg?: number
  loraStrength?: number
  clipSkip?: number | null
  modelType?: 'illustrious' | 'anima' | 'nai'
  /** NovelAI: the model id goes in `checkpoint`, cfg is the scale. */
  sampler?: string
  noiseSchedule?: string
  checkpoint?: string
  textEncoder?: string
  vae?: string
  /** Whose picture this is (the game's character id). Picks the save folder. */
  characterId?: string
  /** Checkpoint preset selected by the game. */
  presetName?: string
  /** Art style folder selected by the game. */
  styleName?: string
  /** Preset LoRAs applied to every render before character-specific LoRAs. */
  qualityLoras?: QualityLora[]
  /** Per-character LoRAs (see workflows/index.ts CharacterLora). */
  characterLoras?: CharacterLora[]
  width?: number
  height?: number
  dimensions?: string
  bulk?: boolean
  bypassCache?: boolean
  debug?: Record<string, unknown>
}

export interface ImageRouteDeps {
  config: Config
  cache: CacheStore
  jobs: JobRunner
  /** Append a line to the cache-miss log. Injected so tests need no disk. */
  logMiss?: (line: Record<string, unknown>) => void
}

/**
 * The URL the client loads a render from, relative to the server root.
 *
 * Each segment is encoded separately so a filename containing a space or a
 * `#` survives, without turning the path separators into `%2F`.
 */
export function imageUrlFor(relativePath: string): string {
  return `/images/${relativePath.split('/').map(encodeURIComponent).join('/')}`
}

function sizeOf(cache: CacheStore, entry: CacheEntry): number {
  const full = cache.absolutePathOf(entry)
  if (!full) return 0
  try {
    return fs.statSync(full).size
  } catch {
    return 0
  }
}

function readAsDataUrl(cache: CacheStore, entry: CacheEntry): string | null {
  const full = cache.absolutePathOf(entry)
  if (!full) return null
  try {
    return `data:${mimeFor(full)};base64,${fs.readFileSync(full).toString('base64')}`
  } catch {
    return null
  }
}

/**
 * The identity of a render.
 *
 * The client normally sends its own `promptHash` so both sides agree. When it
 * does not, generation params are folded in — two requests with the same text
 * but different steps/cfg are different pictures and must not share a cell.
 */
/** The preset/style folder a name lands in (media.ts saveImage uses the same rule). */
export function folderName(name: string | undefined): string {
  return sanitizeName(name?.trim() ?? '') || 'default'
}

export function resolvePromptHash(body: GenerateBody): string {
  if (body.promptHash) return body.promptHash
  return derivePromptHash(body.prompt ?? '', body.negativePrompt ?? '', {
    ...body,
    qualityLoras: body.qualityLoras === undefined ? undefined : sanitizeQualityLoras(body.qualityLoras) ?? [],
    characterLoras: sanitizeCharacterLoras(body.characterLoras),
  })
}

/** Keep only well-formed entries; anything else from the client is dropped. */
function sanitizeLoras(raw: unknown, limit: number): CharacterLora[] | undefined {
  if (!Array.isArray(raw)) return undefined
  const out: CharacterLora[] = []
  for (const l of raw.slice(0, limit)) {
    if (!l || typeof l !== 'object') continue
    const name = typeof (l as CharacterLora).name === 'string' ? (l as CharacterLora).name.trim() : ''
    if (!name || name.includes('..')) continue
    const num = (v: unknown) => (typeof v === 'number' && Number.isFinite(v) ? Math.max(-4, Math.min(4, v)) : undefined)
    out.push({ name, strength: num((l as CharacterLora).strength), clipStrength: num((l as CharacterLora).clipStrength) })
  }
  return out.length ? out : undefined
}

export function sanitizeCharacterLoras(raw: unknown): CharacterLora[] | undefined {
  return sanitizeLoras(raw, 4)
}

export function sanitizeQualityLoras(raw: unknown): QualityLora[] | undefined {
  return sanitizeLoras(raw, 8)
}

export function resolveDimensions(body: GenerateBody): string | undefined {
  if (body.dimensions) return body.dimensions
  if (!body.width || !body.height) return undefined
  return KNOWN_DIMS[`${body.width}x${body.height}`]
}

/**
 * NovelAI size, matching what ComfyUI draws for the same request: the
 * dimension presets are landscape and the workflow always inverts them
 * (workflows/index.ts, `invert: true`), so the game's `1216 x 832` is a
 * portrait. The long side is the height.
 */
export function naiSize(body: GenerateBody): { width: number; height: number } {
  const w = typeof body.width === 'number' && body.width > 0 ? body.width : 0
  const h = typeof body.height === 'number' && body.height > 0 ? body.height : 0
  if (!w || !h) return { width: 832, height: 1216 }
  return { width: Math.min(w, h), height: Math.max(w, h) }
}

function jobResponse(job: GenerationJob, imagesDir: string, inline: boolean) {
  const base: Record<string, unknown> = {
    promptId: job.promptId,
    status: job.status,
    workflow: job.workflow,
  }
  if (job.error) base.error = job.error
  if (job.media) {
    base.imagePath = job.media.relativePath
    base.imageUrl = imageUrlFor(job.media.relativePath)
    base.bytes = job.media.bytes
    if (inline) {
      try {
        const buf = fs.readFileSync(path.join(imagesDir, job.media.relativePath))
        base.imageData = `data:${job.media.mime};base64,${buf.toString('base64')}`
      } catch { /* the URL is still usable */ }
    }
  }
  return base
}

export function registerImageRoutes(router: Router, deps: ImageRouteDeps): void {
  const { config, cache, jobs } = deps

  router.post('/api/image/generate', async ctx => {
    const body = await readJson<GenerateBody>(ctx.req, JSON_BODY_LIMIT)

    const talentName = body.talentName ?? body.talentId
    if (!talentName) throw new HttpError(400, 'talentId is required')
    const prompt = body.prompt
    if (typeof prompt !== 'string' || prompt.length === 0) {
      throw new HttpError(400, 'prompt is required')
    }

    const workflow = (body.workflow ?? 'illustrious') as WorkflowType
    if (!WORKFLOWS.includes(workflow)) {
      throw new HttpError(400, `unknown workflow: ${workflow}. available: ${WORKFLOWS.join(', ')}`)
    }

    const imageType = body.imageType ?? 'portrait'
    const negativePrompt = body.negativePrompt ?? ''
    const promptHash = resolvePromptHash(body)
    const bulk = body.bulk === true
    const bypassCache = body.bypassCache === true
    const inline = ctx.query.get('inline') === '1'

    // The refresh button: the player said this image is bad. Drop EVERY entry
    // for this talentName, not just the matching hash — prompts drift between
    // sessions, so one state routinely has several hashes, and leaving the
    // others alive means the bad image reappears on the next remount.
    if (bypassCache) {
      let dropped = 0
      for (const [key, entry] of Object.entries(cache.entries)) {
        if (entry.talentName !== talentName) continue
        // Compare as folder names: migrated entries store the sanitized name
        // (`il_기본형`), new ones the name the game sent (`IL 기본형`).
        if (folderName(entry.genParams?.presetName) !== folderName(body.presetName) || folderName(entry.genParams?.styleName) !== folderName(body.styleName)) continue
        const full = cache.absolutePathOf(entry)
        if (full && fs.existsSync(full)) {
          try { fs.unlinkSync(full) } catch { /* the entry still goes */ }
        }
        cache.remove(key)
        dropped++
      }
      if (dropped > 0) console.log(`[generate] bypass dropped ${dropped} entr(y/ies) for ${talentName}`)
    }

    const cached = bypassCache ? null : cache.get(talentName, imageType, promptHash, workflow)
    if (cached) {
      const response: Record<string, unknown> = {
        promptId: `cached_${promptHash}`,
        status: 'completed',
        workflow,
        cached: true,
        imagePath: cached.imagePath,
        imageUrl: imageUrlFor(cached.imagePath),
        // Reported so a caller does not have to fetch the bytes just to size
        // them — the bulk runner tallies this per image.
        bytes: sizeOf(cache, cached),
      }
      if (inline) {
        const data = readAsDataUrl(cache, cached)
        if (data) response.imageData = data
      }
      sendJson(ctx.res, 200, response)
      return
    }

    // Only genuine runtime misses are logged: not batch work, not an explicit
    // regen. That keeps the log answering one question — the game asked for
    // something new, was it a truly new state or the same state under a drifted
    // prompt? See `gin images cache-audit`.
    if (!bulk && !bypassCache && deps.logMiss) {
      let priorVariants = 0
      for (const [k, e] of Object.entries(cache.entries)) {
        if (e.talentName === talentName && e.imageType === imageType && k.startsWith(workflow + '_')) {
          priorVariants++
        }
      }
      deps.logMiss({
        at: new Date().toISOString(),
        kind: priorVariants > 0 ? 'drift' : 'new',
        priorVariants,
        talentName,
        imageType,
        workflow,
        promptHash,
        prompt: prompt.slice(0, 300),
      })
    }

    // Bound the damage a runaway or hostile caller can do.
    //
    // The rate ceilings apply to INTERACTIVE work only. Batch work is the
    // operator's own overnight run — it has its own queue and paces itself, and
    // throttling it at a few hundred an hour would quietly stall the
    // pre-generation this server exists to do.
    if (!bulk) {
      if (jobs.queuedCount() >= config.maxQueued) {
        throw new HttpError(429, `too many queued requests (${config.maxQueued})`)
      }
      if (config.maxImagesPerHour > 0 && jobs.completionsThisHour() >= config.maxImagesPerHour) {
        throw new HttpError(429, `hourly image limit reached (${config.maxImagesPerHour})`)
      }
    }
    // The disk ceiling DOES apply to everything: filling the drive is just as
    // bad whoever asked for it.
    if (config.maxDiskGb > 0) {
      const usedGb = cache.diskUsageBytes() / 1024 ** 3
      if (usedGb >= config.maxDiskGb) {
        throw new HttpError(507, `art library is at the ${config.maxDiskGb} GB ceiling`)
      }
    }

    console.log(body)
    const job = await jobs.submit({
      talentId: body.talentId ?? talentName,
      talentName,
      imageType,
      prompt,
      negativePrompt,
      workflow,
      promptHash,
      seed: body.seed,
      overrides: {
        steps: body.steps,
        cfg: body.cfg,
        loraStrength: body.loraStrength,
        clipSkip: typeof body.clipSkip === 'number' && Number.isFinite(body.clipSkip) ? body.clipSkip : body.clipSkip === null ? null : undefined,
        modelType: body.modelType === 'anima' || body.modelType === 'nai' ? body.modelType : undefined,
        ...(body.modelType === 'nai'
          ? {
              sampler: typeof body.sampler === 'string' ? body.sampler : undefined,
              noiseSchedule: typeof body.noiseSchedule === 'string' ? body.noiseSchedule : undefined,
              ...naiSize(body),
            }
          : {
              // ComfyUI (Illustrious, Anima): the preset's sampler / scheduler when it chose one (game: faith/image/image-gen.js wfGenOverride)
              sampler: sanitizeSamplerName(body.sampler),
              noiseSchedule: sanitizeSamplerName(body.noiseSchedule),
            }),
        checkpoint: body.checkpoint,
        textEncoder: body.textEncoder,
        vae: body.vae,
        dimensions: resolveDimensions(body),
        qualityLoras: body.qualityLoras === undefined ? undefined : sanitizeQualityLoras(body.qualityLoras) ?? [],
        characterLoras: sanitizeCharacterLoras(body.characterLoras),
        presetName: body.presetName?.trim() || 'default',
        styleName: body.styleName?.trim() || 'default',
      },
      bulk,
      debug: body.debug,
      characterId: sanitizeCharacterId(body.characterId),
      presetName: typeof body.presetName === 'string' ? body.presetName : undefined,
      styleName: typeof body.styleName === 'string' ? body.styleName : undefined,
    })

    sendJson(ctx.res, 200, jobResponse(job, config.imagesDir, inline))
  })

  router.get('/api/image/status/:promptId', ctx => {
    const { promptId } = ctx.params
    const job = jobs.get(promptId)
    if (!job) {
      // A completed job is reaped after its TTL. 404 is honest: we no longer
      // know. The client falls back to the catalogue, which by then has it.
      throw new HttpError(404, 'unknown promptId')
    }
    const inline = ctx.query.get('inline') === '1'
    const body = jobResponse(job, config.imagesDir, inline)
    // 202 while pending keeps a polling client from treating "not yet" as done.
    sendJson(ctx.res, job.status === 'queued' || job.status === 'processing' ? 202 : 200, body)
  })

  router.post('/api/image/cancel', async ctx => {
    const body = await readJson<{ promptId?: string }>(ctx.req)
    if (!body.promptId) throw new HttpError(400, 'promptId is required')
    const result = await jobs.cancel(body.promptId)
    sendJson(ctx.res, 200, { status: 'ok', ...result })
  })

  router.get('/api/image/check', ctx => {
    const name = ctx.query.get('name')
    const hash = ctx.query.get('hash')
    if (!name || !hash) throw new HttpError(400, 'name and hash are required')
    const imageType = ctx.query.get('type') ?? 'portrait'
    const workflow = (ctx.query.get('workflow') ?? 'illustrious') as WorkflowType

    const entry = cache.get(name, imageType, hash, workflow)
    if (!entry) {
      sendJson(ctx.res, 200, { exists: false })
      return
    }
    const response: Record<string, unknown> = {
      exists: true,
      cached: true,
      imagePath: entry.imagePath,
      imageUrl: imageUrlFor(entry.imagePath),
    }
    if (ctx.query.get('inline') === '1') {
      const data = readAsDataUrl(cache, entry)
      if (data) response.imageData = data
    }
    sendJson(ctx.res, 200, response)
  })

  // Deleting art is off unless the operator asks for it. Nothing in the game
  // needs it; it exists for the review UI, on a machine whose owner opted in.
  router.delete('/api/image/delete', ctx => {
    if (!config.allowDelete) {
      throw new HttpError(403, 'deletion is disabled; start with --allow-delete to enable it')
    }
    const name = ctx.query.get('name')
    if (!name) throw new HttpError(400, 'name is required')
    const imageType = ctx.query.get('type') ?? 'portrait'
    const workflow = ctx.query.get('workflow') ?? 'illustrious'

    let deleted = 0
    for (const [key, entry] of Object.entries(cache.entries)) {
      if (entry.talentName !== name) continue
      if (entry.imageType !== imageType) continue
      if (!key.startsWith(workflow + '_')) continue
      const full = cache.absolutePathOf(entry)
      if (full && fs.existsSync(full)) {
        try { fs.unlinkSync(full) } catch { /* the entry still goes */ }
      }
      // Removing the entry as well as the file — the dev server deleted files
      // but left the index pointing at them, which produced phantom entries
      // that every later consumer had to filter out.
      cache.remove(key)
      deleted++
    }
    sendJson(ctx.res, 200, { deleted })
  })
}

/** Exposed for the health route's queue summary. */
export function describeJobs(jobs: JobRunner): Record<string, unknown> {
  const active = jobs.activeJobs()
  return {
    active: active.length,
    queued: jobs.queuedCount(),
    completedThisHour: jobs.completionsThisHour(),
    keys: active.slice(0, 20).map(j => jobKey(j.talentName, j.imageType, j.promptHash, j.workflow)),
  }
}
