/* Wayward Mod Loader (WML) runtime — classic script, loaded before the game module.
 *
 *  wml/mods/mods.js       WML.enable([...ids])           which mods exist, default order ("id:off" = listed but off)
 *  wml/mods/<id>/mod.js   WML.define({ id, setup(api) }) one file per mod
 *  wml/symbols/<ver>.js   WML.symbols({...})             semantic name -> minified name for this game build
 *  wml/compat/compat.js   WML.compat({...})              what mods do not say about themselves + notices (kept with the loader)
 *
 * The game module (built by tools/build.mjs) ends with a bridge that hands its top-level bindings to
 * WML.boot(); mods run their setup() there, before the first render.
 * Player choices (on/off, load order) live in localStorage and are edited in the manager window.
 * In the WML Player app (Android) the page also gets window.WMLHost: saving files, the back button, and the
 * saves/settings file that came inside a game bundle (imported here before the game starts).
 */
(function () {
  'use strict';
  if (window.WML) return;

  const VERSION = '0.9.3';
  // Which game: Wayward, or Wayward: Faith (built on Wayward 2026-09-30, own versions "faith-2.4.1"). The build names the
  // game before the loader runs (WML_GAME); a build without it is told by the page title.
  const GAME_FAMILY = (() => {
    try {
      const g = String(globalThis.WML_GAME || '');
      if (g) return /^faith(-|$)/.test(g) ? 'faith' : 'wayward';
      return document.title === 'Wayward: Faith' ? 'faith' : 'wayward';
    } catch { return 'wayward'; }
  })();
  const MOD_ROOT = 'wml/mods/';
  const COMPAT_FILE = 'wml/compat/compat.js';
  const LS_TOGGLES = 'wml.toggles';      // { id: true|false } — player's on/off choices
  const LS_ORDER = 'wml.order';          // [ids] — player's load order
  const LS_OLD_DISABLED = 'wml.disabled';
  const LS_FOLDERS = 'wml.folders';      // [ids] — folders in wml/mods registered without mods.js (dropped on the game once)
  const LS_PKGSYMS = 'wml.pkgsyms';      // { id: { game: { name: raw } } } — symbol tables that came inside a mod's package
  const LS_PRESETS = 'wml.presets';      // { key: preset } — presets saved or imported in this browser ("내 프리셋")
  const LS_PRESET_NOW = 'wml.preset';    // { key, name, mods, missing, at } — the preset applied last
  const PRESET_FILE = 'wml/presets/presets.js';   // WML.presets([...]) — presets that come with the game package
  const SS_PRESET_DONE = 'wml.presetApplied';     // sessionStorage: a preset dropped on the game, reported after the reload
  // The fixed tag list (0.9.0). A mod's `tags` take only these ids (others are left out and noted under diagnostics);
  // "main" tags are the manager's filter chips, "flag" tags are small marks on a mod's line. The MCP server reads the
  // block between the markers as JSON: keep it plain JSON.
  // @wml-tags-begin
  const MOD_TAGS = {
    "util": { "kind": "main", "ko": "유틸", "en": "Utility", "about": { "ko": "화면·조작·편의·버그 고침·저장·디버그", "en": "Screens, controls, conveniences, bug fixes, saving, debugging" } },
    "content": { "kind": "main", "ko": "콘텐츠", "en": "Content", "about": { "ko": "시설·직원·이벤트·아이템·캐릭터·이야기·대사 추가·변경", "en": "Adds or changes places, staff, events, items, characters, story, lines" } },
    "h-scene": { "kind": "main", "ko": "H 장면", "en": "H scenes", "about": { "ko": "H 장면 추가·변경", "en": "Adds or changes H scenes" } },
    "image": { "kind": "main", "ko": "그림", "en": "Images", "about": { "ko": "그림 생성 도구·이미지팩·그림 설정", "en": "Image generation tools, image packs, image settings" } },
    "prompt": { "kind": "main", "auto": true, "ko": "프롬프트", "en": "Prompts", "about": { "ko": "그림 프롬프트 변경 — 여러 개 켜면 겹칠 수 있어요", "en": "Changes image prompts — several on together may clash" } },
    "needs-image-server": { "kind": "flag", "ko": "그림 서버 필요", "en": "Needs an image server", "about": { "ko": "그림 생성 서버(ComfyUI 등) 필요", "en": "Needs an image generation server (ComfyUI or similar)" } },
    "needs-llm": { "kind": "flag", "ko": "LLM 필요", "en": "Needs an LLM", "about": { "ko": "LLM 서버 필요", "en": "Needs an LLM server" } },
    "needs-new-game": { "kind": "flag", "ko": "새 게임 필요", "en": "Needs a new game", "about": { "ko": "새 게임에서 적용 (예: 새 아내)", "en": "Applies from a new game (a new wife, for example)" } },
    "experimental": { "kind": "flag", "ko": "실험 중", "en": "Experimental", "about": { "ko": "시험 중인 모드", "en": "Still being tried out" } }
  };
  // @wml-tags-end
  const tagLabel = t => (MOD_TAGS[t] ? L(MOD_TAGS[t].ko, MOD_TAGS[t].en) : t);
  const defs = new Map();          // id -> definition
  const scriptLoads = [];          // promises for mod <script> tags
  let enableCalled = false;        // mods.js has run (WML.enable)
  const unread = new Set();        // listed mods switched off at start: their mod.js is read when the manager opens (0.9.1)
  const state = { listed: [], fromList: [], defaultOff: [], missing: [], order: [], loaded: [], failed: [], warnings: [], orderNotes: [], roleOverlaps: [], diagnostics: [], sourceNotes: [], symbols: null, game: null, booted: false };
  const probing = new Map();       // id -> its definition, while wml/mods/<id>/ is being checked (define() only records it)
  const hooks = new Map();         // minified name -> { orig, before[], around[], after[], replace }
  const pristine = new Map();      // minified name -> the function as the game made it (taken at boot, before any mod ran)
  let setupTrack = null;           // while a mod's setup runs: { id, undo: [] } — what it hooked, taken back if setup fails
  const SETUP_LIMIT = 30000;       // a setup still running after this long no longer holds up the next mods and the game
  let engine = null;
  let bootSnapshot = null;         // on/off + order the running session was started with

  const lsGet = (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch { return d; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* private mode */ } };
  const lsDel = k => { try { localStorage.removeItem(k); } catch { /* private mode */ } };
  const warn = (msg, mod) => { state.warnings.push({ mod, msg }); console.warn('[WML]' + (mod ? ` [${mod}]` : ''), msg); };
  // what the loader can see in the code's structure but cannot tell is a real problem (a mod that passes the call on
  // is fine): for mod authors, in a folded part of the manager and in WML.status(), not among the players' warnings
  const diag = (msg, mod, raw) => { state.diagnostics.push({ mod, msg, raw }); console.info('[WML] diagnostic' + (mod ? ` [${mod}]` : ''), msg); };
  // the loader's own words, in the game's language (the Korean build sets WML_I18N before this file runs)
  // the game's language: the translation layer's (Wayward builds), or the page's own (Wayward: Faith is Korean, with its own English pack)
  const LANG = () => {
    try {
      if (window.WML_I18N && window.WML_I18N.lang) return window.WML_I18N.lang;
      if (GAME_FAMILY === 'faith') return String(document.documentElement.lang || 'ko').slice(0, 2).toLowerCase();
      return 'en';
    } catch { return 'en'; }
  };
  const L = (ko, en) => (LANG() === 'ko' ? ko : en);

  // ---------------------------------------------------------------- where the game runs
  // 'player': the WML Player app on a phone (window.WMLHost); 'browser': a desktop or phone browser
  const HOST = (() => { try { return window.WMLHost && typeof window.WMLHost.version === 'function' ? window.WMLHost : null; } catch { return null; } })();
  const host = Object.freeze({
    kind: HOST ? 'player' : 'browser',
    app: HOST ? String(HOST.version()) : '',
    // which phone app: 'player' (WML Player) or 'faith' (Faith Player); apps before 1.1.0 have no flavor()
    flavor: HOST && typeof HOST.flavor === 'function' ? String(HOST.flavor()) : 'player',
    platform: HOST || /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent || '') ? 'mobile' : 'pc',
  });
  const PLATFORM_LABEL = { pc: 'PC', get mobile() { return L('폰', 'phone'); } };
  const APP_NAMES = { player: ['WML 플레이어', 'WML Player'], faith: ['Wayward : Faith', 'Wayward : Faith'] };
  const appLabel = () => { const n = APP_NAMES[host.flavor] || APP_NAMES.player; return `${L(n[0], n[1])} v${host.app}`; };

  // ---------------------------------------------------------------- diagnostics log (0.9.3)
  // What went wrong while playing, kept so that a player can send it to whoever can help: errors (and the mod they came
  // from), the screen freezing (and which mod code ran then), slow mod hooks, an earlier run that did not end, the
  // browser and the mods. Started here, before anything else of the loader, so that errors while mods load are in it.
  // Kept in IndexedDB (the last DIAG_RUNS runs, one record each) and saved as a text file from the manager's notices tab
  // or the loading screen; addresses and folder paths are taken out when that text is made.
  const DIAG_DB = 'wml-diag', DIAG_STORE = 'runs', DIAG_RUNS = 5;
  const DIAG_MAX = 500, DIAG_HEAD = 40;   // entries kept per run: past DIAG_MAX the oldest after the first DIAG_HEAD go
  const LS_DIAG_ALIVE = 'wml.diag.alive'; // the running run: { sid, start, at, day, slot, errors, stalls, closed } — closed when the page is left
  const SLOW_HOOK = 200, STALL_MIN = 1000, PLAY_BEAT = 250;
  const diagLog = { sid: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), start: Date.now(), entries: [], byKey: new Map(), dropped: 0,
    errors: 0, warns: 0, stalls: 0, media: 0, slow: new Map(), recent: [], prev: null, dirty: false, env: null, perMod: new Map() };
  let diagNow = null;                      // the mod code running now: a hook entry { owner, where } or a setup
  let diagBusy = false;
  const ERRORISH = new Set(['error', 'reject', 'console']);
  const modFromText = t => { const m = /\/wml\/mods\/([a-z0-9][a-z0-9._-]*)\//i.exec(String(t || '')); return m ? m[1] : null; };
  // the loader's own lines name the mod: "[WML] [id] …" and "[WML] hook before:x from id threw"
  const modFromWml = t => { const s = String(t || ''); const m = /^\[WML\][^[\n]*\[([a-z0-9][a-z0-9._-]*)\]/i.exec(s) || /\bfrom ([a-z0-9][a-z0-9._-]*) threw\b/i.exec(s); return m ? m[1] : null; };
  const errText = e => {
    if (e == null) return String(e);
    if (typeof e === 'object' && typeof e.message === 'string') return `${e.name || 'Error'}: ${e.message}`;
    if (typeof e === 'object') { try { return JSON.stringify(e).slice(0, 400); } catch { return String(e); } }
    return String(e);
  };
  const modFromStack = st => { const m = /\/wml\/mods\/([a-z0-9][a-z0-9._-]*)\//i.exec(String(st || '')); return m ? m[1] : null; };
  const stackHead = e => (e && typeof e.stack === 'string' ? e.stack.split('\n').filter(s => /^\s+at |@/.test(s)).slice(0, 3).map(s => s.trim()).join(' | ') : undefined);
  function diagAdd(kind, msg, extra = {}) {
    try {
      msg = String(msg == null ? '' : msg).slice(0, 600);
      const mod = extra.mod || null, t = Math.round(performance.now());
      const key = `${kind}|${mod}|${msg}`;
      const seen = kind === 'stall' ? null : diagLog.byKey.get(key);
      if (seen) { seen.n++; seen.last = t; diagLog.dirty = true; return seen; }
      const e = Object.assign({ kind, t, mod, msg, n: 1 }, extra);
      diagLog.entries.push(e);
      if (kind !== 'stall') diagLog.byKey.set(key, e);
      if (diagLog.entries.length > DIAG_MAX) {
        const gone = diagLog.entries.splice(DIAG_HEAD, 1)[0];
        diagLog.byKey.delete(`${gone.kind}|${gone.mod}|${gone.msg}`);
        diagLog.dropped++;
      }
      if (ERRORISH.has(kind)) diagLog.errors++;
      else if (kind === 'warn') diagLog.warns++;
      diagLog.dirty = true;
      if (ERRORISH.has(kind) || kind === 'stall') diagSoon();
      return e;
    } catch { return null; }
  }
  // console.error / console.warn of the game, the mods and the loader: kept (and passed on as before)
  for (const lvl of ['error', 'warn']) {
    const orig = console[lvl];
    if (typeof orig !== 'function') continue;
    console[lvl] = function (...a) {
      if (!diagBusy) {
        diagBusy = true;
        try {
          const err = a.find(x => x && typeof x === 'object' && typeof x.stack === 'string');
          const text = a.map(x => (typeof x === 'string' ? x : errText(x))).join(' ');
          // who called: the mod file on the stack first (code of one mod can run inside another's hook), then the
          // loader's own line naming it, then the mod code WML was running
          const here = err ? err.stack : new Error().stack;
          diagAdd(lvl === 'error' ? 'console' : 'warn', text, { mod: modFromWml(text) || modFromStack(here) || (diagNow && diagNow.owner), stack: stackHead(err) });
        } catch { /* never in the way */ } finally { diagBusy = false; }
      }
      return orig.apply(this, a);
    };
  }
  // errors nobody caught, promises nobody waited for, and files that did not load (pictures and image packs only counted)
  window.addEventListener('error', ev => {
    try {
      const tg = ev.target;
      if (tg && tg !== window && tg.tagName) {
        const url = String(tg.src || tg.href || '');
        if (/^(IMG|VIDEO|AUDIO|SOURCE)$/.test(tg.tagName) || /\/images[\w-]*\.js(\?|$)/.test(url)) { diagLog.media++; diagLog.dirty = true; return; }
        diagAdd('resource', `${tg.tagName.toLowerCase()} ${url}`, { mod: modFromText(url) });
        return;
      }
      diagAdd('error', ev.message || errText(ev.error), { mod: modFromText(ev.filename) || modFromStack(ev.error && ev.error.stack) || (diagNow && diagNow.owner),
        at: ev.filename ? `${ev.filename}:${ev.lineno}:${ev.colno}` : undefined, stack: stackHead(ev.error) });
    } catch { /* never in the way */ }
  }, true);
  window.addEventListener('unhandledrejection', ev => {
    try { const r = ev.reason; diagAdd('reject', errText(r), { mod: modFromStack(r && r.stack) || (diagNow && diagNow.owner), stack: stackHead(r) }); } catch { /* never in the way */ }
  });
  /** run mod code as `entry` ({ owner, where }): errors in it are put on that mod, and a slow call is noted */
  function diagCall(entry, run) {
    const prev = diagNow, t0 = performance.now();
    diagNow = entry;
    try { return run(); } finally { diagNow = prev; const ms = performance.now() - t0; if (ms >= 20) diagTimed(entry, t0, ms); }
  }
  function diagTimed(entry, t0, ms) {
    const r = diagLog.recent;
    r.push([t0, ms, entry.owner, entry.where]);
    if (r.length > 60) r.shift();
    if (ms < SLOW_HOOK) return;
    const k = `${entry.owner}|${entry.where}`;
    const s = diagLog.slow.get(k) || { owner: entry.owner, where: entry.where, n: 0, max: 0, total: 0 };
    s.n++; s.total += ms; s.max = Math.max(s.max, ms);
    diagLog.slow.set(k, s);
    diagLog.dirty = true;
  }
  /** a mod's own line in the log (api.report): at most 100 per mod and run */
  function diagModNote(id, msg, data) {
    const n = (diagLog.perMod.get(id) || 0) + 1;
    diagLog.perMod.set(id, n);
    if (n > 100) return false;
    let more;
    if (data !== undefined) { try { more = JSON.stringify(data).slice(0, 600); } catch { more = String(data).slice(0, 600); } }
    diagAdd('mod', msg, { mod: id, data: more });
    return true;
  }
  const gameNow = () => { try { const s = engine && engine[resolve('store')].getState().state; return s ? { day: s.day, slot: s.slot } : {}; } catch { return {}; } };
  // the screen standing still while playing (the start has its own, finer record): which mod code ran in that time
  function diagStall(from, ms) {
    const to = from + ms;
    const during = diagLog.recent.filter(([t0, d]) => t0 < to && t0 + d > from).slice(-5).map(([, d, owner, where]) => ({ owner, where, ms: Math.round(d) }));
    diagLog.stalls++;
    diagAdd('stall', '', Object.assign({ ms: Math.round(ms), from: Math.round(from), during, booted: state.booted }, gameNow()));
  }
  let playLast = 0, aliveAt = 0;
  function playBeat() {
    const now = performance.now();
    if (playLast && document.visibilityState === 'visible') { const late = now - playLast - PLAY_BEAT; if (late >= STALL_MIN) diagStall(playLast + PLAY_BEAT, late); }
    playLast = document.visibilityState === 'visible' ? now : 0;
    if (now - aliveAt >= 5000) { aliveAt = now; diagAlive(false); diagFlush(); }
    setTimeout(playBeat, PLAY_BEAT);
  }
  function diagAlive(closed) {
    const s = diagLog.recent[diagLog.recent.length - 1];
    lsSet(LS_DIAG_ALIVE, Object.assign({ sid: diagLog.sid, start: diagLog.start, at: Date.now(), errors: diagLog.errors, stalls: diagLog.stalls, closed,
      last: s ? { owner: s[2], where: s[3], ms: Math.round(s[1]), ago: Math.round(performance.now() - s[0]) } : null }, gameNow()));
  }
  // an earlier run whose page did not end (closed, reloaded): the tab was killed, crashed, or froze for good.
  // Its marker going still under 15 s ago is more likely another tab of the game that is open now.
  (() => {
    const p = lsGet(LS_DIAG_ALIVE, null);
    if (p && p.sid && !p.closed && Date.now() - p.at > 15000) diagLog.prev = p;
  })();
  window.addEventListener('pagehide', () => { diagAlive(true); diagFlush(); });
  setTimeout(playBeat, PLAY_BEAT);
  diagAlive(false);
  let diagDbP = null, diagFlushT = 0, diagDockT = 0;
  const diagDb = () => diagDbP || (diagDbP = idbOpenDb(DIAG_DB, 1, db => { if (!db.objectStoreNames.contains(DIAG_STORE)) db.createObjectStore(DIAG_STORE, { keyPath: 'sid' }); })
    .then(db => { diagPrune(db); return db; }).catch(() => null));
  function diagSoon() {
    clearTimeout(diagFlushT);
    diagFlushT = setTimeout(diagFlush, 1000);
    if (state.booted && !diagDockT) diagDockT = setTimeout(() => { diagDockT = 0; try { renderDock(); } catch { /* not drawn yet */ } }, 1000);
  }
  const diagRecord = () => ({ sid: diagLog.sid, start: diagLog.start, end: Date.now(), wml: VERSION, game: state.game, lang: LANG(), booted: state.booted,
    errors: diagLog.errors, warns: diagLog.warns, stalls: diagLog.stalls, media: diagLog.media, dropped: diagLog.dropped, prev: diagLog.prev,
    entries: diagLog.entries.slice(), slow: [...diagLog.slow.values()], env: diagLog.env });
  async function diagFlush() {
    if (!diagLog.dirty) return;
    diagLog.dirty = false;
    try {
      const db = await diagDb();
      if (!db) return;
      db.transaction(DIAG_STORE, 'readwrite').objectStore(DIAG_STORE).put(diagRecord());
    } catch { diagLog.dirty = true; }
  }
  async function diagPrune(db) {
    try {
      const all = await idbReq(db.transaction(DIAG_STORE).objectStore(DIAG_STORE).getAll());
      const old = all.filter(r => r.sid !== diagLog.sid).sort((a, b) => b.start - a.start).slice(DIAG_RUNS - 1);
      if (old.length) { const st = db.transaction(DIAG_STORE, 'readwrite').objectStore(DIAG_STORE); for (const r of old) st.delete(r.sid); }
    } catch { /* kept as it is */ }
  }
  async function diagPast() {
    try {
      const db = await diagDb();
      if (!db) return [];
      return (await idbReq(db.transaction(DIAG_STORE).objectStore(DIAG_STORE).getAll())).filter(r => r.sid !== diagLog.sid).sort((a, b) => b.start - a.start);
    } catch { return []; }
  }

  // ---------------------------------------------------------------- packed saves
  // The save-compress mod stores big save slots LZ-packed ("wwlz1…", LZ-String UTF-16 form, MIT). The loader
  // always unpacks them on read, so the saves still load when that mod is switched off, deleted, or cannot start
  // after a game update. Code that needs the stored text as it is uses WML.rawGetItem.
  const WWLZ = 'wwlz1';
  const rawGetItem = Storage.prototype.getItem;
  const rawSetItem = Storage.prototype.setItem;      // imports write the stored text as it is (no mod packs it again)
  const unpacked = new Map();                  // key -> [packed text, plain text]
  function wwlzDecode(stored) {
    if (typeof stored !== 'string' || stored.lastIndexOf(WWLZ, 0) !== 0) return null;
    const c = stored.slice(6);
    if (c === '') return null;
    const f = String.fromCharCode, length = c.length, reset = 16384, at = i => c.charCodeAt(i) - 32;
    const dict = [0, 1, 2], out = [], data = { val: at(0), position: reset, index: 1 };
    let enlargeIn = 4, dictSize = 4, numBits = 3, entry = '', w, cc;
    const rd = n => {
      let bits = 0, power = 1;
      const max = Math.pow(2, n);
      while (power !== max) {
        const b = data.val & data.position;
        data.position >>= 1;
        if (data.position === 0) { data.position = reset; data.val = at(data.index++); }
        bits |= (b > 0 ? 1 : 0) * power;
        power <<= 1;
      }
      return bits;
    };
    switch (rd(2)) { case 0: cc = f(rd(8)); break; case 1: cc = f(rd(16)); break; default: return ''; }
    dict[3] = cc; w = cc; out.push(cc);
    for (;;) {
      if (data.index > length) return '';
      cc = rd(numBits);
      switch (cc) {
        case 0: dict[dictSize++] = f(rd(8)); cc = dictSize - 1; enlargeIn--; break;
        case 1: dict[dictSize++] = f(rd(16)); cc = dictSize - 1; enlargeIn--; break;
        case 2: return out.join('');
      }
      if (enlargeIn === 0) { enlargeIn = Math.pow(2, numBits); numBits++; }
      if (dict[cc]) entry = dict[cc];
      else if (cc === dictSize) entry = w + w.charAt(0);
      else return null;
      out.push(entry);
      dict[dictSize++] = w + entry.charAt(0); enlargeIn--; w = entry;
      if (enlargeIn === 0) { enlargeIn = Math.pow(2, numBits); numBits++; }
    }
  }
  function unpack(k, v) {
    if (typeof v !== 'string' || v.charCodeAt(0) !== 2 || v.lastIndexOf(WWLZ, 0) !== 0) return v;
    const hit = unpacked.get(k);
    if (hit && hit[0] === v) return hit[1];
    const plain = wwlzDecode(v);
    if (plain == null) return v;                // not ours after all: hand it over unchanged
    unpacked.set(k, [v, plain]);
    return plain;
  }

  // ---------------------------------------------------------------- saves in the browser database (0.8.1, default 0.9.0)
  // The game keeps every save in localStorage — about 5 million characters for the whole site: the current game
  // (tavern-game, written again on every change), 12 slots and the last 5 day-start autosaves, each the whole game.
  // With "saves in the browser database" on — the default since 0.9.0; the manager's "where saves are kept" switches
  // it off (wml.saves = 'ls') and on again ('idb', or nothing stored) — they live in the IndexedDB database wml-saves
  // instead. localStorage keeps a marker for each, so the game's own lists (key() and
  // length) still find them, and reads and writes of these keys are answered from memory here. The current game goes
  // through the game store's own persist storage, swapped in at boot before the first render (the game reads its store
  // before any mod runs: setOptions + rehydrate), and reaches the database a moment after the changes stop instead of
  // on every change. Saves already in the database stay readable with the switch off: at boot they go back into
  // localStorage where they fit, and the rest are still read from the database.
  const LS_SAVES = 'wml.saves', SAVES_OFF = 'ls';
  const SAVE_DB = 'wml-saves', SAVE_STORE = 'saves';
  const SAVE_MARK = '\u0002wml-saves1';
  const LIVE_KEY = 'tavern-game';
  const LIVE_WAIT = 1200, LIVE_MAX_WAIT = 4000;   // ms after the last change / at most since the first unwritten one
  // large-save-storage leaves these in localStorage; the text is in its database
  const OLD_SAVE_MARKS = ['\u0002wml-large-save-storage-v1', '\u0002wml-opfs-v1'], OLD_SAVE_DB = 'wayward-wml-saves-v1';
  // mods that keep the same saves their own way: not started while the switch is on (their saves come over at boot)
  const SAVE_MODS = ['large-save-storage', 'save-compress', 'ww_imagepromptenhancedmod_savecompressaddon'];
  // Copies kept instead of being overwritten (0.9.0), in the same store as "recovered|<ms>|<why>|<save key>". An older
  // WML, or the game alone, opened on the same saves cannot read the markers, starts over and writes its own copy in
  // localStorage; at the next start here that copy is used and the database's copy is kept as one of these, to put
  // back from the manager. Older loaders read only the save keys from the store, so these are not in their way.
  const REC_PREFIX = 'recovered|', REC_KEEP = 5;     // at most this many copies of each save
  const rawRemoveItem = Storage.prototype.removeItem;
  const isSaveKey = k => k === LIVE_KEY || /^tavern-(slot-\d+|auto-d\d+)$/.test(k);
  const isLS = o => { try { return o === window.localStorage; } catch { return false; } };
  const saves = {
    want: false,          // the switch, as it was when the page loaded
    chosen: false,        // switched on in the manager (not only the default): a database that does not work is said at start
    failedHere: false,    // wanted, but the database does not work in this browser (saves stay in localStorage)
    on: false,            // saves go to the database (confirmed at boot)
    ready: false,         // the database's saves are in memory (boot)
    mem: new Map(),       // key -> text of the saves kept in the database
    touched: new Set(),   // keys written or removed in this session: the database's older copy does not come over them
    dirty: new Map(),     // key -> text, or null to remove: still to write
    live: null,           // the current game as the store gave it last (an object), not yet text
    liveText: null, liveSince: 0, liveTimer: 0, liveHold: false,
    db: null, writing: null, retry: 0, readOnly: false, liveRaw: false, rehydrated: false,
    recovered: [],        // { id, at, why, key, size }: copies kept instead of being overwritten
    recoveredNow: [],     // save keys whose database copy was kept that way at this start
    stats: { writes: 0, liveWrites: 0, errors: 0, lastError: '', moved: 0, restored: 0, kept: 0, missing: [], skipped: [] },
  };
  let liveWasMarked = false;          // the current game was in the database when the game built its store (it read nothing)
  try {
    const pick = rawGetItem.call(localStorage, LS_SAVES);
    saves.want = pick !== SAVES_OFF && GAME_FAMILY === 'wayward';
    saves.chosen = pick === 'idb';
    liveWasMarked = rawGetItem.call(localStorage, LIVE_KEY) === SAVE_MARK;
  } catch { /* storage off */ }
  saves.on = saves.want && typeof indexedDB !== 'undefined';

  function saveRead(k) {
    if (k === LIVE_KEY && saves.live) {
      if (saves.liveText == null) saves.liveText = JSON.stringify(saves.live);
      return saves.liveText;
    }
    return saves.mem.has(k) ? saves.mem.get(k) : null;
  }
  /** a save's text wherever it is kept (backups, the storage screen) */
  function saveText(k) {
    let raw = null;
    try { raw = rawGetItem.call(localStorage, k); } catch { /* storage off */ }
    return saves.mem.has(k) || (k === LIVE_KEY && saves.live) || raw === SAVE_MARK ? saveRead(k) : raw;
  }
  function saveMark(k) {
    try { if (rawGetItem.call(localStorage, k) !== SAVE_MARK) { rawRemoveItem.call(localStorage, k); rawSetItem.call(localStorage, k, SAVE_MARK); } }
    catch { /* full: the save is kept all the same; only the game's own list misses it until there is room */ }
  }
  function saveWrite(k, text, imported) {
    if (k === LIVE_KEY) {
      // before boot this is the game made from scratch while its store was built: the database's copy comes in at boot.
      // After a backup was imported the running game must not write its older state over it before the reload.
      if (!imported && (!saves.ready || saves.liveHold)) return;
      saves.live = null; saves.liveText = null; saves.liveSince = 0; clearTimeout(saves.liveTimer);
      if (imported && saves.ready) saves.liveHold = true;
    }
    saves.mem.set(k, text); saves.touched.add(k);
    // a key with nothing in localStorage gets its marker now; a copy that is there stays until the database has the save.
    // A second tab (read-only) leaves localStorage alone: it is the first tab's list too
    if (!saves.readOnly) { try { if (rawGetItem.call(localStorage, k) == null) rawSetItem.call(localStorage, k, SAVE_MARK); } catch { /* full */ } }
    saves.dirty.set(k, text);
    saveFlushSoon();
  }
  function saveRemove(k) {
    if (k === LIVE_KEY) { saves.live = null; saves.liveText = null; saves.liveSince = 0; clearTimeout(saves.liveTimer); }
    saves.mem.delete(k); saves.touched.add(k);
    saves.dirty.set(k, null);
    saveFlushSoon();
  }
  // the current game from the game store (an object): turned into text and written a moment after the changes stop
  function liveChanged(value) {
    if (!saves.ready || saves.liveHold) return;
    saves.live = value; saves.liveText = null;
    const now = Date.now();
    if (!saves.liveSince) saves.liveSince = now;
    clearTimeout(saves.liveTimer);
    saves.liveTimer = setTimeout(liveFlush, Math.max(0, Math.min(LIVE_WAIT, saves.liveSince + LIVE_MAX_WAIT - now)));
  }
  function liveFlush() {
    clearTimeout(saves.liveTimer); saves.liveTimer = 0;
    if (saves.live) {
      let text;
      try { text = saveRead(LIVE_KEY); } catch (e) { saveFailed(e); return Promise.resolve(); }
      saves.live = null; saves.liveText = null; saves.liveSince = 0;
      saves.mem.set(LIVE_KEY, text); saves.touched.add(LIVE_KEY);
      saves.dirty.set(LIVE_KEY, text);
      saves.stats.liveWrites++;
    }
    return saveFlush();
  }
  // the game store's persist storage while the switch is on (the store hands over objects, not text)
  const persistStorage = {
    getItem: name => {
      const t = unpack(name, saveRead(name));
      if (t == null) return null;
      try { return JSON.parse(t); } catch { return null; }
    },
    setItem: (name, value) => { if (name === LIVE_KEY) liveChanged(value); else saveWrite(name, JSON.stringify(value)); },
    removeItem: name => saveRemove(name),
  };
  const isQuota = e => !!e && (e.name === 'QuotaExceededError' || e.name === 'NS_ERROR_DOM_QUOTA_REACHED' || e.code === 22 || e.code === 1014);
  // switch off, but a save does not fit in localStorage: it goes on in the database (the current game a moment after
  // the changes stop, like with the switch on), and the manager says so once
  let keptTimer = 0, keptSince = 0, keptWarned = false;
  function keepInDb(key, text) {
    saves.mem.set(key, text); saves.touched.add(key);
    if (key === LIVE_KEY) {
      const now = Date.now();
      if (!keptSince) keptSince = now;
      clearTimeout(keptTimer);
      keptTimer = setTimeout(() => { keptSince = 0; const t = saves.mem.get(LIVE_KEY); if (t != null) { saves.dirty.set(LIVE_KEY, t); saveFlush(); } },
        Math.max(0, Math.min(LIVE_WAIT, keptSince + LIVE_MAX_WAIT - now)));
    } else { saves.dirty.set(key, text); saveFlushSoon(); }
    if (!keptWarned) {
      keptWarned = true;
      warn(L('localStorage가 가득 차 세이브를 IndexedDB에 저장 중이에요. 설정·백업에서 "세이브 저장 위치"를 켜 주세요.',
        'localStorage is full, so saves are kept in IndexedDB. Switch on "Where saves are kept" in Settings & backup.'));
    }
  }
  let saveFlushTimer = 0;
  function saveFlushSoon() { if (!saveFlushTimer) saveFlushTimer = setTimeout(() => { saveFlushTimer = 0; saveFlush(); }, 0); }
  function saveFailed(e) {
    saves.stats.errors++;
    saves.stats.lastError = String(e && e.message || e);
    console.error('[WML] saves: the database write failed', e);
  }
  function saveDbOpen() {
    if (saves.db) return Promise.resolve(saves.db);
    return new Promise((ok, no) => {
      const r = indexedDB.open(SAVE_DB, 1);
      r.onupgradeneeded = () => { if (!r.result.objectStoreNames.contains(SAVE_STORE)) r.result.createObjectStore(SAVE_STORE); };
      r.onsuccess = () => {
        const db = r.result;
        db.onversionchange = () => { db.close(); if (saves.db === db) saves.db = null; };
        db.onclose = () => { if (saves.db === db) saves.db = null; };
        saves.db = db;
        ok(db);
      };
      r.onerror = () => no(r.error || new Error('open failed'));
      r.onblocked = () => no(new Error('blocked by another tab'));
    });
  }
  /** fn(store) may return a request or a list of them: their results come back */
  function saveTx(mode, fn) {
    return saveDbOpen().then(db => new Promise((ok, no) => {
      const tx = db.transaction(SAVE_STORE, mode);
      let out;
      tx.oncomplete = () => ok(Array.isArray(out) ? out.map(r => r.result) : out && typeof out === 'object' && 'result' in out ? out.result : out);
      tx.onerror = () => no(tx.error || new Error('transaction failed'));
      tx.onabort = () => no(tx.error || new Error('transaction aborted'));
      out = fn(tx.objectStore(SAVE_STORE));
    }));
  }
  function saveFlush() {
    if (!saves.ready || saves.readOnly) return Promise.resolve();     // before boot: written at boot; a second tab: never
    if (saves.writing) return saves.writing.then(() => saveFlush());
    if (!saves.dirty.size) return Promise.resolve();
    const batch = new Map(saves.dirty);
    saves.dirty.clear();
    saves.writing = saveTx('readwrite', st => { for (const [k, v] of batch) { if (v == null) st.delete(k); else st.put(v, k); } })
      .then(() => {
        saves.stats.writes++;
        // the database has them now: the copies still in localStorage make room for markers
        for (const [k, v] of batch) if (v != null && saves.mem.get(k) === v) saveMark(k);
      })
      .catch(e => {
        saveFailed(e);
        for (const [k, v] of batch) if (!saves.dirty.has(k)) saves.dirty.set(k, v);
        clearTimeout(saves.retry);
        saves.retry = setTimeout(saveFlush, 3000);
      })
      .finally(() => { saves.writing = null; });
    return saves.writing;
  }

  // ---- copies kept instead of being overwritten
  const plainSave = t => (typeof t === 'string' && t.charCodeAt(0) === 2 && t.lastIndexOf(WWLZ, 0) === 0 ? wwlzDecode(t) || t : t);
  function recParse(id) {
    const p = typeof id === 'string' && id.lastIndexOf(REC_PREFIX, 0) === 0 ? id.slice(REC_PREFIX.length).split('|') : null;
    return p && p.length === 3 && isSaveKey(p[2]) ? { id, at: Number(p[0]) || 0, why: p[1], key: p[2] } : null;
  }
  /** inside a write to the store: keeps text as a copy of the save `key` (and drops its oldest beyond REC_KEEP);
   *  returns the change to make to saves.recovered once the write is done */
  function recPut(st, key, text, why) {
    const id = `${REC_PREFIX}${Date.now()}|${why}|${key}`;
    st.put(text, id);
    const drop = saves.recovered.filter(r => r.key === key).sort((a, b) => b.at - a.at).slice(REC_KEEP - 1).map(r => r.id);
    for (const d of drop) st.delete(d);
    return { add: { ...recParse(id), size: text.length }, drop };
  }
  const recApply = ch => { if (ch) saves.recovered = saves.recovered.filter(r => !ch.drop.includes(r.id)).concat(ch.add); };
  const recRead = (keys, vals) => keys.map((k, i) => { const r = recParse(k); return r && typeof vals[i] === 'string' ? { ...r, size: vals[i].length } : null; }).filter(Boolean);
  /** the list when the saves were not read at boot (the switch off and nothing in the database for this game) */
  async function recLoad() {
    if (typeof indexedDB === 'undefined' || await dbInfo(SAVE_DB) === null) return;
    const range = IDBKeyRange.bound(REC_PREFIX, REC_PREFIX + '￿');
    const [keys, vals] = await saveTx('readonly', st => [st.getAllKeys(range), st.getAll(range)]);
    saves.recovered = recRead(keys, vals);
  }
  /** puts a kept copy back as its save; the one it replaces is kept as a copy in its turn. The page reloads after */
  async function recRestore(id) {
    const r = saves.recovered.find(x => x.id === id);
    if (!r) throw new Error(L('그 복구본이 없어요', 'that copy is gone'));
    if (saves.readOnly) throw new Error(L('다른 탭을 닫고 새로고침한 뒤 다시 해 주세요', 'Close the other tab, reload and try again'));
    if (saves.writing) await saves.writing.catch(() => {});
    const text = await saveTx('readonly', st => st.get(id));
    if (typeof text !== 'string') throw new Error(L('복구본을 읽지 못했어요', 'could not read the copy'));
    const k = r.key;
    let cur = null;
    try { cur = plainSave(saveText(k)); } catch { /* none */ }
    if (cur === SAVE_MARK) cur = null;
    // from here to the reload the running game does not write its own state over the restored one
    if (k === LIVE_KEY) { saves.liveHold = true; saves.live = null; saves.liveText = null; saves.liveSince = 0; clearTimeout(saves.liveTimer); }
    saves.dirty.delete(k);
    const inDb = saves.on && !(k === LIVE_KEY && saves.liveRaw);
    let ch = null;
    await saveTx('readwrite', st => {
      if (cur != null && cur !== text) ch = recPut(st, k, cur, 'restore');
      st.delete(id);
      if (inDb) st.put(text, k); else st.delete(k);
    });
    saves.recovered = saves.recovered.filter(x => x.id !== id);
    recApply(ch);
    saves.touched.add(k);
    if (inDb) { saves.mem.set(k, text); saveMark(k); return; }
    saves.mem.delete(k);
    try { rawRemoveItem.call(localStorage, k); rawSetItem.call(localStorage, k, text); }
    catch (e) {
      if (!isQuota(e)) throw e;
      // no room in localStorage: it stays in the database and is read from there
      await saveTx('readwrite', st => { st.put(text, k); });
      saves.mem.set(k, text); saveMark(k);
    }
  }
  async function recDelete(id) {
    await saveTx('readwrite', st => { st.delete(id); });
    saves.recovered = saves.recovered.filter(x => x.id !== id);
  }

  try {
    Storage.prototype.getItem = function getItem(k) {
      const v = rawGetItem.call(this, k);
      if ((v === SAVE_MARK || saves.on) && isLS(this)) {
        const key = String(k);
        if (isSaveKey(key) && (v === SAVE_MARK || saves.mem.has(key) || (key === LIVE_KEY && saves.live))) return unpack(key, saveRead(key));
      }
      return unpack(k, v);
    };
    Storage.prototype.setItem = function setItem(k, value) {
      const key = String(k);
      if (isSaveKey(key) && isLS(this)) {
        if (key === LIVE_KEY && saves.liveHold) return undefined;     // a restored copy waits for the reload
        if (saves.on && !(key === LIVE_KEY && saves.liveRaw)) return saveWrite(key, String(value));
        if (saves.mem.has(key) || rawGetItem.call(this, key) === SAVE_MARK) {
          // the switch is off and this save was in the database: back into localStorage. When it still does not fit it
          // stays in the database (an error here would stop whatever changed the game: a mod's setup, a game action)
          try { rawSetItem.call(this, key, value); }
          catch (e) {
            if (!isQuota(e) || saves.readOnly || !saves.ready) throw e;
            keepInDb(key, String(value));
            return undefined;
          }
          saves.mem.delete(key); saves.touched.add(key); saves.dirty.set(key, null); saveFlushSoon();
          return undefined;
        }
      }
      return rawSetItem.call(this, k, value);
    };
    Storage.prototype.removeItem = function removeItem(k) {
      const key = String(k);
      if (isSaveKey(key) && isLS(this) && (saves.on || saves.mem.has(key) || rawGetItem.call(this, key) === SAVE_MARK)) {
        saveRemove(key);
        if (saves.readOnly) return undefined;          // a second tab: the first tab's marker stays
      }
      return rawRemoveItem.call(this, k);
    };
    // everything wiped (a "delete all data" button): the saves in the database go too, or they would come back at the next start
    const rawClear = Storage.prototype.clear;
    Storage.prototype.clear = function clear() {
      if (isLS(this) && (saves.on || saves.mem.size || saves.live)) {
        saves.live = null; saves.liveText = null; saves.liveSince = 0; clearTimeout(saves.liveTimer);
        saves.mem.clear(); saves.dirty.clear(); saves.recovered = [];
        if (saves.ready && !saves.readOnly) saveTx('readwrite', st => { st.clear(); }).catch(saveFailed);
      }
      return rawClear.call(this);
    };
  } catch { /* storage API locked down: packed saves need the mod, and saves stay where the game puts them */ }

  // large-save-storage's saves (its database, keyPath 'key')
  async function oldSaves() {
    if (await dbInfo(OLD_SAVE_DB) === null) return new Map();
    const db = await idbOpenDb(OLD_SAVE_DB);
    try {
      if (!db.objectStoreNames.contains('saves')) return new Map();
      const all = await idbReq(db.transaction('saves', 'readonly').objectStore('saves').getAll());
      return new Map((all || []).filter(r => r && typeof r.key === 'string' && typeof r.value === 'string').map(r => [r.key, r.value]));
    } finally { db.close(); }
  }
  async function oldSavesForget(keys) {
    const db = await idbOpenDb(OLD_SAVE_DB);
    try {
      await new Promise((ok, no) => {
        const tx = db.transaction('saves', 'readwrite');
        for (const k of keys) tx.objectStore('saves').delete(k);
        tx.oncomplete = () => ok(); tx.onerror = () => no(tx.error); tx.onabort = () => no(tx.error);
      });
    } finally { db.close(); }
  }
  const saveKeysNow = () => {
    const out = [];
    try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k != null && isSaveKey(k)) out.push(k); } } catch { /* storage off */ }
    return out;
  };
  // switch on: what is still in localStorage (plain, packed, or large-save-storage's) goes into the database; each one
  // is read back before its localStorage copy makes room for a marker
  async function savesMoveIn() {
    let old = null;
    const oldDone = [];
    for (const k of saveKeysNow()) {
      if (saves.touched.has(k)) continue;
      const raw = rawGetItem.call(localStorage, k);
      if (raw == null || raw === SAVE_MARK) continue;
      let text = raw;
      const fromOld = OLD_SAVE_MARKS.includes(raw);
      if (fromOld) {
        if (!old) old = await oldSaves().catch(() => new Map());
        if (!old.has(k)) { saves.stats.missing.push(k); continue; }
        text = old.get(k);
      }
      if (text.charCodeAt(0) === 2 && text.lastIndexOf(WWLZ, 0) === 0) { const plain = wwlzDecode(text); if (plain) text = plain; }
      try {
        // the database has another copy: localStorage's was written where WML did not answer for the saves (an older
        // WML or the game alone, opened on the same saves). It is used, as before, and the database's copy is kept
        const before = saves.mem.get(k);
        let ch = null;
        await saveTx('readwrite', st => { if (before != null && before !== text) ch = recPut(st, k, before, 'outside'); st.put(text, k); });
        if (ch) { recApply(ch); saves.recoveredNow.push(k); }
        if (await saveTx('readonly', st => st.get(k)) !== text) throw new Error(`${k}: read back differs`);
        saves.mem.set(k, text);
        saveMark(k);
        saves.stats.moved++;
        if (fromOld) oldDone.push(k);
      } catch (e) { saveFailed(e); }                // stays in localStorage, read from there
    }
    if (oldDone.length) await oldSavesForget(oldDone).catch(() => { /* its copies stay; they are not read while the switch is on */ });
  }
  // switch off: saves in the database go back into localStorage where they fit (the current game first, then the
  // slots, then the newest day-start autosaves); the rest stay and are read from the database
  async function savesMoveOut() {
    const rank = k => (k === LIVE_KEY ? 0 : /^tavern-slot-/.test(k) ? 1 : 2e6 - Number(k.slice(13)));
    for (const k of [...saves.mem.keys()].sort((a, b) => rank(a) - rank(b))) {
      const text = saves.mem.get(k);
      try {
        rawSetItem.call(localStorage, k, text);
        if (rawGetItem.call(localStorage, k) !== text) throw new Error('read back differs');
        saves.mem.delete(k);
        await saveTx('readwrite', st => { st.delete(k); }).catch(saveFailed);
        saves.stats.restored++;
      } catch { saves.stats.kept++; }
    }
  }
  const timeLimit = (p, ms, what) => Promise.race([p, new Promise((_, no) => setTimeout(() => no(new Error(`${what}: no answer in ${ms / 1000} s`)), ms))]);
  /** at boot, before any mod runs and before the first render */
  async function savesBoot() {
    const marked = saveKeysNow().filter(k => rawGetItem.call(localStorage, k) === SAVE_MARK);
    if (!saves.on && !marked.length && !saves.mem.size) {      // the game's own way: nothing to do
      saves.ready = true;
      recLoad().catch(() => { /* the manager just shows none */ });
      return;
    }
    try {
      const [keys, vals] = await timeLimit(saveTx('readonly', st => [st.getAllKeys(), st.getAll()]), 10000, SAVE_DB);
      keys.forEach((k, i) => { if (typeof k === 'string' && isSaveKey(k) && !saves.touched.has(k) && typeof vals[i] === 'string') saves.mem.set(k, vals[i]); });
      saves.recovered = recRead(keys, vals);
    } catch (e) {
      // the database does not work here (a private window, some phone apps): saves stay in localStorage. Said at start
      // when the player switched it on; with the default it shows in the manager only
      saves.stats.lastError = String(e && e.message || e);
      saves.failedHere = saves.on;
      if (saves.on && saves.chosen) warn(L(`IndexedDB를 쓸 수 없어 localStorage에 저장해요 (${saves.stats.lastError}).`,
        `IndexedDB is not available; saves stay in localStorage (${saves.stats.lastError}).`));
      saves.on = false;
      for (const [k, v] of saves.dirty) { try { if (v == null) rawRemoveItem.call(localStorage, k); else { rawSetItem.call(localStorage, k, v); saves.mem.delete(k); } } catch { /* full */ } }
      saves.dirty.clear();
      saves.ready = true;
      if (marked.length) warn(L(`IndexedDB 세이브 ${marked.length}개를 읽지 못했어요: ${marked.map(storageName).join(', ')}. 다른 탭을 닫고 새로고침해 주세요.`,
        `Could not read ${marked.length} save(s) from IndexedDB: ${marked.map(storageName).join(', ')}. Close other tabs and reload.`));
      return;
    }
    saves.stats.missing.push(...marked.filter(k => !saves.mem.has(k)));
    if (saves.on && navigator.locks && typeof navigator.locks.request === 'function') {
      // one tab writes the saves: a second tab of the same game would write its older game over the first one's
      const got = await new Promise(res => {
        navigator.locks.request(SAVE_DB, { ifAvailable: true }, lock => { res(!!lock); return lock ? new Promise(() => {}) : undefined; }).catch(() => res(true));
      });
      if (!got) {
        saves.readOnly = true;
        warn(L('다른 탭에서 게임이 열려 있어 이 탭은 저장하지 않아요. 다른 탭을 닫고 새로고침해 주세요.',
          'The game is open in another tab, so this tab does not save. Close the other tab and reload.'));
      }
    }
    if (saves.on && !saves.readOnly) {
      await savesMoveIn();
      for (const k of saves.mem.keys()) saveMark(k);           // the database is what counts: the game's lists show all of it
    } else if (!saves.on) {
      // switch off: only what localStorage still points at is a save of this game; an older copy left in the database is not
      for (const k of [...saves.mem.keys()]) if (!marked.includes(k) && !saves.touched.has(k)) saves.mem.delete(k);
      await savesMoveOut();
    }
    if (saves.stats.missing.length) warn(L(`IndexedDB에 세이브 ${saves.stats.missing.length}개가 없어요: ${saves.stats.missing.map(storageName).join(', ')}. 백업 파일로 복원해 주세요.`,
      `${saves.stats.missing.length} save(s) are missing from IndexedDB: ${saves.stats.missing.map(storageName).join(', ')}. Restore them from a backup file.`));
    if (saves.recoveredNow.length) {
      const names = saves.recoveredNow.map(storageName).join(', ');
      warn(L(`옛 버전으로 열어 바뀐 세이브: ${names}. 원래 세이브는 복구본으로 보관했어요 (설정·백업 → 세이브 저장 위치).`,
        `Saves changed by an older version: ${names}. The originals are kept as recovery copies (Settings & backup → Where saves are kept).`));
    }
    if (saves.stats.kept) warn(L(`공간 부족으로 세이브 ${saves.stats.kept}개는 IndexedDB에서 읽어요.`,
      `Not enough room: ${saves.stats.kept} save(s) are read from IndexedDB.`));
    saves.ready = true;
    // the current game: the store read it before anything here was ready, so it reads it again now
    let store = null;
    try { store = engine[resolve('store')]; } catch { /* not in this game's table */ }
    const persist = store && store.persist;
    const named = !!(persist && typeof persist.getOptions === 'function' && persist.getOptions().name === LIVE_KEY);
    if (saves.on && named && typeof persist.setOptions === 'function' && typeof persist.rehydrate === 'function') {
      persist.setOptions({ storage: persistStorage });
      try { await persist.rehydrate(); saves.rehydrated = true; }
      catch (e) { warn(L(`현재 게임을 IndexedDB에서 다시 읽지 못했어요: ${e.message}`, `Could not read the current game back from IndexedDB: ${e.message}`)); }
    } else if (saves.on) {
      // this game build's store is not the one known here: the current game stays in localStorage (the rest still move)
      saves.liveRaw = true;
      if (saves.mem.has(LIVE_KEY)) { try { rawSetItem.call(localStorage, LIVE_KEY, saves.mem.get(LIVE_KEY)); saves.mem.delete(LIVE_KEY); saves.dirty.set(LIVE_KEY, null); } catch { /* stays in the database */ } }
      warn(L('이 게임 버전은 이어하기 세이브를 IndexedDB로 옮길 수 없어 localStorage에 둬요.',
        'This game version cannot move the current game to IndexedDB; it stays in localStorage.'));
      if (liveWasMarked && persist && typeof persist.rehydrate === 'function') { try { await persist.rehydrate(); saves.rehydrated = true; } catch { /* as it is */ } }
    } else if (liveWasMarked && persist && typeof persist.rehydrate === 'function') {
      try { await persist.rehydrate(); saves.rehydrated = true; } catch { /* as it is */ }
    }
    if (saves.on) {
      // a moment's play could still be on its way when the page goes: write it as soon as the page is hidden or left
      const now = () => { liveFlush(); };
      document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') now(); });
      window.addEventListener('pagehide', now);
      window.addEventListener('beforeunload', now);
      try { if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {}); } catch { /* not offered */ }
    }
    await saveFlush();
  }

  // ---------------------------------------------------------------- registry & loading
  const localText = v => (v && typeof v === 'object' && !Array.isArray(v) ? String(v[LANG()] || v.en || v.ko || Object.values(v)[0] || '') : v);
  function define(def) {
    if (def && probing.has(def.id)) { probing.set(def.id, def); return; }    // only checking that wml/mods/<id>/ exists
    if (!def || typeof def.id !== 'string' || !/^[a-z0-9][a-z0-9._-]*$/.test(def.id)) throw new Error('WML.define: id must be lower-case [a-z0-9._-]');
    if (typeof def.setup !== 'function') throw new Error(`WML.define(${def.id}): setup(api) is required`);
    if (defs.has(def.id)) warn(`defined twice; keeping the first`, def.id);
    else defs.set(def.id, { requires: [], loadAfter: [], loadBefore: [], conflicts: [], ...def,
      // name / description: a string, or { ko, en } for each game language (WML 0.8.0)
      name: localText(def.name), description: localText(def.description),
      // requiresVersion: { '<required mod id>': '>=1.6.0 <2' } — the versions of mods in `requires` it works with (0.8.0;
      // older loaders ignore it and still check `requires`)
      requiresVersion: def.requiresVersion && typeof def.requiresVersion === 'object' && !Array.isArray(def.requiresVersion) ? def.requiresVersion : {},
      roles: [].concat(def.role || def.roles || []).filter(r => typeof r === 'string' && r),
      platforms: [].concat(def.platform || def.platforms || []).filter(p => p === 'pc' || p === 'mobile'),
      // backup: { indexedDB: ['<database name>', …] } — databases this mod keeps data in; they go into WML backups
      backupDbs: [].concat((def.backup && def.backup.indexedDB) || []).filter(n => typeof n === 'string' && n),
      // lang: 'ko' | ['ko', …] — the game languages the mod is made for: on by default only there
      langs: [].concat(def.lang || def.langs || []).filter(l => typeof l === 'string' && /^[a-z]{2}$/.test(l)),
      // tags: ids from the fixed list (MOD_TAGS); author: who made it; pack: the bundle it ships in (0.9.0)
      tags: normTags(def.tags, def.id), author: normAuthor(def.author), pack: normPack(def.pack) });
  }

  /** tags from the fixed list only; anything else is left out and noted for the mod's author */
  function normTags(raw, id) {
    const out = [];
    for (const x of [].concat(raw || [])) {
      const t = typeof x === 'string' ? x.trim().toLowerCase() : '';
      if (!t || out.includes(t)) continue;
      if (MOD_TAGS[t]) out.push(t);
      else diag(L(`모르는 태그 "${x}" 제외 (사용 가능: ${Object.keys(MOD_TAGS).join(', ')})`, `Unknown tag "${x}" left out (known: ${Object.keys(MOD_TAGS).join(', ')})`), id);
    }
    return out;
  }
  const normAuthor = a => (typeof a === 'string' ? a.trim().slice(0, 80) : '');
  const normPack = p => (typeof p === 'string' && /^[a-z0-9][a-z0-9._-]*$/.test(p.trim()) ? p.trim() : '');

  // ---------------------------------------------------------------- compatibility data (wml/compat/compat.js)
  // Kept with the loader, never written into the mods: what a mod does not say about itself (the languages it is
  // made for, a job it shares with other mods) and notices about known problems in a mod version. A mod's own
  // declaration always wins over this file.
  let compatData = { mods: {}, notices: [] };
  function compat(data) {
    if (!data || typeof data !== 'object') return;
    compatData = { mods: data.mods && typeof data.mods === 'object' ? data.mods : {}, notices: Array.isArray(data.notices) ? data.notices : [] };
  }
  /** fill in what the mods left out (run once the mod files are read) */
  function applyCompat() {
    for (const [id, d] of defs) {
      const c = compatData.mods[id];
      if (!c || typeof c !== 'object') continue;
      if (!d.roles.length && c.role) { d.roles = [].concat(c.role).filter(r => typeof r === 'string' && r); d.rolesFrom = 'compat'; }
      if (!d.langs.length && c.lang) { d.langs = [].concat(c.lang).filter(l => typeof l === 'string' && /^[a-z]{2}$/.test(l)); d.langsFrom = 'compat'; }
      if (!d.tags.length && c.tags) { d.tags = normTags(c.tags, id); d.tagsFrom = 'compat'; }
      if (!d.author && c.author) { d.author = normAuthor(c.author); d.authorFrom = 'compat'; }
      if (!d.pack && c.pack) d.pack = normPack(c.pack);
    }
  }
  // "prompt" found automatically: a mod that hooks one of the image prompt functions. Running mods by the hooks they hold;
  // every mod (also the ones not running) by the api.hook calls in its setup code.
  // Reading every mod's code is the heavy part (a full pack: over 20 MB). 0.9.0 did it on every call before boot, and
  // WML.status() asks for every mod, so mods calling WML.status() while the game started stalled it about a second each
  // time (12 s with 208 listed mods). Now: before boot only the hooks held count; each mod's code is read once (kept per
  // mod), in idle moments after boot (warmPromptHits), and the full answer is kept once boot is over.
  const PROMPT_FNS = ['imagePrompt', 'promptJoin', 'promptRoomFilter', 'imageGenerate'];
  let promptFound = null;
  const promptHit = new Map();          // id -> its setup code hooks an image prompt function (read once)
  const promptNames = () => {
    const raws = new Set(PROMPT_FNS.map(n => { try { return resolve(n); } catch { return null; } }).filter(Boolean));
    return { raws, names: new Set([...PROMPT_FNS, ...raws]) };
  };
  const oldName = n => { try { const lg = globalThis.__WML_LEGACY__; return lg && typeof lg.name === 'function' ? lg.name(n) : null; } catch { return null; } };
  function setupHooksPrompt(id, names) {
    if (promptHit.has(id)) return promptHit.get(id);
    const d = defs.get(id);
    let src = '', hit = false;
    try { src = String(d && d.setup); } catch { /* not readable */ }
    // api.hook('imagePrompt', …), api.hook('r8', …), api.hook(raw('oldName'), …)
    if (src.includes('.hook(')) for (const m of src.matchAll(/\.hook\(\s*(?:['"`]([\w$]+)['"`]|[\w$.]+\(\s*['"`]([\w$]+)['"`]\s*\))/g)) {
      const n = m[1] || oldName(m[2]) || m[2];
      if (names.has(n)) { hit = true; break; }
    }
    promptHit.set(id, hit);
    return hit;
  }
  function promptMods() {
    if (promptFound) return promptFound;
    const found = new Set();
    const { raws, names } = promptNames();
    for (const raw of raws) {
      const h = hooks.get(raw);
      if (!h) continue;
      for (const k of ['before', 'around', 'after']) for (const x of h[k] || []) if (x && x.owner) found.add(x.owner);
      if (h.replace && h.replace.owner) found.add(h.replace.owner);
    }
    if (!state.booted) return found;    // the code reading waits until the game is up
    for (const id of defs.keys()) if (setupHooksPrompt(id, names)) found.add(id);
    promptFound = found;
    return found;
  }
  // after boot: the mods' code is read a few mods at a time while the page is idle, so the first look at the prompt
  // marks (the manager, a mod asking WML.status()) does not stall the game
  function warmPromptHits() {
    const idle = window.requestIdleCallback ? fn => window.requestIdleCallback(fn, { timeout: 2000 }) : fn => setTimeout(() => fn({ timeRemaining: () => 8 }), 50);
    const ids = [...defs.keys()].filter(id => !promptHit.has(id));
    const step = deadline => {
      const { names } = promptNames();
      do { const id = ids.shift(); if (id) setupHooksPrompt(id, names); } while (ids.length && deadline.timeRemaining() > 4);
      if (ids.length) idle(step);
    };
    if (ids.length) idle(step);
  }
  const touchesPrompt = id => !!(defs.get(id) && defs.get(id).tags.includes('prompt')) || promptMods().has(id);
  /** a mod other listed mods need ("requires"): shown as "기반" (base) in the manager, no tag needed */
  const isBase = id => state.listed.some(o => o !== id && defs.has(o) && defs.get(o).requires.includes(id));
  /** notices for this mod at the version that is here */
  function noticesFor(id) {
    const d = defs.get(id);
    const v = d && d.version != null ? String(d.version) : '';
    return compatData.notices.filter(n => n && n.mod === id && (!n.versions || n.versions === '*' || [].concat(n.versions).map(String).includes(v)));
  }
  const compatText = o => (o && typeof o === 'object' ? (o[LANG()] || o.en || o.ko || '') : String(o || ''));   // { ko, en } text of the compat file
  const LANG_NAMES = { ko: ['한국어', 'Korean'], en: ['영어', 'English'], ja: ['일본어', 'Japanese'], zh: ['중국어', 'Chinese'] };
  const langName = l => (LANG_NAMES[l] ? L(LANG_NAMES[l][0], LANG_NAMES[l][1]) : l);
  /**
   * Made for this game language? A mod that names its languages is on by default only in them (players can still
   * switch it on). A mod that needs such a mod follows it: its parent would not be on.
   */
  /** made for this game? A mod whose `game` names the other game (Wayward / Wayward: Faith) starts off here. */
  function gameFits(id, seen = new Set()) {
    if (seen.has(id)) return true;
    seen.add(id);
    const d = defs.get(id);
    if (!d) return true;
    const fam = d.game ? specFamily(d.game) : null;
    if (fam && fam !== GAME_FAMILY) return false;
    return d.requires.every(r => gameFits(r, seen));
  }
  function langFits(id, seen = new Set()) {
    if (seen.has(id)) return true;
    seen.add(id);
    const d = defs.get(id);
    if (!d) return true;
    if (d.langs.length && !d.langs.includes(LANG())) return false;
    return d.requires.every(r => langFits(r, seen));
  }

  /**
   * mods.js: list every mod (default order). "id:off" keeps it listed but switched off by default.
   * The folders are what counts: a listed mod whose folder is gone is skipped quietly (delete the folder = the
   * mod is gone), and folders registered by dropping them on the game load without a mods.js line.
   */
  function enable(list) {
    enableCalled = true;
    bootLog.enableAt = performance.now();
    state.listed = []; state.defaultOff = [];
    for (const raw of list || []) {
      if (typeof raw !== 'string') continue;
      const [id, flag] = raw.split(':');
      if (!id || state.listed.includes(id)) continue;
      state.listed.push(id);
      if (flag === 'off') state.defaultOff.push(id);
    }
    state.fromList = state.listed.slice();
    for (const id of lsGet(LS_FOLDERS, [])) if (/^[a-z0-9][a-z0-9._-]*$/.test(id) && !state.listed.includes(id)) state.listed.push(id);
    // The mod files are read once the page has its <body>. mods.js runs early in <head>, above the game's very large
    // inline script; a game opened as a file reads the mod files at once, while the browser is still parsing that
    // script, and a mod that touches document.body as soon as its file runs (a MutationObserver on it, say) would
    // throw before it reaches WML.define — "mod.js did not call WML.define", a different set on every reload.
    scriptLoads.push(bodyReady().then(() => {
      bootLog.bodyAt = performance.now();
      const loads = [];
      // the loader's compatibility data (an older package may not have it)
      loads.push(new Promise(resolve => {
        const s = document.createElement('script');
        s.src = COMPAT_FILE;
        s.async = false;
        const f = bootFile('(compat)', s);
        s.onload = () => { bootFileDone(f, 'ok'); resolve(); };
        s.onerror = () => { bootFileDone(f, 'none'); resolve(); };
        document.head.appendChild(s);
      }));
      // presets that come with the package (an older package has none)
      loads.push(new Promise(resolve => {
        const s = document.createElement('script');
        s.src = PRESET_FILE;
        s.async = false;
        const f = bootFile('(presets)', s);
        s.onload = () => { bootFileDone(f, 'ok'); resolve(); };
        s.onerror = () => { bootFileDone(f, 'none'); resolve(); };
        document.head.appendChild(s);
      }));
      // the files of the mods that start on are read now (a file only registers its mod; setup() runs at boot).
      // Mods switched off are read when the manager opens, which needs their names (0.9.1): before, every listed file
      // was read and run at start, also the off ones — over half of a full pack's code, for mods that do nothing.
      // A mod installed in the browser and a folder with the same id: the higher version runs (equal: the browser copy),
      // which loadInstalled decides — so the folder is not loaded here.
      const fromBrowser = installedIds();
      const t = toggles();
      for (const id of state.listed) {
        if (fromBrowser.includes(id)) continue;
        if (!startsOn(id, t)) { unread.add(id); continue; }
        loads.push(loadModFile(id));
      }
      loads.push(loadInstalled());
      loadFiles(loads);
      return Promise.all(loads);
    }));
  }
  /** a listed mod switched on by the player, or by mods.js when the player has not chosen (language aside) */
  const startsOn = (id, t) => (Object.prototype.hasOwnProperty.call(t, id) ? !!t[id] : !state.defaultOff.includes(id));
  /** read wml/mods/<id>/mod.js (it calls WML.define); resolves when it ran or turned out missing */
  function loadModFile(id) {
    return new Promise(resolve => {
      const s = document.createElement('script');
      s.src = `${MOD_ROOT}${id}/mod.js`;
      s.async = false;
      const f = state.booted ? null : bootFile(id, s);
      s.onload = () => { if (f) bootFileDone(f, 'ok'); resolve(); };
      s.onerror = () => { if (f) bootFileDone(f, 'none'); state.missing.push(id); resolve(); };   // no folder: not installed
      document.head.appendChild(s);
    });
  }
  /** read the files of these not-read-yet mods */
  function readMods(ids) {
    const todo = state.listed.filter(id => ids.includes(id) && unread.has(id));
    for (const id of todo) unread.delete(id);
    return Promise.all(todo.map(loadModFile));
  }
  /** folders that are gone: not part of this session; registered ones are forgotten for good */
  function dropMissing() {
    if (!state.missing.length) return;
    state.listed = state.listed.filter(id => !state.missing.includes(id));
    const reg = lsGet(LS_FOLDERS, []);
    if (reg.some(id => state.missing.includes(id))) lsSet(LS_FOLDERS, reg.filter(id => !state.missing.includes(id)));
  }
  // the mods switched off at start, read for the manager: once, all together (in list order), with a count to show
  let readingAll = null;
  const readCount = { done: 0, total: 0, show: null };
  function readAllMods() {
    if (readingAll) return readingAll;
    if (!unread.size) return Promise.resolve();
    const ids = state.listed.filter(id => unread.has(id));
    Object.assign(readCount, { done: 0, total: ids.length });
    for (const id of ids) unread.delete(id);
    readingAll = Promise.all(ids.map(id => loadModFile(id).then(() => { readCount.done++; if (readCount.show) readCount.show(); })))
      .then(() => {
        dropMissing();
        applyCompat();
        try { backupDecl(); } catch { /* storage off */ }
        promptFound = null;
        warmPromptHits();
      })
      .finally(() => { readingAll = null; });
    return readingAll;
  }
  /** resolves once document.body exists (at once if it already does) */
  function bodyReady() {
    if (document.body) return Promise.resolve();
    return new Promise(resolve => {
      const done = () => { if (!document.body) return; mo.disconnect(); resolve(); };
      const mo = new MutationObserver(done);
      mo.observe(document.documentElement, { childList: true });
      document.addEventListener('DOMContentLoaded', done, { once: true });
    });
  }

  // the symbols file sets the table once, before boot. A call without a table (from the console or a mod) or after the
  // mods are running would take every semantic name away from them mid-game (seen: WML.symbols() typed in the console)
  function symbols(table) {
    if (!table || typeof table !== 'object') { console.warn('[WML] WML.symbols() needs the table object; nothing changed'); return; }
    if (state.booted) { console.warn('[WML] WML.symbols(): the mods are running on the table already; nothing changed'); return; }
    state.symbols = table;
  }
  /**
   * Another version's table for this game: a name is kept when this game has it, as a function where the table says
   * function. A name this game lacks is left out (a mod using it says so) rather than pointed somewhere else.
   */
  function adoptSymbols(table, game) {
    const kept = {}, gone = [];
    for (const [k, v] of Object.entries(table.symbols || {})) {
      let val;
      try { val = v && v.name ? engine[v.name] : undefined; } catch { val = undefined; }
      if (val !== undefined && (v.kind !== 'function' || typeof val === 'function')) kept[k] = v; else gone.push(k);
    }
    state.symbols = { ...table, game, portedFrom: table.game, symbols: kept };
    console.info(`[WML] no symbol table for ${game}: ${table.game}'s names this game has (${Object.keys(kept).length}/${Object.keys(table.symbols || {}).length})`);
    if (gone.length) diag(L(`${game}용 심볼 표가 없어 ${table.game} 표를 썼어요. 이 게임에 없는 이름 ${gone.length}개: ${gone.join(', ')}`,
      `No symbol table for ${game}: used ${table.game}'s. ${gone.length} name(s) not in this game: ${gone.join(', ')}`));
  }

  // ---------------------------------------------------------------- mods installed in the browser
  // A browser cannot look inside folders, so mods in wml/mods need the mods.js list. Mods dropped on the
  // manager window (folder, zip or mod.js) are stored in IndexedDB instead and need no list at all.
  const IDB_NAME = 'wml', IDB_STORE = 'mods', LS_INSTALLED = 'wml.installed';
  const installed = new Map();                       // id -> record { id, name, version, files: { path: text|Blob } }
  const installedIds = () => lsGet(LS_INSTALLED, []);
  const TEXT_FILE = /\.(m?js|json|css|txt|md|csv|svg)$/i;
  const ID_RULE = /^[a-z0-9][a-z0-9._-]*$/;

  function idb() {
    return new Promise((resolve, reject) => {
      if (!window.indexedDB) { reject(new Error(L('이 브라우저는 IndexedDB를 쓸 수 없어요', 'this browser cannot use IndexedDB'))); return; }
      const r = indexedDB.open(IDB_NAME, 1);
      r.onupgradeneeded = () => r.result.createObjectStore(IDB_STORE, { keyPath: 'id' });
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    });
  }
  async function idbRun(mode, fn) {
    const db = await idb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(IDB_STORE, mode), q = fn(tx.objectStore(IDB_STORE));
      tx.oncomplete = () => resolve(q && q.result);
      tx.onerror = () => reject(tx.error);
    });
  }
  /** run code as a classic script (named for stack traces) */
  function runScript(code, name) {
    const s = document.createElement('script');
    s.textContent = `${code}\n//# sourceURL=${name}`;
    document.head.appendChild(s);
    s.remove();
  }

  let installedLoad = null;
  let stateImport = null;                            // mods coming in with a saves/settings file are written first
  function loadInstalled() {
    if (installedLoad) return installedLoad;
    installedLoad = Promise.resolve(stateImport).catch(() => {})
      .then(() => (installedIds().length ? idbRun('readonly', st => st.getAll()) : [])).then(async records => {
      for (const r of records || []) {
        if (!state.listed.includes(r.id)) state.listed.push(r.id);
        // the same mod also in wml/mods (a mod pack brought it, say): the higher version is the one that runs
        if (state.fromList.includes(r.id) || lsGet(LS_FOLDERS, []).includes(r.id)) {
          const folder = await probeFolder(r.id);
          if (folder && isNewer(folder.version, r.version)) {
            state.sourceNotes.push({ id: r.id, folder: folder.version, browser: r.version || '' });
            await new Promise(resolve => {
              const s = document.createElement('script');
              s.src = `${MOD_ROOT}${r.id}/mod.js`;
              s.onload = s.onerror = () => resolve();
              document.head.appendChild(s);
            });
            continue;
          }
        }
        installed.set(r.id, r);
        const code = r.files && r.files['mod.js'];
        if (typeof code !== 'string') { state.failed.push({ id: r.id, error: L('설치된 모드에 mod.js가 없어요', 'the installed mod has no mod.js') }); continue; }
        try { runScript(code, `wml-installed/${r.id}/mod.js`); } catch (e) { state.failed.push({ id: r.id, error: String(e && e.message || e) }); }
      }
      const have = (records || []).map(r => r.id);
      if (installedIds().some(id => !have.includes(id))) lsSet(LS_INSTALLED, have);   // storage was cleared: forget stale ids
    }).catch(e => warn(L(`브라우저에 설치한 모드를 읽지 못했어요: ${e.message}`, `Could not read the mods installed in the browser: ${e.message}`)));
    return installedLoad;
  }

  // ---- reading what was dropped / picked: entries { path, blob }
  async function unzip(file) {
    const buf = await file.arrayBuffer(), u8 = new Uint8Array(buf), dv = new DataView(buf);
    let end = -1;
    for (let i = u8.length - 22; i >= Math.max(0, u8.length - 65557); i--) if (dv.getUint32(i, true) === 0x06054b50) { end = i; break; }
    if (end < 0) throw new Error(L(`${file.name}: zip 파일이 아니에요`, `${file.name}: not a zip file`));
    const count = dv.getUint16(end + 10, true);
    let p = dv.getUint32(end + 16, true);
    const out = [];
    for (let n = 0; n < count; n++) {
      if (dv.getUint32(p, true) !== 0x02014b50) throw new Error(L(`${file.name}: zip 목록이 깨졌어요`, `${file.name}: the zip's file list is broken`));
      const flags = dv.getUint16(p + 8, true), method = dv.getUint16(p + 10, true), size = dv.getUint32(p + 20, true);
      const nameLen = dv.getUint16(p + 28, true), extraLen = dv.getUint16(p + 30, true), commentLen = dv.getUint16(p + 32, true), local = dv.getUint32(p + 42, true);
      const raw = u8.subarray(p + 46, p + 46 + nameLen);
      let name;
      try { name = new TextDecoder('utf-8', { fatal: !(flags & 0x800) }).decode(raw); } catch { name = new TextDecoder('euc-kr').decode(raw); }
      p += 46 + nameLen + extraLen + commentLen;
      name = name.replace(/\\/g, '/');   // Windows tools write "dir\sub\" although zip requires "/" — fix it before the folder check
      if (name.endsWith('/')) continue;
      const at = local + 30 + dv.getUint16(local + 26, true) + dv.getUint16(local + 28, true);
      const data = u8.subarray(at, at + size);
      let blob;
      if (method === 0) blob = new Blob([data]);
      else if (method === 8) blob = await new Response(new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).blob();
      else throw new Error(L(`${file.name}: 지원하지 않는 압축 방식이에요 (${method})`, `${file.name}: compression method not supported (${method})`));
      out.push({ path: name, blob });
    }
    return out;
  }
  /**
   * dropped items, including whole folders. Everything is taken inside the drop event (the items vanish afterwards).
   * A game opened as a file (file://) may not read inside dropped folders (the browser refuses with an
   * EncodingError), but plain files always work through getAsFile(). An unreadable folder comes back as
   * { dir: name } and is matched against wml/mods by its name.
   */
  function entriesFromDrop(dt) {
    const picked = [...(dt.items || [])].filter(it => it.kind === 'file')
      .map(it => ({ entry: it.webkitGetAsEntry && it.webkitGetAsEntry(), file: it.getAsFile() }));
    if (!picked.length) return Promise.resolve([...(dt.files || [])].map(f => ({ path: f.name, blob: f })));
    const fileOf = entry => new Promise((res, rej) => entry.file(res, rej));
    const visit = async (entry, prefix, out) => {
      if (entry.isFile) out.push({ path: prefix + entry.name, blob: await fileOf(entry) });
      else if (entry.isDirectory) {
        const reader = entry.createReader();
        for (let batch = await new Promise((res, rej) => reader.readEntries(res, rej)); batch.length; batch = await new Promise((res, rej) => reader.readEntries(res, rej))) {
          for (const e of batch) await visit(e, `${prefix}${entry.name}/`, out);
        }
      }
    };
    return (async () => {
      let out = [];
      for (const { entry, file } of picked) {
        if (!entry || !entry.isDirectory) {
          const blob = file || (entry && await fileOf(entry));
          if (blob) out.push({ path: blob.name, blob });
          continue;
        }
        const inside = [];
        try { await visit(entry, '', inside); out = out.concat(inside); }
        catch { out.push({ dir: entry.name }); }     // only the folder's name is known
      }
      return out;
    })();
  }

  /**
   * Wife add-ons made for the old mod manager — what character add-on generators write: a plain script that pushes a
   * wife into window.__WAYWARD_WIFE_ADDONS__ — have no WML.define. Each one found among the dropped files becomes a
   * mod of its own (wife-<shortname>/mod.js) that runs the file unchanged after the compatibility layer (addon-compat)
   * and registers the wife, the way the ported new-wife mods do. The generator's start-up portrait request is sent only
   * while the game's image server can draw, never to the default address on a hunch (as in newwife-miyabi's port fix).
   */
  async function wrapWifeAddons(entries) {
    const out = [];
    const modDirs = entries.filter(e => /(^|\/)mod\.js$/.test(e.path)).map(e => e.path.slice(0, -'mod.js'.length));
    for (const e of entries) {
      if (!/\.js$/i.test(e.path) || /(^|\/)mods?\.js$/i.test(e.path) || modDirs.some(b => e.path.startsWith(b))) continue;
      let code;
      try { code = await e.blob.text(); } catch { continue; }
      if (code.includes('WML.define') || !code.includes('__WAYWARD_WIFE_ADDONS__')) continue;
      const pick = key => { const m = code.match(new RegExp(`(?<![\\w$])["']?${key}["']?\\s*:\\s*(["'])((?:(?!\\1).)+)\\1`)); return m ? m[2] : ''; };
      const file = e.path.replace(/^.*\//, '');
      const short = (pick('shortname') || pick('id') || file.replace(/\.js$/i, '')).toLowerCase().replace(/[^a-z0-9._-]+/g, '-').replace(/^-+|-+$/g, '');
      const id = `wife-${short || 'addon'}`.slice(0, 60);
      const name = pick('name') || short;
      const body = code.replace(
        /const base = \(found \|\| \(prefs\.imageBackendMode === 'custom' && prefs\.imageBackendUrl\s*\?\s*prefs\.imageBackendUrl : 'http:\/\/127\.0\.0\.1:8189'\)\)\.replace\(\/\\\/\+\$\/, ''\);/,
        () => "if (!found || !(api.imageBackend?.()?.comfyui) || globalThis.__WW_STUDIO_OFFLINE_ONLY__ === true) return;\n    const base = found.replace(/\\/+$/, '');");
      const src = [
        L(`// ${name} — 옛 모드 매니저용 아내 애드온(${file})을 WML 모드 관리자가 감쌌어요. 원본 코드는 아래에서 그대로 실행돼요.`, `// ${name} — a wife add-on for the old mod manager (${file}), wrapped by the WML mod manager. The original code runs below unchanged.`),
        'WML.define({',
        `  id: ${JSON.stringify(id)},`,
        `  name: ${JSON.stringify(L(`새 아내: ${name}`, `New wife: ${name}`))},`,
        "  version: '1.0.0',",
        "  game: '>=2026-10-04',",
        `  description: ${JSON.stringify(L(`아내 선택지에 ${name}을(를) 추가해요 (아내 애드온 ${file}).`, `Adds ${name} to the wife choices (wife add-on ${file}).`))},`,
        "  requires: ['addon-compat'],",
        '  setup(__wmlApi) {',
        body,
        ';globalThis.__WML_LEGACY__.registerWives();',
        '  },',
        '});',
        '',
      ].join('\n');
      out.push({ path: `${e.path.replace(/[^/]*$/, '')}${id}/mod.js`, blob: new Blob([src], { type: 'text/javascript' }) });
    }
    return out;
  }

  /**
   * Install mods from files (File objects or { path, blob }): zip archives are opened, every folder that holds
   * a mod.js with WML.define becomes one mod — and so does each old-manager wife add-on (wrapWifeAddons).
   * Returns [{ id, name, version, files, replaced }].
   */
  async function install(items) {
    let entries = [];
    const dirs = [];                                                // dropped folders whose files could not be read
    for (const it of items) {
      if (it.dir) { dirs.push(it.dir); continue; }
      const blob = it.blob || it, path = it.path || blob.webkitRelativePath || blob.name || 'mod.js';
      // each zip gets its own folder in the merged list: two zips that both hold mod.js at their root
      // (one mod per zip, the usual shape) would otherwise land on the same path and only one would install
      if (/\.zip$/i.test(path)) { const home = path.replace(/\.zip$/i, '') + '/'; entries = entries.concat((await unzip(blob)).map(e => ({ ...e, path: home + e.path }))); }
      else entries.push({ path: path.replace(/\\/g, '/'), blob });
    }
    entries = entries.concat(await wrapWifeAddons(entries));
    const bases = entries.filter(e => /(^|\/)mod\.js$/.test(e.path)).map(e => e.path.slice(0, -'mod.js'.length));
    if (!bases.length && !dirs.length) throw new Error(L('mod.js 가 들어 있는 모드를 찾지 못했어요', 'no mod with a mod.js was found'));
    // a package may carry a symbol table it was made with (symbols/<game>.json): its names become the own names of
    // the mods in that package, so the shared table stays ours and other mods never see them
    const pkgTables = {};
    for (const e of entries.filter(x => /(^|\/)symbols\/\d{4}-\d{2}-\d{2}(?:-[a-z][a-z0-9.]*)?\.json$/.test(x.path))) {
      try {
        const t = JSON.parse(await e.blob.text()), game = t.game || e.path.match(/(\d{4}-\d{2}-\d{2}(?:-[a-z][a-z0-9.]*)?)\.json$/)[1];
        const map = {};
        const ours = game === state.game && state.symbols && state.symbols.game === game ? state.symbols.symbols || {} : {};
        for (const [n, v] of Object.entries(t.symbols || {})) if (v && typeof v.name === 'string' && !(ours[n] && ours[n].name === v.name)) map[n] = v.name;
        if (Object.keys(map).length) pkgTables[game] = map;
      } catch { /* not a symbol table */ }
    }
    const rememberPkgSymbols = id => {
      const all = lsGet(LS_PKGSYMS, {});
      if (Object.keys(pkgTables).length) all[id] = pkgTables; else delete all[id];
      lsSet(LS_PKGSYMS, all);
    };
    // a mod pack carries its own mods.js: follow its order and its "id:off" defaults
    const listEntry = entries.find(e => /(^|\/)mods\.js$/.test(e.path));
    const packList = listEntry ? [...(await listEntry.blob.text()).matchAll(/^\s*"([^":]+)(:off)?"/gm)].map(m => ({ id: m[1], off: !!m[2] })) : [];
    const done = [];
    // already a folder in wml/mods? then only remember its name — the folder stays the source of truth
    // (delete the folder and the mod is gone); no copy goes into the browser
    const keepFolder = async (id, name, version, listed, folderVersion) => {
      if (!state.fromList.includes(id)) lsSet(LS_FOLDERS, [...new Set([...lsGet(LS_FOLDERS, []), id])]);
      const hadCopy = installedIds().includes(id);
      if (hadCopy) await removeCopy(id);
      const t = toggles(); t[id] = !(listed && listed.off); lsSet(LS_TOGGLES, t);
      // the folder stays the source of truth — but say so when what was dropped is a different version of it,
      // or the player thinks they updated the mod and nothing changed
      const stale = version && folderVersion && version !== folderVersion
        ? L(`폴더 버전(${folderVersion})을 그대로 써요 (넣은 버전 ${version}). 바꾸려면 wml\\mods\\${id} 폴더를 덮어써 주세요.`, `Keeping the folder version (${folderVersion}; dropped ${version}). To replace it, overwrite the wml\\mods\\${id} folder.`)
        : '';
      return { id, name, version: folderVersion || version, mode: 'folder', replaced: hadCopy, on: t[id], note: stale };
    };
    for (const base of bases) {
      const code = await entries.find(e => e.path === `${base}mod.js`).blob.text();
      const at = code.indexOf('WML.define');
      if (at < 0) continue;                                         // not a WML mod (e.g. an old add-on)
      const field = k => { const m = code.slice(at).match(new RegExp(`\\b${k}\\s*:\\s*(['"\`])(.*?)\\1`)); return m ? m[2] : ''; };
      const id = field('id') || base.replace(/\/$/, '').split('/').pop();
      if (!ID_RULE.test(id)) throw new Error(L(`모드 id "${id}" 가 규칙(소문자·숫자·.-_)에 맞지 않아요`, `mod id "${id}" breaks the rule (lower-case letters, digits, . - _)`));
      const listed = packList.find(l => l.id === id);
      rememberPkgSymbols(id);
      const folder = await probeFolder(id);
      // the folder copy stays in use unless what was dropped is a higher version: then the dropped one goes into the
      // browser and runs instead (a browser copy runs over an older folder) — dropping a newer zip is an update
      if (folder && !isNewer(field('version'), folder.version)) {
        done.push(await keepFolder(id, field('name') || id, field('version'), listed, folder.version));
        continue;
      }
      // this mod's files: everything under its folder, except folders of other mods inside it
      const inner = bases.filter(b => b !== base && b.startsWith(base));
      const files = {};
      let size = 0;
      for (const e of entries) {
        if (!e.path.startsWith(base) || inner.some(b => e.path.startsWith(b))) continue;
        const rel = e.path.slice(base.length);
        files[rel] = TEXT_FILE.test(rel) ? await e.blob.text() : e.blob;
        size += e.blob.size;
      }
      const replaced = installedIds().includes(id);
      await idbRun('readwrite', st => st.put({ id, name: field('name') || id, version: field('version'), files, size, installedAt: Date.now() }));
      lsSet(LS_INSTALLED, [...new Set([...installedIds(), id])]);
      const t = toggles(); t[id] = !(listed && listed.off); lsSet(LS_TOGGLES, t);   // a mod you just added is on, unless its pack says off
      const overFolder = folder ? L(`폴더 버전(${folder.version || '?'})보다 새 버전(${field('version')})이라 설치했어요. 되돌리려면 [삭제].`,
        `Newer than the folder version (${folder.version || '?'}), so ${field('version')} was installed. [Delete] to go back.`) : '';
      done.push({ id, name: field('name') || id, version: field('version'), mode: 'browser', files: Object.keys(files).length, size, replaced, on: t[id], note: overFolder });
    }
    // a folder known only by its name (game opened as a file): it counts if wml/mods/<name>/ is there
    const unread = [];
    for (const name of dirs) {
      const def = ID_RULE.test(name) && await probeFolder(name);
      if (def) done.push(await keepFolder(name, def.name || name, def.version || '', packList.find(l => l.id === name), def.version || ''));
      else unread.push(name);
    }
    if (unread.length) {
      const msg = L(`"${unread.join('", "')}" 폴더를 읽지 못했어요. zip으로 끌어다 놓거나 [폴더 고르기]를 써 주세요.`,
      `Could not read the folder "${unread.join('", "')}". Drop it as a zip or use [Pick folder].`);
      if (!done.length) throw new Error(msg);
      done.skipped = msg;
    }
    if (!done.length) throw new Error(L('WML 모드가 아니에요 (WML.define 없음). 옛 애드온은 WML 모드로 변환해야 해요.', 'Not a WML mod (no WML.define). Old add-ons need converting to WML mods first.'));
    if (packList.length) {
      const ids = packList.map(l => l.id).filter(id => done.some(d => d.id === id));
      lsSet(LS_ORDER, [...lsGet(LS_ORDER, []).filter(id => !ids.includes(id)), ...ids]);
    }
    return done;
  }

  /** does wml/mods/<id>/mod.js exist? (loads it once with its define() only recorded) → its definition, or false */
  function probeFolder(id) {
    return new Promise(resolve => {
      probing.set(id, null);
      const s = document.createElement('script');
      const done = ok => { const def = probing.get(id); probing.delete(id); s.remove(); resolve(ok && (def || {})); };
      s.onload = () => done(true);
      s.onerror = () => done(false);
      s.src = `${MOD_ROOT}${id}/mod.js`;
      document.head.appendChild(s);
    });
  }
  async function removeCopy(id) {
    await idbRun('readwrite', st => st.delete(id));
    lsSet(LS_INSTALLED, installedIds().filter(x => x !== id));
  }

  /**
   * Delete a mod from the browser: an installed copy is removed from storage, a registered folder is forgotten,
   * and the mod's leftovers in web storage go too (on/off, order, its settings, window positions).
   * Files on disk cannot be touched from a browser: a folder in wml/mods has to be deleted by hand.
   */
  async function uninstall(id) {
    const hadCopy = installedIds().includes(id);
    if (hadCopy) await removeCopy(id);
    // a browser copy that ran over an older folder of the same mod: with the copy gone the folder runs again, so its
    // registration stays
    const folderBack = hadCopy && lsGet(LS_FOLDERS, []).includes(id) && await probeFolder(id);
    if (!folderBack) lsSet(LS_FOLDERS, lsGet(LS_FOLDERS, []).filter(x => x !== id));
    const t = toggles(); delete t[id]; lsSet(LS_TOGGLES, t);       // back to the default of a same-named folder mod
    lsSet(LS_ORDER, lsGet(LS_ORDER, []).filter(x => x !== id));
    lsDel(`wml.mod.${id}`);
    const pkg = lsGet(LS_PKGSYMS, {});
    if (pkg[id]) { delete pkg[id]; lsSet(LS_PKGSYMS, pkg); }
    try { for (const k of Object.keys(localStorage)) if (k.startsWith(`wml.win.${id}:`)) localStorage.removeItem(k); } catch { /* storage off */ }
    return { removed: id };
  }

  // player choices ------------------------------------------------------------------------------
  function toggles() {
    let t = lsGet(LS_TOGGLES, null);
    if (!t) {                                   // carry over the old "disabled" list once
      t = {};
      for (const id of lsGet(LS_OLD_DISABLED, [])) t[id] = false;
      if (Object.keys(t).length) { lsSet(LS_TOGGLES, t); lsDel(LS_OLD_DISABLED); }
    }
    return t;
  }
  // the player's choice, else the list's default ("id:off"), else off where the mod is not made for the game's language
  const isOn = (id, t = toggles()) => (Object.prototype.hasOwnProperty.call(t, id) ? !!t[id] : !state.defaultOff.includes(id) && langFits(id) && gameFits(id));
  /** listed mods in the player's order (new mods keep their mods.js position at the end) */
  function playerOrder() {
    const saved = lsGet(LS_ORDER, []).filter(id => state.listed.includes(id));
    return [...saved, ...state.listed.filter(id => !saved.includes(id))];
  }

  // dependency order: requires/loadAfter go first, loadBefore after; notes say what was moved.
  // `requires` has to hold: a mod set up before a mod it needs does not start. loadAfter/loadBefore only ask, so when
  // the conditions go round in a circle one of those is given up — one the list order disagrees with too, if there is
  // one — and the sort starts over (0.9.1). Before, the circle was cut wherever the walk met it, sometimes at a
  // `requires` (seen: imagestudio-multiwoman_images requires imagestudio, and six loadAfter/loadBefore of five other
  // mods led back round to it, so it did not start).
  function sortMods(ids, notes = []) {
    const want = new Set(ids), pos = new Map(ids.map((id, i) => [id, i]));
    const dropped = new Map();          // 'dep>id' -> its note, for asks given up to open a circle
    const depsOf = id => {              // [dep, required?]: what has to come before id
      const d = defs.get(id), out = new Map();
      for (const r of d.requires) out.set(r, true);
      for (const r of d.loadAfter) if (!out.has(r)) out.set(r, false);
      for (const o of ids) if (!out.has(o) && defs.get(o).loadBefore.includes(id)) out.set(o, false);
      return [...out].filter(([dep, hard]) => want.has(dep) && dep !== id && (hard || !dropped.has(`${dep}>${id}`)));
    };
    const chainText = ring => ring.map(nameOf).join(' → ');
    for (let round = 0; ; round++) {
      const order = [], mark = new Map(), stack = [], hardTo = [], said = [];
      let again = false;
      const visit = (id, hardIn) => {      // hardIn: id is required by the mod that led here
        mark.set(id, 1); stack.push(id); hardTo.push(hardIn);
        for (const [dep, hard] of depsOf(id)) {
          if (again) return;
          if (mark.get(dep) === 2) continue;
          if (mark.get(dep) === 1) {
            // a circle: stack[j] … id, closed by "dep before id". Each step is [first, then, required?]
            const j = stack.indexOf(dep), top = stack.length - 1;
            const steps = [[dep, id, hard]];
            for (let k = j + 1; k <= top; k++) steps.push([stack[k], stack[k - 1], hardTo[k]]);
            const soft = steps.filter(s => !s[2]);
            const pick = soft.find(s => pos.get(s[0]) > pos.get(s[1])) || soft[0];
            const ring = [dep, ...stack.slice(j + 1).reverse(), dep];
            if (pick && round < ids.length * 4) {          // (the bound only guards against a loop)
              dropped.set(`${pick[0]}>${pick[1]}`, { id: pick[1], msg: L(`순서 조건 순환(${chainText(ring)}): ${nameOf(pick[0])} → ${nameOf(pick[1])} 무시`,
                `Load-order loop (${chainText(ring)}): ${nameOf(pick[0])} → ${nameOf(pick[1])} ignored`) });
              again = true;
              return;
            }
            said.push({ id, msg: pick ? L(`순서 조건 순환(${chainText(ring)}): 목록 순서대로 둬요`, `Load-order loop (${chainText(ring)}): list order kept`)
              : L(`requires 순환(${chainText(ring)}): 모드 수정 필요`,
                `requires loop (${chainText(ring)}): the mods need fixing`) });
            continue;
          }
          if (pos.get(dep) > pos.get(id)) said.push({ id, msg: L(`필요한 모드 ${nameOf(dep)} 뒤로 옮겼어요`, `Moved after ${nameOf(dep)}, which it needs`) });
          visit(dep, hard);
          if (again) return;
        }
        mark.set(id, 2); stack.pop(); hardTo.pop();
        order.push(id);
      };
      for (const id of ids) { if (!mark.has(id)) visit(id, true); if (again) break; }
      if (again) continue;
      notes.push(...said, ...dropped.values());
      return order;
    }
  }
  const nameOf = id => (defs.get(id) && defs.get(id).name) || id;
  // roles: mods that do the same job may run together (players choose), but the manager says so
  const ROLE_LABELS = {
    'hotkeys': ['단축키', 'hotkeys'], 'hall-staff': ['홀 직원', 'hall staff'], 'custom-guests': ['사용자 손님', 'custom guests'], 'image-variants': ['장면별 그림 수', 'images per scene'],
    'character-look': ['아내 외형 태그', 'wife look tags'], 'scene-prompt': ['장면·의상 태그', 'scene & outfit tags'], 'aftermath-look': ['정사 후 모습', 'aftermath look'], 'cheat-editor': ['수치 편집', 'stat editing'],
    'stats': ['통계', 'statistics'], 'theme': ['화면 테마', 'screen theme'], 'music': ['배경음악', 'music'], 'save-format': ['세이브 저장 방식', 'save format'], 'layout': ['화면 배치', 'screen layout'],
    'pregnancy-link': ['H Status → 임신 연결', 'H Status → pregnancy link'], 'guidance-fix': ['남편 방침 대화 시간 초과 고침', 'guidance timeout fix'],
    'tavern-capacity': ['주점 수용 인원', 'tavern capacity'], 'sound-effects': ['효과음·음성', 'sound effects'],
  };
  const roleLabel = r => (ROLE_LABELS[r] ? L(...ROLE_LABELS[r]) : r);
  /** other mods in ids that share a role with id: [{ role, ids }] */
  function roleMates(id, ids) {
    const d = defs.get(id);
    if (!d || !d.roles.length) return [];
    return d.roles.map(role => ({ role, ids: ids.filter(o => o !== id && defs.has(o) && defs.get(o).roles.includes(role)) })).filter(x => x.ids.length);
  }

  // ---------------------------------------------------------------- presets
  // A preset is the list of mods to switch on, in load order — nothing else (mod settings stay as they are).
  // The file form (what Export writes, what can be dropped on the game or put in wml/presets/presets.js):
  //   { "type": "wml-preset", "version": 1, "name": "…", "description": "…", "game": "2026-10-04", "wml": "0.8.0",
  //     "mods": [ { "id": "addon-compat", "version": "2.1.1" }, "hooker", … ] }
  // Applying one switches its mods on in its order and every other listed mod off. Mods it names that are not here are
  // reported ("모드 파일을 찾을 수 없어요") and the rest is applied all the same.
  const bundledPresets = [];             // from wml/presets/presets.js
  const presetKey = name => String(name || '').trim().toLowerCase().replace(/[^a-z0-9ㄱ-힝._-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60) || 'preset';
  function normPreset(raw) {
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error(L('프리셋 파일이 아니에요', 'not a preset file'));
    if (raw.storage && typeof raw.storage === 'object') throw new Error(L('세이브·설정 백업 파일이에요. "옮기기·백업"에서 가져와 주세요', 'This is a saves & settings backup. Import it under "Move & back up"'));
    if (raw.type && raw.type !== 'wml-preset') throw new Error(L(`프리셋 파일이 아니에요 (type: ${raw.type})`, `not a preset file (type: ${raw.type})`));
    if (!Array.isArray(raw.mods)) throw new Error(L('프리셋에 mods 목록이 없어요', 'the preset has no mods list'));
    const mods = [], seen = new Set();
    for (const m of raw.mods) {
      if (typeof m === 'string' && /:off$/.test(m)) continue;          // a line copied from mods.js that is off
      const id = typeof m === 'string' ? m.replace(/:on$/, '') : m && typeof m.id === 'string' ? m.id : '';
      if (!/^[a-z0-9][a-z0-9._-]*$/.test(id) || seen.has(id)) continue;
      seen.add(id);
      mods.push(m && typeof m === 'object' && m.version != null && String(m.version) ? { id, version: String(m.version) } : { id });
    }
    const name = String(localText(raw.name) || '').trim().slice(0, 80) || L('이름 없는 프리셋', 'Unnamed preset');
    return { type: 'wml-preset', version: 1, key: typeof raw.key === 'string' && raw.key ? presetKey(raw.key) : presetKey(name), name,
      description: String(localText(raw.description) || '').slice(0, 500), game: typeof raw.game === 'string' ? raw.game : '', wml: typeof raw.wml === 'string' ? raw.wml : '', mods };
  }
  /** wml/presets/presets.js: WML.presets([ preset, … ]) */
  function presets(list) {
    for (const raw of [].concat(list || [])) {
      try {
        const p = normPreset(raw);
        if (!bundledPresets.some(b => b.key === p.key)) bundledPresets.push(p);
      } catch (e) { console.warn('[WML] presets.js:', e.message); }
    }
  }
  const userPresets = () => {
    const all = lsGet(LS_PRESETS, {});
    return Object.values(all && typeof all === 'object' ? all : {}).map(p => { try { return normPreset(p); } catch { return null; } }).filter(Boolean);
  };
  /** keeps a preset in this browser (a preset with the same name is replaced) → its key */
  function saveUserPreset(p) {
    const all = lsGet(LS_PRESETS, {});
    const key = presetKey(p.name);
    all[key] = { ...p, key };
    lsSet(LS_PRESETS, all);
    return key;
  }
  function deleteUserPreset(key) {
    const all = lsGet(LS_PRESETS, {});
    delete all[key];
    lsSet(LS_PRESETS, all);
  }
  const modEntry = id => (defs.get(id) && defs.get(id).version ? { id, version: String(defs.get(id).version) } : { id });
  /** the mods that are on now, in load order, as a preset */
  function presetFromCurrent(name, description = '') {
    const t = toggles();
    return normPreset({ type: 'wml-preset', name, description, game: state.game || '', wml: VERSION, mods: playerOrder().filter(id => isOn(id, t) && defs.has(id)).map(modEntry) });
  }
  /** what mods.js switches on by default, as a preset */
  function presetFromList() {
    return normPreset({ type: 'wml-preset', name: L('mods.js 기본값', 'mods.js defaults'), game: state.game || '', wml: VERSION,
      mods: state.listed.filter(id => defs.has(id) && !state.defaultOff.includes(id) && langFits(id) && gameFits(id)).map(modEntry) });
  }
  /** listed here: read, or switched off at start and not read yet */
  const known = id => defs.has(id) || unread.has(id);
  /** what applying a preset would do here */
  function presetCheck(p) {
    const ids = p.mods.map(m => m.id);
    const present = ids.filter(known);
    const missing = ids.filter(id => !known(id));
    const versions = p.mods.filter(m => m.version && defs.has(m.id) && defs.get(m.id).version != null && String(defs.get(m.id).version) !== m.version)
      .map(m => ({ id: m.id, want: m.version, have: String(defs.get(m.id).version) }));
    const needs = [], conflicts = [];
    for (const id of present) {
      const d = defs.get(id);
      if (!d) continue;                  // not read yet: what it needs is not known here
      const lack = d.requires.filter(r => !present.includes(r));
      if (lack.length) needs.push({ id, lack });
      for (const c of d.conflicts) if (present.includes(c) && !conflicts.some(([a, b]) => a === c && b === id)) conflicts.push([id, c]);
    }
    const notes = [];
    sortMods(present.filter(id => defs.has(id)), notes);
    return { present, missing, versions, needs, conflicts, notes, off: state.listed.filter(id => known(id) && !present.includes(id)) };
  }
  /** switch the preset's mods on in its order and the rest off (applies after a reload) → presetCheck */
  function applyPreset(p, source) {
    const c = presetCheck(p);
    const t = {};
    for (const id of state.listed) t[id] = false;
    for (const id of c.present) t[id] = true;
    lsSet(LS_TOGGLES, t);
    lsSet(LS_ORDER, [...c.present, ...playerOrder().filter(id => !c.present.includes(id))]);
    lsSet(LS_PRESET_NOW, { key: `${source}:${p.key}`, name: p.name, mods: c.present, missing: c.missing, at: Date.now() });
    return c;
  }
  /** has the on/off or order changed since the last preset was applied? */
  function presetChanged(now) {
    if (!now || !Array.isArray(now.mods)) return false;
    const t = toggles();
    return playerOrder().filter(id => isOn(id, t) && known(id)).join('|') !== now.mods.filter(known).join('|');
  }

  // ---------------------------------------------------------------- symbols & hooks
  function resolve(name) {
    const sym = state.symbols && state.symbols.symbols && state.symbols.symbols[name];
    if (sym) return sym.name;
    if (engine && Object.prototype.hasOwnProperty.call(engine, name)) return name;  // raw minified name
    throw new Error(L(`이 게임(${state.game})에 없는 이름 "${name}" — 로더나 모드 업데이트가 필요해요. [unknown symbol "${name}" for game ${state.game}]`,
      `No name "${name}" for this game (${state.game}) — update the loader or the mod. [unknown symbol "${name}" for game ${state.game}]`));
  }

  function getHook(raw) {
    let h = hooks.get(raw);
    if (h) return h;
    const orig = engine[raw];
    if (typeof orig !== 'function') throw new Error(`${raw} is not a function`);
    h = { raw, orig, before: [], around: [], after: [], replace: null, frames: [], calls: 0 };
    const dispatcher = function (...args) { h.calls++; return runHook(h, this, args); };
    dispatcher.__wmlOriginal = orig;
    h.dispatcher = dispatcher;
    try { engine[raw] = dispatcher; } catch { throw new Error(`${raw} is a const and cannot be hooked`); }
    if (engine[raw] !== dispatcher) throw new Error(`${raw} could not be replaced`);
    hooks.set(raw, h);
    return h;
  }

  // A mod assigned the function directly after it was hooked, so the game now calls that mod's function instead of
  // the hooks. Nothing is put back — that would drop the other mod's wrapper, and taking it in as the "original"
  // loops when it calls the dispatcher it replaced. Most such mods pass the call on (the hooks still run), which the
  // loader cannot see from here: a diagnostic, once per function. The manager shows how often the hooks ran since.
  function checkDrift(h) {
    let now;
    try { now = engine[h.raw]; } catch { return; }
    if (now === h.dispatcher || h.driftWarned) return;
    h.driftWarned = true;
    const who = [...new Set([...h.before, ...h.around, ...h.after].map(e => e.owner).concat(h.replace ? [h.replace.owner] : []))].join(', ');
    diag(L(`${h.raw}: 다른 모드가 WML 밖에서 교체함 (${who} 훅이 빠질 수 있어요)`,
      `${h.raw}: replaced outside WML by another mod (${who}'s hooks may be skipped)`), null, h.raw);
  }

  // a replacement called back into its own function this many times over is looping, not recursing
  const REENTRY_MAX = 4;
  const sameArgs = (a, b) => a.length === b.length && a.every((v, i) => v === b[i]);

  function runHook(h, self, args) {
    // Called back from inside this function's replacement. With the same arguments, the replacing mod is passing
    // the call on to what it kept as "the original" — this dispatcher, when another mod had hooked the function
    // first. Running the hooks again would loop back into the replacement forever (rival_tavern after badguest
    // froze the game), so it gets the game's original, as it would have without the other mod.
    // With other arguments it is usually the game's own function calling itself (work_in_tavern), which gets
    // every hook again; a replacement that keeps coming back with new arguments is cut off after a few rounds.
    const top = h.frames[h.frames.length - 1];
    if (top && top.replace) {
      if (sameArgs(top.args, args)) return callOrig(h, self, args);
      if (h.frames.filter(f => f.replace).length >= REENTRY_MAX) {
        if (!h.loopWarned) {
          h.loopWarned = true;
          warn(L(`${h.raw} 무한 반복을 막고 원래 함수로 돌렸어요. 모드 제작자에게 알려 주세요.`,
            `${h.raw} looped endlessly; the game's own function was used instead. Tell the mod author.`), h.replace.owner);
        }
        return callOrig(h, self, args);
      }
    }
    for (const b of h.before) {
      try {
        const r = diagCall(b, () => b.fn.call(self, args));
        if (r && r.cancel) return r.value;     // before(args) => ({ cancel:true, value })
        if (Array.isArray(r)) args = r;        // or return replacement args
      } catch (e) { reportHookError(b, e); }
    }
    let call = (...a) => {
      if (!h.replace) return callOrig(h, self, a);
      h.frames.push({ replace: true, args: a });
      try { return diagCall(h.replace, () => h.replace.fn.apply(self, a)); } finally { h.frames.pop(); }
    };
    for (const w of h.around) {
      const inner = call;
      call = (...a) => {
        // What the hook passes on is remembered: if the hook throws after the rest of the chain (and the game's own
        // function) already ran, that work is not done a second time — its result stands. An error that came from
        // the rest of the chain itself is the caller's to see, as it would be without this hook, and is not retried.
        let ran = false, out, failed = false, err;
        // timed for the diagnostics log as this hook's own work: the rest of the chain it passes on to is not counted
        const outer = diagNow, t0 = performance.now();
        let innerMs = 0;
        const next = (...b) => {
          ran = true;
          const ti = performance.now();
          diagNow = outer;
          try { out = inner(...b); failed = false; return out; } catch (e) { failed = true; err = e; throw e; } finally { diagNow = w; innerMs += performance.now() - ti; }
        };
        diagNow = w;
        try { return w.fn.call(self, next, ...a); }
        catch (e) {
          if (ran && failed) { if (e !== err) reportHookError(w, e); throw err; }
          reportHookError(w, e);
          if (ran) return out;
          diagNow = outer;
          return inner(...a);   // threw before passing on: the rest of the chain still runs, once
        } finally {
          diagNow = outer;
          const ms = performance.now() - t0 - innerMs;
          if (ms >= 20) diagTimed(w, t0, ms);
        }
      };
    }
    let result = call(...args);
    for (const af of h.after) {
      try { const r = diagCall(af, () => af.fn.call(self, result, args)); if (r !== undefined) result = r; } catch (e) { reportHookError(af, e); }
    }
    return result;
  }

  // the game's own function; when it calls itself (work_in_tavern does), that is a fresh call with all the hooks
  function callOrig(h, self, args) {
    h.frames.push({ replace: false });
    try { return h.orig.apply(self, args); } finally { h.frames.pop(); }
  }

  function reportHookError(entry, e) {
    if (entry.errors++ < 3) console.error(`[WML] hook ${entry.where} from ${entry.owner} threw`, e);
    if (entry.errors === 3) warn(`hook ${entry.where} keeps throwing; further errors hidden`, entry.owner);
  }

  // hooks run in load order: a mod loaded later wraps around the earlier ones
  const loadIndex = owner => { const i = state.order.indexOf(owner); return i < 0 ? 1e6 : i; };
  function addHook(owner, name, spec, raw = resolve(name)) {
    const existed = hooks.has(raw);
    const h = getHook(raw);
    if (existed) checkDrift(h);
    const added = [];
    const prio = (spec && spec.priority) || 0;
    const push = (list, fn, kind) => {
      const entry = { fn, owner, prio, where: `${kind}:${name}`, errors: 0 };
      list.push(entry);
      list.sort((x, y) => (y.prio - x.prio) || (loadIndex(x.owner) - loadIndex(y.owner)));
      added.push([list, entry]);
    };
    if (spec.before) push(h.before, spec.before, 'before');
    if (spec.around) push(h.around, spec.around, 'around');
    if (spec.after) push(h.after, spec.after, 'after');
    if (spec.replace) {
      if (h.replace) throw new Error(`replace conflict on ${name}: ${h.replace.owner} vs ${owner}`);
      h.replace = { fn: spec.replace, owner, where: `replace:${name}` };
      // Another mod had changed this function outside WML before it was first hooked (assigned it directly), so that
      // change is what this hook sees as "the original". It still runs when the replacement passes the call on
      // (through the function or what it kept of it) — rival_tavern does — and not when it does not; the loader
      // cannot tell which from here: a diagnostic.
      const game = pristine.get(raw);
      if (game && h.orig !== game) {
        diag(L(`${name}: WML 밖에서 바뀐 함수를 다시 교체해요`,
          `${name}: replaces a function another mod changed outside WML`), owner, raw);
      }
    }
    const undo = () => { for (const [list, e] of added) { const i = list.indexOf(e); if (i >= 0) list.splice(i, 1); } if (h.replace && h.replace.owner === owner) h.replace = null; };
    if (setupTrack && setupTrack.id === owner) setupTrack.undo.push(undo);
    return undo;
  }

  // ---------------------------------------------------------------- mod symbols
  // WML.define({ symbols: { name: { raw: { "<game>": "<minified>" }, find: <recipe>, aliases, optional, doc } } })
  // gives a mod its own names. The name recorded for this game wins; otherwise the recipe finds the binding
  // again, with the same rules as tools/symbols-lib.mjs matchRecipe (keep the two in step):
  //   functions: all/any features + like pattern on fn.toString(); len = size sanity; refs = sub-recipes
  //   for what a tiny function calls; "@name@" in a pattern = that binding's minified name
  //   other bindings: decl = regex over the game module text (group 1 = the name); value = a plain value
  const LS_SYMCACHE = 'wml.symcache';
  const modSyms = new Map();              // mod id -> { name: raw } for this game
  const provided = new Map();             // mod id -> what it shared with api.provide (a parent mod's API)
  let symCtx = null;                      // engine snapshot for recipes, taken before any mod ran
  const reEsc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const symHash = s => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0).toString(36); };
  function modSymbolFeature(feat) {
    if (feat[0] === '#') return new RegExp(`(?<![\\w$.])${reEsc(feat.slice(1))}(?![\\w$])`);
    if (feat[0] === '.') return new RegExp(`${reEsc(feat)}(?![\\w$])`);
    if (feat.endsWith(':')) return new RegExp(`(?<![\\w$.])${reEsc(feat)}`);
    return new RegExp(reEsc(feat));
  }
  function symContext() {
    if (symCtx) return symCtx;
    const fns = new Map(), values = new Map();
    for (const k of Object.keys(engine)) {
      let v;
      try { v = engine[k]; } catch { continue; }                 // not initialised yet
      if (typeof v === 'function') {
        const h = hooks.get(k);
        try { fns.set(k, Function.prototype.toString.call(h ? h.orig : v)); } catch { /* not readable */ }
      } else if (v === null || typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean') values.set(k, v);
    }
    const script = document.querySelector('script[type="module"]');
    symCtx = { fns, values, module: (script && script.textContent) || '' };
    return symCtx;
  }
  /** minified names a recipe finds (names: semantic name -> minified, for "@name@") */
  function modSymbolMatch(recipe, ctx, names) {
    if (recipe.refs) {
      names = Object.assign({}, names);
      for (const k of Object.keys(recipe.refs)) { const m = modSymbolMatch(recipe.refs[k], ctx, names); if (m.length !== 1) return []; names[k] = m[0]; }
    }
    let missing = false;
    const bind = p => p.replace(/@([A-Za-z_$][\w$]*)@/g, (m, n) => (names[n] ? reEsc(names[n]) : ((missing = true), m)));
    if (recipe.decl) {
      const src = bind(recipe.decl);
      if (missing || !ctx.module) return [];
      const out = new Set(), rx = new RegExp(src, 'g');
      for (let m = rx.exec(ctx.module); m; m = rx.exec(ctx.module)) { if (Object.prototype.hasOwnProperty.call(engine, m[1])) out.add(m[1]); if (!m[0].length) rx.lastIndex++; }
      return [...out];
    }
    if ('value' in recipe) return [...ctx.values].filter(([, v]) => v === recipe.value).map(([k]) => k);
    const like = recipe.like ? bind(recipe.like) : null;
    if (missing) return [];
    const tests = (recipe.all || []).map(modSymbolFeature);
    const re = like ? new RegExp(`^(?:${like})$`) : null;
    const near = (src, k) => !recipe.len || (src.length >= recipe.len / k && src.length <= recipe.len * k);
    const out = [];
    for (const [k, src] of ctx.fns) if (near(src, 4) && tests.every(t => t.test(src)) && (!re || re.test(src))) out.push(k);
    if (out.length < 2 || !recipe.any || !recipe.any.length) return out;
    const extra = recipe.any.map(modSymbolFeature);
    const scored = out.filter(k => near(ctx.fns.get(k), 2)).map(k => [k, extra.filter(t => t.test(ctx.fns.get(k))).length]).sort((a, b) => b[1] - a[1]);
    return scored.length && scored[0][1] * 2 >= extra.length && (scored.length === 1 || scored[0][1] > scored[1][1]) ? [scored[0][0]] : out;
  }
  /** resolve the own names of every mod about to start; mod id -> [missing names] for mods that cannot start */
  function resolveModSymbols(ids) {
    const old = lsGet(LS_SYMCACHE, null);
    const cache = old && old.game === state.game && old.map ? old.map : {};
    const used = {};
    let found = false;
    const shared = {};
    for (const [k, v] of Object.entries((state.symbols && state.symbols.symbols) || {})) shared[k] = v.name;
    const pending = [], failed = new Map();
    const pkg = lsGet(LS_PKGSYMS, {});
    for (const id of ids) {
      const def = defs.get(id);
      // names from the table that came with the mod's package: only where they differ from the shared table
      const fromPkg = pkg[id] && pkg[id][state.game];
      if (fromPkg) {
        const map = {};
        for (const [n, raw] of Object.entries(fromPkg)) if (shared[n] !== raw && Object.prototype.hasOwnProperty.call(engine, raw)) map[n] = raw;
        if (Object.keys(map).length) modSyms.set(id, map);
      }
      if (!def || !def.symbols || typeof def.symbols !== 'object') continue;
      const map = modSyms.get(id) || {};
      modSyms.set(id, map);
      for (const [name, e] of Object.entries(def.symbols)) pending.push({ id, name, e: e || {}, map });
    }
    // the loader's own: the game's pause menu (api.ui.pauseSettings), found the same way as a mod's names
    const coreMap = {};
    pending.push({ id: 'wml', name: 'pauseMenu', e: PAUSE_MENU, map: coreMap, core: true });
    // two passes: a recipe may name another of the mod's own symbols
    for (let pass = 0; pass < 2; pass++) {
      for (const p of pending) {
        if (p.done) continue;
        const known = p.e.raw && p.e.raw[state.game];
        let raw = null, why = '';
        if (known && Object.prototype.hasOwnProperty.call(engine, known)) raw = known;
        else if (p.e.find) {
          const key = `${p.id}|${p.name}|${symHash(JSON.stringify(p.e.find))}`;
          if (cache[key] && Object.prototype.hasOwnProperty.call(engine, cache[key])) raw = cache[key];
          else {
            const hits = modSymbolMatch(p.e.find, symContext(), Object.assign({}, shared, p.map));
            if (hits.length === 1) { raw = hits[0]; found = true; } else why = hits.length ? L(`후보 ${hits.length}개`, `${hits.length} candidates`) : L('찾지 못함', 'not found');
          }
          if (raw) used[key] = raw;
        } else why = known ? L(`${known}이(가) 이 게임에 없음`, `${known} is not in this game`) : L('이 게임의 이름도 찾는 기준도 없음', 'no name for this game and no recipe to find it');
        if (raw) {
          p.done = true;
          p.map[p.name] = raw;
          for (const a of p.e.aliases || []) p.map[a] = raw;
        } else if (pass === 1) {
          p.done = true;
          if (p.core) continue;               // said when a mod asks for it (hookPauseMenu)
          if (p.e.optional) warn(L(`${p.name} 없음 (${why}) — 이 기능은 꺼져요`, `${p.name} not found (${why}) — that feature is off`), p.id);
          else { if (!failed.has(p.id)) failed.set(p.id, []); failed.get(p.id).push(`${p.name} (${why})`); }
        }
      }
    }
    pauseMenu.raw = coreMap.pauseMenu || null;
    if (found || Object.keys(used).length !== Object.keys(cache).length) lsSet(LS_SYMCACHE, { game: state.game, map: used });
    symCtx = null;                        // the snapshot is only needed while resolving
    return failed;
  }

  // ---------------------------------------------------------------- per-mod API
  const alertKinds = new Map();
  const actions = new Map();
  const dock = [];
  const settingsPanels = new Map();   // mod id -> render(body, win)
  const setupWatchers = [];           // { owner, fn } from api.afterEachSetup

  function makeApi(def) {
    const id = def.id;
    // names: this mod's own symbols first, then the shared table, then raw minified names
    const own = modSyms.get(id) || {};
    const declared = def.symbols && typeof def.symbols === 'object' ? def.symbols : {};
    const isOwnName = n => Object.prototype.hasOwnProperty.call(declared, n) || Object.values(declared).some(e => e && Array.isArray(e.aliases) && e.aliases.includes(n));
    const res = name => {
      if (Object.prototype.hasOwnProperty.call(own, name)) return own[name];
      if (isOwnName(name)) throw new Error(L(`"${name}"을(를) 이 게임(${state.game})에서 찾지 못했어요`, `"${name}" not found in this game (${state.game})`));
      return resolve(name);
    };
    const fn = name => engine[res(name)];
    const store = () => fn('store');
    const api = {
      id,
      wml: VERSION,
      game: state.game,
      /** raw engine bindings (minified names) — prefer sym()/fn() */
      engine,
      sym: res,
      /** current value of an engine binding, by semantic or raw name */
      fn,
      /** share an object (a parent mod's API) with the mods that list this one in requires → they call api.use('<this id>') */
      provide: obj => { provided.set(id, obj); return obj; },
      /** what another mod shared with api.provide; list that mod in requires so it is set up first */
      use: other => {
        if (!provided.has(other)) throw new Error(L(`"${other}" 모드가 필요해요 (켜고 requires에 추가)`, `Needs the "${other}" mod (switch it on and add it to requires)`));
        return provided.get(other);
      },
      /** a value kept out of the 옮기기·백업 file (API keys, tokens): browser storage wml.secret.<id> */
      secret: {
        get: () => { try { return localStorage.getItem(`wml.secret.${id}`) || ''; } catch { return ''; } },
        set: value => { try { if (value) localStorage.setItem(`wml.secret.${id}`, String(value)); else localStorage.removeItem(`wml.secret.${id}`); } catch { /* storage off */ } },
      },
      /**
       * Backups. Databases the mod keeps data in are declared in WML.define({ backup: { indexedDB: ['<name>'] } }) and go
       * into WML backups whole. beforeExport(fn): fn() is awaited before a backup is made — finish writes still on
       * their way; throw (or reject) when they could not be finished, and the backup is marked partial. → unsubscribe
       */
      backup: {
        beforeExport: fn => {
          const f = { owner: id, fn };
          backupFlushers.push(f);
          return () => { const i = backupFlushers.indexOf(f); if (i >= 0) backupFlushers.splice(i, 1); };
        },
      },
      has: name => { try { res(name); return true; } catch { return false; } },
      hook: (name, spec) => addHook(id, name, spec, res(name)),
      /** a line of this mod's own in the diagnostics log (players send that file): at most 100 per run → true when kept */
      report: (msg, data) => diagModNote(id, msg, data),

      store: {
        get: () => store().getState(),
        game: () => store().getState().state,
        set: updater => store().setState(updater),
        /** update the game state with (state) => state */
        update: f => store().setState(s => ({ ...s, state: f(s.state) })),
        dispatch: action => store().getState().dispatch(action),
        subscribe: listener => store().subscribe(listener),
      },

      /** this mod's own saved data, kept at state.mods[id] (travels with saves) */
      data: {
        get: () => ((store().getState().state || {}).mods || {})[id],
        set: valueOrFn => api.store.update(s => {
          const mods = { ...(s.mods || {}) };
          mods[id] = typeof valueOrFn === 'function' ? valueOrFn(mods[id]) : valueOrFn;
          return { ...s, mods };
        }),
      },

      /** this mod's own browser settings (not in saves): api.settings.get(defaults) / set(obj) */
      settings: {
        get: (defaults = {}) => ({ ...defaults, ...lsGet(`wml.mod.${id}`, {}) }),
        set: obj => lsSet(`wml.mod.${id}`, { ...lsGet(`wml.mod.${id}`, {}), ...obj }),
      },

      log: text => api.store.update(s => fn('log')(s, String(text))),

      events: {
        /** resolver: (state, choiceId) => state */
        onAlert: (kind, resolver) => {
          const k = kind.includes(':') ? kind : `${id}:${kind}`;
          alertKinds.set(k, id);
          fn('registerAlert')(k, resolver);
          return k;
        },
        /** queue an alert with choices; shows when nothing else is pending */
        alert: (s, { kind, title, body, choices }) => {
          const k = kind.includes(':') ? kind : `${id}:${kind}`;
          const a = { id: `${k}:${s.slot}:${Math.random().toString(36).slice(2, 7)}`, kind: k, severity: 'critical', pause: true, slot: s.slot, title, body, choices };
          return fn('drainAlerts')(fn('queueAlert')(s, a));
        },
      },

      actions: {
        /** handler: (state, action) => state; dispatch with api.store.dispatch({ type }). info: { label } (shown by other mods, e.g. hotkey makers) */
        register: (type, handler, info = {}) => {
          if (actions.has(type)) throw new Error(`action ${type} already registered by ${actions.get(type).owner}`);
          actions.set(type, { owner: id, handler, label: info && typeof info.label === 'string' ? info.label : '' });
        },
        /** the actions mods registered: [{ type, owner, label }] */
        list: () => [...actions].map(([type, a]) => ({ type, owner: a.owner, label: a.label })),
        /**
         * fn({ type, owner, label, action }) after every dispatched action (payload = the same action object) — a mod's (owner = its id) or the game's
         * (owner 'game'). E.g. "do it once, I'll bind a key to it". Returns an unsubscribe.
         */
        observe: fn => {
          const o = { owner: id, fn };
          actionObservers.push(o);
          return () => { const i = actionObservers.indexOf(o); if (i >= 0) actionObservers.splice(i, 1); };
        },
      },

      ui: {
        /**
         * a button in the WML dock — the one bar every mod button shares, so put yours here instead of
         * pinning your own to a corner. Returns { remove(), update({ label, title }) }.
         */
        addButton: ({ label, title, onClick }) => {
          const entry = { owner: id, label, title, onClick };
          dock.push(entry);
          renderDock();
          return {
            remove: () => { const i = dock.indexOf(entry); if (i >= 0) { dock.splice(i, 1); renderDock(); } },
            update: patch => { Object.assign(entry, patch); renderDock(); },
          };
        },
        /**
         * take a button this mod already made (or another mod's, with care) into the dock, element and all:
         * its own click handler keeps working. Returns a function that puts it back where it was.
         */
        adopt: (node, info) => dockAdopt(id, node, info),
        /**
         * a movable, resizable window; render(body, win) fills it. Opening the same id again brings it to the front.
         * returns { el, body, close(), focus(), setTitle(text), refresh() }
         */
        window: opts => openWindow({ ...opts, id: `${id}:${opts.id || 'main'}`, owner: id }),
        /** settings shown from the ⚙ button of this mod in the manager: render(body, win) */
        settings: render => { settingsPanels.set(id, render); },
        /**
         * this mod's entry in the game's pause menu, right below the game's own Settings (0.8.0):
         * { label (text or { ko, en }), onClick, attributes: { 'data-…': … } }. Without onClick it opens this mod's
         * ⚙ settings. One entry per mod (a second call replaces it); returns a function that takes it out again.
         */
        pauseSettings: (opts = {}) => addPauseEntry(id, opts),
        /** helpers for building windows */
        h: el,
        button: uiButton,
      },

      warn: msg => warn(msg, id),

      /**
       * fn(modId) after every mod's setup from this one on (its own too, failed ones too), before the next one starts —
       * for a compatibility layer that tidies what mods leave on a shared object. Returns an unsubscribe.
       */
      afterEachSetup: fn => { const w = { owner: id, fn }; setupWatchers.push(w); return () => { const i = setupWatchers.indexOf(w); if (i >= 0) setupWatchers.splice(i, 1); }; },

      /** where the game runs: { kind: 'player'|'browser', app: player version, platform: 'pc'|'mobile' } */
      host,
      /**
       * the phone's back button (WML Player): fn() returns true when it handled it (closed this mod's panel…).
       * Newest first; then WML closes its top window; otherwise the player shows its menu. Returns an unsubscribe.
       */
      onBack: fn => { const h = { owner: id, fn }; backHandlers.push(h); return () => { const i = backHandlers.indexOf(h); if (i >= 0) backHandlers.splice(i, 1); }; },
      /** save a file for the player: a download in a browser, Download/WML on the phone. data: string | Blob | ArrayBuffer */
      saveFile: (name, data, type) => saveFile(name, data, type),

      /** load a classic script from this mod's folder (await it in an async setup): api.loadScript('files/a.js') */
      loadScript: file => {
        const rec = installed.get(id);
        if (rec) {                                   // installed in the browser: the file is in storage
          const v = rec.files[file];
          if (v == null) return Promise.reject(new Error(`could not load ${file} (not in the installed mod ${id})`));
          return (typeof v === 'string' ? Promise.resolve(v) : v.text()).then(code => runScript(code, `wml-installed/${id}/${file}`));
        }
        return new Promise((resolve, reject) => {
          const s = document.createElement('script');
          s.src = `${MOD_ROOT}${id}/${file}`;
          s.async = false;
          const f = state.booted ? null : bootExtra(id, file, s);
          s.onload = () => { if (f) bootFileDone(f, 'ok'); resolve(); };
          s.onerror = () => { if (f) bootFileDone(f, 'none'); reject(new Error(`could not load ${s.src}`)); };
          document.head.appendChild(s);
        });
      },
      /** URL of a file in this mod's folder (images, data) — works for folder mods and browser-installed mods */
      fileUrl: file => {
        const rec = installed.get(id);
        if (!rec) return `${MOD_ROOT}${id}/${file}`;
        const v = rec.files[file];
        if (v == null) return null;
        rec.urls = rec.urls || {};
        return rec.urls[file] || (rec.urls[file] = URL.createObjectURL(typeof v === 'string' ? new Blob([v]) : v));
      },
      /** true when this mod was installed by dropping it on the manager (not from wml/mods) */
      installed: installed.has(id),

      /** language of this build ('en', 'ko', …) and a picker for mod text: api.t({ en: 'Hi', ko: '안녕' }) */
      lang: LANG(),
      t: texts => (typeof texts === 'string' ? texts : texts[api.lang] ?? texts.en ?? Object.values(texts)[0]),
    };
    return api;
  }

  // custom actions: wrap the store's dispatch (and tell observers what was dispatched).
  // A mod that puts in a dispatch of its own without calling the one it replaced (rival_tavern) drops the router,
  // so after every mod's setup a router goes back on top if it is not there. A router on top of mods that only
  // wrapped (pregnancy, wayworks) passes everything on while the router underneath still answers.
  const actionObservers = [];          // { owner, fn } from api.actions.observe
  let routedBelow = false;             // a router ran inside the dispatch the current router passed an action on to
  const FN_OWN = new Set(['length', 'name', 'prototype', 'caller', 'arguments']);
  function makeRouter(st, original) {
    let routerBelow = false;           // passing on still reaches a router (learned from the last action passed on)
    const routed = action => {
      const a = action && actions.get(action.type);
      let out, below = false;
      if (a && !routerBelow) st.setState(s => ({ ...s, state: a.handler(s.state, action) }));
      else {
        const outer = routedBelow;
        routedBelow = false;
        try { out = original(action); } finally { below = routedBelow; routedBelow = outer; }
        routerBelow = below;
      }
      if (!below && actionObservers.length && action && typeof action.type === 'string') {   // else it told them already
        const seen = { type: action.type, owner: a ? a.owner : 'game', label: a ? a.label : '', action, payload: action };
        for (const o of actionObservers.slice()) { try { o.fn(seen); } catch (e) { console.error(`[WML] ${o.owner} actions.observe`, e); } }
      }
      routedBelow = true;
      return out;
    };
    // marks a mod put on its dispatch (to install it only once) stay visible on top
    for (const k of Object.getOwnPropertyNames(original)) {
      if (!FN_OWN.has(k)) try { Object.defineProperty(routed, k, Object.getOwnPropertyDescriptor(original, k)); } catch { /* not copyable */ }
    }
    Object.defineProperty(routed, '__wmlRouter', { value: true });
    return routed;
  }
  function installActionRouter() {
    const st = engine[resolve('store')];
    const current = st.getState().dispatch;
    if (typeof current === 'function' && !current.__wmlRouter) st.setState({ dispatch: makeRouter(st, current) });
  }

  // ---------------------------------------------------------------- loading screen (0.9.1)
  // The game draws nothing until boot() hands it back, so reading the listed mod files and starting the switched-on
  // mods used to be a blank screen. This shows how far along that is, and goes once the game has drawn.
  // The browser paints only between tasks: the file part moves file by file, while setups that finish at once move it
  // in one jump. No pause is put between setups to paint: a mod's own timers would then run before the next mod's setup.
  let loadView = null;
  const LOAD_STUCK = 10000;            // no progress for this long: a button to take the screen away appears
  function loadShow() {
    if (loadView || state.booted || !document.body) return;
    ensureStyle();
    const bar = el('div', { class: 'wml-load-fill' });
    const line = el('div', { class: 'wml-load-line' });
    const sub = el('div', { class: 'wml-load-sub' });
    const title = el('div', { class: 'wml-load-title' }, L('Wayward 불러오는 중', 'Loading Wayward'));
    // stuck or stopped: take the screen away, or copy what the start did so far to send to someone
    const close = el('div', { class: 'wml-load-btns' },
      uiButton(L('가리개 닫기', 'Hide this screen'), () => loadHide(), { title: L('불러오기는 그대로 계속돼요', 'Loading goes on behind it') }),
      uiButton(L('진단 파일 저장', 'Save diagnostics file'), () => { diagSave().catch(e => console.error('[WML] diagnostics', e)); }),
      uiButton(L('시작 기록 복사', 'Copy start record'), () => copyOut(bootReport().text, close)));
    close.hidden = true;
    const box = el('div', { class: 'wml-load wml-ui', role: 'status' },
      el('div', { class: 'wml-load-card' },
        title,
        el('div', { class: 'wml-load-track' }, bar, el('div', { class: 'wml-load-shine' })),
        line, sub, close));
    document.body.appendChild(box);
    loadView = { box, title, bar, line, sub, close, stage: 'files', files: 0, filesDone: 0, mods: 0, at: 0, id: '', since: performance.now(), error: '' };
    loadView.tick = setInterval(loadPaint, 500);
    loadPaint();
  }
  /** the mod files enable() reads: each one moves the bar when it has run (or failed to load) */
  function loadFiles(loads) {
    loadShow();
    if (!loadView) return;
    loadView.files += loads.length;
    for (const p of loads) Promise.resolve(p).catch(() => {}).then(() => { if (!loadView) return; loadView.filesDone++; loadView.since = performance.now(); loadPaint(); });
    loadPaint();
  }
  function loadStage(stage, mods) {
    if (!loadView) return;
    loadView.stage = stage;
    if (mods != null) loadView.mods = mods;
    loadView.since = performance.now();
    loadPaint();
  }
  function loadMod(id, at) {
    if (!loadView) return;
    loadView.id = id; loadView.at = at;
    loadView.since = performance.now();
    loadPaint();
  }
  function loadPaint() {
    const v = loadView;
    if (!v) return;
    const waited = Math.floor((performance.now() - v.since) / 1000);
    let p, line, sub = '';
    if (v.error) {
      p = 1; line = v.error;
      sub = L('자세한 내용은 개발자 도구 콘솔(F12)에 있어요.', 'The developer console (F12) has the details.');
    } else if (v.stage === 'files') {
      p = v.files ? 0.55 * v.filesDone / v.files : 0;
      line = L(`모드 파일 읽는 중 ${v.filesDone}/${v.files}`, `Reading mod files ${v.filesDone}/${v.files}`);
      if (waited >= 3) sub = L(`남은 파일 기다리는 중 (${waited}초)`, `Waiting for the remaining files (${waited} s)`);
    } else if (v.stage === 'prep') {
      p = 0.58; line = L('세이브·설정 준비 중', 'Getting saves and settings ready');
      if (waited >= 3) sub = L(`${waited}초`, `${waited} s`);
    } else if (v.stage === 'setup') {
      p = 0.6 + 0.38 * (v.mods ? v.at / v.mods : 1);
      line = L(`모드 켜는 중 ${Math.min(v.at + 1, v.mods)}/${v.mods}`, `Starting mods ${Math.min(v.at + 1, v.mods)}/${v.mods}`);
      sub = v.id ? nameOf(v.id) : '';
      if (v.id && waited >= 3) sub = L(`${nameOf(v.id)} 준비 중 (${waited}초)`,
        `Waiting for ${nameOf(v.id)} (${waited} s)`);
    } else { p = 1; line = L('게임 화면 그리는 중', 'Drawing the game'); }
    v.bar.style.transform = `scaleX(${Math.max(0, Math.min(1, p))})`;
    if (v.line.textContent !== line) v.line.textContent = line;
    if (v.sub.textContent !== sub) v.sub.textContent = sub;
    v.close.hidden = !(v.error || performance.now() - v.since >= LOAD_STUCK);
    v.box.classList.toggle('wml-load-bad', !!v.error);
  }
  /** the game has drawn: fade out */
  function loadDone() {
    if (!loadView) return;
    loadStage('render');
    const v = loadView;
    clearInterval(v.tick);
    // after the game's first frame; a tab in the background gets no frames, so a timer as well
    let going = false;
    const out = () => { if (going) return; going = true; v.box.classList.add('wml-load-out'); setTimeout(() => loadHide(v), 300); };
    requestAnimationFrame(() => requestAnimationFrame(out));
    setTimeout(out, 500);
  }
  function loadHide(v = loadView) {
    if (!v) return;
    clearInterval(v.tick);
    v.box.remove();
    if (loadView === v) loadView = null;
  }
  /** boot threw before the game drew: say so instead of a bar that never moves */
  function loadFail(e) {
    if (!loadView) return;
    loadView.error = String(e && e.message || e);
    loadView.title.textContent = L('Wayward를 시작하지 못했어요', 'Wayward could not start');
    clearInterval(loadView.tick);
    loadPaint();
  }

  // ---------------------------------------------------------------- start record (0.9.1)
  // How long the start took and on what: each file's turn, each mod's setup, the extra files mods read while starting,
  // and how long the screen stood still. Copied from the manager's notices tab, or from the loading screen when it is
  // stuck, it tells a slow disk, a heavy mod and a mod that never finishes apart on someone else's PC.
  // Times are ms since the page began to load. Mods are named by id; addresses and folder paths are left out.
  const LS_BOOTLOG = 'wml.bootlog';    // [{ at, total, files, setup, listed, on, loaded, failed }] — the last starts, oldest first
  const BOOTLOG_KEEP = 10;
  const bootLog = { coreAt: performance.now(), enableAt: 0, bodyAt: 0, filesEnd: 0, filesWaitedOut: false, bootAt: 0, setupAt: 0, setupEnd: 0, drawn: 0, frameAt: 0,
    notRead: 0, files: [], extra: [], setups: [], long: [], hidden: false, res: new Map(), watch: [] };
  // The screen standing still: a timer due every 50 ms that came 0.1 s or more late. The browser's own long-task
  // report is missing in some browsers and window states, where it would read as "never stood still". Not counted
  // while the page is hidden, whose timers the browser slows down on purpose.
  const BEAT = 50, STALL = 100;
  let beatLast = performance.now(), beatTimer = 0;
  function beat() {
    const now = performance.now(), late = now - beatLast - BEAT;
    if (document.visibilityState !== 'visible') bootLog.hidden = true;
    else if (late >= STALL) bootLog.long.push([beatLast + BEAT, late]);
    beatLast = now;
    beatTimer = now < 180000 ? setTimeout(beat, BEAT) : 0;
  }
  beatTimer = setTimeout(beat, BEAT);
  try {
    // an observer still hears every entry once the page's resource list is full (250 by default)
    const po = new PerformanceObserver(list => {
      for (const e of list.getEntries()) if (e.initiatorType === 'script') bootLog.res.set(e.name, { fetch: e.responseEnd - e.startTime, size: e.decodedBodySize || e.encodedBodySize || 0 });
    });
    po.observe({ type: 'resource', buffered: true });
    bootLog.watch.push(po);
  } catch { /* not offered */ }
  function bootFile(id, s) { const f = { id, url: s.src, at: performance.now(), done: 0, ok: '' }; bootLog.files.push(f); return f; }
  function bootExtra(id, file, s) { const f = { id, file, url: s.src, at: performance.now(), done: 0, ok: '' }; bootLog.extra.push(f); return f; }
  function bootFileDone(f, ok) { f.done = performance.now(); f.ok = ok; }
  /** after boot: wait for the game's first content, keep a short line of this start, stop listening */
  function bootSettle() {
    const t0 = performance.now();
    const root = document.getElementById('root');
    const look = () => {
      if (!(root && root.childElementCount) && performance.now() - t0 < 5000) { setTimeout(look, 50); return; }
      bootLog.frameAt = performance.now();
      try {
        const list = lsGet(LS_BOOTLOG, []);
        list.push({ at: Date.now(), total: Math.round(bootLog.frameAt), files: Math.round(bootLog.filesEnd - bootLog.bodyAt), setup: Math.round(bootLog.setupEnd - bootLog.setupAt),
          listed: state.listed.length, on: state.order.length, loaded: state.loaded.length, failed: state.failed.length });
        lsSet(LS_BOOTLOG, (Array.isArray(list) ? list : []).slice(-BOOTLOG_KEEP));
      } catch { /* storage off */ }
      setTimeout(() => { clearTimeout(beatTimer); for (const po of bootLog.watch) { try { po.disconnect(); } catch { /* gone */ } } }, 3000);
    };
    setTimeout(look, 0);
  }
  // no addresses or folder paths in a text meant to be pasted somewhere: what is under wml/ is kept
  const scrub = t => String(t)
    .replace(/(?:file|https?|blob):\/\/[^\s'")]*/g, u => { const i = u.indexOf('/wml/'); return i >= 0 ? u.slice(i + 1) : L('(주소 가림)', '(address hidden)'); })
    .replace(/[A-Za-z]:\\[^\s'")]*/g, L('(경로 가림)', '(path hidden)'))
    .replace(/\b\d{1,3}(?:\.\d{1,3}){3}(?::\d+)?\b/g, L('(주소 가림)', '(address hidden)'));
  function browserLine() {
    const ua = navigator.userAgent || '';
    const BR = [['Edge', /Edg\/(\d+)/], ['Whale', /Whale\/(\d+)/], ['Samsung Internet', /SamsungBrowser\/(\d+)/], ['Opera', /OPR\/(\d+)/], ['Firefox', /Firefox\/(\d+)/], ['Chrome', /Chrome\/(\d+)/], ['Safari', /Version\/(\d+)[^]*Safari/]];
    const hit = BR.map(([n, re]) => [n, re.exec(ua)]).find(([, m]) => m);
    const br = hit ? `${hit[0]} ${hit[1][1]}${/; wv\)/.test(ua) ? ' WebView' : ''}` : L('알 수 없는 브라우저', 'unknown browser');
    const os = /Android/.test(ua) ? 'Android' : /iPhone|iPad/.test(ua) ? 'iOS' : /Windows/.test(ua) ? 'Windows' : /Mac OS/.test(ua) ? 'macOS' : /Linux/.test(ua) ? 'Linux' : '?';
    const cpu = navigator.hardwareConcurrency ? L(`CPU ${navigator.hardwareConcurrency}개`, `${navigator.hardwareConcurrency} CPUs`) : '';
    const mem = navigator.deviceMemory ? L(`메모리 ${navigator.deviceMemory}GB${navigator.deviceMemory >= 8 ? ' 이상' : ''}`, `memory ${navigator.deviceMemory} GB${navigator.deviceMemory >= 8 ? '+' : ''}`) : '';
    return [br, os, cpu, mem].filter(Boolean).join(' · ');
  }
  /** the start so far as numbers (also before the start is over) and as a text to paste */
  function bootReport() {
    const b = bootLog, now = performance.now();
    const sec = ms => (ms / 1000).toFixed(2);
    const mb = n => (n >= 1048576 ? `${(n / 1048576).toFixed(1)}MB` : `${Math.max(1, Math.round(n / 1024))}KB`);
    // files run one after another in list order: a file's turn is the time from the one before it to its own end
    const doneFiles = b.files.filter(f => f.done).sort((x, y) => x.done - y.done);
    let prev = b.bodyAt;
    const files = doneFiles.map(f => {
      const turn = Math.max(0, f.done - Math.max(prev, f.at));
      prev = Math.max(prev, f.done);
      const r = b.res.get(f.url);
      return { id: f.id, turn, fetch: r ? r.fetch : null, size: r ? r.size : 0, ok: f.ok };
    });
    const fileBytes = files.reduce((n, f) => n + f.size, 0);
    const pendingFiles = b.files.filter(f => !f.done).map(f => f.id);
    const extra = b.extra.map(f => ({ id: f.id, file: f.file, ms: (f.done || now) - f.at, ok: f.ok || 'waiting', fetch: (b.res.get(f.url) || {}).fetch }));
    const end = (t, from) => (t || (from ? now : 0));
    const phases = [
      { key: 'page', label: L('게임 페이지 읽기', 'Reading the game page'), from: 0, to: b.bodyAt || now },
      { key: 'files', label: L('모드 파일 읽기', 'Reading mod files'), from: b.bodyAt, to: end(b.filesEnd, b.bodyAt) },
      { key: 'prep', label: L('세이브·설정 준비', 'Saves and settings'), from: b.filesEnd, to: end(b.setupAt, b.filesEnd) },
      { key: 'setup', label: L('모드 켜기', 'Starting mods'), from: b.setupAt, to: end(b.setupEnd, b.setupAt) },
      { key: 'draw', label: L('게임 첫 화면', 'First game screen'), from: b.setupEnd, to: end(b.frameAt, b.setupEnd) },
    ].filter(p => p.key === 'page' || p.from);
    for (const p of phases) {
      p.ms = Math.max(0, p.to - p.from);
      p.open = p.key !== 'page' && !({ files: b.filesEnd, prep: b.setupAt, setup: b.setupEnd, draw: b.frameAt })[p.key];
      const lt = b.long.filter(([s]) => s >= p.from && s < p.to);
      p.long = { n: lt.length, ms: lt.reduce((n, [, d]) => n + d, 0), max: lt.reduce((m, [, d]) => Math.max(m, d), 0) };
    }
    const last = b.setups[b.setups.length - 1];
    const setups = b.setups.map(r => (!b.setupEnd && r === last && r.result === 'not-started' ? { ...r, ms: now - r.at, result: 'running' } : { ...r }));
    const long = { n: b.long.length, ms: b.long.reduce((n, [, d]) => n + d, 0), max: b.long.reduce((m, [, d]) => Math.max(m, d), 0) };
    const data = { version: VERSION, game: state.game, lang: LANG(), host: host.kind, platform: host.platform, file: location.protocol === 'file:', browser: browserLine(),
      listed: state.listed.length, on: state.order.length, loaded: state.loaded.length, failed: state.failed.length, missing: state.missing.length, booted: state.booted, notRead: b.notRead,
      loaderAt: b.coreAt, listAt: b.enableAt || null, hiddenWhileStarting: b.hidden, total: b.frameAt || null, gameReady: b.bootAt || null, filesWaitedOut: b.filesWaitedOut, phases, files, fileBytes, pendingFiles, extra, setups, long };

    // the text
    const d = new Date(), p2 = n => String(n).padStart(2, '0');
    const out = [];
    out.push(`${L('WML 시작 기록', 'WML start record')} — ${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())} ${p2(d.getHours())}:${p2(d.getMinutes())}`);
    const where = host.kind === 'player' ? appLabel()
      : `${PLATFORM_LABEL[host.platform]} ${L('브라우저', 'browser')} (${location.protocol === 'file:' ? L('파일로 엶', 'opened as a file') : L('웹 서버로 엶', 'from a web server')})`;
    out.push(`WML ${VERSION} · ${L('게임', 'game')} ${state.game || '?'} · ${langName(LANG())} · ${where} · ${data.browser}`);
    out.push(L(`모드: 목록 ${data.listed} · 켤 모드 ${data.on} · 작동 ${data.loaded} · 실패 ${data.failed} · 폴더 없음 ${data.missing} · 세이브 저장 위치 ${saves.on ? 'IndexedDB' : 'localStorage'}`,
      `Mods: listed ${data.listed} · to start ${data.on} · running ${data.loaded} · failed ${data.failed} · folder missing ${data.missing} · saves kept in ${saves.on ? 'IndexedDB' : 'localStorage'}`));
    const offAtStart = b.notRead;
    if (offAtStart > 0) out.push(L(`꺼진 모드 ${offAtStart}개는 읽지 않음`, `${offAtStart} off mod(s) not read`));
    out.push('');
    out.push(b.frameAt ? L(`걸린 시간: 게임 첫 화면까지 ${sec(b.frameAt)}초`, `Time: ${sec(b.frameAt)} s to the first game screen`)
      : L(`아직 시작 중 (${sec(now)}초)`, `Still starting (${sec(now)} s)`));
    // Hangul takes two columns in a fixed-width font
    const cols = t => [...t].reduce((n, c) => n + (/[\u1100-\u11ff\u3000-\u9fff\uac00-\ud7af\uff00-\uffef]/.test(c) ? 2 : 1), 0);
    const width = Math.max(...phases.map(p => cols(p.label)));
    for (const p of phases) {
      let more = '';
      if (p.key === 'files') more = L(`, ${files.length}개${fileBytes ? `, ${mb(fileBytes)}` : ''}${b.filesWaitedOut ? ', 15초 초과로 건너뜀' : ''}`, `, ${files.length} file(s)${fileBytes ? `, ${mb(fileBytes)}` : ''}${b.filesWaitedOut ? ', rest skipped after 15 s' : ''}`);
      if (p.key === 'setup') more = L(`, ${setups.length}개`, `, ${setups.length} mod(s)`);
      out.push(`  ${p.label}${' '.repeat(width - cols(p.label))}  ${sec(p.from)} → ${p.open ? L('진행 중', 'going on') : sec(p.to)}  (${sec(p.ms)}${L('초', ' s')}${more})`);
    }
    if (b.bootAt && b.filesEnd > b.bootAt + 100) out.push(L(`  게임 코드 ${sec(b.bootAt)}초, 이후 모드 파일 대기 ${sec(b.filesEnd - b.bootAt)}초`, `  game code at ${sec(b.bootAt)} s, then ${sec(b.filesEnd - b.bootAt)} s waiting for mod files`));
    out.push('');
    const hiddenNote = b.hidden ? L(' (창이 가려진 동안 제외)', ' (hidden time not counted)') : '';
    if (long.n) {
      out.push(L(`멈춤(0.1초↑) ${long.n}번 · 합 ${sec(long.ms)}초 · 최장 ${sec(long.max)}초${hiddenNote}`, `Freezes (>0.1 s): ${long.n} · total ${sec(long.ms)} s · longest ${sec(long.max)} s${hiddenNote}`));
      out.push('  ' + phases.filter(p => p.long.n).map(p => L(`${p.label} ${p.long.n}번 ${sec(p.long.ms)}초`, `${p.label} ${p.long.n}× ${sec(p.long.ms)} s`)).join(' · '));
    } else out.push(L(`멈춤(0.1초↑) 없음${hiddenNote}`, `Freezes (>0.1 s): none${hiddenNote}`));
    const resultText = r => ({ ok: '', running: L(' [준비 중]', ' [starting]'), 'stand-in': L(' [WML이 대신함]', ' [WML stands in]'), 'not-started': L(' [켜지 않음]', ' [not started]'), failed: L(' [실패]', ' [failed]'), timeout: L(' [시간 초과]', ' [timed out]') })[r.result] || '';
    const slow = setups.filter(r => r.ms >= 1).sort((x, y) => y.ms - x.ms).slice(0, 10);
    if (slow.length) {
      out.push('');
      out.push(L('준비가 오래 걸린 모드 (상위 10)', 'Mods slowest to start (top 10)'));
      slow.forEach((r, i) => out.push(`  ${i + 1}. ${nameOf(r.id)} (${r.id})  ${sec(r.ms)}${L('초', ' s')}${r.async && r.ms - r.sync >= 50 ? L(` — 대기 포함, 바로 실행 ${sec(r.sync)}초`, ` — includes waiting; ran at once for ${sec(r.sync)} s`) : ''}${resultText(r)}`));
    }
    const slowExtra = extra.slice().sort((x, y) => y.ms - x.ms).slice(0, 10);
    if (slowExtra.length) {
      out.push('');
      out.push(L(`추가로 읽은 파일 ${extra.length}개 (느린 순)`, `Extra files read by mods: ${extra.length} (slowest first)`));
      slowExtra.forEach((f, i) => out.push(`  ${i + 1}. ${f.id} / ${scrub(f.file)}  ${sec(f.ms)}${L('초', ' s')}${f.fetch != null ? L(` (받기 ${sec(f.fetch)}초)`, ` (fetch ${sec(f.fetch)} s)`) : ''}${f.ok === 'waiting' ? L(' [아직 기다리는 중]', ' [still waiting]') : f.ok === 'none' ? L(' [없음]', ' [missing]') : ''}`));
    }
    const slowFiles = files.slice().sort((x, y) => y.turn - x.turn).slice(0, 10).filter(f => f.turn >= 1);
    if (slowFiles.length) {
      out.push('');
      out.push(L('느린 모드 파일 (상위 10)',
        'Slowest mod files (top 10)'));
      slowFiles.forEach((f, i) => out.push(`  ${i + 1}. ${f.id}  ${sec(f.turn)}${L('초', ' s')}${f.fetch != null ? L(` (받기 ${sec(f.fetch)}초${f.size ? `, ${mb(f.size)}` : ''})`, ` (fetch ${sec(f.fetch)} s${f.size ? `, ${mb(f.size)}` : ''})`) : ''}${f.ok === 'none' ? L(' [없음]', ' [missing]') : ''}`));
    }
    if (pendingFiles.length) out.push('', L(`아직 다 읽지 못한 파일 ${pendingFiles.length}개: `, `${pendingFiles.length} file(s) not read yet: `) + pendingFiles.slice(0, 20).join(', ') + (pendingFiles.length > 20 ? ' …' : ''));
    const running = setups.find(r => r.result === 'running');
    if (running) out.push('', L(`지금 기다리는 모드: ${nameOf(running.id)} (${running.id}) — ${sec(now - running.at)}초째`, `Waiting for: ${nameOf(running.id)} (${running.id}) — ${sec(now - running.at)} s so far`));
    if (state.failed.length || state.warnings.length) {
      out.push('');
      out.push(L(`켜지 못한 모드 ${state.failed.length} · 알림 ${state.warnings.length}`, `Not started ${state.failed.length} · notices ${state.warnings.length}`));
      for (const f of state.failed.slice(0, 30)) out.push(`  ! ${nameOf(f.id)} (${f.id}): ${scrub(f.error)}`);
      for (const w of state.warnings.slice(0, 15)) out.push(`  - ${w.mod ? `${nameOf(w.mod)}: ` : ''}${scrub(w.msg)}`);
    }
    const past = lsGet(LS_BOOTLOG, []);
    const earlier = (Array.isArray(past) ? past : []).filter(h => h && typeof h.total === 'number' && !(b.frameAt && Math.abs(h.total - Math.round(b.frameAt)) < 2 && Date.now() - h.at < 600000)).slice(-6).reverse();
    if (earlier.length) {
      out.push('');
      out.push(L('지난 시작 (최근 것부터): ', 'Earlier starts (newest first): ') + earlier.map(h => { const t = new Date(h.at); return `${sec(h.total)}${L('초', ' s')} (${p2(t.getMonth() + 1)}-${p2(t.getDate())} ${p2(t.getHours())}:${p2(t.getMinutes())}, ${L('켤 모드', 'on')} ${h.on})`; }).join(' · '));
    }
    return { data, text: out.join('\n') };
  }
  /** copy a text; when the browser will not, show it ready to select */
  function copyOut(text, where) {
    const note = msg => { const n = el('span', { class: 'wml-note' }, msg); where.insertBefore(n, where.querySelector('.wml-copyout')); setTimeout(() => n.remove(), 2500); };
    const show = () => {
      let ta = where.querySelector('.wml-copyout');
      if (!ta) { ta = el('textarea', { class: 'wml-copyout', readonly: true }); where.append(ta); }
      ta.value = text;
      ta.focus(); ta.select();
      note(L('복사가 막혀 있어요. 아래 글을 Ctrl+C로 복사해 주세요', 'Copying is blocked: press Ctrl+C on the text below'));
    };
    // The old way first, while the click is still going on: browsers (and in-app browsers) that keep the clipboard API
    // from the page usually still let a selected text be copied. Then the clipboard API, then the text to select by hand.
    let done = false;
    try {
      const ta = el('textarea', { readonly: true, style: 'position:fixed;left:-9999px;top:0;opacity:0' });
      ta.value = text;
      document.body.append(ta);
      ta.focus(); ta.select();
      done = document.execCommand('copy');
      ta.remove();
    } catch { done = false; }
    if (done) { note(L('복사했어요', 'Copied')); return; }
    try { navigator.clipboard.writeText(text).then(() => note(L('복사했어요', 'Copied')), show); } catch { show(); }
  }
  /** the start record in the manager's notices tab */
  function bootSection() {
    const r = bootReport(), b = r.data, sec = ms => (ms / 1000).toFixed(1);
    const box = el('div', { class: 'wml-section' }, el('h4', null, L('시작 기록', 'Start record')));
    const setup = b.phases.find(p => p.key === 'setup'), files = b.phases.find(p => p.key === 'files');
    box.append(el('div', { class: 'wml-small' }, b.total
      ? L(`시작 ${sec(b.total)}초 (모드 파일 ${sec(files ? files.ms : 0)}초 · 모드 켜기 ${sec(setup ? setup.ms : 0)}초 · 멈춤 ${sec(b.long.ms)}초)`,
        `Start ${sec(b.total)} s (mod files ${sec(files ? files.ms : 0)} s · starting mods ${sec(setup ? setup.ms : 0)} s · freezes ${sec(b.long.ms)} s)`)
      : L('시작 시간 재는 중…', 'Timing the start…')));
    const top = b.setups.filter(x => x.ms >= 100).sort((x, y) => y.ms - x.ms).slice(0, 5);
    if (top.length) box.append(el('div', { class: 'wml-small wml-muted', style: 'margin-top:2px' },
      L('오래 걸린 모드: ', 'Slowest mods: ') + top.map(x => `${nameOf(x.id)} ${(x.ms / 1000).toFixed(2)}${L('초', ' s')}`).join(' · ')));
    const past = lsGet(LS_BOOTLOG, []);
    if (Array.isArray(past) && past.length > 1) box.append(el('div', { class: 'wml-small wml-muted', style: 'margin-top:2px' },
      L('최근 시작: ', 'Recent starts: ') + past.slice(-6).reverse().map(h => `${sec(h.total)}${L('초', ' s')}`).join(' · ')));
    const btns = el('div', { style: 'display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin-top:6px' });
    btns.append(
      uiButton(L('시작 기록 복사', 'Copy start record'), () => copyOut(bootReport().text, btns)),
      uiButton(L('파일로 저장', 'Save as file'), () => { const d = new Date(); saveFile(`wml-start-${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}-${String(d.getHours()).padStart(2, '0')}${String(d.getMinutes()).padStart(2, '0')}.txt`, bootReport().text, 'text/plain;charset=utf-8').catch(e => console.error('[WML] start record', e)); }));
    box.append(btns, el('details', null, el('summary', { class: 'wml-small', style: 'cursor:pointer;margin-top:6px' }, L('전체 보기', 'Show all')), el('pre', { class: 'wml-bootlog' }, r.text)));
    return box;
  }

  // ---------------------------------------------------------------- diagnostics report (0.9.3)
  /** the browser, the device and the storage, as far as the browser tells */
  async function diagEnvNow() {
    const n = navigator, s = window.screen || {};
    const env = { browser: browserLine(), ua: n.userAgent || '', languages: (n.languages || [n.language]).filter(Boolean).join(', '),
      tz: (() => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone; } catch { return ''; } })(),
      screen: `${s.width}×${s.height}`, view: `${window.innerWidth}×${window.innerHeight}`, dpr: window.devicePixelRatio, cores: n.hardwareConcurrency || null, mem: n.deviceMemory || null,
      online: n.onLine, saves: (() => { try { return saves.on ? 'IndexedDB' : 'localStorage'; } catch { return '?'; } })() };
    try {
      if (n.userAgentData && n.userAgentData.getHighEntropyValues) {
        const h = await n.userAgentData.getHighEntropyValues(['fullVersionList', 'platformVersion', 'architecture', 'model']);
        env.brands = (h.fullVersionList || []).filter(b => !/not.?a.?brand/i.test(b.brand)).map(b => `${b.brand} ${b.version}`).join(', ');
        env.os = `${h.platform || ''} ${h.platformVersion || ''}`.trim();
        env.arch = h.architecture || '';
        env.model = h.model || '';
      }
    } catch { /* not offered */ }
    try { if (n.storage && n.storage.estimate) { const e = await n.storage.estimate(); env.storage = { usage: e.usage, quota: e.quota }; } } catch { /* not offered */ }
    try { const pm = performance.memory; if (pm) env.heap = { used: pm.usedJSHeapSize, limit: pm.jsHeapSizeLimit }; } catch { /* not offered */ }
    try { const u = storageUsage(); env.ls = { used: u.used, quota: u.quota }; } catch { /* storage off */ }
    try { const st = JSON.parse(rawGetItem.call(localStorage, 'tavern-settings') || '{}'); env.imageBackend = (st.state && st.state.imageBackendMode) || ''; } catch { /* storage off */ }
    return env;
  }
  /** every listed mod: version, on or off, how it went, where it comes from */
  function diagMods() {
    const inst = new Set(installedIds()), reg = new Set(lsGet(LS_FOLDERS, []));
    return state.listed.map(id => {
      const d = defs.get(id), f = state.failed.find(x => x.id === id), s = bootLog.setups.find(x => x.id === id);
      const st = state.loaded.includes(id) ? 'running' : f ? 'failed' : state.missing.includes(id) ? 'missing' : !isOn(id) ? 'off' : 'not-started';
      return { id, name: d ? String(nameOf(id)) : '', version: d && d.version != null ? String(d.version) : '', state: st,
        from: inst.has(id) ? 'installed' : reg.has(id) ? 'folder-registered' : 'folder', setup: s ? Math.round(s.ms) : null, error: f ? String(f.error) : null };
    });
  }
  const DIAG_KIND = { error: ['오류', 'error'], reject: ['처리 안 된 오류', 'unhandled'], console: ['콘솔 오류', 'console error'], warn: ['경고', 'warning'],
    resource: ['못 읽은 파일', 'file not loaded'], mod: ['모드 기록', 'mod note'], stall: ['멈춤', 'freeze'] };
  const kindLabel = k => (DIAG_KIND[k] ? L(DIAG_KIND[k][0], DIAG_KIND[k][1]) : k);
  /** everything as data and as a text to send: this run, the runs before it, the mods, the start */
  async function diagReport() {
    diagLog.env = await diagEnvNow();
    diagLog.dirty = true;
    const past = await diagPast();
    const env = diagLog.env, now = Date.now();
    const p2 = n => String(n).padStart(2, '0');
    const when = ms => { const d = new Date(ms); return `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())} ${p2(d.getHours())}:${p2(d.getMinutes())}`; };
    const sec = ms => (ms / 1000).toFixed(1);
    const mb = n => (n == null ? '?' : n >= 1073741824 ? `${(n / 1073741824).toFixed(1)}GB` : `${(n / 1048576).toFixed(1)}MB`);
    const clock = t => { const s = Math.round(t / 1000); return `${Math.floor(s / 60)}:${p2(s % 60)}`; };   // time since the page opened
    const mods = diagMods();
    const out = [];
    out.push(`${L('WML 진단 기록', 'WML diagnostics')} — ${when(now)}`);
    const where = host.kind === 'player' ? appLabel()
      : `${PLATFORM_LABEL[host.platform]} ${L('브라우저', 'browser')} (${location.protocol === 'file:' ? L('파일로 엶', 'opened as a file') : L('웹 서버로 엶', 'from a web server')})`;
    out.push(`WML ${VERSION} · ${L('게임', 'game')} ${state.game || '?'} · ${langName(LANG())} · ${where}`);
    out.push('');
    out.push(L('■ 환경', '■ Environment'));
    out.push(`  ${L('브라우저', 'Browser')}: ${env.browser}${env.brands ? ` (${env.brands})` : ''}`);
    if (env.os || env.arch) out.push(`  OS: ${[env.os, env.arch, env.model].filter(Boolean).join(' · ')}`);
    out.push(`  User-Agent: ${env.ua}`);
    out.push(`  ${L('화면', 'Screen')}: ${env.screen} · ${L('창', 'window')} ${env.view} · ${L('배율', 'scale')} ${env.dpr} · ${L('언어', 'languages')} ${env.languages} · ${env.tz}`);
    out.push(`  ${L('저장', 'Storage')}: ${L('세이브', 'saves')} ${env.saves} · localStorage ${env.ls ? `${Math.round(env.ls.used / env.ls.quota * 100)}% (${Math.round(env.ls.used / 1024)}K/${Math.round(env.ls.quota / 1024)}K)` : '?'}`
      + `${env.storage ? ` · ${L('브라우저 저장소', 'browser storage')} ${mb(env.storage.usage)} / ${mb(env.storage.quota)}` : ''}${env.heap ? ` · ${L('메모리', 'memory')} ${mb(env.heap.used)} / ${mb(env.heap.limit)}` : ''}`);
    out.push(`  ${L('그림 서버 설정', 'Image server setting')}: ${env.imageBackend || '?'} · ${L('온라인', 'online')} ${env.online ? 'yes' : 'no'}`);
    out.push('');
    const errs = diagLog.entries.filter(e => e.kind !== 'stall' && e.kind !== 'mod');
    const stalls = diagLog.entries.filter(e => e.kind === 'stall');
    const longest = stalls.reduce((m, e) => Math.max(m, e.ms), 0);
    out.push(L('■ 이번 실행', '■ This run'));
    out.push(`  ${L('시작', 'started')} ${when(diagLog.start)} · ${L('지난 시간', 'running for')} ${clock(performance.now())} · `
      + L(`오류 ${diagLog.errors} · 경고 ${diagLog.warns} · 멈춤 ${diagLog.stalls}${stalls.length ? ` (최장 ${sec(longest)}초)` : ''} · 느린 훅 ${diagLog.slow.size} · 그림 없음 ${diagLog.media}`,
        `errors ${diagLog.errors} · warnings ${diagLog.warns} · freezes ${diagLog.stalls}${stalls.length ? ` (longest ${sec(longest)} s)` : ''} · slow hooks ${diagLog.slow.size} · missing pictures ${diagLog.media}`));
    if (diagLog.dropped) out.push(L(`  (오래된 기록 ${diagLog.dropped}개 생략)`, `  (${diagLog.dropped} older entries dropped)`));
    const prev = diagLog.prev;
    if (prev) out.push(L(`  ! 지난 실행(${when(prev.start)} 시작) 비정상 종료 — 마지막 기록 ${when(prev.at)}, ${prev.day != null ? `${prev.day}일째 ` : ''}오류 ${prev.errors} · 멈춤 ${prev.stalls}${prev.last ? `, 마지막 느린 코드: ${prev.last.owner} ${prev.last.where} (${prev.last.ms}ms)` : ''}`,
      `  ! The run started ${when(prev.start)} did not end normally — last entry ${when(prev.at)}, ${prev.day != null ? `day ${prev.day}, ` : ''}errors ${prev.errors} · freezes ${prev.stalls}${prev.last ? `, last slow code: ${prev.last.owner} ${prev.last.where} (${prev.last.ms}ms)` : ''}`));
    if (errs.length) {
      out.push('');
      out.push(L(`■ 오류·경고 (${errs.length}종류, 최근 순, ×n = 반복 횟수)`, `■ Errors & warnings (${errs.length} kinds, newest first, ×n = repeats)`));
      for (const e of errs.slice().sort((a, b) => (b.last || b.t) - (a.last || a.t)).slice(0, 80)) {
        out.push(`  [${clock(e.t)}${e.last ? `~${clock(e.last)}` : ''}] ${kindLabel(e.kind)}${e.mod ? ` · ${nameOf(e.mod)} (${e.mod})` : ''}${e.n > 1 ? ` ×${e.n}` : ''}: ${scrub(e.msg)}`);
        if (e.at) out.push(`      @ ${scrub(e.at)}`);
        if (e.stack) out.push(`      ${scrub(e.stack)}`);
      }
    }
    if (stalls.length) {
      out.push('');
      out.push(L('■ 멈춤 (1초↑, 최근 순)', '■ Freezes (>1 s, newest first)'));
      for (const e of stalls.slice().reverse().slice(0, 40)) {
        const g = e.day != null ? L(` · ${e.day}일째`, ` · day ${e.day}`) : '';
        const what = e.during && e.during.length ? L(' — 실행 중이던 모드 코드: ', ' — mod code running: ') + e.during.map(x => `${x.owner} ${x.where} ${x.ms}ms`).join(', ')
          : L(' — 모드 코드 없음 (게임·브라우저 쪽)', ' — no mod code (game or browser)');
        out.push(`  [${clock(e.from)}] ${sec(e.ms)}${L('초', ' s')}${g}${e.booted ? '' : L(' · 시작 중', ' · while starting')}${what}`);
      }
    }
    const slow = [...diagLog.slow.values()].sort((a, b) => b.max - a.max).slice(0, 20);
    if (slow.length) {
      out.push('');
      out.push(L(`■ 느린 모드 훅 (${SLOW_HOOK / 1000}초↑, 느린 순)`, `■ Slow mod hooks (>${SLOW_HOOK / 1000} s, slowest first)`));
      for (const s of slow) out.push(`  ${nameOf(s.owner)} (${s.owner}) ${s.where} — ${L('가장 긴', 'longest')} ${sec(s.max)}${L('초', ' s')} · ${s.n}${L('번', '×')} · ${L('합', 'total')} ${sec(s.total)}${L('초', ' s')}`);
    }
    const notes = diagLog.entries.filter(e => e.kind === 'mod');
    if (notes.length) {
      out.push('');
      out.push(L('■ 모드가 남긴 기록', '■ Notes left by mods'));
      for (const e of notes.slice(-40)) out.push(`  [${clock(e.t)}] ${nameOf(e.mod)} (${e.mod})${e.n > 1 ? ` ×${e.n}` : ''}: ${scrub(e.msg)}${e.data ? ` ${scrub(e.data)}` : ''}`);
    }
    out.push('');
    const stLabel = { running: L('작동', 'running'), failed: L('실패', 'failed'), missing: L('폴더 없음', 'folder missing'), off: L('꺼짐', 'off'), 'not-started': L('켜지 않음', 'not started') };
    const fromLabel = { installed: L('설치본', 'installed'), 'folder-registered': L('폴더 등록', 'folder (registered)'), folder: L('폴더', 'folder') };
    const on = mods.filter(m => m.state !== 'off');
    out.push(L(`■ 모드 (목록 ${mods.length} · 켤 모드 ${on.length} · 작동 ${state.loaded.length} · 실패 ${state.failed.length}) — 불러온 순서`, `■ Mods (listed ${mods.length} · on ${on.length} · running ${state.loaded.length} · failed ${state.failed.length}) — in load order`));
    const order = id => { const i = state.order.indexOf(id); return i < 0 ? 1e6 + mods.findIndex(m => m.id === id) : i; };
    for (const m of on.slice().sort((a, b) => order(a.id) - order(b.id))) {
      out.push(`  ${m.id} ${m.version ? `v${m.version}` : ''} [${stLabel[m.state]}] ${fromLabel[m.from]}${m.setup != null && m.setup >= 50 ? ` · ${L('준비', 'setup')} ${m.setup}ms` : ''}${m.error ? ` — ${scrub(m.error)}` : ''}`);
    }
    const off = mods.filter(m => m.state === 'off');
    if (off.length) out.push(`  ${L('꺼진 모드', 'Off')} ${off.length}: ${off.map(m => m.id + (m.version ? `@${m.version}` : '')).join(', ')}`);
    if (state.warnings.length) {
      out.push('');
      out.push(L(`■ 로더 알림 ${state.warnings.length}`, `■ Loader notices ${state.warnings.length}`));
      for (const w of state.warnings.slice(0, 30)) out.push(`  - ${w.mod ? `${nameOf(w.mod)}: ` : ''}${scrub(w.msg)}`);
    }
    if (past.length) {
      out.push('');
      out.push(L('■ 지난 실행 (최근 순)', '■ Earlier runs (newest first)'));
      for (const r of past) {
        out.push(`  ${when(r.start)} ~ ${when(r.end)} · WML ${r.wml} · ${L('게임', 'game')} ${r.game || '?'} · ${L(`오류 ${r.errors} · 경고 ${r.warns} · 멈춤 ${r.stalls}`, `errors ${r.errors} · warnings ${r.warns} · freezes ${r.stalls}`)}`);
        const top = (r.entries || []).filter(e => ERRORISH.has(e.kind)).sort((a, b) => b.n - a.n).slice(0, 3);
        for (const e of top) out.push(`      ${kindLabel(e.kind)}${e.mod ? ` · ${e.mod}` : ''}${e.n > 1 ? ` ×${e.n}` : ''}: ${scrub(e.msg).slice(0, 200)}`);
      }
    }
    out.push('');
    out.push(L('■ 시작 기록', '■ Start record'));
    out.push(bootReport().text.split('\n').map(l => `  ${l}`).join('\n'));
    const data = { version: VERSION, game: state.game, lang: LANG(), host: host.kind, platform: host.platform, env, errors: diagLog.errors, warns: diagLog.warns, stalls: diagLog.stalls,
      media: diagLog.media, prev: diagLog.prev, entries: diagLog.entries.slice(), slow, mods, past: past.map(r => ({ start: r.start, end: r.end, wml: r.wml, game: r.game, errors: r.errors, warns: r.warns, stalls: r.stalls })) };
    return { data, text: out.join('\n') };
  }
  let diagCopyText = '';                // the report as last made (the notices tab makes it when it opens): copied at once on a click
  function diagFileName() { const d = new Date(), p2 = n => String(n).padStart(2, '0'); return `wml-diag-${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}-${p2(d.getHours())}${p2(d.getMinutes())}.txt`; }
  async function diagSave() { const r = await diagReport(); await saveFile(diagFileName(), r.text, 'text/plain;charset=utf-8'); diagFlush(); return r; }
  /** "문제 보고" in the manager's notices tab: what this run has seen, and the file to send */
  function diagSection() {
    const box = el('div', { class: 'wml-section' }, el('h4', null, L('문제 보고', 'Report a problem')));
    const stalls = diagLog.entries.filter(e => e.kind === 'stall');
    box.append(el('div', { class: 'wml-small' }, L(`이번 실행: 오류 ${diagLog.errors} · 경고 ${diagLog.warns} · 멈춤 ${diagLog.stalls} · 느린 훅 ${diagLog.slow.size}`,
      `This run: errors ${diagLog.errors} · warnings ${diagLog.warns} · freezes ${diagLog.stalls} · slow hooks ${diagLog.slow.size}`)));
    if (diagLog.prev) box.append(el('div', { class: 'wml-small', style: 'color:#fcd34d;margin-top:2px' }, L('지난 실행이 비정상 종료됐어요.',
      'The last run did not end normally.')));
    const recent = diagLog.entries.filter(e => ERRORISH.has(e.kind)).slice(-5).reverse();
    for (const e of recent) box.append(el('div', { class: 'wml-small wml-muted', style: 'margin-top:2px' }, `• ${e.mod ? `${nameOf(e.mod)}: ` : ''}${scrub(e.msg).slice(0, 160)}${e.n > 1 ? ` ×${e.n}` : ''}`));
    if (stalls.length) { const e = stalls[stalls.length - 1]; box.append(el('div', { class: 'wml-small wml-muted', style: 'margin-top:2px' }, L(`• 최근 멈춤 ${(e.ms / 1000).toFixed(1)}초`, `• Last freeze ${(e.ms / 1000).toFixed(1)} s`) + (e.during && e.during.length ? ` — ${e.during.map(x => `${nameOf(x.owner)} ${x.where}`).join(', ')}` : ''))); }
    box.append(el('div', { class: 'wml-small wml-muted', style: 'margin-top:4px' }, L('문제 발생 시 진단 파일을 저장해 제보에 첨부해 주세요.',
      'If something goes wrong, save the diagnostics file and attach it to your report.')));
    const btns = el('div', { style: 'display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin-top:6px' });
    btns.append(
      uiButton(L('진단 파일 저장', 'Save diagnostics file'), () => { diagSave().catch(e => console.error('[WML] diagnostics', e)); }),
      uiButton(L('복사', 'Copy'), () => {
        // copying has to happen in the click; making the report takes a moment, so the one made when this opened goes
        if (diagCopyText) copyOut(diagCopyText, btns);
        diagReport().then(r => { const first = !diagCopyText; diagCopyText = r.text; if (first) copyOut(r.text, btns); }).catch(e => console.error('[WML] diagnostics', e));
      }));
    box.append(btns);
    diagReport().then(r => { diagCopyText = r.text; }).catch(() => { /* made on the click instead */ });
    return box;
  }

  // ---------------------------------------------------------------- boot
  function boot(args) {
    return bootRun(args).catch(e => { try { loadFail(e); } catch { /* the page has no body */ } throw e; });
  }
  /**
   * The game's top-level names, read from the module's text: declarations, and names assigned in a declaration list.
   * Kept only when the module has the name (the lookup finds a value that is not just the browser's global of that name).
   */
  function moduleNames(eng) {
    const script = document.querySelector('script[type="module"]');
    const src = (script && script.textContent) || '';
    const re = /(?:\bfunction\*?\s+|\bclass\s+|\b(?:const|let|var)\s+)([A-Za-z_$][\w$]*)|[,;]\s*([A-Za-z_$][\w$]*)\s*(?:=(?![=>])|(?=[,;]))/g;
    const seen = new Set();
    let m;
    while ((m = re.exec(src))) seen.add(m[1] || m[2]);
    const out = [];
    for (const k of seen) {
      let v;
      try { v = eng[k]; } catch { continue; }
      if (v === undefined || (k in globalThis && globalThis[k] === v)) continue;
      out.push(k);
    }
    return out;
  }
  /**
   * A game that hands over its own hook (Wayward: Faith: one Proxy that looks a top-level name up) lists no names; the
   * build's object of getters does. The lookup gets the names from the module's text, so both look the same to WML and mods.
   */
  function listableEngine(eng) {
    if (!eng || typeof eng !== 'object' || Object.keys(eng).length) return eng;
    let names = null;
    const list = () => names || (names = new Set(moduleNames(eng)));
    return new Proxy(eng, {
      ownKeys: () => [...list()],
      getOwnPropertyDescriptor: (t, k) => (typeof k === 'string' && list().has(k) ? { configurable: true, enumerable: true, writable: true, value: eng[k] } : undefined),
      has: (t, k) => typeof k === 'string' && list().has(k),
    });
  }
  /** a loader file that may be missing (a package without it): resolves either way */
  function loadQuiet(src, label) {
    return new Promise(resolve => {
      const s = document.createElement('script');
      s.src = src;
      s.async = false;
      const f = bootFile(label, s);
      s.onload = () => { bootFileDone(f, 'ok'); resolve(true); };
      s.onerror = () => { bootFileDone(f, 'none'); resolve(false); };
      document.head.appendChild(s);
    });
  }
  async function bootRun({ game, engine: eng, render }) {
    bootLog.bootAt = performance.now();
    engine = listableEngine(eng);
    state.game = game;
    // a page with only the loader's own script tag (a game's own hook): the mod list and the symbol table are read now
    if (!enableCalled) await loadQuiet(MOD_ROOT + 'mods.js', '(mods.js)');
    if (!state.symbols || state.symbols.game !== game) await loadQuiet(`wml/symbols/${game}.js`, '(symbols)');
    // a game version newer than every table here: the newest table of the same game (<family>-latest.js), keeping the
    // names this game still has. Wayward: Faith keeps its top-level names from version to version (2.4.1 → 2.4.2: all 158).
    if (!state.symbols || state.symbols.game !== game) {
      const before = state.symbols;
      await loadQuiet(`wml/symbols/${GAME_FAMILY}-latest.js`, '(symbols)');
      const t = state.symbols;
      if (t && t !== before && t.game !== game && gameFamily(t.game) === GAME_FAMILY) adoptSymbols(t, game);
      else state.symbols = before;
    }
    // the game's functions before any mod ran: a later replacement can tell a change made outside WML
    for (const k of Object.keys(engine)) { try { const v = engine[k]; if (typeof v === 'function') pristine.set(k, v); } catch { /* not initialised yet */ } }
    if (!state.symbols || state.symbols.game !== game) warn(`no symbol table for ${game}; mods can only use raw names`);
    bootLog.filesWaitedOut = await Promise.race([Promise.all([...scriptLoads, loadInstalled()]).then(() => false), new Promise(r => setTimeout(() => r(true), 15000))]);
    bootLog.filesEnd = performance.now();
    loadStage('prep');
    dropMissing();
    applyCompat();
    // saves kept in the browser database: in memory, and the current game read again, before any mod looks at it
    try { await savesBoot(); } catch (e) { saves.ready = true; warn(L(`세이브 저장 위치를 준비하지 못했어요: ${e && e.message || e}`, `Could not prepare where saves are kept: ${e && e.message || e}`)); }
    // mods' databases from an imported backup go in now, before any mod opens them. A backup imported at this very
    // start (a phone bundle) may still be writing them to the waiting place: wait for that first.
    if (stateImport) await Promise.race([Promise.resolve(stateImport).catch(() => {}), new Promise(r => setTimeout(r, 120000))]);
    try { await applyPendingRestore(); } catch (e) { warn(L(`백업의 모드 저장소를 넣지 못했어요: ${e.message}`, `Could not put in the backup's mod databases: ${e.message}`)); }
    // not read at start but wanted now: mods a backup imported at this start switched on (their setup runs) and mods
    // that mods on require (their name, version and language count)
    const wanted = () => {
      const tt = toggles(), out = new Set();
      for (const id of unread) if (isOn(id, tt)) out.add(id);
      for (const [id, d] of defs) if (isOn(id, tt)) for (const r of d.requires) if (unread.has(r)) out.add(r);
      return [...out];
    };
    for (let more = wanted(); more.length; more = wanted()) await readMods(more);
    bootLog.notRead = unread.size;
    dropMissing();
    applyCompat();
    try { backupDecl(); } catch { /* storage off */ }   // remember which databases this session's mods declare

    const t = toggles();
    const listedOrder = playerOrder();
    bootSnapshot = { order: listedOrder.slice(), on: Object.fromEntries(state.listed.map(id => [id, isOn(id, t)])) };
    for (const id of state.listed) if (!defs.has(id) && !unread.has(id) && !state.failed.some(f => f.id === id)) state.failed.push({ id, error: L('mod.js에 WML.define이 없어요', 'mod.js has no WML.define') });
    const ids = listedOrder.filter(id => isOn(id, t) && defs.has(id));
    const ok = ids.filter(id => {
      const d = defs.get(id);
      const missing = d.requires.filter(r => !ids.includes(r));
      if (missing.length) { state.failed.push({ id, error: L(`필요한 모드가 꺼져 있거나 없어요: ${missing.map(nameOf).join(', ')}`, `a mod it needs is off or missing: ${missing.map(nameOf).join(', ')}`) }); return false; }
      const wrongVersion = d.requires.filter(r => wantVersion(d, r) && !versionMatches(defs.get(r).version, wantVersion(d, r)));
      if (wrongVersion.length) {
        const list = wrongVersion.map(r => L(`${nameOf(r)} ${defs.get(r).version || '(버전 없음)'} → 필요 ${wantVersion(d, r)}`, `${nameOf(r)} ${defs.get(r).version || '(no version)'} → needs ${wantVersion(d, r)}`)).join(', ');
        state.failed.push({ id, error: L(`필요한 모드의 버전이 맞지 않아요: ${list}`, `a mod it needs has a version it does not work with: ${list}`) });
        return false;
      }
      const clash = d.conflicts.filter(c => ids.includes(c));
      // the mod that lists the other stops (both, when each lists the other), so the game never runs half-patched;
      // a listing on one side only stops that side. The message says what to do about it
      if (clash.length) { state.failed.push({ id, error: L(`같이 켤 수 없어 둘 다 꺼졌어요: ${clash.map(nameOf).join(', ')}. 하나를 끄고 새로고침해 주세요.`,
        `These cannot run together, so both are off: ${clash.map(nameOf).join(', ')}. Switch one off and reload.`) }); return false; }
      if (d.game && !gameMatches(d.game, game)) warn(L(`게임 ${d.game}용인데 지금 게임은 ${game}이에요`, `made for game ${d.game}; this game is ${game}`), id);
      return true;
    });
    state.order = sortMods(ok, state.orderNotes);
    const elsewhere = state.order.filter(id => defs.get(id).platforms.length && !defs.get(id).platforms.includes(host.platform));
    if (elsewhere.length) warn(L(`${PLATFORM_LABEL[host.platform]}에서 안 맞을 수 있는 모드: ${elsewhere.map(id => `${nameOf(id)}(${defs.get(id).platforms.map(p => PLATFORM_LABEL[p]).join('·')} 전용)`).join(', ')}`,
      `Mods that may not suit ${host.platform === 'mobile' ? 'a phone' : 'a PC'}: ${elsewhere.map(id => `${nameOf(id)} (${defs.get(id).platforms.map(p => PLATFORM_LABEL[p]).join('/')} only)`).join(', ')}`));
    // switched on by the player although made for another language: allowed, but said
    const otherLang = state.order.filter(id => defs.get(id).langs.length && !defs.get(id).langs.includes(LANG()));
    if (otherLang.length) warn(L(`다른 언어용 모드가 켜져 있어요: ${otherLang.map(id => `${nameOf(id)}(${defs.get(id).langs.map(langName).join('·')})`).join(', ')}`,
      `Mods for another language are on: ${otherLang.map(id => `${nameOf(id)} (${defs.get(id).langs.map(langName).join('·')})`).join(', ')}`));
    // save mods WML stands in for while saves are in the database: not started below, so not warned about either
    const savesStandIn = id => saves.on && (SAVE_MODS.includes(id) || defs.get(id).roles.includes('save-format'));
    const running = state.order.filter(id => !savesStandIn(id));
    // known problems of a mod version that can lose data or break the game: said at start, the rest in the manager
    for (const id of running) for (const n of noticesFor(id)) if (n.severity === 'high') warn(`${compatText(n.title)} — ${compatText(n.impact)}`, id);
    for (const id of running) {
      for (const { role, ids } of roleMates(id, running)) {
        if (state.roleOverlaps.some(o => o.role === role)) continue;
        const all = running.filter(o => defs.get(o).roles.includes(role));
        state.roleOverlaps.push({ role, ids: all });
        warn(L(`기능이 겹치는 모드(${roleLabel(role)}): ${all.map(nameOf).join(', ')}`,
          `Mods doing the same job (${roleLabel(role)}): ${all.map(nameOf).join(', ')}`));
      }
    }
    // mods' own symbols: all resolved before any mod runs (and before any mod changes an engine binding)
    let symFailed = new Map();
    try { symFailed = resolveModSymbols(state.order); } catch (e) { warn(L('이 게임 버전에 없는 이름: ', 'Names missing in this game version: ') + e.message); }
    try { installActionRouter(); } catch (e) { warn('custom actions unavailable: ' + e.message); }
    loadStage('setup', state.order.length);
    bootLog.setupAt = performance.now();
    let started = 0;
    for (const id of state.order) {
      loadMod(id, started++);
      const rec = { id, at: performance.now(), ms: 0, sync: 0, async: false, result: 'not-started' };
      bootLog.setups.push(rec);
      if (symFailed.has(id)) {
        state.failed.push({ id, error: L(`이 게임 버전(${game})과 맞지 않아요 (${symFailed.get(id).join(', ')} 없음). 모드 업데이트가 필요해요.`,
          `Does not match this game version (${game}; missing ${symFailed.get(id).join(', ')}). The mod needs an update.`) });
        continue;
      }
      // `requires` was checked against the mods that are on; what counts now is whether they actually started —
      // a child of a parent whose setup failed would run on a half-made parent
      const d = defs.get(id);
      if (savesStandIn(id)) {
        // not a failure (the default since 0.9.0 would show one for every player with such a mod): its row says so
        saves.stats.skipped.push(id);
        rec.result = 'stand-in';
        continue;
      }
      const down = d.requires.filter(r => !state.loaded.includes(r));
      if (down.length) {
        state.failed.push({ id, error: L(`필요한 모드가 실패해 이 모드도 꺼졌어요: ${down.map(nameOf).join(', ')}`,
          `A mod it needs failed, so this one is off too: ${down.map(nameOf).join(', ')}`) });
        continue;
      }
      const track = setupTrack = { id, undo: [] };
      let timer;
      try {
        const run = Promise.resolve().then(() => {
          const api = makeApi(d), t0 = performance.now();
          const outer = diagNow;
          diagNow = { owner: id, where: 'setup' };
          try { const r = d.setup(api); rec.async = !!(r && typeof r.then === 'function'); return r; } finally { rec.sync = performance.now() - t0; diagNow = outer; }
        });
        const late = new Promise((_, no) => { timer = setTimeout(() => no(Object.assign(new Error('setup timeout'), { wmlTimeout: true })), SETUP_LIMIT); });
        await Promise.race([run, late]);
        state.loaded.push(id);
        rec.result = 'ok';
      } catch (e) {
        rec.result = e && e.wmlTimeout ? 'timeout' : 'failed';
        if (e && e.wmlTimeout) {
          // still running: the next mods and the game no longer wait for it, and mods that need it do not start
          state.failed.push({ id, error: L(`준비 시간 초과(${SETUP_LIMIT / 1000}초)로 건너뛰었어요.`,
            `Setup took over ${SETUP_LIMIT / 1000} s and was skipped.`) });
          console.warn(`[WML] ${id} setup timed out`);
        } else {
          // take back what it set up through the api, so a half-set-up mod does not stay hooked into the game
          // (functions it assigned directly on the engine cannot be taken back)
          for (const u of track.undo.reverse()) { try { u(); } catch { /* already gone */ } }
          for (const [type, a] of [...actions]) if (a.owner === id) actions.delete(type);
          for (let i = backupFlushers.length - 1; i >= 0; i--) if (backupFlushers[i].owner === id) backupFlushers.splice(i, 1);
          provided.delete(id);
          state.failed.push({ id, error: String(e && e.message || e) });
          console.error(`[WML] ${id} setup failed`, e);
        }
      } finally { clearTimeout(timer); if (setupTrack === track) setupTrack = null; rec.ms = performance.now() - rec.at; }
      try { installActionRouter(); } catch { /* said once before the mods ran */ }
      for (const w of setupWatchers.slice()) { try { w.fn(id); } catch (e) { console.error(`[WML] ${w.owner} afterEachSetup`, e); } }
    }
    // a function hooked here and then assigned directly by a later mod: report it (see checkDrift)
    for (const h of hooks.values()) checkDrift(h);
    bootLog.setupEnd = performance.now();
    // [Faith] 모드가 일시정지 메뉴 항목을 달지 않아도 "모드 설정"을 붙인다 (예전에는 api.ui.pauseSettings를 부를 때만 연결했다)
    hookPauseMenu();
    state.booted = true;
    render();
    renderDock();
    bootLog.drawn = performance.now();
    loadDone();
    bootSettle();
    installDropTarget();
    // a preset was dropped on the game before this reload: say what came of it
    try {
      const done = sessionStorage.getItem(SS_PRESET_DONE);
      if (done) { sessionStorage.removeItem(SS_PRESET_DONE); presetBanner = JSON.parse(done); openManager(); }
    } catch { /* storage off */ }
    // saves another version wrote over the ones kept here: show where to put them back
    if (saves.recoveredNow.length) { managerTab = 'settings'; openManager(); }
    try { warmPromptHits(); } catch { /* the marks are worked out when first asked for */ }
    faithAppPacks().catch(e => console.warn('[WML] image packs', e));
    console.info(`[WML ${VERSION}] game ${game}: ${state.loaded.length} mod(s) loaded`, state.loaded, state.failed.length ? state.failed : '');
  }

  /**
   * Wayward: Faith in its phone app: the app reads the image pack zips in place and answers for image-packs/<folder>/;
   * the game learns about packs from a folder the player picks, which a phone cannot do. So the packs the app has are
   * handed to the game's own registration (wfPackScanFolder) as the pack.js files it would have read from that folder.
   * Nothing happens when the game already has exactly these packs.
   */
  const LS_APP_PACKS = 'wml.faith.appPacks';
  async function faithAppPacks() {
    if (GAME_FAMILY !== 'faith' || host.kind !== 'player' || !window.WMLHost || typeof window.WMLHost.imagePacks !== 'function') return;
    let folders;
    try { folders = JSON.parse(window.WMLHost.imagePacks() || '[]'); } catch { return; }
    const scan = engine && engine.wfPackScanFolder, installed = engine && engine.wfPackInstalled;
    if (typeof scan !== 'function' || typeof installed !== 'function') return;
    const want = folders.map(f => `image-packs/${f}/pack.js`);
    const before = lsGet(LS_APP_PACKS, []);
    const have = new Set(installed().map(x => x.cataloguePath).filter(Boolean));
    const gone = before.filter(x => !want.includes(x) && have.has(x));            // packs taken out of the app since last time
    if (!want.length || (want.every(x => have.has(x)) && !gone.length)) { lsSet(LS_APP_PACKS, want); return; }
    const files = [];
    for (const x of want) {
      try {
        const res = await fetch(x);
        if (!res.ok) continue;
        const f = new File([await res.text()], 'pack.js', { type: 'text/javascript' });
        Object.defineProperty(f, 'webkitRelativePath', { value: x });
        files.push(f);
      } catch { /* that pack cannot be read now */ }
    }
    if (!files.length) return;
    // After a scan the game forgets each character's pack whose pack is no longer there (wfPackDropOrphans). A pack
    // taken out of the app, or a zip that cannot be read at this start, is not the player choosing again: the choice
    // stays (no picture while the pack is away) and works again once the pack is back.
    if (!faithKeepChoices && typeof engine.wfPackDropOrphans === 'function') {
      try { addHook('wml', 'wfPackDropOrphans', { around(next, ...a) { return faithPackSync ? undefined : next(...a); } }, 'wfPackDropOrphans'); faithKeepChoices = true; }
      catch (e) { console.warn('[WML] image pack choices are not kept:', e); }
    }
    faithPackSync = true;
    try {
      const n = await scan(files);
      lsSet(LS_APP_PACKS, want);
      console.info(`[WML] image packs registered with the game: ${n}`);
    } catch (e) { warn(L(`이미지팩을 게임에 등록하지 못했어요: ${e && e.message || e}`, `Could not register the image packs with the game: ${e && e.message || e}`)); }
    finally { faithPackSync = false; }
  }
  let faithPackSync = false, faithKeepChoices = false;

  // mod versions: the numbers are compared in turn ("1.10.0" > "1.9.2", "1.6" = "1.6.0"); what follows them
  // ("-beta", ".bug1010") is not looked at
  function versionParts(v) {
    const m = String(v == null ? '' : v).trim().match(/^v?(\d+(?:\.\d+)*)/i);
    return m ? m[1].split('.').map(Number) : null;
  }
  function versionCompare(a, b) {
    for (let i = 0; i < Math.max(a.length, b.length); i++) { const d = (a[i] || 0) - (b[i] || 0); if (d) return d < 0 ? -1 : 1; }
    return 0;
  }
  /** does a mod version meet a condition such as ">=1.6.0 <2"? An unknown version or an unreadable condition does not */
  function versionMatches(v, range) {
    const have = versionParts(v);
    if (!have) return false;
    const parts = String(range == null ? '' : range).trim().split(/\s+/).filter(Boolean);
    return parts.length > 0 && parts.every(part => {
      const m = part.match(/^(>=|<=|>|<|=)?v?(\d+(?:\.\d+)*)$/i);
      if (!m) return false;
      const c = versionCompare(have, m[2].split('.').map(Number)), op = m[1] || '=';
      return op === '>=' ? c >= 0 : op === '<=' ? c <= 0 : op === '>' ? c > 0 : op === '<' ? c < 0 : c === 0;
    });
  }
  /** is version a higher than version b? (false when either cannot be read) */
  const isNewer = (a, b) => { const x = versionParts(a), y = versionParts(b); return !!(x && y) && versionCompare(x, y) > 0; };
  /** the version condition this mod puts on a mod it requires, '' when none */
  const wantVersion = (d, r) => (d && d.requiresVersion && typeof d.requiresVersion[r] === 'string' ? d.requiresVersion[r] : '');

  // game versions are dates, or a date with a tag for a pre-release (2026-10-18-pre): a pre-release comes before
  // the release of its date, so ">=2026-10-18" does not take 2026-10-18-pre
  // Wayward: Faith versions are "faith-2.4.1"; `game: 'faith'` or 'faith>=2.4.0' names it, a date names Wayward
  const gameFamily = v => (/^faith(-|$|[<>=])/.test(String(v)) ? 'faith' : 'wayward');
  const gameKey = v => {
    const f = String(v).match(/^faith-(\d+(?:\.\d+)*)$/);
    if (f) return 'faith ' + f[1].split('.').map(n => n.padStart(6, '0')).join('.');
    const m = String(v).match(/^(\d{4}-\d{2}-\d{2})(?:-([a-z][a-z0-9.]*))?$/); return m ? m[1] + (m[2] ? ' ' + m[2] : '~') : String(v);
  };
  /** the game a mod's `game` names: 'faith', 'wayward', or null when it names none */
  const specFamily = spec => (/faith/.test(String(spec)) ? 'faith' : /\d{4}-\d{2}-\d{2}|wayward/.test(String(spec)) ? 'wayward' : null);
  function gameMatches(spec, game) {
    const g = gameKey(game), fam = gameFamily(game);
    const cmp = (op, v) => (op === '>=' ? g >= v : op === '<=' ? g <= v : op === '>' ? g > v : op === '<' ? g < v : g === v);
    return String(spec).split(/\s+/).every(part => {
      if (part === 'faith' || part === 'wayward') return fam === part;
      let m = part.match(/^faith(>=|<=|>|<|=)?-?(\d+(?:\.\d+)*)$/) || part.match(/^(>=|<=|>|<|=)?faith-(\d+(?:\.\d+)*)$/);
      if (m) return fam === 'faith' && cmp(m[1] || '=', gameKey(`faith-${m[2]}`));
      m = part.match(/^(>=|<=|>|<|=)?(\d{4}-\d{2}-\d{2}(?:-[a-z][a-z0-9.]*)?)$/);
      if (!m) return true;
      return fam === 'wayward' && cmp(m[1] || '=', gameKey(m[2]));
    });
  }

  // ---------------------------------------------------------------- UI: styles, helpers, windows
  const CSS = `
.wml-ui{font:13px/1.45 system-ui,-apple-system,"Malgun Gothic",sans-serif;color:#e7e5e4}
.wml-ui *{box-sizing:border-box}
.wml-dock{position:fixed;left:8px;bottom:8px;z-index:2147483050;display:flex;align-items:flex-end;gap:4px;max-width:calc(100vw - 16px)}
.wml-dock-bar{display:flex;align-items:stretch;gap:4px;padding:3px;border-radius:9px;background:#1c1917d9;border:1px solid #57534e;box-shadow:0 2px 10px #0007}
.wml-dock-grip{flex:0 0 auto;width:13px;border-radius:5px;border:0;padding:0;cursor:move;touch-action:none;background:repeating-linear-gradient(#78716c 0 2px,transparent 2px 5px) center/5px 100% no-repeat}
.wml-dock-grip:hover{background-color:#44403c}
.wml-dock-items{display:grid;gap:4px;justify-items:stretch}
.wml-dock-items>*{min-width:0}
.wml-dock-fold{flex:0 0 auto;align-self:stretch;padding:0 5px;border-radius:5px;border:0;background:none;color:#a8a29e;cursor:pointer;font:inherit;line-height:1}
.wml-dock-fold:hover{background:#44403c;color:#fff}
.wml-dock-tab{padding:3px 9px;border-radius:9px;border:1px solid #57534e;background:#1c1917d9;color:#e7e5e4;cursor:pointer;font:inherit;box-shadow:0 2px 10px #0007}
.wml-dock-tab:hover{background:#292524}
.wml-dock-adopted{display:flex;align-items:center}
.wml-dock-adopted>*{position:static!important;inset:auto!important;margin:0!important;z-index:auto!important;float:none!important;transform:none!important}
[data-wml-stowed]{display:none!important}
.wml-btn{padding:4px 10px;border-radius:6px;border:1px solid #57534e;background:#292524;color:#e7e5e4;cursor:pointer;font:inherit;line-height:1.3}
.wml-btn:hover{background:#3f3a36}.wml-btn:disabled{opacity:.4;cursor:default}
.wml-btn.wml-primary{background:#b45309;border-color:#d97706;color:#fff}.wml-btn.wml-primary:hover{background:#c2410c}
.wml-btn.wml-icon{padding:2px 7px;min-width:28px}
.wml-dock .wml-btn{opacity:.85;background:#1c1917;border-color:#78716c}
.wml-win{position:fixed;z-index:2147483100;display:flex;flex-direction:column;background:#1c1917;border:1px solid #57534e;border-radius:10px;box-shadow:0 14px 44px #000c;min-width:280px;min-height:160px;resize:both;overflow:hidden}
.wml-win-title{display:flex;align-items:center;gap:8px;padding:7px 8px 7px 12px;background:#292524;border-bottom:1px solid #44403c;cursor:move;user-select:none;touch-action:none}
.wml-win-title b{flex:1;font-size:13px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.wml-win-close{background:none;border:0;color:#a8a29e;font-size:17px;line-height:1;cursor:pointer;padding:2px 6px;border-radius:4px}
.wml-win-close:hover{background:#44403c;color:#fff}
.wml-win-body{flex:1;overflow:auto;padding:10px 12px}
.wml-win-foot{display:flex;flex-wrap:wrap;gap:6px;align-items:center;padding:8px 12px;border-top:1px solid #44403c;background:#1c1917}
.wml-muted{color:#a8a29e}.wml-small{font-size:12px}
.wml-note{color:#fcd34d;font-size:12px}
.wml-grid{width:100%;border-collapse:collapse}
.wml-grid th{position:sticky;top:-10px;background:#1c1917;text-align:left;font-weight:600;color:#a8a29e;font-size:12px;padding:6px;border-bottom:1px solid #44403c;white-space:nowrap}
.wml-grid td{padding:7px 6px;border-bottom:1px solid #292524;vertical-align:top}
.wml-grid tr.wml-off td.wml-fade{opacity:.5}
.wml-grid tr.wml-drop td{box-shadow:inset 0 2px 0 #d97706}
.wml-grid tr.wml-dragging{opacity:.4}
.wml-grid tr.wml-new td{background:#2a2310}
.wml-handle{cursor:grab;color:#78716c;user-select:none;font-size:15px;line-height:1;touch-action:none}
.wml-drag-ghost{position:fixed;left:0;top:0;z-index:2147483000;pointer-events:none;max-width:260px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;padding:3px 9px;border:1px solid #d97706;border-radius:6px;background:#292018;color:#fde68a;font:12px/1.4 system-ui,sans-serif;box-shadow:0 4px 14px rgba(0,0,0,.45)}
html.wml-grabbing,html.wml-grabbing *{cursor:grabbing!important;user-select:none!important}
.wml-chip{display:inline-block;padding:1px 8px;border-radius:999px;font-size:11px;white-space:nowrap}
.wml-chip-on{background:#14532d;color:#bbf7d0}.wml-chip-off{background:#292524;color:#a8a29e;border:1px solid #44403c}
.wml-chip-err{background:#7f1d1d;color:#fecaca}.wml-chip-warn{background:#78350f;color:#fde68a}
.wml-name{font-weight:600}.wml-id{color:#78716c;font-size:11px;margin-left:6px}
.wml-acts{display:flex;gap:4px;justify-content:flex-end}
.wml-section{margin-top:12px}
.wml-section h4{margin:0 0 4px;font-size:12px;color:#a8a29e;font-weight:600}
.wml-add{border:1px dashed #78716c;border-radius:8px;padding:8px 10px;margin:0 0 10px;background:#1c1917}
.wml-win.wml-dropping{outline:3px dashed #d97706;outline-offset:-3px}.wml-win.wml-dropping .wml-add{border-color:#d97706;background:#292018}
.wml-chip-inst{background:#1e3a5f;color:#bfdbfe;margin-left:6px}
.wml-btn.wml-danger{border-color:#7f1d1d;color:#fecaca}.wml-btn.wml-danger:hover{background:#7f1d1d;color:#fff}
.wml-confirm-shade{position:absolute;inset:0;z-index:5;background:#0c0a09cc;display:flex;align-items:center;justify-content:center;padding:16px}
.wml-confirm{max-width:440px;width:100%;background:#1c1917;border:1px solid #7f1d1d;border-radius:10px;padding:14px 16px;box-shadow:0 10px 30px #000c}
.wml-confirm-title{font-weight:600;font-size:14px;color:#fde68a}
.wml-meter{display:flex;height:10px;margin-top:4px;border-radius:999px;background:#292524;border:1px solid #44403c;overflow:hidden}
.wml-meter>i{display:block;height:100%}
.wml-dot{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:5px;vertical-align:middle}
.wml-store-row{display:flex;justify-content:space-between;gap:12px;padding:2px 0 2px 12px;border-bottom:1px solid #292524}
.wml-ui input[type=checkbox]{width:16px;height:16px;accent-color:#d97706;cursor:pointer}
.wml-grid tr.wml-sel td{background:#3b2a12}.wml-grid tr.wml-sel.wml-new td{background:#4a3410}
.wml-modtab .wml-grid tr:hover td{background:#231f1c}.wml-modtab .wml-grid tr.wml-sel:hover td{background:#46321a}
.wml-win-body.wml-body-fill{display:flex;flex-direction:column;overflow:hidden}
.wml-tabs{display:flex;gap:4px;align-items:center;flex-wrap:wrap;margin:0 0 8px;border-bottom:1px solid #44403c;padding-bottom:6px}
.wml-tab{padding:4px 12px;border-radius:6px;border:1px solid transparent;background:none;color:#a8a29e;cursor:pointer;font:inherit}
.wml-tab:hover{color:#e7e5e4;background:#292524}
.wml-tab-on{color:#fde68a;border-color:#57534e;background:#292524}
.wml-tab-warn{color:#fcd34d}
.wml-modtab{display:flex;flex-direction:column;gap:6px;flex:1;min-height:0}
.wml-modtop{display:flex;gap:6px;align-items:center;flex-wrap:wrap}
.wml-gap{flex:1;min-width:8px}
.wml-search{flex:0 1 260px;min-width:140px;background:#0c0a09;color:#e7e5e4;border:1px solid #57534e;border-radius:6px;padding:4px 8px;font:inherit}
.wml-banner{padding:4px 8px;border:1px solid #14532d;border-radius:6px;background:#0c1a10}
.wml-dual{flex:1;min-height:0;display:grid;gap:6px;grid-template-columns:minmax(0,1fr);grid-template-rows:minmax(0,1fr) auto minmax(0,1fr);grid-template-areas:"on" "bar" "off"}
.wml-modtab.wml-wide .wml-dual{grid-template-columns:minmax(0,1fr) auto minmax(0,1fr);grid-template-rows:minmax(0,1fr);grid-template-areas:"on bar off"}
.wml-box-on{grid-area:on}.wml-box-off{grid-area:off}
.wml-dualbar{grid-area:bar;display:flex;gap:6px;align-items:center;justify-content:center}
.wml-modtab.wml-wide .wml-dualbar{flex-direction:column}
.wml-dualbar .wml-btn{min-width:44px}
.wml-g-wide{display:none}.wml-modtab.wml-wide .wml-g-wide{display:inline}.wml-modtab.wml-wide .wml-g-narrow{display:none}
.wml-listbox{display:flex;flex-direction:column;min-height:0;border:1px solid #44403c;border-radius:8px;padding:2px 6px 4px}
.wml-listbox.wml-drop-here{outline:2px dashed #d97706;outline-offset:-2px}
.wml-listhead{display:flex;gap:6px;align-items:baseline;margin:4px 2px;font-weight:600;font-size:13px;color:#fde68a}
.wml-listhead-off{color:#a8a29e}
.wml-listscroll{flex:1;min-height:0;overflow:auto}
.wml-grid.wml-compact{table-layout:fixed}
.wml-grid.wml-compact td{padding:3px 4px;vertical-align:middle;cursor:default}
.wml-compact td.wml-c-h{width:14px}.wml-compact td.wml-c-n{width:26px;text-align:right}.wml-compact td.wml-c-v{width:62px}
.wml-compact td.wml-c-s{width:84px}.wml-compact td.wml-c-a{width:34px;text-align:right}
.wml-compact td.wml-c-name{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.wml-grid tr.wml-focus td{box-shadow:inset 0 -1px 0 #d97706}
.wml-flag{display:inline-block;margin-left:5px;padding:0 6px;border-radius:999px;font-size:10px;line-height:15px;vertical-align:1px}
.wml-detail{flex:0 0 auto;max-height:32%;min-height:52px;overflow:auto;border:1px solid #44403c;border-radius:8px;padding:6px 8px;background:#0c0a09}
.wml-detail-head{display:flex;gap:4px;align-items:center;flex-wrap:wrap}
.wml-chipbar{display:flex;gap:4px;flex-wrap:wrap;align-items:center}
.wml-fchip{padding:1px 10px;border-radius:999px;border:1px solid #57534e;background:#1c1917;color:#d6d3d1;cursor:pointer;font:inherit;font-size:12px;line-height:20px}
.wml-fchip:hover{background:#292524}.wml-fchip-on{background:#78350f;border-color:#d97706;color:#fde68a}
.wml-chip-tag{background:#312e81;color:#c7d2fe}.wml-chip-prompt{background:#164e63;color:#a5f3fc}
.wml-select.wml-select-sm{min-width:0;padding:1px 4px;font-size:12px}
.wml-grid tr.wml-grouphead td{background:#231f1c;cursor:pointer;padding:4px 6px;font-size:12px;border-bottom:1px solid #44403c;position:sticky;top:0;z-index:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.wml-grid tr.wml-grouphead:hover td{background:#2c2622}
.wml-gfold{display:inline-block;width:12px;color:#fcd34d}.wml-gacts{float:right}.wml-gacts .wml-btn{padding:0 8px;font-size:11px}
.wml-linkbtns{display:flex;gap:6px}
.wml-link{background:none;border:0;padding:0;color:#93c5fd;cursor:pointer;font:inherit;font-size:12px}.wml-link:hover{text-decoration:underline}
.wml-presets{margin:0 0 10px;padding:8px 10px;border:1px solid #57534e;border-radius:8px;background:#0c0a09}
.wml-preset-bar{display:flex;gap:6px;align-items:center;flex-wrap:wrap}
.wml-select{background:#1c1917;color:#e7e5e4;border:1px solid #57534e;border-radius:6px;padding:4px 8px;font:inherit;max-width:100%;min-width:180px}
.wml-preview{margin-top:6px;padding:6px 8px;border:1px solid #44403c;border-radius:6px;background:#1c1917}
.wml-text-in{display:block;width:100%;box-sizing:border-box;margin-top:3px;background:#0c0a09;color:#e7e5e4;border:1px solid #57534e;border-radius:6px;padding:5px 8px;font:inherit}
.wml-confirm.wml-ask{border-color:#57534e}
@media (max-width:640px){.wml-win{left:2vw!important;top:3vh!important;width:96vw!important;height:90vh!important;resize:none}.wml-col-ver,.wml-col-num{display:none}}
.wml-load{position:fixed;inset:0;z-index:2147483040;display:flex;align-items:center;justify-content:center;padding:16px;background:#1c1917}
.wml-load.wml-load-out{animation:wml-load-out .25s both}
@keyframes wml-load-out{to{opacity:0}}
.wml-load-card{width:min(380px,100%);display:flex;flex-direction:column;gap:8px}
.wml-load-title{font-size:15px;font-weight:600;color:#f5f5f4}
.wml-load-track{position:relative;height:8px;border-radius:4px;background:#292524;border:1px solid #44403c;overflow:hidden}
.wml-load-fill{position:absolute;inset:0;transform-origin:left;transform:scaleX(0);background:#d97706}
.wml-load-shine{position:absolute;top:0;bottom:0;left:0;width:35%;background:linear-gradient(90deg,transparent,#ffffff30,transparent);animation:wml-load-shine 1.3s linear infinite}
@keyframes wml-load-shine{from{transform:translateX(-100%)}to{transform:translateX(290%)}}
.wml-load-line{color:#d6d3d1;font-variant-numeric:tabular-nums}
.wml-load-sub{color:#a8a29e;font-size:12px;min-height:1.45em;overflow-wrap:anywhere}
.wml-load-btns{display:flex;flex-wrap:wrap;gap:6px;align-items:center}
.wml-load-btns[hidden]{display:none}
.wml-copyout{width:100%;height:9em;margin-top:6px;font:11px/1.4 ui-monospace,Consolas,monospace;background:#0c0a09;color:#e7e5e4;border:1px solid #44403c;border-radius:6px}
.wml-bootlog{max-height:22em;overflow:auto;white-space:pre-wrap;font:11px/1.45 ui-monospace,Consolas,monospace;background:#0c0a09;border:1px solid #292524;border-radius:6px;padding:6px 8px;margin:6px 0 0;color:#d6d3d1}
.wml-load-bad .wml-load-fill{background:#b91c1c}
.wml-load-bad .wml-load-shine{display:none}
@media (prefers-reduced-motion:reduce){.wml-load.wml-load-out{animation:none}.wml-load-shine{display:none}}
`;
  function ensureStyle() {
    if (document.getElementById('wml-style')) return;
    const s = document.createElement('style');
    s.id = 'wml-style';
    s.textContent = CSS;
    document.head.appendChild(s);
  }

  /** tiny DOM helper: el('div', {class, style, title, onclick…}, children…) */
  function el(tag, props, ...kids) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (v == null || v === false) continue;
      if (k === 'class') e.className = v;
      else if (k === 'style') e.style.cssText = v;
      else if (k.startsWith('on') && typeof v === 'function') e.addEventListener(k.slice(2), v);
      else if (k in e && k !== 'list') e[k] = v;
      else e.setAttribute(k, v === true ? '' : v);
    }
    for (const c of kids.flat()) if (c != null && c !== false) e.append(c.nodeType ? c : String(c));
    return e;
  }
  function uiButton(label, onClick, opts = {}) {
    return el('button', { class: 'wml-btn' + (opts.primary ? ' wml-primary' : '') + (opts.icon ? ' wml-icon' : '') + (opts.danger ? ' wml-danger' : ''), title: opts.title, disabled: opts.disabled, type: 'button', onclick: onClick }, label);
  }

  /** a yes/no question shown inside a WML window; resolves true for the confirm button */
  const openQuestions = [];             // cancel functions, newest last (the back button answers "no")
  function askConfirm(win, { title, lines = [], ok = L('확인', 'OK'), cancel = L('취소', 'Cancel'), primary = false }) {
    return new Promise(resolve => {
      const shade = el('div', { class: 'wml-confirm-shade' });
      const finish = v => { const i = openQuestions.indexOf(no); if (i >= 0) openQuestions.splice(i, 1); shade.remove(); resolve(v); };
      const no = () => finish(false);
      openQuestions.push(no);
      const yes = uiButton(ok, () => finish(true), primary ? { primary: true } : { danger: true });
      const box = el('div', { class: 'wml-confirm', role: 'alertdialog' },
        el('div', { class: 'wml-confirm-title' }, title),
        ...lines.map(l => el('div', { class: 'wml-small', style: 'margin-top:6px;color:#d6d3d1' }, l)),
        el('div', { style: 'display:flex;gap:6px;justify-content:flex-end;margin-top:14px' }, uiButton(cancel, () => finish(false)), yes));
      shade.addEventListener('pointerdown', e => { if (e.target === shade) finish(false); });
      shade.addEventListener('keydown', e => { if (e.key === 'Escape') finish(false); });
      shade.append(box);
      win.el.append(shade);
      yes.focus();
    });
  }

  /** a few text boxes shown inside a WML window; resolves the values (trimmed) or null for cancel */
  function askText(win, { title, lines = [], fields = [], ok = L('확인', 'OK'), cancel = L('취소', 'Cancel') }) {
    return new Promise(resolve => {
      const shade = el('div', { class: 'wml-confirm-shade' });
      const finish = v => { const i = openQuestions.indexOf(no); if (i >= 0) openQuestions.splice(i, 1); shade.remove(); resolve(v); };
      const no = () => finish(null);
      openQuestions.push(no);
      const inputs = fields.map(f => el('input', { type: 'text', class: 'wml-text-in', value: f.value || '', placeholder: f.placeholder || '', maxLength: f.max || 200, 'aria-label': f.label }));
      const submit = () => {
        const v = inputs.map(i => i.value.trim());
        const empty = fields.findIndex((f, i) => f.required && !v[i]);
        if (empty >= 0) { inputs[empty].focus(); return; }
        finish(v);
      };
      const yes = uiButton(ok, submit, { primary: true });
      const box = el('div', { class: 'wml-confirm wml-ask', role: 'alertdialog' },
        el('div', { class: 'wml-confirm-title' }, title),
        ...lines.map(l => el('div', { class: 'wml-small', style: 'margin-top:6px;color:#d6d3d1' }, l)),
        ...fields.map((f, i) => el('label', { class: 'wml-small', style: 'display:block;margin-top:8px;color:#d6d3d1' }, f.label, inputs[i])),
        el('div', { style: 'display:flex;gap:6px;justify-content:flex-end;margin-top:14px' }, uiButton(cancel, no), yes));
      shade.addEventListener('pointerdown', e => { if (e.target === shade) no(); });
      shade.addEventListener('keydown', e => { if (e.key === 'Escape') no(); else if (e.key === 'Enter') { e.preventDefault(); submit(); } });
      shade.append(box);
      win.el.append(shade);
      (inputs[0] || yes).focus();
    });
  }

  const windows = new Map();     // id -> handle
  // above WAYWORKS' workspace (2147483000) so WML windows are not buried, below its menus and notices (2147483551+)
  const Z_WIN = 2147483100, Z_WIN_MAX = 2147483400;
  let zTop = Z_WIN;
  function openWindow({ id, title, width = 520, height = 420, render, onClose, owner }) {
    ensureStyle();
    const existing = windows.get(id);
    if (existing) { existing.focus(); return existing; }
    const saved = lsGet(`wml.win.${id}`, null);
    const vw = window.innerWidth, vh = window.innerHeight;
    const w = Math.min(saved ? saved.w : width, vw - 16), h = Math.min(saved ? saved.h : height, vh - 16);
    const x = Math.max(8, Math.min(saved ? saved.x : (vw - w) / 2, vw - w - 8));
    const y = Math.max(8, Math.min(saved ? saved.y : Math.max(24, (vh - h) / 3), vh - 60));
    const titleEl = el('b', null, title || id);
    const body = el('div', { class: 'wml-win-body' });
    const win = el('div', { class: 'wml-ui wml-win', 'data-wml-ui': true, role: 'region', 'aria-label': title || id,
      style: `left:${x}px;top:${y}px;width:${w}px;height:${h}px` });
    const close = () => { win.remove(); windows.delete(id); ro && ro.disconnect(); if (onClose) try { onClose(); } catch (e) { console.error(e); } };
    const bar = el('div', { class: 'wml-win-title' }, titleEl, el('button', { class: 'wml-win-close', title: L('닫기', 'Close'), type: 'button', onclick: close }, '✕'));
    win.append(bar, body);
    const save = () => lsSet(`wml.win.${id}`, { x: win.offsetLeft, y: win.offsetTop, w: win.offsetWidth, h: win.offsetHeight });
    const focus = () => { zTop = Math.min(zTop + 1, Z_WIN_MAX); win.style.zIndex = String(zTop); };
    win.addEventListener('pointerdown', focus);
    // drag by the title bar (mouse and touch)
    bar.addEventListener('pointerdown', e => {
      if (e.target.closest('button')) return;
      const sx = e.clientX - win.offsetLeft, sy = e.clientY - win.offsetTop;
      bar.setPointerCapture(e.pointerId);
      const move = m => {
        win.style.left = Math.max(-win.offsetWidth + 80, Math.min(m.clientX - sx, window.innerWidth - 80)) + 'px';
        win.style.top = Math.max(0, Math.min(m.clientY - sy, window.innerHeight - 40)) + 'px';
      };
      const up = () => { bar.removeEventListener('pointermove', move); bar.removeEventListener('pointerup', up); save(); };
      bar.addEventListener('pointermove', move);
      bar.addEventListener('pointerup', up);
    });
    let ro = null;
    if (window.ResizeObserver) { let tmr; ro = new ResizeObserver(() => { clearTimeout(tmr); tmr = setTimeout(save, 300); }); ro.observe(win); }
    const handle = {
      el: win, body, owner, close, focus,
      setTitle: t => { titleEl.textContent = t; },
      refresh: () => { body.textContent = ''; try { render && render(body, handle); } catch (e) { body.append(el('div', { class: 'wml-note' }, L(`창을 그리다 오류가 났어요: ${e.message}`, `Error while drawing this window: ${e.message}`))); console.error(e); } },
    };
    windows.set(id, handle);
    document.body.appendChild(win);
    focus();
    handle.refresh();
    return handle;
  }

  // ---------------------------------------------------------------- dock (the WML button bar)
  // One bar for every mod button, so the screen keeps one place for them: drag it by the grip, fold it away
  // (only a small tab is left), and it lays the buttons out in lines of `perLine` (5 by default) — a sixth
  // button starts another line. A mod's own floating button can be taken in with api.ui.adopt(el).
  const DOCK_KEY = 'wml.dock';
  let dockEl = null, dockBar = null, dockItems = null, dockTab = null, dockFold = null, dockOpt = null;
  const dockOpts = () => (dockOpt || (dockOpt = { open: true, perLine: 5, x: null, y: null, ...lsGet(DOCK_KEY, {}) }));
  const saveDock = () => lsSet(DOCK_KEY, dockOpts());
  function dockSet(patch) { Object.assign(dockOpts(), patch); saveDock(); renderDock(); }

  /** top of the page's own controls along the bottom edge (a phone layout's tab bar), or 0 when there are none */
  function bottomControlsTop() {
    const h = window.innerHeight;
    let top = 0;
    for (const fx of [0.05, 0.25, 0.5, 0.75]) {
      for (const e of document.elementsFromPoint(window.innerWidth * fx, h - 4)) {
        if (e.closest('.wml-ui')) continue;
        const c = e.closest('button, a[href], [role="tab"], [role="button"], input, select');
        if (c) { const t = c.getBoundingClientRect().top; if (t > h / 2 && (!top || t < top)) top = t; }
        break;                                              // only what the page shows on top at that spot
      }
    }
    return top;
  }
  function dockPlace() {
    const o = dockOpts();
    dockEl.dataset.wmlMoved = o.x == null ? '' : '1';
    if (o.x == null) {
      dockEl.style.left = ''; dockEl.style.top = '';
      const lift = bottomControlsTop();
      dockEl.style.bottom = lift ? `${Math.round(window.innerHeight - lift + 4)}px` : '';
      return;
    }
    const r = dockEl.getBoundingClientRect();
    dockEl.style.left = `${Math.max(0, Math.min(o.x, window.innerWidth - Math.max(44, r.width)))}px`;
    dockEl.style.top = `${Math.max(0, Math.min(o.y, window.innerHeight - Math.max(26, r.height)))}px`;
    dockEl.style.bottom = 'auto';
  }
  function dockDrag(e) {
    if (e.button > 0) return;
    const r = dockEl.getBoundingClientRect(), sx = e.clientX - r.left, sy = e.clientY - r.top;
    e.target.setPointerCapture(e.pointerId);
    e.preventDefault();
    const move = m => {
      const box = dockEl.getBoundingClientRect();
      dockOpts().x = Math.max(0, Math.min(m.clientX - sx, window.innerWidth - box.width));
      dockOpts().y = Math.max(0, Math.min(m.clientY - sy, window.innerHeight - box.height));
      dockPlace();
    };
    const up = () => { e.target.removeEventListener('pointermove', move); e.target.removeEventListener('pointerup', up); saveDock(); };
    e.target.addEventListener('pointermove', move);
    e.target.addEventListener('pointerup', up);
  }

  function renderDock() {
    if (!state.booted || !document.body) return;
    ensureStyle();
    const o = dockOpts();
    if (!dockEl) {
      dockEl = el('div', { id: 'wml-dock', class: 'wml-ui wml-dock', 'data-wml-ui': true });
      dockItems = el('div', { class: 'wml-dock-items' });
      dockFold = el('button', { class: 'wml-dock-fold', type: 'button', title: L('버튼 줄 접기', 'Fold the bar'), onclick: () => dockSet({ open: false }) }, '‹');
      dockBar = el('div', { class: 'wml-dock-bar' },
        el('button', { class: 'wml-dock-grip', type: 'button', title: L('끌어서 옮기기', 'Drag to move'), 'aria-label': L('WML 버튼 줄 옮기기', 'Move the WML button bar'), onpointerdown: dockDrag }),
        dockItems, dockFold);
      dockTab = el('button', { class: 'wml-dock-tab', type: 'button', onclick: () => dockSet({ open: true }) }, 'WML ›');
      dockEl.append(dockBar, dockTab);
      document.body.appendChild(dockEl);
      window.addEventListener('resize', () => { if (dockEl) dockPlace(); });
      setInterval(() => { if (dockEl && dockOpts().x == null) dockPlace(); }, 1500);
    }
    const failed = state.failed.length, errs = diagLog.errors;
    dockBar.style.display = o.open ? '' : 'none';
    dockTab.style.display = o.open ? 'none' : '';
    dockTab.textContent = `WML ${state.loaded.length}${failed ? ` ⚠${failed}` : ''}${errs ? ` ✖${errs}` : ''} ›`;
    dockTab.title = L('WML 버튼 줄 펴기', 'Unfold the WML button bar');
    dockItems.textContent = '';
    // [Faith] 모드 관리자는 게임 일시정지 메뉴의 "모드 설정"에서 연다. 그 메뉴에 붙지 못했을 때만 WML 버튼을 둔다(관리자로 갈 길이 없어지지 않게).
    // 독에는 모드가 올린 버튼(api.ui.addButton·adopt)만 남고, 하나도 없으면 독을 숨긴다 (vendor/WML.md)
    const launcher = pauseMenuReady() ? [] : [{ label: `WML ${state.loaded.length}${failed ? ` · ⚠${failed}` : ''}${errs ? ` · ✖${errs}` : ''}`, title: errs ? L(`WML 모드 관리자 — 오류 ${errs}개 (알림 탭)`, `WML mod manager — ${errs} error(s) (Notices tab)`) : L('WML 모드 관리자', 'WML mod manager'), onClick: toggleManager }];
    const items = [...launcher, ...dock];
    dockEl.style.display = items.length ? '' : 'none';
    if (!items.length) return;
    const cols = Math.max(1, Math.min(12, Number(o.perLine) || 5));
    dockItems.style.gridTemplateColumns = `repeat(${Math.min(cols, items.length)}, auto)`;
    for (const d of items) {
      if (d.node) { dockItems.append(d.node); continue; }                   // a mod's own button, taken in as it is
      dockItems.append(uiButton(d.label, () => { try { d.onClick(); } catch (e) { console.error(`[WML] ${d.owner} button`, e); } }, { title: d.title || d.owner }));
    }
    dockPlace();
  }

  /**
   * Take a mod's own floating button into the dock. Two ways, both undone by the function they return:
   *  - move (the default): the element itself goes into the bar. For a button a mod built with plain DOM.
   *  - { proxy: true }: the element is hidden where it is and the bar gets a button that clicks it. For one the
   *    game drew (inside #root, React): moving such a node out breaks the next render.
   */
  function dockAdopt(owner, node, info = {}) {
    if (!node || !node.nodeType) throw new Error(L('붙일 요소(element)가 아니에요', 'not an element that can be adopted'));
    if (dock.some(d => d.el === node)) return () => {};
    const label = info.label || (node.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 24) || node.title || owner;
    const title = info.title || `${label} (${owner})`;
    let entry, undo;
    if (info.proxy) {
      node.setAttribute('data-wml-stowed', '');
      entry = { owner, el: node, proxy: true, label, title, onClick: () => node.click() };
      undo = () => node.removeAttribute('data-wml-stowed');
    } else {
      const home = { parent: node.parentNode, next: node.nextSibling, style: node.getAttribute('style') };
      const wrap = el('span', { class: 'wml-dock-adopted' });
      wrap.append(node);
      entry = { owner, el: node, node: wrap, label, title };
      undo = () => {
        if (!wrap.contains(node)) { wrap.remove(); return; }         // its mod took the button away itself
        if (home.style == null) node.removeAttribute('style'); else node.setAttribute('style', home.style);
        if (home.parent && home.parent.isConnected) home.parent.insertBefore(node, home.next && home.next.isConnected ? home.next : null);
        else wrap.replaceWith(node);
        wrap.remove();
      };
    }
    dock.push(entry);
    renderDock();
    return () => {
      const i = dock.indexOf(entry);
      if (i < 0) return;
      dock.splice(i, 1);
      try { undo(); } catch (e) { console.error(`[WML] ${owner} button undo`, e); }
      renderDock();
    };
  }

  // ---------------------------------------------------------------- manager window
  function toggleManager() {
    const w = windows.get('wml:manager');
    if (w) w.close(); else openManager();
  }

  function openManager() {
    // the two-list manager wants more room than the old one-table window: an old saved size goes, once (0.8.1)
    if (!lsGet('wml.mgr2', false)) {
      const saved = lsGet('wml.win.wml:manager', null);
      if (saved && saved.w < 940) lsDel('wml.win.wml:manager');
      lsSet('wml.mgr2', true);
    }
    return openWindow({ id: 'wml:manager', title: `${L('WML 모드 관리자', 'WML mod manager')} · v${VERSION}`, width: 1040, height: 700, render: renderManager });
  }

  // ---- adding mods by drag & drop or file picker (installs into the browser)
  const sessionChanges = [];            // installs / removals made since the page loaded (need a reload)
  const justAdded = new Set();          // ids installed or registered since the page loaded: marked in the list
  let managerQuery = '';                // the manager's search box (kept across refreshes)
  const pickUsed = new Set(), pickUnused = new Set();   // rows picked in the "in use" / "not in use" lists
  let pickAnchor = null;                // the row a Shift-click range starts from
  let presetPick = '';                  // the manager's preset list: '' | 'mods.js' | 'pkg:<key>' | 'my:<key>'
  let presetNote = null;                // { ok, text } — what the last preset action did
  let presetBanner = null;              // a preset dropped on the game before this reload
  let installError = '';
  async function installAndReport(getItems) {
    installError = '';
    try {
      const items = await getItems();
      const res = await install(items);
      for (const r of res) justAdded.add(r.id);
      const kind = r => (r.mode === 'folder' ? L('폴더 등록', 'folder registered') : r.replaced ? L('브라우저 설치(바꿈)', 'installed in the browser (replaced)') : L('브라우저 설치', 'installed in the browser'));
      if (res.length > 4) {
        const folder = res.filter(r => r.mode === 'folder').length, browser = res.length - folder;
        sessionChanges.push(L(`모드 ${res.length}개 (${[folder && `폴더 등록 ${folder}`, browser && `브라우저 설치 ${browser}`].filter(Boolean).join(', ')} · 켜짐 ${res.filter(r => r.on).length}, 기본 꺼짐 ${res.filter(r => !r.on).length})`,
          `${res.length} mod(s) (${[folder && `${folder} folder(s) registered`, browser && `${browser} installed in the browser`].filter(Boolean).join(', ')} · on ${res.filter(r => r.on).length}, off by default ${res.filter(r => !r.on).length})`));
      } else for (const r of res) sessionChanges.push(`${kind(r)}: ${r.name}${r.version ? ` v${r.version}` : ''} (${r.id})`);
      const notes = res.map(r => r.note).filter(Boolean);
      if (notes.length) installError = notes.join(' ');          // shown in the manager as a notice, not an error
      if (res.skipped) installError = res.skipped;
    } catch (e) { installError = String(e && e.message || e); }
    const w = windows.get('wml:manager') || openManager();
    w.refresh();
  }
  const hasFiles = e => !!e.dataTransfer && [...(e.dataTransfer.types || [])].includes('Files');
  /** dropping files anywhere on the page opens the manager and installs them (unless something else took the drop) */
  function installDropTarget() {
    if (document.documentElement.dataset.wmlDrop) return;
    document.documentElement.dataset.wmlDrop = '1';
    document.addEventListener('dragover', e => {
      if (!hasFiles(e) || e.defaultPrevented) return;
      e.preventDefault();
      const w = windows.get('wml:manager') || openManager();
      w.el.classList.add('wml-dropping');
    });
    document.addEventListener('dragleave', e => {
      if (e.relatedTarget) return;            // still inside the page
      const w = windows.get('wml:manager');
      if (w) w.el.classList.remove('wml-dropping');
    });
    document.addEventListener('drop', e => {
      if (!hasFiles(e) || e.defaultPrevented) return;
      e.preventDefault();
      const w = windows.get('wml:manager');
      if (w) w.el.classList.remove('wml-dropping');
      const dt = e.dataTransfer;
      // one .json file: a preset (applied, then the page reloads)
      const files = [...(dt.files || [])];
      if (files.length === 1 && /\.json$/i.test(files[0].name)) { presetDrop(files[0]); return; }
      const pending = entriesFromDrop(dt);    // must start inside the event: the dropped items vanish afterwards
      installAndReport(() => pending);
    });
  }
  /** a preset file dropped on the game: kept under "my presets", applied, and the page reloads to start that set */
  async function presetDrop(file) {
    let p;
    try { p = normPreset(JSON.parse(await file.text())); } catch (e) {
      presetNote = { ok: false, text: L(`${file.name}: 프리셋으로 읽지 못했어요 — ${e.message}`, `${file.name}: could not read it as a preset — ${e.message}`) };
      (windows.get('wml:manager') || openManager()).refresh();
      return;
    }
    const key = saveUserPreset(p);
    try { await readAllMods(); } catch { /* checked with what is read */ }
    const c = applyPreset({ ...p, key }, 'my');
    try { sessionStorage.setItem(SS_PRESET_DONE, JSON.stringify({ name: p.name, file: file.name, on: c.present.length, missing: c.missing, needs: c.needs, conflicts: c.conflicts })); } catch { /* reported in the manager only */ }
    try { await liveFlush(); } catch { /* reload all the same */ }
    location.reload();
  }
  /** "삭제" on a row: what it can do depends on where the mod lives (a browser cannot delete files on disk) */
  function deleteButton(id, win) {
    return uiButton(L('삭제', 'Delete'), async () => {
      const name = nameOf(id);
      const copy = installedIds().includes(id);
      const registered = !copy && lsGet(LS_FOLDERS, []).includes(id);
      const leftovers = L('켜짐·순서·모드 설정·창 위치도 지워요.', 'Its on/off, order, settings and window positions go too.');
      const folderNote = L(`wml\\mods\\${id} 폴더는 직접 지워 주세요.`, `Delete the wml\\mods\\${id} folder yourself.`);
      const ask = copy
        ? { lines: [L('설치한 모드를 지워요. ', 'Deletes the installed mod. ') + leftovers, L('되돌릴 수 없어요.', 'This cannot be undone.')], ok: L('삭제', 'Delete') }
        : registered
          ? { lines: [L('목록에서 빼요. ', 'Takes it off the list. ') + leftovers, folderNote], ok: L('삭제', 'Delete') }
          : { lines: [L('mods.js에 있는 모드라 끄기만 해요. ', 'Listed in mods.js, so it is only switched off. ') + leftovers, folderNote], ok: L('끄고 설정 지우기', 'Switch off and clear settings') };
      if (!await askConfirm(win, { title: L(`"${name}" 모드를 정말 삭제할까요?`, `Delete the mod "${name}"?`), ...ask })) return;
      try {
        await uninstall(id);
        if (!copy && !registered) { const t = toggles(); t[id] = false; lsSet(LS_TOGGLES, t); }   // a mods.js folder mod: keep it off
        sessionChanges.push(copy ? L(`삭제: ${name} (${id})`, `deleted: ${name} (${id})`)
        : registered ? L(`목록에서 뺌: ${name} (${id}) — 폴더는 직접 지워 주세요`, `taken off the list: ${name} (${id}) — delete the folder yourself`)
          : L(`끄고 설정 지움: ${name} (${id})`, `switched off, settings cleared: ${name} (${id})`));
      } catch (e) { installError = String(e && e.message || e); }
      win.refresh();
    }, { danger: true });
  }

  function installBox() {
    const fileIn = el('input', { type: 'file', accept: '.zip,.js', multiple: true, style: 'display:none' });
    const dirIn = el('input', { type: 'file', style: 'display:none' });
    dirIn.webkitdirectory = true;
    fileIn.onchange = () => { const f = [...fileIn.files]; fileIn.value = ''; if (f.length) installAndReport(async () => f); };
    dirIn.onchange = () => { const f = [...dirIn.files]; dirIn.value = ''; if (f.length) installAndReport(async () => f); };
    // the phone app has no folders to drop or pick: mods come in as zip (or mod.js) files
    const hint = host.kind === 'player'
      ? L(' — 모드 zip·mod.js를 고르면 설치돼요.',
        ' — pick a mod zip or mod.js to install it.')
      : L(' — 모드 폴더를 wml\\mods에 넣고 이 창에 끌어다 놓으세요. zip도 돼요.',
        ' — put the mod folder in wml\\mods and drop it on this window. Zips work too.');
    return el('div', { class: 'wml-add' },
      el('div', null, el('b', null, L('모드 추가', 'Add mods')), el('span', { class: 'wml-muted' }, hint)),
      el('div', { style: 'display:flex;gap:6px;margin-top:6px;flex-wrap:wrap' },
        uiButton(host.kind === 'player' ? L('모드 파일 고르기 (zip·js)', 'Pick mod files (zip, js)') : L('파일 고르기 (zip·js)', 'Pick files (zip, js)'), () => fileIn.click()),
        host.kind === 'player' ? null : uiButton(L('폴더 고르기', 'Pick folder'), () => dirIn.click())),
      ...sessionChanges.map(s => el('div', { class: 'wml-note' }, L(`✓ ${s} — 새로고침하면 적용돼요`, `✓ ${s} — applies after a reload`))),
      installError ? el('div', { class: 'wml-small', style: 'color:#fca5a5;margin-top:4px' }, L(`설치 실패: ${installError}`, `Install failed: ${installError}`)) : null,
      fileIn, dirIn);
  }

  function statusOf(id, on) {
    const fail = state.failed.find(f => f.id === id);
    if (!defs.has(id)) return { cls: 'err', text: L('파일 오류', 'file error'), tip: fail ? fail.error : '' };
    if (fail) return { cls: 'err', text: L('오류', 'error'), tip: fail.error };
    if (on && saves.stats.skipped.includes(id)) return { cls: 'off', text: L('WML이 대신함', 'WML does it'),
      tip: L('세이브 저장 위치가 켜져 있어 WML이 대신해요.',
        '"Where saves are kept" is on, so WML does this job.') };
    if (state.loaded.includes(id)) {
      if (!on) return { cls: 'warn', text: L('새로고침하면 꺼짐', 'off after reload'), tip: L('끄기는 새로고침하면 적용돼요', 'switching off applies after a reload') };
      const d = defs.get(id);
      if (d.game && !gameMatches(d.game, state.game)) return { cls: 'warn', text: L('버전 확인', 'check version'), tip: L(`게임 ${d.game}용 (지금 ${state.game})`, `for game ${d.game} (this is ${state.game})`) };
      return { cls: 'on', text: L('작동 중', 'running'), tip: '' };
    }
    return on ? { cls: 'warn', text: L('새로고침 필요', 'reload needed'), tip: L('켜기는 새로고침하면 적용돼요', 'switching on applies after a reload') } : { cls: 'off', text: L('꺼짐', 'off'), tip: '' };
  }

  // ---- how full the browser storage is. Game saves live in localStorage: about 5 MB per site, and every
  // html file opened by double-click (file://) shares that one space. Mods dropped on the game go to IndexedDB.
  const LS_QUOTA = 5 * 1024 * 1024;        // characters (keys + values): the limit in Chrome, Edge and Firefox
  const STORE_KINDS = [
    { key: 'save', get label() { return L('세이브', 'saves'); }, color: '#d97706', test: k => /^(tavern|faith)-(game|slot-|auto-d|save)/.test(k) },
    { key: 'log', get label() { return L('플레이 기록', 'play log'); }, color: '#0ea5e9', test: k => k === 'tavern-play-log' || k === 'faith-play-log' },
    { key: 'game', get label() { return L('게임 설정', 'game settings'); }, color: '#a8a29e', test: k => /^(tavern-|faith-|elena-image-|wayward-custom-wives|wayward-image-backend)/.test(k) },
    { key: 'other', get label() { return L('모드·기타', 'mods & other'); }, color: '#818cf8', test: () => true },
  ];
  function storageUsage() {
    const items = [];
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i), v = rawGetItem.call(localStorage, k) || '';
        items.push({ key: k, size: k.length + v.length, kind: STORE_KINDS.find(s => s.test(k)).key });
      }
    } catch { return null; }               // storage blocked (private mode etc.)
    const used = items.reduce((n, it) => n + it.size, 0);
    const byKind = Object.fromEntries(STORE_KINDS.map(s => [s.key, items.filter(it => it.kind === s.key).reduce((n, it) => n + it.size, 0)]));
    return { used, quota: LS_QUOTA, percent: Math.min(100, used / LS_QUOTA * 100), byKind, items: items.sort((a, b) => b.size - a.size) };
  }
  const sizeText = n => (n >= 1048576 ? `${(n / 1048576).toFixed(1)}MB` : `${Math.max(1, Math.round(n / 1024))}KB`);
  const percentText = p => (p > 0 && p < 1 ? L('1% 미만', 'under 1%') : `${Math.round(p)}%`);
  const storageColor = p => (p >= 95 ? '#fca5a5' : p >= 80 ? '#fcd34d' : '#a8a29e');
  function storageName(k) {
    let m;
    if (k === 'tavern-game' || k === 'faith-game') return L('현재 게임', 'current game');
    if ((m = k.match(/^faith-slot-(\d+)$/))) return L(`저장 칸 ${Number(m[1]) + 1}`, `save slot ${Number(m[1]) + 1}`);
    if ((m = k.match(/^faith-auto-d(\d+)$/))) return L(`${m[1]}일차 시작 자동저장`, `day ${m[1]} start autosave`);
    if (k === 'faith-play-log') return L('플레이 기록', 'play log');
    if (k === 'faith-settings') return L('게임 설정', 'game settings');
    if (k.startsWith('faith-')) return L('Faith 게임 데이터', 'Faith game data');
    if ((m = k.match(/^tavern-slot-(\d+)$/))) return L(`저장 칸 ${Number(m[1]) + 1}`, `save slot ${Number(m[1]) + 1}`);
    if ((m = k.match(/^tavern-auto-d(\d+)$/))) return L(`${m[1]}일차 시작 자동저장`, `day ${m[1]} start autosave`);
    if (k === 'tavern-play-log') return L('플레이 기록', 'play log');
    if (k === 'tavern-settings') return L('게임 설정', 'game settings');
    if (k.startsWith('elena-image-')) return L('게임 그림 기록', 'game image records');
    if (k.startsWith('wayward-custom-wives')) return L('직접 만든 아내', 'custom wives');
    if (k.startsWith('wayward-image-backend')) return L('그림 서버 설정', 'image server settings');
    if ((m = k.match(/^wml\.mod\.(.+)$/))) return L(`${nameOf(m[1])} 모드 설정`, `${nameOf(m[1])} settings`);
    if ((m = k.match(/^wml\.win\.([^:]+)/))) return m[1] === 'wml' ? L('WML 창 위치', 'WML window positions') : L(`${nameOf(m[1])} 창 위치`, `${nameOf(m[1])} window positions`);
    if (k.startsWith('wml.')) return L('WML 설정', 'WML settings');
    const owner = storageOwner(k);
    return owner ? L(`${nameOf(owner)} 모드 데이터`, `${nameOf(owner)} data`) : k;
  }
  /** best guess of the mod a key belongs to: a mod id inside the key ("wayward-brothel-v3" → brothel) */
  function storageOwner(k) {
    if (/^(tavern-|elena-image-)/.test(k)) return null;
    const flat = s => s.toLowerCase().replace(/[-_.]/g, '');
    const hits = state.listed.filter(id => new RegExp(`(^|[-_.])${id.replace(/\./g, '\\.')}([-_.]|$)`).test(k) || (id.length >= 5 && flat(k).includes(flat(id))));
    return hits.sort((a, b) => b.length - a.length)[0] || null;
  }
  /** the WML button bar: where it sits, how many buttons fit on a line, folded or not */
  function dockSection() {
    const o = dockOpts();
    const box = el('div', { class: 'wml-section' }, el('h4', null, L('버튼 줄', 'Button bar')));
    const count = el('input', { type: 'number', min: '1', max: '12', value: String(o.perLine), style: 'width:56px' });
    count.onchange = () => dockSet({ perLine: Math.max(1, Math.min(12, Number(count.value) || 5)) });
    box.append(
      el('div', { class: 'wml-small wml-muted' }, L('손잡이로 옮기고 ‹ 로 접어요.', 'Drag the handle to move; ‹ folds it.')),
      el('div', { style: 'display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-top:6px' },
        el('label', null, L('한 줄에 ', 'Per line: '), count, L(' 개', '')),
        uiButton(o.open ? L('접기', 'Fold') : L('펴기', 'Unfold'), () => dockSet({ open: !dockOpts().open })),
        uiButton(L('제자리로', 'Reset position'), () => dockSet({ x: null, y: null }), { title: L('왼쪽 아래 기본 자리로 되돌려요', 'Back to the default place at the bottom left') })),
      el('div', { class: 'wml-small wml-muted', style: 'margin-top:4px' },
        L(`지금 버튼 ${dock.length + 1}개`, `${dock.length + 1} button(s) now`) + (dock.some(d => d.el) ? L(` (다른 모드 버튼 ${dock.filter(d => d.el).length}개)`, ` (${dock.filter(d => d.el).length} from other mods)`) : '')),
    );
    return box;
  }

  let storageOpen = false;                 // the "what is big" list stays open across refreshes
  function storageSection() {
    const box = el('div', { class: 'wml-section' }, el('h4', null, L('저장 공간', 'Storage')));
    const u = storageUsage();
    if (!u) {
      box.append(el('div', { class: 'wml-small wml-muted' }, L('브라우저 저장소를 읽을 수 없어요. 사생활 보호 창이면 일반 창으로 열어 주세요.', 'Cannot read browser storage. If this is a private window, open the game in a normal one.')));
      return box;
    }
    const kinds = STORE_KINDS.filter(s => u.byKind[s.key]);
    box.append(...[
      el('div', { class: 'wml-small', style: `color:${storageColor(u.percent)}` },
        L(`localStorage ${sizeText(u.used)} / 약 5MB (${percentText(u.percent)})`, `localStorage ${sizeText(u.used)} / about 5MB (${percentText(u.percent)})`)),
      el('div', { class: 'wml-meter', title: L(`${u.used.toLocaleString()}자 / ${u.quota.toLocaleString()}자`, `${u.used.toLocaleString()} / ${u.quota.toLocaleString()} characters`) },
        ...kinds.map(s => el('i', { style: `width:${(u.byKind[s.key] / u.quota * 100).toFixed(2)}%;background:${s.color}`, title: `${s.label} ${sizeText(u.byKind[s.key])}` }))),
      el('div', { class: 'wml-small wml-muted', style: 'display:flex;flex-wrap:wrap;gap:2px 12px;margin-top:4px' },
        ...kinds.map(s => el('span', null, el('span', { class: 'wml-dot', style: `background:${s.color}` }), `${s.label} ${sizeText(u.byKind[s.key])}`))),
      u.percent >= 80 ? el('div', { class: 'wml-small', style: `color:${storageColor(u.percent)};margin-top:4px` },
        L('거의 가득 찼어요. 오래된 저장 칸을 지워 주세요.', 'Almost full. Delete old save slots.')) : null,
      el('details', { class: 'wml-small', style: 'margin-top:4px', open: storageOpen, ontoggle: e => { storageOpen = e.target.open; } },
        el('summary', { class: 'wml-muted', style: 'cursor:pointer' }, L('무엇이 큰지 보기', 'What takes the space')),
        ...u.items.slice(0, 10).map(it => el('div', { class: 'wml-store-row' },
          el('span', { title: it.key }, el('span', { class: 'wml-dot', style: `background:${STORE_KINDS.find(s => s.key === it.kind).color}` }), storageName(it.key)),
          el('span', { class: 'wml-muted' }, sizeText(it.size))))),
      el('div', { class: 'wml-small wml-muted', style: 'margin-top:4px' },
        L('게임 세이브와 모드 설정이 저장되는 곳이에요.', 'Game saves and mod settings are kept here.') + (location.protocol === 'file:' ? L(' 파일로 연 다른 html 게임과 같이 써요.', ' Shared with other html games opened as files.') : '')),
    ].filter(Boolean));
    // mods dropped on the game live in IndexedDB, which has a much larger limit
    const n = installedIds().length;
    const idbText = (used, gb) => (n
      ? L(`설치한 모드 ${n}개는 IndexedDB에 있어요${used ? `: ${used}` : ''}.`,
        `${n} installed mod(s) are in IndexedDB${used ? `: ${used}` : ''}.`)
      : L('끌어다 놓아 설치한 모드는 IndexedDB에 저장돼요.',
        'Mods installed by dropping go into IndexedDB.'));
    const idb = el('div', { class: 'wml-small wml-muted' }, idbText());
    box.append(idb);
    if (navigator.storage && navigator.storage.estimate) {
      navigator.storage.estimate().then(e => {
        idb.textContent = idbText(e.usage ? sizeText(e.usage) : '', e.quota ? Math.max(1, Math.round(e.quota / 1073741824)) : 0);
      }).catch(() => {});
    }
    return box;
  }

  function savesStatus() {
    let size = 0;
    for (const v of saves.mem.values()) size += v.length;
    return { want: saves.want, chosen: saves.chosen, failedHere: saves.failedHere, on: saves.on, ready: saves.ready, readOnly: saves.readOnly, liveRaw: saves.liveRaw, rehydrated: saves.rehydrated,
      keys: [...saves.mem.keys()], size, pending: saves.dirty.size + (saves.live ? 1 : 0), ...JSON.parse(JSON.stringify(saves.stats)),
      recovered: saves.recovered.map(r => ({ ...r })), recoveredNow: saves.recoveredNow.slice() };
  }
  let recNote = null;                      // the last restore / delete problem, shown under the kept copies
  /** copies kept instead of being overwritten: put one back, or delete it */
  function recoveredBox(win) {
    const when = at => { const d = new Date(at), p2 = n => String(n).padStart(2, '0'); return `${d.getMonth() + 1}/${d.getDate()} ${p2(d.getHours())}:${p2(d.getMinutes())}`; };
    const why = r => (r.why === 'restore' ? L('되돌리기 전에 쓰던 것', 'in use before a restore') : L('다른 버전에서 바뀌기 전 원래 세이브', 'the original, before another version changed it'));
    const box = el('div', { class: 'wml-banner', style: 'margin-top:6px' },
      el('div', { class: 'wml-small', style: 'color:#fcd34d' }, L(`보관한 세이브 ${saves.recovered.length}개`, `${saves.recovered.length} kept save copy(ies)`)),
      el('div', { class: 'wml-small wml-muted' }, L('옛 버전 게임이 세이브를 덮어쓰면 원래 세이브를 여기 보관해요. 옛 버전과 번갈아 쓰려면 저장 위치를 꺼 주세요.',
        'When an older version overwrites a save, the original is kept here. To switch between versions, turn this off.')),
      ...saves.recovered.slice().sort((a, b) => b.at - a.at).map(r => el('div', { class: 'wml-store-row' },
        el('span', { title: r.id }, `${storageName(r.key)} · ${when(r.at)} · ${sizeText(r.size)} · ${why(r)}`),
        el('span', { style: 'display:flex;gap:4px;flex:none' },
          uiButton(L('이걸로 되돌리기', 'Restore this'), async () => {
            if (!await askConfirm(win, { title: L(`${storageName(r.key)}을(를) 이 복구본으로 되돌릴까요?`, `Restore the ${storageName(r.key)} from this copy?`),
              lines: [L('지금 세이브는 복구본으로 보관해요.', 'The current save is kept as a recovery copy.')], ok: L('되돌리고 새로고침', 'Restore and reload'), primary: true })) return;
            try { await recRestore(r.id); location.reload(); }
            catch (e) { recNote = L(`되돌리지 못했어요: ${e.message}`, `Could not restore: ${e.message}`); win.refresh(); }
          }, { primary: true }),
          uiButton(L('지우기', 'Delete'), async () => {
            if (!await askConfirm(win, { title: L('이 복구본을 지울까요?', 'Delete this copy?'), lines: [L('지우면 되돌릴 수 없어요.', 'This cannot be undone.')], ok: L('지우기', 'Delete') })) return;
            try { await recDelete(r.id); recNote = null; } catch (e) { recNote = L(`지우지 못했어요: ${e.message}`, `Could not delete: ${e.message}`); }
            win.refresh();
          })))));
    if (recNote) box.append(el('div', { class: 'wml-small', style: 'color:#fca5a5;margin-top:4px' }, recNote));
    return box;
  }
  /** where saves are kept: the browser database (the default since 0.9.0) or localStorage (the game's own way) */
  function savesSection(win) {
    if (GAME_FAMILY !== 'wayward') return el('div', { class: 'wml-section' }, el('h4', null, L('세이브 저장 위치', 'Where saves are kept')),
      el('div', { class: 'wml-small wml-muted' }, L('Faith가 세이브를 직접 IndexedDB에 저장해요.', 'Faith keeps its saves in its own IndexedDB.')));
    const box = el('div', { class: 'wml-section' }, el('h4', null, L('세이브 저장 위치', 'Where saves are kept')));
    let stored = true;                     // what the next start does: on unless switched off
    try { stored = rawGetItem.call(localStorage, LS_SAVES) !== SAVES_OFF; } catch { /* storage off */ }
    const s = savesStatus();
    const n = s.keys.length;
    box.append(el('div', { class: 'wml-small wml-muted' }, saves.on
      ? L(`세이브 ${n}개를 IndexedDB에 저장 중이에요: ${sizeText(s.size)}.`,
        `${n} save(s) kept in IndexedDB: ${sizeText(s.size)}.`)
      : L('세이브가 localStorage에 있어요 (약 5MB 한도). 켜면 IndexedDB로 옮겨요.',
        'Saves are in localStorage (about 5MB limit). Switching on moves them to IndexedDB.')));
    if (saves.failedHere) box.append(el('div', { class: 'wml-small', style: 'color:#fcd34d' },
      L(`이 브라우저는 IndexedDB를 쓸 수 없어 localStorage에 저장해요 (${s.lastError}).`, `IndexedDB is not available in this browser; saves are in localStorage (${s.lastError}).`)));
    if (!saves.on && n) box.append(el('div', { class: 'wml-small', style: 'color:#fcd34d' },
      L(`공간 부족으로 IndexedDB에 남은 세이브 ${n}개: ${s.keys.map(storageName).join(', ')}`, `Left in IndexedDB for lack of room, ${n} save(s): ${s.keys.map(storageName).join(', ')}`)));
    if (s.skipped.length) box.append(el('div', { class: 'wml-small wml-muted' }, L(`WML이 대신하는 모드: ${s.skipped.map(nameOf).join(', ')}`, `Mods WML stands in for: ${s.skipped.map(nameOf).join(', ')}`)));
    if (s.readOnly) box.append(el('div', { class: 'wml-small', style: 'color:#fca5a5' }, L('다른 탭에서 이 게임이 열려 있어 이 탭은 세이브를 저장하지 않아요.', 'The game is open in another tab, so this tab does not store saves.')));
    if (s.errors) box.append(el('div', { class: 'wml-small', style: 'color:#fca5a5' }, L(`IndexedDB 쓰기 실패 ${s.errors}번 (재시도 중): ${s.lastError}`, `IndexedDB write failed ${s.errors}× (retrying): ${s.lastError}`)));
    if (saves.recovered.length) box.append(recoveredBox(win));
    const changed = stored !== saves.want;
    box.append(el('div', { style: 'display:flex;gap:6px;flex-wrap:wrap;margin-top:6px' },
      uiButton(stored ? L('끄기 (localStorage로)', 'Switch off (to localStorage)') : L('켜기 (IndexedDB로)', 'Switch on (to IndexedDB)'), () => {
        try { rawSetItem.call(localStorage, LS_SAVES, stored ? SAVES_OFF : 'idb'); } catch { /* storage off */ }
        win.refresh();
      }),
      changed ? uiButton(L('새로고침해서 적용', 'Reload to apply'), async () => { try { await liveFlush(); } catch { /* reload all the same */ } location.reload(); }, { primary: true }) : null));
    if (changed) box.append(el('div', { class: 'wml-small', style: 'color:#fcd34d;margin-top:4px' }, L('새로고침하면 세이브를 옮겨요. 먼저 백업을 권장해요.', 'Saves move on reload. A backup first is recommended.')));
    return box;
  }

  // Moving mods between "in use" and "not in use" in the manager. What they need (switching on) or what needs them
  // (switching off) comes along when the player says so; otherwise only these mods change, and the others show why
  // they do not run. Mods switched on go to the end of the in-use list, or in front of `before` (a drop on a row).
  async function setOnWithDeps(ids, on, win, { before = null } = {}) {
    ids = ids.filter((x, i) => ids.indexOf(x) === i);
    if (!ids.length) return;
    const tt = toggles();
    const listText = list => list.slice(0, 10).map(nameOf).join(', ') + (list.length > 10 ? L(` 외 ${list.length - 10}개`, ` and ${list.length - 10} more`) : '');
    const who = ids.length === 1 ? nameOf(ids[0]) : L(`고른 모드 ${ids.length}개`, `the ${ids.length} chosen mods`);
    const apply = list => {
      const t = toggles();
      for (const x of list) t[x] = on;
      lsSet(LS_TOGGLES, t);
      if (!on) return;
      // where they go in the load order: in front of the row they were dropped on, else after the last mod in use
      const rest = playerOrder().filter(x => !list.includes(x));
      const inUse = rest.filter(x => isOn(x, t));
      const at = before && rest.includes(before) ? rest.indexOf(before) : inUse.length ? rest.indexOf(inUse[inUse.length - 1]) + 1 : 0;
      rest.splice(at, 0, ...list);
      lsSet(LS_ORDER, rest);
    };
    if (on) {
      // everything they need, all the way up: off ones to switch on, missing ones and wrong versions to mention
      const need = [], missing = [], wrong = [], seen = new Set(ids);
      const up = x => {
        const d = defs.get(x);
        if (!d) return;
        for (const r of d.requires) {
          if (seen.has(r)) continue;
          seen.add(r);
          const p = defs.get(r);
          if (!p) { missing.push(r); continue; }
          if (wantVersion(d, r) && !versionMatches(p.version, wantVersion(d, r))) wrong.push(L(`${nameOf(r)} ${p.version || '(버전 없음)'} → 필요 ${wantVersion(d, r)}`, `${nameOf(r)} ${p.version || '(no version)'} → needs ${wantVersion(d, r)}`));
          if (!isOn(r, tt)) need.push(r);
          up(r);
        }
      };
      ids.forEach(up);
      const lines = [];
      if (need.length) lines.push(L(`${who}에 필요한 모드: ${listText(need)}`, `${who} needs: ${listText(need)}`));
      if (missing.length) lines.push(L(`설치되지 않은 모드: ${missing.join(', ')}`, `Not installed: ${missing.join(', ')}`));
      if (wrong.length) lines.push(L(`버전이 맞지 않는 모드: ${wrong.join(', ')}`, `Wrong version: ${wrong.join(', ')}`));
      if (need.length) {
        const all = await askConfirm(win, { title: L('필요한 모드도 같이 켤까요?', 'Switch on the mods they need too?'), lines, ok: L('같이 켜기', 'Switch them on too'), cancel: ids.length === 1 ? L('이 모드만 켜기', 'Only this mod') : L('고른 모드만 켜기', 'Only the chosen mods'), primary: true });
        apply(all ? [...need.reverse(), ...ids] : ids);   // what they need loads first
      } else if (lines.length) {
        if (await askConfirm(win, { title: L('지금은 실행되지 않는 모드가 있어요', 'Some will not run as things are'), lines, ok: L('그래도 켜기', 'Switch on anyway'), cancel: L('취소', 'Cancel'), primary: true })) apply(ids);
      } else apply(ids);
    } else {
      // everything that needs them, all the way down, that is on now
      const dependents = [], seen = new Set(ids);
      const down = x => {
        for (const o of state.listed) {
          const d = defs.get(o);
          if (seen.has(o) || !d || !d.requires.includes(x)) continue;
          seen.add(o);
          if (isOn(o, tt)) { dependents.push(o); down(o); }
        }
      };
      ids.forEach(down);
      if (dependents.length) {
        const all = await askConfirm(win, { title: L('이 모드가 필요한 모드도 같이 끌까요?', 'Switch off the mods that need it too?'),
          lines: [L(`${who}을(를) 끄면 ${dependents.length}개가 실행되지 않아요: ${listText(dependents)}`, `With ${who} off, the ${dependents.length} mod(s) that need it will not run: ${listText(dependents)}`),
            L('그대로 두면 "오류"로 표시돼요.', 'Left on, they show as "error".')],
          ok: L('같이 끄기', 'Switch them off too'), cancel: ids.length === 1 ? L('이 모드만 끄기', 'Only this mod') : L('고른 모드만 끄기', 'Only the chosen mods') });
        apply(all ? [...ids, ...dependents] : ids);
      } else apply(ids);
    }
    win.refresh();
  }

  // ---- presets in the manager: pick one (mods.js defaults, ones that came with the game, mine), see what it would do here,
  // apply it (the page reloads), keep the current set as one, export one as a file to share, import files
  function presetFind(v, mine = userPresets()) {
    if (!v) return null;
    if (v === 'mods.js') return presetFromList();
    if (v.startsWith('pkg:')) return bundledPresets.find(p => `pkg:${p.key}` === v) || null;
    if (v.startsWith('my:')) return mine.find(p => `my:${p.key}` === v) || null;
    return null;
  }
  function presetSelect(win, mine = userPresets()) {
    if (presetPick && !presetFind(presetPick, mine)) presetPick = '';
    const sel = el('select', { class: 'wml-select', 'aria-label': L('프리셋 고르기', 'Choose a preset'), onchange: () => { presetPick = sel.value; presetNote = null; win.refresh(); } },
      el('option', { value: '' }, L('— 프리셋 고르기 —', '— Choose a preset —')),
      el('option', { value: 'mods.js' }, L('mods.js 기본값', 'mods.js default')),
      bundledPresets.length ? el('optgroup', { label: L('게임에 들어 있는 프리셋', 'Came with the game') }, ...bundledPresets.map(p => el('option', { value: `pkg:${p.key}` }, p.name))) : null,
      mine.length ? el('optgroup', { label: L('내 프리셋 (이 브라우저)', 'My presets (this browser)') }, ...mine.map(p => el('option', { value: `my:${p.key}` }, p.name))) : null);
    sel.value = presetPick;
    return sel;
  }
  /** apply the preset chosen in the list (asks first; the page reloads) */
  async function presetApply(win) {
    const picked = presetFind(presetPick);
    if (!picked) return;
    const c = presetCheck(picked);
    const lines = [L(`모드 ${c.present.length}개 사용 · ${c.off.length}개 사용 안 함`, `${c.present.length} mod(s) on · ${c.off.length} off`)];
    if (c.missing.length) lines.push(L(`없는 모드 파일 (빼고 적용): ${c.missing.join(', ')}`, `Missing mod files (left out): ${c.missing.join(', ')}`));
    if (c.conflicts.length) lines.push(L(`같이 켤 수 없는 모드가 들어 있어요: ${c.conflicts.map(([x, y]) => `${nameOf(x)} ↔ ${nameOf(y)}`).join(', ')}`, `It holds mods that cannot run together: ${c.conflicts.map(([x, y]) => `${nameOf(x)} ↔ ${nameOf(y)}`).join(', ')}`));
    lines.push(L('적용 후 새로고침해요.', 'The game reloads right away.'));
    if (!await askConfirm(win, { title: L(`프리셋 "${picked.name}"을(를) 적용할까요?`, `Apply the preset "${picked.name}"?`), lines, ok: L('적용하고 새로고침', 'Apply and reload'), primary: true })) return;
    if (presetPick === 'mods.js') {
      lsDel(LS_ORDER); lsDel(LS_TOGGLES);
      lsSet(LS_PRESET_NOW, { key: 'mods.js', name: picked.name, mods: c.present, missing: [], at: Date.now() });
    } else applyPreset(picked, presetPick.split(':')[0]);
    try { sessionStorage.setItem(SS_PRESET_DONE, JSON.stringify({ name: picked.name, on: c.present.length, missing: c.missing, needs: c.needs, conflicts: c.conflicts })); } catch { /* reported in the manager only */ }
    try { await liveFlush(); } catch { /* reload all the same */ }
    location.reload();
  }
  /** a preset file dropped on the game before this reload: what came of it */
  function presetBannerEls() {
    const b = presetBanner;
    if (!b) return [];
    const out = [el('div', { class: 'wml-small', style: 'color:#86efac' }, L(`프리셋 "${b.name}" 적용 — 사용 중 ${b.on}개`, `Preset "${b.name}" applied — ${b.on} in use`))];
    if (b.missing && b.missing.length) out.push(el('div', { class: 'wml-small', style: 'color:#fca5a5' }, L(`없는 모드 파일: ${b.missing.join(', ')}`, `Missing mod files: ${b.missing.join(', ')}`)));
    for (const n of b.needs || []) out.push(el('div', { class: 'wml-small', style: 'color:#fcd34d' }, L(`${nameOf(n.id)}에 필요한 모드가 프리셋에 없어요: ${n.lack.map(nameOf).join(', ')}`, `${nameOf(n.id)} needs mods that are not in the preset: ${n.lack.map(nameOf).join(', ')}`)));
    if (b.conflicts && b.conflicts.length) out.push(el('div', { class: 'wml-small', style: 'color:#fca5a5' }, L(`같이 켤 수 없는 모드: ${b.conflicts.map(([x, y]) => `${nameOf(x)} ↔ ${nameOf(y)}`).join(', ')}`, `Cannot run together: ${b.conflicts.map(([x, y]) => `${nameOf(x)} ↔ ${nameOf(y)}`).join(', ')}`)));
    return [el('div', { class: 'wml-banner' }, ...out)];
  }
  // the preset tab: everything about presets
  function presetSection(win) {
    const box = el('div', { class: 'wml-section wml-presets' }, el('h4', null, L('프리셋', 'Presets')));
    const mine = userPresets();
    const now = lsGet(LS_PRESET_NOW, null);
    const fail = e => { presetNote = { ok: false, text: String(e && e.message || e) }; win.refresh(); };
    const sel = presetSelect(win, mine);
    const picked = presetFind(presetPick, mine);
    box.append(...presetBannerEls());
    const fileIn = el('input', { type: 'file', accept: '.json,application/json', multiple: true, style: 'display:none' });
    fileIn.onchange = async () => {
      const files = [...fileIn.files];
      fileIn.value = '';
      const ok = [], bad = [];
      for (const f of files) {
        try { const p = normPreset(JSON.parse(await f.text())); presetPick = `my:${saveUserPreset(p)}`; ok.push(p.name); } catch (e) { bad.push(`${f.name}: ${e.message}`); }
      }
      presetNote = { ok: !bad.length, text: [ok.length ? L(`가져왔어요: ${ok.join(', ')}`, `Imported: ${ok.join(', ')}`) : '',
        bad.length ? L(`가져오지 못했어요: ${bad.join(' · ')}`, `Could not import: ${bad.join(' · ')}`) : ''].filter(Boolean).join(' ') };
      win.refresh();
    };
    const nameFields = (name = '', description = '') => [
      { label: L('이름', 'Name'), value: name, required: true, max: 80 },
      { label: L('설명 (선택)', 'Description (optional)'), value: description, max: 500 }];
    const inUse = () => { const t = toggles(); return playerOrder().filter(id => isOn(id, t) && defs.has(id)).length; };
    const saveNow = async () => {
      const mineNow = now && String(now.key || '').startsWith('my:') ? mine.find(p => `my:${p.key}` === now.key) : null;
      const v = await askText(win, { title: L('지금 설정을 프리셋으로 저장', 'Save the current set as a preset'),
        lines: [L(`사용 중인 모드 ${inUse()}개와 순서를 저장해요. 같은 이름은 덮어써요.`, `Saves the ${inUse()} mod(s) in use and their order. The same name is overwritten.`)],
        fields: nameFields(mineNow ? mineNow.name : '', mineNow ? mineNow.description : ''), ok: L('저장', 'Save') });
      if (!v) return;
      const p = presetFromCurrent(v[0], v[1]);
      presetPick = `my:${saveUserPreset(p)}`;
      lsSet(LS_PRESET_NOW, { key: presetPick, name: p.name, mods: p.mods.map(m => m.id), missing: [], at: Date.now() });
      presetNote = { ok: true, text: L(`저장했어요: ${p.name} (모드 ${p.mods.length}개)`, `Saved: ${p.name} (${p.mods.length} mods)`) };
      win.refresh();
    };
    const exportNow = async () => {
      let p = picked;
      if (!p) {
        const v = await askText(win, { title: L('지금 설정을 프리셋 파일로 내보내기', 'Export the current set as a preset file'),
          lines: [L(`사용 중인 모드 ${inUse()}개와 그 순서를 파일로 저장해요.`, `Saves the ${inUse()} mod(s) in use and their order as a file.`)], fields: nameFields(), ok: L('내보내기', 'Export') });
        if (!v) return;
        p = presetFromCurrent(v[0], v[1]);
      }
      const { key, ...file } = p;
      const name = `wml-preset-${key || presetKey(p.name)}.json`;
      try {
        await saveFile(name, JSON.stringify(file, null, 2), 'application/json');
        presetNote = { ok: true, text: L(`내보냈어요: ${name} (${host.kind === 'player' ? '다운로드/WML 폴더' : '다운로드 폴더'})`,
          `Exported: ${name} (${host.kind === 'player' ? 'Download/WML' : 'Downloads'})`) };
      } catch (e) { presetNote = { ok: false, text: L(`내보내지 못했어요: ${e.message}`, `Could not export: ${e.message}`) }; }
      win.refresh();
    };
    const deleteNow = async () => {
      if (!picked || !presetPick.startsWith('my:')) return;
      if (!await askConfirm(win, { title: L(`프리셋 "${picked.name}"을(를) 지울까요?`, `Delete the preset "${picked.name}"?`),
        lines: [L('이 브라우저의 프리셋만 지워요.', 'Only the preset saved in this browser is deleted.')], ok: L('지우기', 'Delete') })) return;
      deleteUserPreset(picked.key);
      presetNote = { ok: true, text: L(`지웠어요: ${picked.name}`, `Deleted: ${picked.name}`) };
      presetPick = '';
      win.refresh();
    };
    box.append(el('div', { class: 'wml-preset-bar' }, sel,
      uiButton(L('적용', 'Apply'), () => { presetApply(win).catch(fail); }, { primary: !!picked, disabled: !picked, title: L('고른 프리셋으로 바꾸고 새로고침해요', 'Switches to the chosen preset and reloads') }),
      uiButton(L('지금 설정 저장…', 'Save current…'), () => { saveNow().catch(fail); }, { title: L('사용 중인 모드와 순서를 "내 프리셋"으로 저장해요', 'Saves the mods in use and their order as one of "My presets"') }),
      uiButton(L('내보내기', 'Export'), () => { exportNow().catch(fail); }, { title: picked ? L('고른 프리셋을 파일(.json)로 저장해요', 'Saves the chosen preset as a file (.json)') : L('지금 설정을 프리셋 파일(.json)로 저장해요', 'Saves the current set as a preset file (.json)') }),
      uiButton(L('가져오기…', 'Import…'), () => fileIn.click(), { title: L('프리셋 파일(.json)을 "내 프리셋"에 추가해요', 'Adds a preset file (.json) to "My presets"') }),
      picked && presetPick.startsWith('my:') ? uiButton(L('삭제', 'Delete'), () => { deleteNow().catch(fail); }, { danger: true, title: L('이 브라우저에 저장한 프리셋을 지워요', 'Deletes this preset from the browser') }) : null,
      fileIn));
    // what the chosen preset would do here
    if (picked) {
      const c = presetCheck(picked);
      const pv = el('div', { class: 'wml-preview wml-small' });
      if (picked.description) pv.append(el('div', { style: 'color:#d6d3d1' }, picked.description));
      pv.append(el('div', { class: 'wml-muted' }, L(`모드 ${picked.mods.length}개 · 적용하면 사용 중 ${c.present.length}개, 사용 안 함 ${c.off.length}개`, `${picked.mods.length} mod(s) · applied: ${c.present.length} in use, ${c.off.length} not in use`)
        + (picked.game && state.game && picked.game !== state.game ? L(` · 게임 ${picked.game}에서 만든 프리셋`, ` · made on game ${picked.game}`) : '')));
      if (c.missing.length) pv.append(el('div', { style: 'color:#fca5a5' }, L(`없는 모드 파일: ${c.missing.join(', ')}`, `Missing mod files: ${c.missing.join(', ')}`)));
      if (c.versions.length) pv.append(el('div', { style: 'color:#fcd34d' }, L(`버전 다름: ${c.versions.map(x => `${nameOf(x.id)} (프리셋 ${x.want}, 지금 ${x.have})`).join(', ')}`,
        `Different versions: ${c.versions.map(x => `${nameOf(x.id)} (preset ${x.want}, now ${x.have})`).join(', ')}`)));
      for (const n of c.needs) pv.append(el('div', { style: 'color:#fcd34d' }, L(`${nameOf(n.id)}에 필요한 모드가 프리셋에 없어요: ${n.lack.map(nameOf).join(', ')}`, `${nameOf(n.id)} needs mods not in the preset: ${n.lack.map(nameOf).join(', ')}`)));
      if (c.conflicts.length) pv.append(el('div', { style: 'color:#fca5a5' }, L(`같이 켤 수 없는 모드: ${c.conflicts.map(([x, y]) => `${nameOf(x)} ↔ ${nameOf(y)}`).join(', ')}`, `Cannot run together: ${c.conflicts.map(([x, y]) => `${nameOf(x)} ↔ ${nameOf(y)}`).join(', ')}`)));
      if (c.notes.length) pv.append(el('div', { class: 'wml-muted' }, L(`순서 자동 조정: ${c.notes.map(n => `${nameOf(n.id)} — ${n.msg}`).join(' · ')}`, `Order adjusted at load: ${c.notes.map(n => `${nameOf(n.id)} — ${n.msg}`).join(' · ')}`)));
      const order = el('details', { style: 'margin-top:4px' }, el('summary', { style: 'cursor:pointer;color:#a8a29e' }, L(`프리셋의 모드 순서 보기 (${picked.mods.length})`, `Show the preset's mods in order (${picked.mods.length})`)),
        el('ol', { style: 'margin:4px 0 0 18px;padding:0' }, ...picked.mods.map(m => el('li', { style: defs.has(m.id) ? '' : 'color:#fca5a5' }, `${defs.has(m.id) ? nameOf(m.id) : m.id}${m.version ? ` ${m.version}` : ''}${defs.has(m.id) ? '' : L(' — 파일 없음', ' — not found')}`))));
      pv.append(order);
      box.append(pv);
    }
    if (now && now.name) box.append(el('div', { class: 'wml-small wml-muted', style: 'margin-top:4px' },
      L(`마지막으로 적용한 프리셋: ${now.name}`, `Last applied preset: ${now.name}`) + (presetChanged(now) ? L(' (그 뒤로 바꿈)', ' (changed since)') : '')));
    if (presetNote) box.append(el('div', { class: 'wml-small', style: `margin-top:4px;color:${presetNote.ok ? '#86efac' : '#fca5a5'}` }, presetNote.text));
    box.append(el('div', { class: 'wml-small wml-muted', style: 'margin-top:4px' }, host.kind === 'player'
      ? L('프리셋 파일은 [가져오기]로 넣어요.', 'Add preset files with [Import].')
      : L('프리셋 파일(.json)을 게임 화면에 끌어다 놓으면 바로 적용돼요.', 'Drop a preset file (.json) on the game to apply it.')));
    return box;
  }

  // ---- the manager window: tabs (mods · presets · add · settings & backup · notices)
  let managerTab = 'mods';              // the tab on show
  let detailId = null;                  // the mod shown in the mods tab's details pane
  const listScroll = { on: 0, off: 0 }; // where the two lists were scrolled to (kept across redraws)
  let modTabRO = null;                  // watches the mods tab's width (side by side or stacked)
  let managerTagPick = '';              // the mods tab's tag filter: '' (all) | a main tag | 'base' | 'untagged'
  let groupMode = 'author';             // how the not-in-use list is grouped (groups folded): 'author' (or pack) | 'tag' | 'none'
  const openGroups = new Set();         // groups opened in the not-in-use list

  function renderManager(body, win) {
    // mods switched off at start are read the first time the manager opens: their names, versions and tags are in
    // their files (0.9.1)
    if (unread.size || readingAll) {
      const line = el('div', { class: 'wml-small wml-muted', style: 'padding:16px' });
      const show = () => { line.textContent = L(`꺼진 모드 읽는 중 ${readCount.done}/${readCount.total}`, `Reading off mods ${readCount.done}/${readCount.total}`); };
      readAllMods().then(() => { readCount.show = null; if (win.el.isConnected) win.refresh(); },
        e => { readCount.show = null; line.textContent = L(`꺼진 모드를 읽지 못했어요: ${e && e.message || e}`, `Could not read the mods that are off: ${e && e.message || e}`); });
      readCount.show = show;
      show();
      body.append(line);
      return;
    }
    const t = toggles();
    const order = playerOrder();
    const pending = () => {
      const now = playerOrder(), tt = toggles();
      return !bootSnapshot || sessionChanges.length > 0 || now.join('|') !== bootSnapshot.order.join('|') || state.listed.some(id => isOn(id, tt) !== bootSnapshot.on[id]);
    };
    const probs = [
      ...state.failed.map(f => `${nameOf(f.id)}: ${f.error}`),
      ...state.warnings.map(w => `${w.mod ? nameOf(w.mod) + ': ' : ''}${w.msg}`),
    ];
    const TABS = [
      ['mods', L('모드', 'Mods')],
      ['presets', L('프리셋', 'Presets')],
      ['add', L('추가·설치', 'Add')],
      ['settings', L('설정·백업', 'Settings & backup')],
      ['notices', probs.length ? L(`알림 ${probs.length}`, `Notices ${probs.length}`) : L('알림', 'Notices')],
    ];
    if (!TABS.some(([k]) => k === managerTab)) managerTab = 'mods';
    if (modTabRO) { modTabRO.disconnect(); modTabRO = null; }
    body.classList.toggle('wml-body-fill', managerTab === 'mods');
    body.append(el('div', { class: 'wml-tabs', role: 'tablist' },
      ...TABS.map(([k, label]) => el('button', { type: 'button', role: 'tab', class: 'wml-tab' + (k === managerTab ? ' wml-tab-on' : '') + (k === 'notices' && probs.length ? ' wml-tab-warn' : ''),
        'aria-selected': k === managerTab ? 'true' : 'false', onclick: () => { managerTab = k; win.refresh(); } }, label)),
      el('span', { style: 'flex:1' }),
      el('span', { class: 'wml-small wml-muted' },
        L(`게임 ${state.game || '?'} · 언어 ${LANG()} · 작동 중 ${state.loaded.length} / 목록 ${state.listed.length}`, `Game ${state.game || '?'} · ${LANG()} · running ${state.loaded.length} / listed ${state.listed.length}`)
        + (host.kind === 'player' ? ` · ${appLabel()}` : ''))));
    const usage = storageUsage();
    if (usage && usage.percent >= 80) body.append(el('div', { class: 'wml-small', style: `color:${storageColor(usage.percent)};margin:0 0 6px` },
      L(`⚠ 저장 공간 ${percentText(usage.percent)} 사용 중 (설정·백업 → 저장 공간)`, `⚠ Storage ${percentText(usage.percent)} full (Settings & backup → Storage)`)));

    if (managerTab === 'mods') body.append(modsTab(win, t, order));
    else if (managerTab === 'presets') body.append(presetSection(win));
    else if (managerTab === 'add') {
      body.append(installBox());
      const gone = state.missing.filter(id => state.fromList.includes(id));
      if (gone.length) body.append(el('div', { class: 'wml-small wml-muted', style: 'margin-top:6px' },
        L(`폴더가 없어 건너뛴 모드 ${gone.length}개: ${gone.join(', ')}`,
          `Skipped for a missing folder, ${gone.length} mod(s): ${gone.join(', ')}`)));
    } else if (managerTab === 'settings') {
      body.append(dockSection(), storageSection(), savesSection(win), transferSection(win));
    } else {
      const box = el('div', { class: 'wml-section' }, el('h4', null, L(`이번 실행의 알림 ${probs.length}`, `Notices this session ${probs.length}`)));
      if (!probs.length) box.append(el('div', { class: 'wml-small wml-muted' }, L('알림이 없어요.', 'No notices.')));
      box.append(...probs.map(p => el('div', { class: 'wml-small', style: 'color:#fcd34d;margin:2px 0' }, '• ' + p)));
      body.append(box, diagSection(), bootSection());
      // for mod authors: what the structure shows, folded (not a problem by itself)
      if (state.diagnostics.length) {
        body.append(el('details', { class: 'wml-section' },
          el('summary', { style: 'cursor:pointer' }, L(`개발자용 진단 ${state.diagnostics.length}`, `Developer diagnostics ${state.diagnostics.length}`)),
          ...state.diagnostics.map(dg => {
            const h = dg.raw && hooks.get(dg.raw);
            const runs = h ? L(` · 지금까지 훅 실행 ${h.calls}번`, ` · hook runs so far: ${h.calls}`) : '';
            return el('div', { class: 'wml-small wml-muted' }, `• ${dg.mod ? nameOf(dg.mod) + ': ' : ''}${dg.msg}${runs}`);
          })));
      }
    }

    // footer
    const isPending = pending();
    const foot = el('div', { class: 'wml-win-foot' },
      uiButton(L('기본값으로', 'Defaults'), () => { lsDel(LS_ORDER); lsDel(LS_TOGGLES); win.refresh(); }, { title: L('mods.js에 적힌 순서와 켜짐 상태로 되돌려요', 'Back to the order and on/off of mods.js (and the language defaults)') }),
      uiButton(L('모두 사용', 'Use all'), () => { const tt = {}; state.listed.forEach(i => { tt[i] = true; }); lsSet(LS_TOGGLES, tt); win.refresh(); }),
      uiButton(L('모두 사용 안 함', 'Use none'), () => { const tt = {}; state.listed.forEach(i => { tt[i] = false; }); lsSet(LS_TOGGLES, tt); win.refresh(); }),
      host.kind === 'player' ? null : uiButton(L('mods.js로 복사', 'Copy as mods.js'), () => copyModsJs(foot), { title: L('지금 순서와 켜짐 상태를 mods.js 내용으로 복사해요 (배포용)', 'Copies the current order and on/off as mods.js text (for packaging)') }),
      HOST && typeof HOST.menu === 'function' ? uiButton(L('플레이어 메뉴', 'Player menu'), () => HOST.menu(), { title: L('게임 묶음·그림 묶음 가져오기와 플레이어 설정', 'Import game and image bundles, player settings') }) : null,
      el('span', { style: 'flex:1' }),
      isPending ? el('span', { class: 'wml-note' }, L('바뀐 설정이 있어요', 'Settings changed')) : null,
      uiButton(L('새로고침해서 적용', 'Reload to apply'), () => location.reload(), { primary: true, disabled: !isPending }));
    const old = win.el.querySelector('.wml-win-foot');
    if (old) old.remove();
    win.el.append(foot);
  }

  // the mods tab: "in use" and "not in use" side by side (stacked when narrow), one line per mod, each list scrolls by
  // itself, and the picked mod's details in a pane below
  function modsTab(win, t, order) {
    const root = el('div', { class: 'wml-modtab' });
    const fail = e => console.error('[WML] move', e);
    const used = order.filter(id => isOn(id, t)), unused = order.filter(id => !isOn(id, t));
    // the selection stays across redraws; mods that moved to the other list drop out of it
    for (const id of [...pickUsed]) if (!used.includes(id)) pickUsed.delete(id);
    for (const id of [...pickUnused]) if (!unused.includes(id)) pickUnused.delete(id);
    if (detailId && !order.includes(detailId)) detailId = null;
    const preview = [];
    sortMods(used.filter(id => defs.has(id)), preview);

    // top: what a dropped preset did, the preset list (apply here, the rest in the preset tab), search
    root.append(...presetBannerEls());
    const rowText = new Map();            // row -> lower-case name, id and description
    const groupHeads = [];                // [head row, its rows] of the not-in-use list, when grouped
    const countOn = el('span'), countOff = el('span');
    const searchNote = el('span', { class: 'wml-small wml-muted' });
    // the filter chips: main tags, "base" (other mods need it, found automatically) and "no tag"
    const tagsOf = id => {
      const d = defs.get(id);
      const main = d ? d.tags.filter(x => MOD_TAGS[x] && MOD_TAGS[x].kind === 'main') : [];
      if (d && !main.includes('prompt') && touchesPrompt(id)) main.push('prompt');
      return [...main, ...(isBase(id) ? ['base'] : []), ...(main.length ? [] : ['untagged'])];
    };
    const applySearch = () => {
      const q = managerQuery.trim().toLowerCase();
      const filtering = !!q || !!managerTagPick;
      let on = 0;
      const offHits = new Set();            // in tag groups one mod can sit in several groups: count it once
      for (const [row, text] of rowText) {
        const hit = (!q || text.includes(q)) && (!managerTagPick || row.dataset.tags.split(' ').includes(managerTagPick));
        row.dataset.hit = hit ? '1' : '';
        // a row in a folded group stays hidden unless a search or filter is on (then every group with a hit opens)
        row.style.display = hit && (filtering || !row.dataset.group || openGroups.has(row.dataset.group)) ? '' : 'none';
        if (hit) { if (row.dataset.list === 'on') on++; else offHits.add(row.dataset.id); }
      }
      const off = offHits.size;
      for (const [head, rows] of groupHeads) {
        const n = rows.filter(r => r.dataset.hit).length;
        head.style.display = n ? '' : 'none';
        head.querySelector('.wml-gcount').textContent = filtering ? `${n}/${rows.length}` : String(rows.length);
        head.querySelector('.wml-gfold').textContent = filtering || openGroups.has(head.dataset.group) ? '▾' : '▸';
      }
      countOn.textContent = filtering ? `${on}/${used.length}` : String(used.length);
      countOff.textContent = filtering ? `${off}/${unused.length}` : String(unused.length);
      searchNote.textContent = filtering ? (on + off ? L(`${on + off}개`, `${on + off} shown`) : L('맞는 모드가 없어요', 'no matching mod')) : '';
    };
    const searchBox = el('input', { type: 'search', value: managerQuery, placeholder: L('모드 찾기 (이름·id·설명)', 'Find mods (name, id, description)'), 'aria-label': L('모드 찾기', 'Find mods'), class: 'wml-search',
      oninput: () => { managerQuery = searchBox.value; applySearch(); } });
    const picked = presetFind(presetPick);
    root.append(el('div', { class: 'wml-modtop' },
      el('span', { class: 'wml-small wml-muted' }, L('프리셋', 'Preset')), presetSelect(win),
      uiButton(L('적용', 'Apply'), () => { presetApply(win).catch(fail); }, { primary: !!picked, disabled: !picked, title: L('고른 프리셋으로 바꾸고 새로고침해요', 'Switches to the chosen preset and reloads') }),
      uiButton(L('관리…', 'Manage…'), () => { managerTab = 'presets'; win.refresh(); }, { title: L('저장·내보내기·가져오기·미리보기 (프리셋 탭)', 'Save, export, import, preview (the preset tab)') }),
      el('span', { class: 'wml-gap' }), searchBox, searchNote));
    const chipIds = [...Object.keys(MOD_TAGS).filter(k => MOD_TAGS[k].kind === 'main'), 'base', 'untagged'];
    const chipLabel = k => (k === 'base' ? L('기반', 'Base') : k === 'untagged' ? L('태그 없음', 'No tag') : tagLabel(k));
    const chipTip = k => (k === 'base' ? L('다른 모드가 필요로 하는 모드 (자동으로 찾아요)', 'Mods other mods need (found automatically)') : k === 'untagged' ? L('태그가 없는 모드', 'Mods without a tag') : compatText(MOD_TAGS[k].about));
    if (managerTagPick && !chipIds.includes(managerTagPick)) managerTagPick = '';
    root.append(el('div', { class: 'wml-chipbar', role: 'group', 'aria-label': L('태그로 거르기', 'Filter by tag') },
      el('button', { type: 'button', class: 'wml-fchip' + (managerTagPick ? '' : ' wml-fchip-on'), onclick: () => { managerTagPick = ''; win.refresh(); } }, L(`전체 ${order.length}`, `All ${order.length}`)),
      ...chipIds.map(k => {
        const n = order.filter(id => tagsOf(id).includes(k)).length;
        return n || managerTagPick === k ? el('button', { type: 'button', class: 'wml-fchip' + (managerTagPick === k ? ' wml-fchip-on' : ''), title: chipTip(k),
          onclick: () => { managerTagPick = managerTagPick === k ? '' : k; win.refresh(); } }, `${chipLabel(k)} ${n}`) : null;
      })));
    if (sessionChanges.length || installError) {
      root.append(el('div', { class: 'wml-small', style: 'color:#fde68a' },
        sessionChanges.length ? L(`✓ ${sessionChanges.slice(-3).join(' · ')}${sessionChanges.length > 3 ? ` 외 ${sessionChanges.length - 3}개` : ''} — 새로고침하면 적용돼요`, `✓ ${sessionChanges.slice(-3).join(' · ')}${sessionChanges.length > 3 ? ` and ${sessionChanges.length - 3} more` : ''} — applies after a reload`) : '',
        installError ? el('span', { style: 'color:#fca5a5;margin-left:6px' }, installError) : null));
    }

    // order inside the in-use list: a drop takes the dropped row's place; ↑↓ (details pane) trade places with the neighbour
    const placeAt = (id, targetId) => {
      const ord = playerOrder(), from = ord.indexOf(id), to = ord.indexOf(targetId);
      if (from < 0 || to < 0 || from === to) return;
      ord.splice(from, 1); ord.splice(to, 0, id);
      lsSet(LS_ORDER, ord);
      win.refresh();
    };
    // Dragging a row uses pointer events, not the browser's drag-and-drop: that one stops the mouse wheel while a row is
    // held (Chrome and Edge on Windows), so a long list could not be scrolled to the place. Now the wheel scrolls the
    // list under the pointer, a list scrolls by itself near its top and bottom edges, Esc gives up, and a touch drags
    // from the ⠿ handle (elsewhere a swipe still scrolls the list). A drop on a row in use takes that row's place (from
    // the other list: starts using it there); a drop on the other list's box moves it to that list.
    let drag = null;                      // { id, from: 'used' | 'unused', row, name, x, y, started, target, ghost } while held
    let dragClickBlock = false;           // the click that ends a drag does not also pick a row
    const dropTarget = () => {
      const hit = document.elementFromPoint(drag.x, drag.y);
      const row = hit && hit.closest && hit.closest('tr[data-list="on"]');
      if (row && root.contains(row)) return row.dataset.id === drag.id ? null : { row, id: row.dataset.id };
      const box = hit && hit.closest && hit.closest('.wml-listbox');
      if (box && root.contains(box)) { const inUse = box.classList.contains('wml-box-on'); if ((drag.from === 'used') !== inUse) return { box, inUse }; }
      return null;
    };
    const unmark = t => { if (t && t.row) t.row.classList.remove('wml-drop'); if (t && t.box) t.box.classList.remove('wml-drop-here'); };
    const markTarget = () => {
      const t = dropTarget(), old = drag.target;
      if (old && t && old.row === t.row && old.box === t.box) return;
      unmark(old);
      if (t && t.row) t.row.classList.add('wml-drop');
      if (t && t.box) t.box.classList.add('wml-drop-here');
      drag.target = t;
    };
    const DRAG_EDGE = 36;                 // px from a list's top or bottom where it scrolls by itself, faster nearer the edge
    const edgeScroll = () => {
      if (!drag || !drag.started) return;
      const hit = document.elementFromPoint(drag.x, drag.y);
      const sc = hit && hit.closest && hit.closest('.wml-listscroll');
      if (sc && root.contains(sc)) {
        const r = sc.getBoundingClientRect();
        const dy = drag.y < r.top + DRAG_EDGE ? drag.y - (r.top + DRAG_EDGE) : drag.y > r.bottom - DRAG_EDGE ? drag.y - (r.bottom - DRAG_EDGE) : 0;
        if (dy) { sc.scrollTop += Math.round(dy / 3); markTarget(); }      // at most 12 px a frame
      }
      drag.raf = requestAnimationFrame(edgeScroll);
    };
    const dragMove = e => {
      if (!drag || e.pointerId !== drag.pointerId) return;
      drag.x = e.clientX; drag.y = e.clientY;
      if (!drag.started) {
        if (Math.hypot(drag.x - drag.x0, drag.y - drag.y0) < 5) return;     // a click, not a drag (yet)
        drag.started = true;
        try { getSelection().removeAllRanges(); } catch { /* nothing selected */ }
        drag.row.classList.add('wml-dragging');
        drag.ghost = el('div', { class: 'wml-drag-ghost' }, drag.name);
        document.body.append(drag.ghost);
        document.documentElement.classList.add('wml-grabbing');
        drag.raf = requestAnimationFrame(edgeScroll);
      }
      e.preventDefault();
      drag.ghost.style.transform = `translate(${drag.x + 14}px, ${drag.y + 10}px)`;
      markTarget();
    };
    const dragScroll = () => { if (drag && drag.started) markTarget(); };     // the wheel or the edge moved the rows under the pointer
    const dragStop = dropIt => {
      const d = drag;
      drag = null;
      window.removeEventListener('pointermove', dragMove, true);
      window.removeEventListener('pointerup', dragUp, true);
      window.removeEventListener('pointercancel', dragCancel, true);
      window.removeEventListener('keydown', dragKey, true);
      document.removeEventListener('scroll', dragScroll, true);
      if (!d || !d.started) return;
      cancelAnimationFrame(d.raf);
      d.row.classList.remove('wml-dragging');
      if (d.ghost) d.ghost.remove();
      document.documentElement.classList.remove('wml-grabbing');
      unmark(d.target);
      dragClickBlock = true;
      setTimeout(() => { dragClickBlock = false; }, 0);
      const t = d.target;
      if (!dropIt || !t) return;
      if (t.row) { if (d.from === 'used') placeAt(d.id, t.id); else setOnWithDeps([d.id], true, win, { before: t.id }).catch(fail); }
      else setOnWithDeps([d.id], t.inUse, win).catch(fail);
    };
    const dragUp = e => { if (drag && e.pointerId === drag.pointerId) dragStop(true); };
    const dragCancel = e => { if (drag && e.pointerId === drag.pointerId) dragStop(false); };
    const dragKey = e => { if (drag && e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); dragStop(false); } };
    const dragBegin = (e, id, inUse, row, name) => {
      if (drag || e.button !== 0 || inControl(e)) return;
      if (e.pointerType !== 'mouse' && !e.target.closest('.wml-handle')) return;
      drag = { id, from: inUse ? 'used' : 'unused', row, name, pointerId: e.pointerId, x0: e.clientX, y0: e.clientY, x: e.clientX, y: e.clientY, started: false, target: null };
      window.addEventListener('pointermove', dragMove, true);
      window.addEventListener('pointerup', dragUp, true);
      window.addEventListener('pointercancel', dragCancel, true);
      window.addEventListener('keydown', dragKey, true);
      document.addEventListener('scroll', dragScroll, true);
    };
    // click picks one row (and shows it below), Ctrl adds or removes one, Shift takes a range; the other list's pick is dropped
    const pickRow = (e, id, list, pickedSet) => {
      // a Shift range runs over the rows on show (not over rows hidden by a search, a filter or a folded group)
      const shown = [...root.querySelectorAll(`tr[data-list="${pickedSet === pickUsed ? 'on' : 'off'}"]`)].filter(r => r.style.display !== 'none').map(r => r.dataset.id);
      if (e.shiftKey && pickAnchor && shown.includes(pickAnchor) && shown.includes(id)) {
        const a = shown.indexOf(pickAnchor), b = shown.indexOf(id);
        for (const x of shown.slice(Math.min(a, b), Math.max(a, b) + 1)) pickedSet.add(x);
      } else if (e.ctrlKey || e.metaKey) {
        if (pickedSet.has(id)) pickedSet.delete(id); else pickedSet.add(id);
        pickAnchor = id;
      } else {
        pickedSet.clear();
        pickedSet.add(id);
        pickAnchor = id;
      }
      (pickedSet === pickUsed ? pickUnused : pickUsed).clear();
      detailId = id;
      win.refresh();
    };
    const inControl = e => !!e.target.closest('button,a,input,select,summary,label');
    // what the manager knows about one mod: shown as small flags in its line and in full in the details pane
    const facts = (id, inUse) => {
      const d = defs.get(id);
      const st = statusOf(id, inUse);
      const notes = preview.filter(n => n.id === id).map(n => n.msg);
      // the same mod in the browser and in wml/mods: say which copy runs
      for (const sn of state.sourceNotes.filter(x => x.id === id)) notes.push(L(`폴더 버전(${sn.folder})이 설치본(${sn.browser || '?'})보다 새것이라 폴더 버전을 써요.`, `The folder version (${sn.folder}) is newer than the installed copy (${sn.browser || '?'}) and is used.`));
      if (d && !(d.game && specFamily(d.game)) && !gameFits(id)) notes.push(L('필요한 모드가 다른 게임용이라 기본 꺼짐', 'A mod it needs is for the other game, so it starts off'));
      if (d && !d.langs.length && !langFits(id)) notes.push(L('필요한 모드가 다른 언어용이라 기본 꺼짐', 'A mod it needs is for another language, so it starts off'));
      // what it needs that is not here, or here at a version it does not work with (it will not run until that changes)
      if (d && inUse) for (const r of d.requires) {
        const p = defs.get(r);
        if (!p) notes.push(L(`필요한 모드 ${r}이(가) 설치돼 있지 않아요`, `Needs ${r}, which is not installed`));
        else if (!isOn(r, t)) notes.push(L(`필요한 모드 ${nameOf(r)}이(가) 꺼져 있어요`, `Needs ${nameOf(r)}, which is off`));
        else if (wantVersion(d, r) && !versionMatches(p.version, wantVersion(d, r))) notes.push(L(`${nameOf(r)} 버전 불일치 (지금 ${p.version || '(버전 없음)'}, 필요 ${wantVersion(d, r)})`, `${nameOf(r)} version mismatch (now ${p.version || '(none)'}, needs ${wantVersion(d, r)})`));
      }
      if (inUse) for (const { role, ids } of roleMates(id, used)) notes.push(L(`기능이 겹쳐요(${roleLabel(role)}): ${ids.map(nameOf).join(', ')}`, `Same job (${roleLabel(role)}): ${ids.map(nameOf).join(', ')}`));
      const flags = [
        justAdded.has(id) && { cls: 'wml-chip-warn', text: L('새로 넣음', 'new'), tip: L('새로고침하면 적용돼요.', 'Applies after a reload.') },
        installedIds().includes(id) && { cls: 'wml-chip-inst', text: L('설치본', 'installed'), tip: L('브라우저에 설치한 모드', 'Installed in the browser') },
        lsGet(LS_FOLDERS, []).includes(id) && !installedIds().includes(id) && { cls: 'wml-chip-inst', text: L('폴더 등록', 'folder'), tip: L('폴더에서 등록한 모드', 'Registered from its folder') },
        d && d.platforms.length && { cls: d.platforms.includes(host.platform) ? 'wml-chip-inst' : 'wml-chip-warn', text: L(`${d.platforms.map(p => PLATFORM_LABEL[p]).join('·')} 전용`, `${d.platforms.map(p => PLATFORM_LABEL[p]).join('/')} only`),
          tip: d.platforms.includes(host.platform) ? '' : L(`${PLATFORM_LABEL[host.platform]}에서 안 맞을 수 있어요`, 'May not suit this device') },
        // a mod made for other languages: off by default here, still allowed
        d && d.langs.length && !d.langs.includes(LANG()) && { cls: 'wml-chip-warn', text: L(`${d.langs.map(langName).join('·')} 전용`, `${d.langs.map(langName).join('/')} only`),
          tip: L('다른 언어용이라 기본 꺼짐', 'For another language; starts off') },
        d && d.game && specFamily(d.game) && specFamily(d.game) !== GAME_FAMILY && { cls: 'wml-chip-warn', text: specFamily(d.game) === 'faith' ? 'Faith' : L('본편', 'Wayward'),
          tip: L('다른 게임용이라 기본 꺼짐', 'Made for the other game; starts off') },
        noticesFor(id).length && { cls: 'wml-chip-warn', text: L(`알림 ${noticesFor(id).length}`, `${noticesFor(id).length} notice(s)`), tip: L('알려진 문제 있음 (상세 칸)', 'Known problems (details pane)') },
        notes.length && { cls: 'wml-chip-warn', text: `↳ ${notes.length}`, tip: notes.join('\n') },
        d && isBase(id) && { meta: true, cls: 'wml-chip-inst', text: L('기반', 'base'),
          tip: L(`필요로 하는 모드: ${state.listed.filter(o => defs.has(o) && defs.get(o).requires.includes(id)).map(nameOf).slice(0, 8).join(', ')}`, `Other mods need it: ${state.listed.filter(o => defs.has(o) && defs.get(o).requires.includes(id)).map(nameOf).slice(0, 8).join(', ')}`) },
        d && touchesPrompt(id) && { meta: true, cls: 'wml-chip-prompt', text: tagLabel('prompt'), tip: compatText(MOD_TAGS.prompt.about) },
        ...(d ? d.tags.filter(x => MOD_TAGS[x].kind === 'flag').map(x => ({ meta: true, cls: 'wml-chip-tag', text: tagLabel(x), tip: compatText(MOD_TAGS[x].about) })) : []),
      ].filter(Boolean);
      return { d, st, notes, flags };
    };
    const modRow = (id, i, inUse, group = '') => {
      const { d, st, flags } = facts(id, inUse);
      const pickedSet = inUse ? pickUsed : pickUnused;
      // the plain "off" of a mod not in use says nothing the list does not say already
      const showStatus = inUse || st.cls === 'err' || state.loaded.includes(id);
      const row = el('tr', { class: [inUse ? '' : 'wml-off', justAdded.has(id) ? 'wml-new' : '', pickedSet.has(id) ? 'wml-sel' : '', detailId === id ? 'wml-focus' : ''].filter(Boolean).join(' '),
        'data-id': id, 'data-list': inUse ? 'on' : 'off', 'data-tags': tagsOf(id).join(' '), 'data-group': group || null,
        'aria-selected': pickedSet.has(id) ? 'true' : 'false', title: (d && d.description) || '' },
        el('td', { class: 'wml-c-h wml-handle', title: inUse ? L('끌어서 순서 바꾸기', 'Drag to reorder') : L('사용 중 칸으로 끌어다 놓기', 'Drag into the in-use list') }, '⠿'),
        el('td', { class: 'wml-c-n wml-col-num wml-muted' }, inUse ? String(i + 1) : ''),
        el('td', { class: 'wml-c-name wml-fade' }, el('span', { class: 'wml-name' }, (d && d.name) || id), el('span', { class: 'wml-id' }, id),
          ...flags.map(f => el('span', { class: `wml-flag ${f.cls}`, title: f.tip }, f.text))),
        el('td', { class: 'wml-c-v wml-col-ver wml-muted wml-small wml-fade' }, d && d.version ? 'v' + d.version : ''),
        el('td', { class: 'wml-c-s' }, showStatus ? el('span', { class: `wml-chip wml-chip-${st.cls}`, title: st.tip }, st.text) : null),
        el('td', { class: 'wml-c-a' }, hasSettings(id) ? uiButton('⚙', () => openSettings(id), { icon: true, title: L('설정', 'Settings') }) : null));
      row.addEventListener('click', e => { if (!dragClickBlock && !inControl(e)) pickRow(e, id, inUse ? used : unused, pickedSet); });
      row.addEventListener('dblclick', e => { if (!inControl(e) && d) setOnWithDeps([id], !inUse, win).catch(fail); });
      // a mod in use can always be moved; one not in use only when its file is here
      if (d || inUse) row.addEventListener('pointerdown', e => dragBegin(e, id, inUse, row, (d && d.name) || id));
      rowText.set(row, `${(d && d.name) || ''} ${id} ${(d && d.description) || ''}`.toLowerCase());
      return row;
    };
    const arrow = (wide, narrow, text) => [el('span', { class: 'wml-g-wide' }, wide), el('span', { class: 'wml-g-narrow' }, narrow), text];
    // groups of the not-in-use list. By author: the mod's pack when it names one, else its author. By tag: one group per
    // main tag (a mod with several sits in each of them) and one for mods without a tag
    const MAIN_TAGS = Object.keys(MOD_TAGS).filter(k => MOD_TAGS[k].kind === 'main');
    const groupKeys = id => {
      const d = defs.get(id);
      if (groupMode === 'tag') { const t = tagsOf(id).filter(x => MAIN_TAGS.includes(x)); return t.length ? t.map(x => `tag:${x}`) : ['tag:']; }
      return [d && d.pack ? `pack:${d.pack}` : `author:${(d && d.author) || ''}`];
    };
    const groupName = (k, id) => {
      if (k.startsWith('tag:')) return k === 'tag:' ? L('태그 없음', 'No tag') : tagLabel(k.slice(4));
      const d = defs.get(id), a = (d && d.author) || '';
      return d && d.pack ? (a ? `${a} · ${d.pack}` : d.pack) : (a || L('제작자 모름', 'Unknown author'));
    };
    const list = (ids, inUse) => {
      const tbody = el('tbody');
      if (!inUse && groupMode !== 'none' && ids.length) {
        const groups = new Map();
        if (groupMode === 'tag') for (const k of [...MAIN_TAGS.map(x => `tag:${x}`), 'tag:']) groups.set(k, []);
        for (const id of ids) for (const k of groupKeys(id)) { if (!groups.has(k)) groups.set(k, []); groups.get(k).push(id); }
        for (const [k, members] of groups) {
          if (!members.length) continue;
          const usable = members.filter(x => defs.has(x));
          const head = el('tr', { class: 'wml-grouphead', 'data-group': k },
            el('td', { colspan: 6 },
              el('span', { class: 'wml-gfold' }, '▸'), ' ', el('b', { title: k.startsWith('tag:') && MOD_TAGS[k.slice(4)] ? compatText(MOD_TAGS[k.slice(4)].about) : '' }, groupName(k, members[0])), ' ', el('span', { class: 'wml-gcount wml-muted' }, String(members.length)),
              usable.length ? el('span', { class: 'wml-gacts' }, uiButton(arrow('◀', '▲', L(' 모두 사용', ' Use all')), () => { setOnWithDeps(usable, true, win).catch(fail); },
                { title: L(`이 묶음 ${usable.length}개를 모두 사용`, `Use all ${usable.length} of this group`) })) : null));
          head.addEventListener('click', e => {
            if (e.target.closest('button')) return;
            if (openGroups.has(k)) openGroups.delete(k); else openGroups.add(k);
            applySearch();
          });
          tbody.append(head);
          const rows = members.map((id, i) => modRow(id, i, false, k));
          rows.forEach(r => tbody.append(r));
          groupHeads.push([head, rows]);
        }
      } else ids.forEach((id, i) => tbody.append(modRow(id, i, inUse)));
      if (!order.length && inUse) tbody.append(el('tr', null, el('td', { colspan: 6, class: 'wml-muted' }, L('mods.js에 모드가 없어요.', 'No mods in mods.js.'))));
      else if (!ids.length) tbody.append(el('tr', null, el('td', { colspan: 6, class: 'wml-muted wml-small' }, inUse
        ? L('사용 중인 모드가 없어요.', 'No mods in use.')
        : L('모든 모드를 사용 중이에요.', 'Every mod is in use.'))));
      const scroller = el('div', { class: 'wml-listscroll' }, el('table', { class: 'wml-grid wml-compact' }, tbody));
      scroller.addEventListener('scroll', () => { listScroll[inUse ? 'on' : 'off'] = scroller.scrollTop; }, { passive: true });
      return scroller;
    };
    const onScroll = list(used, true), offScroll = list(unused, false);
    const onBox = el('div', { class: 'wml-listbox wml-box-on' },
      el('div', { class: 'wml-listhead' }, L('사용 중 ', 'In use '), countOn, el('span', { class: 'wml-small wml-muted' }, L('위에서부터 차례로 로드돼요', 'loads from the top down'))), onScroll);
    const groupPick = el('select', { class: 'wml-select wml-select-sm', 'aria-label': L('묶어 보기', 'Group by'), onchange: () => { groupMode = groupPick.value; win.refresh(); } },
      el('option', { value: 'author' }, L('제작자별', 'By author')), el('option', { value: 'tag' }, L('태그별', 'By tag')), el('option', { value: 'none' }, L('묶지 않음', 'No groups')));
    groupPick.value = groupMode;
    const allGroups = open => { for (const [h] of groupHeads) { if (open) openGroups.add(h.dataset.group); else openGroups.delete(h.dataset.group); } applySearch(); };
    const offBox = el('div', { class: 'wml-listbox wml-box-off' },
      el('div', { class: 'wml-listhead wml-listhead-off' }, L('사용 안 함 ', 'Not in use '), countOff,
        el('span', { class: 'wml-gap' }),
        groupMode !== 'none' && unused.length ? el('span', { class: 'wml-linkbtns' },
          el('button', { type: 'button', class: 'wml-link', onclick: () => allGroups(true) }, L('모두 펼치기', 'Open all')),
          el('button', { type: 'button', class: 'wml-link', onclick: () => allGroups(false) }, L('모두 접기', 'Fold all'))) : null,
        el('label', { class: 'wml-small wml-muted', style: 'font-weight:400;display:flex;gap:4px;align-items:center' }, L('묶어 보기', 'Group'), groupPick)),
      offScroll);
    // a preset applied earlier names mods that are not here
    const presetNow = lsGet(LS_PRESET_NOW, null);
    const presetGone = presetNow && Array.isArray(presetNow.missing) ? presetNow.missing.filter(id => !defs.has(id)) : [];
    if (presetGone.length) onBox.append(el('div', { class: 'wml-small', style: 'color:#fca5a5;margin-top:3px' },
      L(`프리셋 "${presetNow.name}"의 모드 파일이 없어요: ${presetGone.join(', ')}`, `Preset "${presetNow.name}" lists missing mod files: ${presetGone.join(', ')}`)));
    // the arrows between the lists: ◀ ▶ side by side (in use on the left), ▲ ▼ stacked (in use on top); CSS shows the right pair
    const toUse = unused.filter(id => pickUnused.has(id) && defs.has(id)), toDrop = used.filter(id => pickUsed.has(id));
    const bar = el('div', { class: 'wml-dualbar' },
      uiButton(arrow('◀', '▲', toUse.length ? ` ${toUse.length}` : ''), () => { setOnWithDeps(toUse, true, win).catch(fail); },
        { primary: toUse.length > 0, disabled: !toUse.length, title: L('고른 모드를 사용 중 칸 끝으로 옮겨요', 'Moves the picked mods to the end of the in-use list') }),
      uiButton(arrow('▶', '▼', toDrop.length ? ` ${toDrop.length}` : ''), () => { setOnWithDeps(toDrop, false, win).catch(fail); },
        { disabled: !toDrop.length, title: L('고른 모드를 사용 안 함 칸으로 옮겨요', 'Moves the picked mods to the not-in-use list') }));
    root.append(el('div', { class: 'wml-dual' }, onBox, bar, offBox));
    root.append(detailPane(win, used, unused, facts, placeAt, fail));
    applySearch();

    // side by side when there is room for two lists, stacked otherwise; the lists keep where they were scrolled to
    const fit = w => root.classList.toggle('wml-wide', w >= 700);
    setTimeout(() => {
      fit(root.clientWidth || win.body.clientWidth);
      onScroll.scrollTop = listScroll.on;
      offScroll.scrollTop = listScroll.off;
      // the first mod added this session comes into view (it is usually at the end of a long list)
      const firstNew = !managerQuery && !listScroll.on && !listScroll.off && root.querySelector('tr.wml-new');
      if (firstNew) try { firstNew.scrollIntoView({ block: 'nearest' }); } catch { /* old browsers */ }
    }, 0);
    fit(win.body.clientWidth);
    if (window.ResizeObserver) { modTabRO = new ResizeObserver(() => fit(root.clientWidth)); modTabRO.observe(root); }
    return root;
  }

  // the details pane under the two lists: everything about the mod last clicked, and what can be done with it
  function detailPane(win, used, unused, facts, placeAt, fail) {
    const pane = el('div', { class: 'wml-detail' });
    const picks = pickUsed.size || pickUnused.size;
    const id = detailId;
    if (!id) {
      pane.append(el('div', { class: 'wml-small wml-muted' }, L('클릭: 상세 · 더블클릭: 칸 옮기기 · 드래그: 순서 · Ctrl/Shift: 여러 개 선택',
        'Click: details · Double-click: move · Drag: order · Ctrl/Shift: pick several')));
      return pane;
    }
    const inUse = used.includes(id);
    const { d, st, notes, flags } = facts(id, inUse);
    const i = used.indexOf(id);
    const deps = d ? [
      d.requires.length && (() => { const lst = d.requires.map(r => `${nameOf(r)}${wantVersion(d, r) ? ` ${wantVersion(d, r)}` : ''}`).join(', '); return L(`필요: ${lst}`, `needs: ${lst}`); })(),
      d.loadAfter.length && L(`다음에 로드: ${d.loadAfter.map(nameOf).join(', ')}`, `loads after: ${d.loadAfter.map(nameOf).join(', ')}`),
      d.loadBefore.length && L(`먼저 로드: ${d.loadBefore.map(nameOf).join(', ')}`, `loads before: ${d.loadBefore.map(nameOf).join(', ')}`),
      d.conflicts.length && L(`충돌: ${d.conflicts.map(nameOf).join(', ')}`, `conflicts: ${d.conflicts.map(nameOf).join(', ')}`),
      d.roles.length && L(`역할: ${d.roles.map(roleLabel).join(', ')}`, `job: ${d.roles.map(roleLabel).join(', ')}`),
      d.game && L(`게임 ${d.game}`, `game ${d.game}`),
    ].filter(Boolean).join(' · ') : '';
    pane.append(...[
      el('div', { class: 'wml-detail-head' },
        el('span', { class: 'wml-name' }, (d && d.name) || id), el('span', { class: 'wml-id' }, id),
        d && d.version ? el('span', { class: 'wml-muted wml-small', style: 'margin-left:6px' }, 'v' + d.version) : null,
        el('span', { class: `wml-chip wml-chip-${st.cls}`, style: 'margin-left:6px', title: st.tip }, st.text),
        ...flags.filter(f => !f.meta && !/^↳/.test(f.text)).map(f => el('span', { class: `wml-chip ${f.cls}`, style: 'margin-left:6px', title: f.tip }, f.text)),
        picks > 1 ? el('span', { class: 'wml-small', style: 'color:#fde68a;margin-left:8px' }, L(`고른 모드 ${picks}개`, `${picks} picked`)) : null,
        el('span', { style: 'flex:1' }),
        el('span', { class: 'wml-acts' },
          inUse ? uiButton(L('↑ 먼저', '↑ Earlier'), () => placeAt(id, used[i - 1]), { title: L('순서 위로 (먼저 로드)', 'Load earlier'), disabled: i <= 0 }) : null,
          inUse ? uiButton(L('↓ 나중에', '↓ Later'), () => placeAt(id, used[i + 1]), { title: L('순서 아래로 (나중에 로드)', 'Load later'), disabled: i < 0 || i === used.length - 1 }) : null,
          d ? uiButton(inUse ? L('사용 안 함', "Don't use") : L('사용하기', 'Use'), () => { setOnWithDeps([id], !inUse, win).catch(fail); }, { primary: !inUse }) : null,
          hasSettings(id) ? uiButton(L('⚙ 설정', '⚙ Settings'), () => openSettings(id)) : null,
          d || installedIds().includes(id) ? deleteButton(id, win) : null)),
      d ? el('div', { class: 'wml-small wml-muted', style: 'margin-top:3px;display:flex;gap:4px;flex-wrap:wrap;align-items:center' },
        L('제작자', 'Author'), el('b', { style: 'color:#d6d3d1;font-weight:500' }, d.author || L('모름', 'unknown')),
        d.authorFrom === 'compat' ? el('span', { title: L('WML 호환 자료(compat.js)에서 채움', 'Filled from WML compat data (compat.js)') }, L('(WML 호환 자료)', '(WML compat data)')) : null,
        d.pack ? el('span', null, L(`· 묶음 ${d.pack}`, `· pack ${d.pack}`)) : null,
        el('span', null, L('· 태그', '· Tags')),
        ...(d.tags.length ? d.tags.map(x => el('span', { class: `wml-chip ${MOD_TAGS[x].kind === 'main' ? 'wml-chip-on' : 'wml-chip-tag'}`, title: compatText(MOD_TAGS[x].about) }, tagLabel(x))) : touchesPrompt(id) ? [] : [el('span', null, L('없음', 'none'))]),
        !d.tags.includes('prompt') && touchesPrompt(id) ? el('span', { class: 'wml-chip wml-chip-prompt', title: L('로더가 자동으로 붙인 태그', 'Added by the loader') }, L('프롬프트 (자동)', 'Prompts (auto)')) : null,
        isBase(id) ? el('span', { class: 'wml-chip wml-chip-inst', title: L('다른 모드가 이 모드를 필요로 해요 (자동)', 'Other mods need it (found automatically)') }, L('기반', 'base')) : null) : null,
      d && d.description ? el('div', { class: 'wml-small', style: 'color:#d6d3d1;margin-top:3px' }, d.description) : null,
      deps ? el('div', { class: 'wml-small', style: 'color:#93c5fd;margin-top:2px' }, deps) : null,
      ...noticesFor(id).map(n => el('details', { class: 'wml-small', style: `margin:2px 0;color:${n.severity === 'high' ? '#fca5a5' : '#fcd34d'}` },
        el('summary', { style: 'cursor:pointer' }, `⚠ ${compatText(n.title)}`),
        ...[[L('언제', 'When'), n.condition], [L('영향', 'Impact'), n.impact], [L('WML이 하는 일', 'What WML does'), n.support], [L('고치는 법 (모드 제작자)', 'Fix (for the mod author)'), n.fix]]
          .filter(([, v]) => v).map(([k, v]) => el('div', { style: 'color:#d6d3d1;margin-left:12px' }, `${k}: ${compatText(v)}`)))),
      ...notes.map(n => el('div', { class: 'wml-note' }, '↳ ' + n)),
      st.tip && st.cls === 'err' ? el('div', { class: 'wml-small', style: 'color:#fca5a5' }, st.tip) : null].filter(Boolean));
    return pane;
  }

  function copyModsJs(where) {
    const tt = toggles();
    const lines = playerOrder().map(id => `  "${id}${isOn(id, tt) ? '' : ':off'}",${defs.get(id) && defs.get(id).name ? `   // ${defs.get(id).name}` : ''}`);
    const head = L(`// 켤 모드를 순서대로 적어요. "id:off" 는 목록에는 있지만 기본으로 꺼져 있어요.\n// 게임 안 왼쪽 아래 "WML" 버튼(모드 관리자)에서도 켜고 끄고 순서를 바꿀 수 있어요.\n`,
      `// Mods to load, in order. "id:off" = listed but off by default.\n// The "WML" button at the bottom left of the game (mod manager) also switches them and changes the order.\n`);
    const text = `${head}WML.enable([\n${lines.join('\n')}\n]);\n`;
    const done = ok => { const n = el('span', { class: 'wml-note' }, ok ? L('복사했어요', 'Copied') : L('복사가 막혀 있어요', 'Copying is blocked')); where.prepend(n); setTimeout(() => n.remove(), 2000); };
    try { navigator.clipboard.writeText(text).then(() => done(true), () => done(false)); } catch { done(false); }
  }

  function openSettings(id) {
    const render = settingsPanels.get(id);
    if (!render) {
      // a mod with only a pause menu entry of its own: ⚙ opens the same thing
      const entry = pauseEntries.get(id);
      if (entry && entry.onClick) runPauseEntry(entry);
      return;
    }
    openWindow({ id: `${id}:settings`, title: L(`${nameOf(id)} 설정`, `${nameOf(id)} settings`), width: 460, height: 420, owner: id, render });
  }
  const hasSettings = id => settingsPanels.has(id) || !!(pauseEntries.get(id) && pauseEntries.get(id).onClick);

  // ---------------------------------------------------------------- the game's pause menu (api.ui.pauseSettings)
  // Many mods put "<mod> settings" into the game's pause menu. Here it is one place for all of them, right below
  // the game's own Settings, in load order — no mod has to find the menu, keep an observer on the page or line up
  // after the others. The menu is the game's component, found by its code (not its text, which a translated build
  // changes) and given the entries when React draws it. Where it cannot be found, ⚙ in the manager opens them.
  const PAUSE_MENU = { raw: { '2026-10-04': 'N6e' }, find: { all: ['.returnToTitle', '("settings")', '("changelog")', 'onClose:'], len: 2791 } };
  const pauseEntries = new Map();          // mod id -> { owner, label, onClick, attributes }
  const pauseMenu = { raw: null, hooked: false, missed: false, errors: 0 };
  const PAUSE_ATTR = /^(data-[\w.:-]+|aria-[\w-]+|title|id)$/;
  function addPauseEntry(owner, opts) {
    const o = opts && typeof opts === 'object' ? opts : {};
    const attributes = {};
    for (const [k, v] of Object.entries(o.attributes && typeof o.attributes === 'object' ? o.attributes : {})) if (PAUSE_ATTR.test(k)) attributes[k] = String(v);
    const entry = { owner, label: o.label, onClick: typeof o.onClick === 'function' ? o.onClick : null, attributes };
    pauseEntries.set(owner, entry);
    hookPauseMenu();
    const undo = () => { if (pauseEntries.get(owner) === entry) pauseEntries.delete(owner); };
    if (setupTrack && setupTrack.id === owner) setupTrack.undo.push(undo);
    return undo;
  }
  function runPauseEntry(entry) {
    try { if (entry.onClick) entry.onClick(); else openSettings(entry.owner); }
    catch (e) { console.error(`[WML] ${entry.owner} pause menu entry`, e); warn(L(`설정을 여는 중 오류가 났어요: ${e && e.message || e}`, `Opening its settings failed: ${e && e.message || e}`), entry.owner); }
  }
  function hookPauseMenu() {
    if (pauseMenu.hooked) return;
    pauseMenu.hooked = true;
    if (!pauseMenu.raw) {
      diag(L('일시정지 메뉴를 찾지 못했어요. 모드 설정은 ⚙에서 열어 주세요.',
        'Pause menu not found. Open mod settings with ⚙.'), null, 'pauseMenu');
      return;
    }
    try { addHook('wml', 'pauseMenu', { around: pauseMenuAround }, pauseMenu.raw); }
    catch (e) { pauseMenu.failed = true; diag(L(`게임 일시정지 메뉴에 연결하지 못했어요: ${e.message}`, `Could not attach to the game's pause menu: ${e.message}`), null, 'pauseMenu'); }
  }
  /** [Faith] 일시정지 메뉴에 "모드 설정"을 붙일 수 있는가 — 아니면 독에 WML 버튼을 둔다 (renderDock) */
  const pauseMenuReady = () => !!(pauseMenu.raw && pauseMenu.hooked && !pauseMenu.failed && !pauseMenu.missed);
  /** [Faith] "모드 설정" 버튼 이름: 오류·경고가 있으면 개수를 붙인다 (예전 WML 버튼이 보이던 것) */
  function modMenuLabel() {
    const failed = state.failed.length, errs = diagLog.errors;
    return `${L('모드 설정', 'Mod settings')}${failed ? ` ⚠${failed}` : ''}${errs ? ` ✖${errs}` : ''}`;
  }
  /**
   * [Faith] 일시정지 메뉴의 "모드 설정"이 여는 하위 화면 — 게임의 하위 화면(그래픽 설정 등)과 같은 모양으로 React가 그린다:
   * 맨 위에 모드 관리자(재개하기와 같은 주황 버튼), 그 아래에 모드들이 api.ui.pauseSettings로 단 항목(게임 설정과 같은 버튼, 로드 순서).
   * 예전에는 그 항목들이 일시정지 메뉴에 하나씩 붙었다. 모드 관리자와 모드의 설정 창은 그대로 WML 창이다 (vendor/WML.md)
   */
  const MOD_PANEL_PRIMARY = 'w-full px-4 py-2 bg-amber-700 hover:bg-amber-600 text-white rounded text-sm font-medium';
  /** [Faith] "모드 설정"에서 연 WML 창의 id — 일시정지 메뉴가 닫히면(Esc·재개하기) 같이 닫는다 */
  const pauseOpened = new Set();
  function modMenuPanel(R, close) {
    const h = R.createElement;
    const usable = e => !!(e.onClick || settingsPanels.has(e.owner));
    const failed = state.failed.length, errs = diagLog.errors;
    const entries = [...pauseEntries.values()].filter(usable).sort((a, b) => loadIndex(a.owner) - loadIndex(b.owner));
    // 모드 관리자나 모드의 설정 창을 열면 이 화면은 닫는다 (WML 창은 일시정지 메뉴 위에 뜬다).
    // 여기서 연 WML 창은 기억해 두었다가 일시정지 메뉴가 닫힐 때 같이 닫는다 (pauseMenuAround의 정리 함수)
    const go = (fn, ids = []) => ev => {
      ev.preventDefault(); ev.stopPropagation(); close();
      const before = new Set(windows.keys());
      fn();
      for (const k of windows.keys()) if (!before.has(k)) pauseOpened.add(k);
      for (const k of ids) if (windows.has(k)) pauseOpened.add(k);   // 이미 열려 있어 앞으로만 온 창도
    };
    const buttons = [
      h('button', { key: 'wml-manager', type: 'button', className: MOD_PANEL_PRIMARY, 'data-wml-pause-entry': 'wml-manager',
        title: errs ? L(`오류 ${errs}개 — 알림 탭`, `${errs} error(s) — Notices tab`) : L('모드 켜고 끄기·순서·설치·백업', 'Turn mods on and off, order, install, back up'),
        onClick: go(() => openManager(), ['wml:manager']) },
      `${L('모드 관리자', 'Mod manager')}${failed ? ` ⚠${failed}` : ''}${errs ? ` ✖${errs}` : ''}`),
      ...entries.map(e => h('button', { ...e.attributes, key: `wml-pause-${e.owner}`, type: 'button', className: MOD_MENU_CLASS, 'data-wml-pause-entry': e.owner,
        title: nameOf(e.owner), onClick: go(() => runPauseEntry(e), [`${e.owner}:settings`]) },
      String(localText(e.label) || L(`${nameOf(e.owner)} 설정`, `${nameOf(e.owner)} settings`)))),
    ];
    return h('div', { key: 'wml-mod-panel', className: 'fixed inset-0 z-50 flex items-center justify-center bg-black/70 px-4', 'data-wml-mod-panel': '',
      onClick: ev => { ev.stopPropagation(); close(); } },
    h('div', { className: 'w-full max-w-sm bg-stone-900 border border-stone-700 rounded-lg shadow-2xl p-5 max-h-[90vh] overflow-y-auto overscroll-contain',
      onClick: ev => ev.stopPropagation() },
    h('div', { className: 'flex items-center justify-between mb-4' },
      h('h2', { className: 'text-xl font-bold text-amber-300' }, L('모드 설정', 'Mod settings')),
      h('button', { type: 'button', onClick: ev => { ev.stopPropagation(); close(); }, className: 'text-stone-400 hover:text-stone-100 text-sm', 'aria-label': L('닫기', 'Close') }, '✕')),
    h('div', { className: 'flex flex-col gap-2' }, ...buttons),
    h('p', { className: 'text-xs text-stone-500 mt-2' }, entries.length
      ? L('모드 관리자에서 모드를 켜고 끄거나 설치합니다.', 'Turn mods on and off or install them in the mod manager.')
      : L('설정 항목을 단 모드가 없습니다. 모드마다의 설정은 모드 관리자의 ⚙에서도 열 수 있습니다.', 'No mod has added a settings entry. Each mod\'s settings also open from ⚙ in the mod manager.'))));
  }
  /** the game's Settings button: the one whose click opens the game's "settings" panel */
  const isGameSettings = k => !!(k && k.type === 'button' && k.props && typeof k.props.onClick === 'function'
    && /\(\s*["'`]settings["'`]\s*\)/.test(Function.prototype.toString.call(k.props.onClick)));
  /** the element tree with the mods' entries put right after the game's Settings; null where there is none */
  function withPauseEntries(node, R, made, depth = 0) {
    if (!node || typeof node !== 'object' || !node.props || depth > 8) return null;
    const kids = node.props.children;
    const list = Array.isArray(kids) ? kids : [kids];
    const at = list.findIndex(isGameSettings);
    if (at >= 0) return R.cloneElement(node, {}, ...list.slice(0, at + 1), ...made(), ...list.slice(at + 1));
    for (let i = 0; i < list.length; i++) {
      const inner = withPauseEntries(list[i], R, made, depth + 1);
      if (inner) { const copy = list.slice(); copy[i] = inner; return R.cloneElement(node, {}, ...copy); }
    }
    return null;
  }
  // [Faith] "모드 설정" 버튼은 바로 위의 게임 버튼(게임 설정)과 같은 모양으로 (game.js 일시정지 메뉴 SPe의 버튼 클래스)
  const MOD_MENU_CLASS = 'w-full px-4 py-2 bg-stone-800 hover:bg-stone-700 text-stone-100 rounded text-sm border border-stone-700';
  function pauseMenuAround(next, ...args) {
    const tree = next(...args);
    let R = null;
    try { R = engine[resolve('React')]; } catch { /* below: the menu as the game drew it */ }
    if (!R || !R.useState) return tree;
    // [Faith] "모드 설정" 하위 화면이 열려 있는지 — 이 함수는 게임의 일시정지 메뉴 컴포넌트 안에서 불리므로(around 훅) React 상태를
    // 둘 수 있다. 매번 같은 순서로 부른다. Esc는 게임 하위 화면처럼 이 화면만 닫는다(게임의 Esc 처리보다 먼저, capture)
    const [modOpen, setModOpen] = R.useState(false);
    R.useEffect(() => {
      if (!modOpen) return undefined;
      const onKey = ev => { if (ev.key === 'Escape') { ev.preventDefault(); ev.stopImmediatePropagation(); setModOpen(false); } };
      window.addEventListener('keydown', onKey, true);
      return () => window.removeEventListener('keydown', onKey, true);
    }, [modOpen]);
    // [Faith] 일시정지 메뉴가 화면에서 사라질 때(Esc·재개하기) "모드 설정"에서 연 WML 창(모드 관리자·모드 설정 창)도 닫는다
    R.useEffect(() => () => {
      for (const k of pauseOpened) { const w = windows.get(k); if (w) { try { w.close(); } catch (e) { console.error('[WML] close', k, e); } } }
      pauseOpened.clear();
    }, []);
    try {
      // [Faith] 모드들의 설정 항목을 하나씩 붙이지 않고 "모드 설정" 하나만 게임 설정 아래에 둔다. 항목들은 그 하위 화면 안에 (modMenuPanel)
      const made = () => [R.createElement('button', {
        key: 'wml-pause-mods', type: 'button', className: MOD_MENU_CLASS, 'data-wml-pause-entry': 'wml',
        onClick: ev => { ev.preventDefault(); ev.stopPropagation(); setModOpen(true); },
      }, modMenuLabel())];
      const out = withPauseEntries(tree, R, made);
      // 열려 있든 아니든 같은 모양(Fragment)으로 돌려준다 — 바뀌면 React가 메뉴를 처음부터 다시 만든다
      if (out) return R.createElement(R.Fragment, null, out, modOpen ? modMenuPanel(R, () => setModOpen(false)) : null);
      if (!pauseMenu.missed) {
        pauseMenu.missed = true;
        diag(L('일시정지 메뉴를 찾지 못했어요. 모드 설정은 ⚙에서 열어 주세요.',
          'Pause menu not found. Open mod settings with ⚙.'), null, 'pauseMenu');
        renderDock();                     // [Faith] 메뉴에 붙지 못했으니 WML 버튼을 다시 보인다
      }
    } catch (e) { if (pauseMenu.errors++ < 3) console.error('[WML] pause menu entries', e); }
    return tree;
  }

  // ---------------------------------------------------------------- saving files & the back button (phone app)
  const backHandlers = [];               // { owner, fn } from api.onBack, newest last
  /** the phone's back button: answer an open question, let a mod close its panel, close the top WML window */
  function back() {
    if (openQuestions.length) { openQuestions[openQuestions.length - 1](); return true; }
    for (let i = backHandlers.length - 1; i >= 0; i--) {
      try { if (backHandlers[i].fn() === true) return true; } catch (e) { console.error(`[WML] ${backHandlers[i].owner} back`, e); }
    }
    let top = null;
    for (const w of windows.values()) if (!top || Number(w.el.style.zIndex) > Number(top.el.style.zIndex)) top = w;
    if (top) { top.close(); return true; }
    return false;
  }

  const blobToBase64 = blob => new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => { const s = String(r.result); resolve(s.slice(s.indexOf(',') + 1)); };
    r.onerror = () => reject(r.error);
    r.readAsDataURL(blob);
  });
  const base64ToBlob = (b64, type) => {
    const bin = atob(b64), u8 = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
    return new Blob([u8], { type: type || '' });
  };
  /** a download in a browser; Download/WML in the phone app */
  async function saveFile(name, data, type = '') {
    const blob = data instanceof Blob ? data : new Blob([data], { type: type || 'application/octet-stream' });
    if (HOST && typeof HOST.saveFile === 'function') {
      const err = HOST.saveFile(String(name), blob.type || type || '', await blobToBase64(blob));
      if (err) throw new Error(err);
      return true;
    }
    const url = URL.createObjectURL(blob);
    const a = el('a', { href: url, download: String(name), style: 'display:none' });
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
    return true;
  }
  // A page in the phone app cannot download. Links that save a blob:/data: URL (export buttons of mods and of the
  // game) go to Download/WML instead. Blobs are remembered when their URL is made: pages often revoke it right
  // after the click, before the file could be read.
  if (HOST && typeof HOST.saveFile === 'function') {
    try {
      const blobs = new Map();
      const made = URL.createObjectURL, revoked = URL.revokeObjectURL;
      URL.createObjectURL = function createObjectURL(obj) { const u = made.call(URL, obj); if (obj instanceof Blob) blobs.set(u, obj); return u; };
      URL.revokeObjectURL = function revokeObjectURL(u) { revoked.call(URL, u); setTimeout(() => blobs.delete(u), 60000); };
      const wants = a => !!a && typeof a.hasAttribute === 'function' && a.hasAttribute('download') && /^(blob|data):/i.test(a.href || '');
      const viaHost = a => {
        const name = a.getAttribute('download') || 'download';
        const known = blobs.get(a.href);
        (known ? Promise.resolve(known) : fetch(a.href).then(r => r.blob()))
          .then(b => saveFile(name, b)).catch(e => console.warn('[WML] could not save', name, e));
      };
      const click = HTMLAnchorElement.prototype.click;
      HTMLAnchorElement.prototype.click = function () { if (wants(this)) { viaHost(this); return undefined; } return click.call(this); };
      document.addEventListener('click', e => {
        const a = e.target && e.target.closest ? e.target.closest('a[download]') : null;
        if (wants(a)) { e.preventDefault(); viaHost(a); }
      }, true);
    } catch (e) { console.warn('[WML] download bridge', e); }
  }

  // ---------------------------------------------------------------- databases mods keep (IndexedDB) in backups
  // A mod declares them: WML.define({ backup: { indexedDB: ['<name>'] } }). The backup file then carries each such
  // database whole — version, stores, keys, indexes, records — so a restore needs no mod code at all: the file is
  // written to a waiting place when it is imported and put in at the next start, before any mod runs (on a phone the
  // import already happens at start). Mods still writing are asked to finish first (api.backup.beforeExport).
  // Databases nobody declared are only pointed out; WML does not guess whose they are or whether they matter.
  const LS_BACKUP_DECL = 'wml.backup.decl';     // { "<database>": ["<mod id>", …] } — kept when the mod is gone
  const LS_RESTORE_LAST = 'wml.restore.last';   // what the last restore at start did (shown in the manager)
  const RESTORE_DB = 'wml-restore';             // the restore waiting for the next start
  // the game's own databases: Wayward: Faith keeps its saves (and, when the player turns localStorage off, its settings) there
  const GAME_DBS = GAME_FAMILY === 'faith' ? ['faith-saves', 'faith-ls'] : [];
  const backupFlushers = [];                    // { owner, fn } from api.backup.beforeExport
  const seenDbs = new Set();                    // IndexedDB names opened in this page — a hint, not who opened them
  try {
    const open = IDBFactory.prototype.open;
    IDBFactory.prototype.open = function (name, ...rest) { try { seenDbs.add(String(name)); } catch { /* odd name */ } return open.call(this, name, ...rest); };
  } catch { /* no IndexedDB */ }
  const idbReq = r => new Promise((ok, no) => { r.onsuccess = () => ok(r.result); r.onerror = () => no(r.error); });
  function idbOpenDb(name, version, upgrade) {
    return new Promise((ok, no) => {
      const r = version ? indexedDB.open(name, version) : indexedDB.open(name);
      r.onupgradeneeded = () => { try { if (upgrade) upgrade(r.result); } catch (err) { try { r.transaction.abort(); } catch { /* gone */ } no(err); } };
      r.onsuccess = () => ok(r.result);
      r.onerror = () => no(r.error);
      r.onblocked = () => no(new Error(L('이 저장소를 다른 탭이 열고 있어요. 다른 탭을 닫고 다시 해 보세요', 'another tab has this database open; close it and try again')));
    });
  }
  /** { name, version } when it exists, null when it does not, undefined when the browser cannot tell */
  async function dbInfo(name) {
    if (typeof indexedDB.databases !== 'function') return undefined;
    try { return (await indexedDB.databases()).find(d => d.name === name) || null; } catch { return undefined; }
  }
  // what JSON can carry back exactly (a Date or a Blob would come back as something else)
  function plainValue(v, depth = 0) {
    if (depth > 64) return false;
    if (v === null || typeof v === 'string' || typeof v === 'boolean') return true;
    if (typeof v === 'number') return Number.isFinite(v);
    if (Array.isArray(v)) return v.every(x => plainValue(x, depth + 1));
    if (typeof v === 'object' && Object.getPrototypeOf(v) === Object.prototype) return Object.values(v).every(x => plainValue(x, depth + 1));
    return false;
  }
  /** declared databases: what this session's mods declare, plus what earlier sessions recorded */
  function backupDecl() {
    const decl = lsGet(LS_BACKUP_DECL, {});
    const out = decl && typeof decl === 'object' ? decl : {};
    let changed = false;
    for (const [id, d] of defs) for (const name of d.backupDbs || []) {
      const owners = Array.isArray(out[name]) ? out[name] : (out[name] = []);
      if (!owners.includes(id)) { owners.push(id); changed = true; }
    }
    if (changed) lsSet(LS_BACKUP_DECL, out);
    return out;
  }
  async function dumpDb(name) {
    const known = await dbInfo(name);
    if (known === null) return null;                       // never made: nothing to keep
    const db = await idbOpenDb(name);
    try {
      // the browser could not say whether it existed, and opening it just made an empty one: take that back
      if (known === undefined && db.version === 1 && !db.objectStoreNames.length) { db.close(); try { indexedDB.deleteDatabase(name); } catch { /* gone */ } return null; }
      const stores = [];
      for (const sName of [...db.objectStoreNames]) {
        const st = db.transaction(sName, 'readonly').objectStore(sName);
        const [values, keys] = await Promise.all([idbReq(st.getAll()), idbReq(st.getAllKeys())]);
        const bad = values.findIndex((v, i) => !plainValue(v) || !plainValue(keys[i]));
        if (bad >= 0) throw new Error(L(`${sName} 저장소의 ${bad + 1}번째 값은 파일에 그대로 담을 수 없는 형식이에요`, `record ${bad + 1} in ${sName} is of a kind the file cannot carry`));
        const indexes = [...st.indexNames].map(n => { const ix = st.index(n); return { name: n, keyPath: ix.keyPath, unique: ix.unique, multiEntry: ix.multiEntry }; });
        stores.push({ name: sName, keyPath: st.keyPath, autoIncrement: st.autoIncrement, indexes,
          records: values.map((v, i) => (st.keyPath == null ? { k: keys[i], v } : { v })) });
      }
      return { kind: 'indexedDB', name, version: db.version, stores };
    } finally { try { db.close(); } catch { /* closed */ } }
  }
  /** put a database from a backup back in, then read it again to be sure; throws with the reason */
  async function restoreDb(entry) {
    const make = d => {
      for (const s of entry.stores) {
        if (d.objectStoreNames.contains(s.name)) continue;
        const st = d.createObjectStore(s.name, { ...(s.keyPath != null ? { keyPath: s.keyPath } : {}), autoIncrement: !!s.autoIncrement });
        for (const ix of s.indexes || []) st.createIndex(ix.name, ix.keyPath, { unique: !!ix.unique, multiEntry: !!ix.multiEntry });
      }
    };
    let db;
    // the backup's version: the database is made (or raised) to exactly that, so the mod opening it later finds what it expects
    try { db = await idbOpenDb(entry.name, entry.version || 1, make); }
    catch (e) {
      if (!e || e.name !== 'VersionError') throw e;
      db = await idbOpenDb(entry.name);                   // the database here is newer than the backup: use it as it is
    }
    try {
      const missing = entry.stores.filter(s => !db.objectStoreNames.contains(s.name)).map(s => s.name);
      if (missing.length) throw new Error(L(`저장소가 백업보다 새 버전이라 넣지 못했어요 (${missing.join(', ')} 칸 없음)`, `the database here is newer than the backup and has no ${missing.join(', ')}`));
      const names = entry.stores.map(s => s.name);
      if (names.length) {
        await new Promise((ok, no) => {
          const tx = db.transaction(names, 'readwrite');
          tx.oncomplete = () => ok();
          tx.onerror = () => no(tx.error);
          tx.onabort = () => no(tx.error || new Error('aborted'));
          for (const s of entry.stores) {
            const st = tx.objectStore(s.name);
            st.clear();
            for (const r of s.records) { if (st.keyPath == null) st.put(r.v, r.k); else st.put(r.v); }
          }
        });
      }
      // read back: same number of records and the same content, store by store
      let records = 0;
      for (const s of entry.stores) {
        const st = db.transaction(s.name, 'readonly').objectStore(s.name);
        const [values, keys] = await Promise.all([idbReq(st.getAll()), idbReq(st.getAllKeys())]);
        const got = JSON.stringify(values.map((v, i) => (st.keyPath == null ? { k: keys[i], v } : { v })));
        if (got !== JSON.stringify(s.records)) throw new Error(L(`${s.name} 칸을 다시 읽어 보니 백업과 달라요`, `${s.name} reads back different from the backup`));
        records += s.records.length;
      }
      return { name: entry.name, stores: names.length, records };
    } finally { try { db.close(); } catch { /* closed */ } }
  }
  const pendingDb = () => idbOpenDb(RESTORE_DB, 1, d => { if (!d.objectStoreNames.contains('pending')) d.createObjectStore('pending'); });
  async function writePendingRestore(payload) {
    const db = await pendingDb();
    try { await new Promise((ok, no) => { const tx = db.transaction('pending', 'readwrite'); tx.objectStore('pending').put(payload, 'external'); tx.oncomplete = () => ok(); tx.onerror = () => no(tx.error); tx.onabort = () => no(tx.error); }); }
    finally { db.close(); }
  }
  /** at start, before any mod: put in the databases a backup brought; the waiting copy goes once it was tried */
  async function applyPendingRestore() {
    if (await dbInfo(RESTORE_DB) === null) return null;     // nothing was ever brought in here (and no empty database gets made)
    let pending = null;
    try { const db = await pendingDb(); try { pending = await idbReq(db.transaction('pending', 'readonly').objectStore('pending').get('external')); } finally { db.close(); } }
    catch (e) { warn(L(`가져온 백업의 저장소 자료를 읽지 못했어요: ${e.message}`, `Could not read the databases a backup brought in: ${e.message}`)); return null; }
    if (!pending) return null;
    const result = { at: new Date().toISOString(), created: pending.created || '', ok: [], failed: [] };
    for (const entry of pending.external || []) {
      try { result.ok.push(await restoreDb(entry)); }
      catch (e) { result.failed.push({ name: entry.name, error: String(e && e.message || e) }); }
    }
    // tried once, then gone: a later start must not put this older copy over newer data again
    try { const db = await pendingDb(); try { await idbReq(db.transaction('pending', 'readwrite').objectStore('pending').delete('external')); } finally { db.close(); } } catch { /* stays; harmless */ }
    lsSet(LS_RESTORE_LAST, result);
    if (result.failed.length) {
      warn(L(`모드 저장소 ${result.failed.length}개 복원 실패: ${result.failed.map(f => `${f.name} (${f.error})`).join(', ')}`,
        `Restoring ${result.failed.length} mod database(s) failed: ${result.failed.map(f => `${f.name} (${f.error})`).join(', ')}`));
    } else console.info('[WML] restored mod databases from a backup', result.ok);
    return result;
  }

  // ---------------------------------------------------------------- moving saves & settings (PC ↔ phone, backups)
  // One JSON file: the localStorage keys as stored (packed saves stay packed) + mods installed in the browser.
  const STATE_FORMAT = 'wml-state';
  const STATE_SKIP = /^wml\.(symcache$|win\.|installed$|i18n\.|dev$|secret\.|backup\.decl$|restore\.last$|bootlog$|diag\.alive$|faith\.appPacks$)/;     // caches, window positions, debug data, secrets (api.secret), this browser's backup notes and start times
  const STATE_PARTS = [
    { key: 'saves', get label() { return L('세이브·플레이 기록', 'saves & play log'); }, test: k => /^(tavern|faith)-(game$|slot-|auto-d|save|play-log$)/.test(k) },
    { key: 'game', get label() { return L('게임 설정', 'game settings'); }, test: k => /^(tavern-|faith-|elena-image-|wayward-custom-wives|wayward-image-backend)/.test(k) },
    { key: 'mods', get label() { return L('모드 켜기·끄기·순서·설정', 'mod on/off, order, settings'); }, test: k => k.startsWith('wml.') || !!storageOwner(k) },
    { key: 'other', get label() { return L('그 밖의 저장 값', 'other stored values'); }, test: () => true },
  ];
  const statePart = k => STATE_PARTS.find(p => p.test(k)).key;
  function storageKeys() {
    const out = [];
    try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k != null && !STATE_SKIP.test(k)) out.push(k); } } catch { /* storage off */ }
    return out;
  }
  function stateSummary() {
    const parts = Object.fromEntries(STATE_PARTS.map(p => [p.key, { keys: 0, size: 0 }]));
    for (const k of storageKeys()) { const p = parts[statePart(k)]; p.keys++; p.size += k.length + ((isSaveKey(k) ? saveText(k) : rawGetItem.call(localStorage, k)) || '').length; }
    return { parts, installed: installedIds().length };
  }
  /** want: { saves, game, mods, other, installed, external } — false leaves that kind out */
  async function exportState(want = {}) {
    const take = key => want[key] !== false;
    // mods still writing are asked to finish first: a save made a moment ago may still be on its way into their
    // database. Whatever cannot be finished or read makes this a partial backup, and the file says so.
    const external = [], problems = [];
    if (take('external')) {
      for (const f of backupFlushers.slice()) {
        let timer;
        try {
          await Promise.race([Promise.resolve().then(() => f.fn()),
            new Promise((_, no) => { timer = setTimeout(() => no(new Error(L('20초 안에 끝나지 않았어요', 'did not finish within 20 s'))), 20000); })]);
        } catch (e) { problems.push({ mod: f.owner, problem: L(`저장 마무리 실패: ${e && e.message || e}`, `could not finish saving: ${e && e.message || e}`) }); }
        finally { clearTimeout(timer); }
      }
      for (const [name, owners] of Object.entries(backupDecl())) {
        try { const dump = await dumpDb(name); if (dump) external.push({ ...dump, declaredBy: owners }); }
        catch (e) { problems.push({ db: name, problem: String(e && e.message || e) }); }
      }
    }
    if (take('gameDb')) for (const name of GAME_DBS) {
      try { const dump = await dumpDb(name); if (dump) external.push({ ...dump, game: true }); }
      catch (e) { problems.push({ db: name, problem: String(e && e.message || e) }); }
    }
    const storage = {};
    // saves kept in the browser database go into the file as their text (the file works anywhere, switch or not)
    if (saves.on) { try { await liveFlush(); } catch { /* the text below is current all the same */ } }
    for (const k of storageKeys()) if (take(statePart(k))) storage[k] = isSaveKey(k) ? saveText(k) : rawGetItem.call(localStorage, k);
    const mods = [];
    if (take('installed') && installedIds().length) {
      for (const r of (await idbRun('readonly', st => st.getAll())) || []) {
        const files = {};
        for (const [p, v] of Object.entries(r.files || {})) files[p] = typeof v === 'string' ? v : { b64: await blobToBase64(v), type: v.type || '' };
        mods.push({ id: r.id, name: r.name, version: r.version, size: r.size, installedAt: r.installedAt, files });
      }
    }
    // version 2 adds `external` (mods' databases); a version 1 file has none and imports as before
    return { format: STATE_FORMAT, version: 2, wml: VERSION, game: state.game, lang: LANG(),
      created: new Date().toISOString(), from: host.platform, storage, installed: mods, external,
      ...(problems.length ? { partial: true, problems } : {}) };
  }
  function checkState(obj) {
    if (!obj || obj.format !== STATE_FORMAT || !obj.storage || typeof obj.storage !== 'object') throw new Error(L('WML 세이브·설정 파일(wml-state)이 아니에요', 'not a WML saves & settings file (wml-state)'));
    return obj;
  }
  /**
   * Write a saves/settings file into this browser. Same keys are overwritten, other keys stay. Settings go first,
   * then saves (the play log last), so a full storage loses the least. → { written, failed: [keys], mods, done }
   */
  function importState(obj, want = {}) {
    checkState(obj);
    const take = key => want[key] !== false;
    const order = ['mods', 'game', 'saves', 'other'];
    const keys = Object.keys(obj.storage).filter(k => !STATE_SKIP.test(k) && take(statePart(k)) && typeof obj.storage[k] === 'string')
      .sort((a, b) => order.indexOf(statePart(a)) - order.indexOf(statePart(b)) || (a === 'tavern-play-log') - (b === 'tavern-play-log'));
    let written = 0;
    const failed = [];
    for (const k of keys) {
      try {
        // with the switch on, saves go into the browser database (and the running game no longer writes its own over them)
        if (saves.on && isSaveKey(k)) saveWrite(k, obj.storage[k], true);
        else rawSetItem.call(localStorage, k, obj.storage[k]);
        unpacked.delete(k); written++;
      } catch { failed.push(k); }
    }
    const mods = take('installed') && Array.isArray(obj.installed) ? obj.installed.filter(r => r && ID_RULE.test(r.id || '')) : [];
    let done = Promise.resolve();
    if (mods.length) {
      lsSet(LS_INSTALLED, [...new Set([...installedIds(), ...mods.map(r => r.id)])]);
      done = idbRun('readwrite', st => {
        for (const r of mods) {
          const files = {};
          for (const [p, v] of Object.entries(r.files || {})) files[p] = typeof v === 'string' ? v : v && typeof v.b64 === 'string' ? base64ToBlob(v.b64, v.type) : '';
          st.put({ id: r.id, name: r.name || r.id, version: r.version || '', files, size: r.size || 0, installedAt: r.installedAt || Date.now() });
        }
      });
    }
    // mods' databases: not into the databases now (a running mod would write its older copy back over them) but to
    // the waiting place; the next start puts them in before any mod runs — on a phone that start is this one
    const dbs = Array.isArray(obj.external) ? obj.external.filter(e => e && e.kind === 'indexedDB' && typeof e.name === 'string' && Array.isArray(e.stores)) : [];
    const external = take('external') ? dbs.filter(e => !e.game) : [];
    if (external.length) done = Promise.all([done, writePendingRestore({ created: obj.created || '', external })]);
    // the game's databases go in now: the game reads them as its page starts, before WML; the caller reloads next
    const gameDbs = take('gameDb') ? dbs.filter(e => e.game && GAME_DBS.includes(e.name)) : [];
    if (gameDbs.length) done = Promise.all([done, ...gameDbs.map(e => restoreDb(e))]);
    return { written, failed, mods: mods.length, external: external.length, gameDbs: gameDbs.length, done };
  }

  let transferNote = null;                // the last export/import result, shown in the manager
  const transferWant = { saves: true, game: true, mods: true, other: true, installed: true, external: true, gameDb: true };
  // databases no mod declared (whose they are, and whether a backup needs them, is not guessed)
  async function undeclaredDbs() {
    const known = new Set([...Object.keys(backupDecl()), 'wml', RESTORE_DB, SAVE_DB, DIAG_DB, ...GAME_DBS,     // SAVE_DB: its saves are in the file
      ...(GAME_FAMILY === 'faith' ? ['faith-idb-test'] : [])]);                                                 // Faith's storage check
    let names = [...seenDbs];
    if (typeof indexedDB.databases === 'function') { try { names = names.concat((await indexedDB.databases()).map(d => d.name)); } catch { /* the hint only */ } }
    return [...new Set(names)].filter(n => n && !known.has(n));
  }
  function transferSection(win) {
    const box = el('div', { class: 'wml-section' }, el('h4', null, L('옮기기·백업', 'Move & back up')));
    box.append(el('div', { class: 'wml-small wml-muted' }, host.kind === 'player'
      ? L('세이브·모드 설정을 파일로 내보내고 가져와요. 앱을 지우기 전에 꼭 내보내 주세요.',
        'Export and import saves and mod settings as a file. Export before uninstalling the app.')
      : L('세이브·모드 설정을 파일로 내보내고 가져와요.',
        'Export and import saves and mod settings as a file.')));
    let sum = null;
    try { sum = stateSummary(); } catch { /* storage off */ }
    if (!sum) return box;
    const rows = [
      ...STATE_PARTS.map(p => ({ key: p.key, label: p.label, n: sum.parts[p.key].keys, info: `${sum.parts[p.key].keys} · ${sizeText(sum.parts[p.key].size)}` })),
      { key: 'installed', label: L('브라우저에 설치한 모드', 'mods installed in the browser'), n: sum.installed, info: `${sum.installed}` },
      (() => { const n = Object.keys(backupDecl()).length; return { key: 'external', label: L('모드 저장소 (IndexedDB)', 'Mod databases (IndexedDB)'), n, info: L(`${n}개`, `${n}`) }; })(),
      ...(GAME_DBS.length ? [{ key: 'gameDb', label: L('게임 세이브 저장소 (IndexedDB)', 'Game save databases (IndexedDB)'), n: GAME_DBS.length, info: GAME_DBS.join(', ') }] : []),
    ];
    const list = el('div', { style: 'display:flex;flex-wrap:wrap;gap:2px 14px;margin:6px 0' });
    for (const r of rows) {
      const cb = el('input', { type: 'checkbox', checked: transferWant[r.key] && r.n > 0, disabled: !r.n, onchange: () => { transferWant[r.key] = cb.checked; } });
      list.append(el('label', { class: 'wml-small', style: `display:flex;gap:6px;align-items:center;cursor:pointer${r.n ? '' : ';opacity:.5'}` }, cb, `${r.label} (${r.n ? r.info : L('없음', 'none')})`));
    }
    box.append(list);
    // what is known about mods' databases: the last restore, owners that are off, databases nobody declared
    const notes = [];
    const last = lsGet(LS_RESTORE_LAST, null);
    if (last && (last.ok || last.failed)) {
      const okN = (last.ok || []).length, badN = (last.failed || []).length;
      let when = '';
      try { when = last.at ? new Date(last.at).toLocaleString() : ''; } catch { /* odd date */ }
      notes.push({ bad: badN > 0, text: badN
        ? L(`마지막 복원(${when}): 성공 ${okN} · 실패 ${badN} — ${last.failed.map(f => `${f.name} — ${f.error}`).join(' · ')}`,
          `Last restore (${when}): ${okN} ok · ${badN} failed — ${last.failed.map(f => `${f.name} — ${f.error}`).join(' · ')}`)
        : L(`마지막 복원(${when}): 모드 저장소 ${okN}개 성공`, `Last restore (${when}): ${okN} mod database(s) ok`) });
    }
    for (const [name, owners] of Object.entries(backupDecl())) {
      if (owners.some(id => state.loaded.includes(id))) continue;
      notes.push({ bad: true, text: L(`${name}: 모드(${owners.map(nameOf).join(', ')}) 꺼짐 — 자료는 보관돼요`,
        `${name}: its mod (${owners.map(nameOf).join(', ')}) is off — the data is kept`) });
    }
    const noteBox = el('div', { class: 'wml-small' });
    const paint = () => { noteBox.replaceChildren(...notes.map(n => el('div', { style: `margin:2px 0;color:${n.bad ? '#fca5a5' : '#a8a29e'}` }, n.text))); };
    paint();
    undeclaredDbs().then(names => {
      if (!names.length) return;
      notes.push({ bad: true, text: L(`주인을 모르는 저장소 (백업 여부 모름): ${names.join(', ')}`,
        `Databases with no known owner (backup unknown): ${names.join(', ')}`) });
      paint();
    }).catch(() => { /* the hint only */ });
    box.append(noteBox);
    const pick = el('input', { type: 'file', accept: '.json,application/json', style: 'display:none' });
    pick.onchange = async () => {
      const f = pick.files && pick.files[0];
      pick.value = '';
      if (!f) return;
      let obj;
      try { obj = checkState(JSON.parse(await f.text())); } catch (e) { transferNote = { ok: false, text: L(`가져오지 못했어요: ${e.message}`, `Could not import: ${e.message}`) }; win.refresh(); return; }
      const count = part => Object.keys(obj.storage).filter(k => !STATE_SKIP.test(k) && statePart(k) === part).length;
      const ext = Array.isArray(obj.external) ? obj.external.filter(e => e && e.kind === 'indexedDB') : [];
      const gameExt = ext.filter(e => e.game && GAME_DBS.includes(e.name)), modExt = ext.filter(e => !e.game);
      const slotKey = k => typeof k === 'string' && /^(tavern|faith)-(game$|slot-|auto-d)/.test(k);
      // one save kept in both places (Faith keeps a localStorage copy) counts once
      const slots = new Set([...Object.keys(obj.storage).filter(slotKey),
        ...gameExt.flatMap(e => e.stores.flatMap(st => (st.records || []).map(r => r.k).filter(slotKey)))]).size;
      const lines = [
        `${f.name}${obj.created ? ` · ${new Date(obj.created).toLocaleString()}` : ''}${PLATFORM_LABEL[obj.from] ? L(` · ${PLATFORM_LABEL[obj.from]}에서 내보냄`, ` · exported on ${obj.from === 'mobile' ? 'a phone' : 'a PC'}`) : ''}`,
        L(`세이브 ${slots}개 · 설정 ${count('game') + count('mods')}개 · 그 밖 ${count('other')}개 · 설치한 모드 ${(obj.installed || []).length}개`,
          `${slots} save(s) · ${count('game') + count('mods')} setting(s) · ${count('other')} other · ${(obj.installed || []).length} installed mod(s)`),
        L('같은 저장 칸·설정은 덮어써요. 끝나면 새로고침해요.', 'Same save slots and settings are overwritten. Reloads when done.'),
      ];
      if (obj.game && state.game && obj.game !== state.game) lines.push(L(`다른 게임 버전(${obj.game})의 파일이에요.`, `From another game version (${obj.game}).`));
      if (modExt.length) lines.push(L(`모드 저장소 ${modExt.length}개 (${modExt.map(e => e.name).join(', ')}) — 다음 시작 때 넣어요.`,
        `${modExt.length} mod database(s) (${modExt.map(e => e.name).join(', ')}) — restored on the next start.`));
      if (gameExt.length) lines.push(L(`게임 세이브 저장소: ${gameExt.map(e => e.name).join(', ')}`, `Game save databases: ${gameExt.map(e => e.name).join(', ')}`));
      if (obj.partial) lines.push(L(`부분 백업 — 빠진 것: ${(obj.problems || []).map(p => `${p.mod || p.db}: ${p.problem}`).join(' · ')}`,
        `Partial backup — missing: ${(obj.problems || []).map(p => `${p.mod || p.db}: ${p.problem}`).join(' · ')}`));
      if (!await askConfirm(win, { title: L('세이브·설정을 가져올까요?', 'Import saves & settings?'), lines, ok: L('가져오기', 'Import') })) return;
      try {
        const r = importState(obj, transferWant);
        await r.done;
        // the game's databases are in: reload before the running game writes its older copy back
        if (r.gameDbs) { location.reload(); return; }
        transferNote = { ok: !r.failed.length, text: L(`가져왔어요: 저장 값 ${r.written}개${r.mods ? `, 모드 ${r.mods}개` : ''}.`, `Imported: ${r.written} stored value(s)${r.mods ? `, ${r.mods} mod(s)` : ''}.`)
          + (r.failed.length ? L(` 공간 부족으로 ${r.failed.length}개 실패: ${r.failed.slice(0, 5).map(storageName).join(', ')}.`, ` ${r.failed.length} did not fit in the storage: ${r.failed.slice(0, 5).map(storageName).join(', ')}.`) : '')
          + (r.external ? L(` 모드 저장소 ${r.external}개는 새로고침 후 넣어요.`, ` ${r.external} mod database(s) go in after the reload.`) : '')
          + L(' 새로고침하면 적용돼요.', ' Applies after a reload.') };
        sessionChanges.push(L('세이브·설정 가져옴', 'saves & settings imported'));
      } catch (e) { transferNote = { ok: false, text: L(`가져오지 못했어요: ${e.message}`, `Could not import: ${e.message}`) }; }
      win.refresh();
    };
    const exportNow = async () => {
      try {
        const data = await exportState(transferWant);
        const d = new Date(), p2 = n => String(n).padStart(2, '0');
        const name = `wml-state-${state.game || 'game'}-${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}-${p2(d.getHours())}${p2(d.getMinutes())}.json`;
        await saveFile(name, JSON.stringify(data), 'application/json');
        const modN = data.external.filter(e => !e.game).length, gameN = data.external.length - modN;
        const extText = (modN ? L(`, 모드 저장소 ${modN}개`, `, ${modN} mod database(s)`) : '')
          + (gameN ? L(`, 게임 세이브 저장소 ${gameN}개`, `, ${gameN} game save database(s)`) : '');
        // a fact, not a guess about whose they are: these databases are in this browser and not in the file
        let left = [];
        if (transferWant.external) { try { left = await undeclaredDbs(); } catch { /* the hint only */ } }
        const leftText = left.length ? L(` · 빠진 저장소(주인 미선언): ${left.join(', ')}`, ` · not in the file (no mod declared them): ${left.join(', ')}`) : '';
        transferNote = data.partial
          // not a complete backup: say what is missing instead of "exported"
          ? { ok: false, text: L(`부분 백업으로 내보냈어요: ${name} — 빠진 것: ${data.problems.map(p => `${p.mod || p.db}: ${p.problem}`).join(' · ')}`,
            `Exported a PARTIAL backup: ${name} — left out: ${data.problems.map(p => `${p.mod || p.db}: ${p.problem}`).join(' · ')}`) + leftText }
          : { ok: true, text: L(`내보냈어요: ${name} (${host.kind === 'player' ? '다운로드/WML 폴더' : '다운로드 폴더'}) · 저장 값 ${Object.keys(data.storage).length}개${data.installed.length ? `, 모드 ${data.installed.length}개` : ''}`,
            `Exported: ${name} (${host.kind === 'player' ? 'Download/WML folder' : 'Downloads folder'}) · ${Object.keys(data.storage).length} stored value(s)${data.installed.length ? `, ${data.installed.length} mod(s)` : ''}`) + `${extText}${leftText}` };
      } catch (e) { transferNote = { ok: false, text: L(`내보내지 못했어요: ${e.message}`, `Could not export: ${e.message}`) }; }
      win.refresh();
    };
    box.append(el('div', { style: 'display:flex;gap:6px;flex-wrap:wrap' },
      uiButton(L('내보내기', 'Export'), exportNow, { title: L('고른 종류를 파일 하나로 저장해요', 'Saves the ticked kinds as one file') }),
      uiButton(L('가져오기…', 'Import…'), () => pick.click(), { title: L('내보낸 파일(wml-state-….json)을 골라요', 'Pick an exported file (wml-state-….json)') }), pick));
    if (transferNote) box.append(el('div', { class: 'wml-small', style: `margin-top:4px;color:${transferNote.ok ? '#86efac' : '#fca5a5'}` }, transferNote.text));
    return box;
  }

  /** console access for mod authors: localStorage.setItem('wml.dev','true') then WML.dev() */
  function dev() {
    if (!lsGet('wml.dev', false)) throw new Error("WML.dev(): run localStorage.setItem('wml.dev','true') and reload first");
    if (!engine) throw new Error('WML.dev(): game not booted yet');
    return Object.freeze({ ...makeApi({ id: 'dev' }), hooks });
  }

  // A game bundle may carry a saves/settings file the player app was told to bring in. It goes in now, before
  // mods.js and the game read anything (installed mods: before the installed copies are loaded).
  if (HOST && typeof HOST.takePendingState === 'function') {
    try {
      const text = HOST.takePendingState();
      if (text) {
        const r = importState(JSON.parse(text));
        stateImport = r.done;
        // the game's own save databases went in now, but the game read them as its page started: start once more
        if (r.gameDbs) stateImport = Promise.resolve(r.done).then(() => { location.reload(); return new Promise(() => {}); });
        transferNote = { ok: !r.failed.length, text: L(`게임 묶음의 세이브·설정을 가져왔어요: 저장 값 ${r.written}개${r.mods ? `, 모드 ${r.mods}개` : ''}.`, `Imported the saves & settings from the game bundle: ${r.written} stored value(s)${r.mods ? `, ${r.mods} mod(s)` : ''}.`)
          + (r.failed.length ? L(` 공간 부족으로 ${r.failed.length}개 실패.`, ` ${r.failed.length} did not fit in the storage.`) : '')
          + (r.external ? L(` 모드 저장소 ${r.external}개는 모드보다 먼저 넣어요.`, ` ${r.external} mod database(s) go in before any mod runs.`) : '') };
        console.info('[WML]', transferNote.text);
      }
    } catch (e) { warn(L(`게임 묶음의 세이브·설정을 가져오지 못했어요: ${e.message}`, `Could not import the saves & settings from the game bundle: ${e.message}`)); }
  }

  window.WML = Object.freeze({
    VERSION, define, enable, symbols, boot, dev, compat,
    /** wml/presets/presets.js: presets that come with the package (shown in the manager's preset list) */
    presets,
    /** apply a preset object (the file form): its mods in use in its order, the rest not → { present, missing, … }; takes effect after a reload */
    applyPreset: (obj, { reload = false } = {}) => { const c = applyPreset(normPreset(obj), 'api'); if (reload) location.reload(); return c; },
    /** the mods in use now, in load order, as a preset object (the file form) */
    currentPreset: (name, description) => { const { key, ...p } = presetFromCurrent(name || 'preset', description || ''); return p; },
    /** the stored text of a localStorage key as it is (getItem unpacks packed saves) */
    rawGetItem: k => rawGetItem.call(localStorage, k),
    openManager, window: openWindow,
    /** what a mod shared with api.provide (for the console and plain scripts) */
    use: id => provided.get(id),
    /** where the game runs: { kind: 'player'|'browser', app, platform: 'pc'|'mobile' } */
    host,
    /** the phone's back button (WML Player calls it): true when something was closed */
    back,
    /** save a file: a download in a browser, Download/WML in the phone app */
    saveFile: (name, data, type) => saveFile(name, data, type),
    /** saves + settings (+ installed mods) as one object; want: { saves, game, mods, other, installed } (false = leave out) */
    exportState: want => exportState(want),
    /** write such an object into this browser → { written, failed, mods, done (Promise) }; reload afterwards */
    importState: (obj, want) => importState(obj, want),
    status: () => { const pm = promptMods(); return ({ ...JSON.parse(JSON.stringify(state)), unread: [...unread], host, lang: LANG(), installed: installedIds(), modSymbols: Object.fromEntries(modSyms),
      roles: Object.fromEntries([...defs].filter(([, d]) => d.roles.length).map(([id, d]) => [id, d.roles])),
      langs: Object.fromEntries([...defs].filter(([, d]) => d.langs.length).map(([id, d]) => [id, d.langs])),
      notices: Object.fromEntries([...defs.keys()].map(id => [id, noticesFor(id).map(n => n.id)]).filter(([, n]) => n.length)),
      pauseMenu: { found: pauseMenu.raw, entries: [...pauseEntries.keys()] }, saves: savesStatus(),
      presets: { bundled: bundledPresets.map(p => p.key), mine: userPresets().map(p => p.key), applied: lsGet(LS_PRESET_NOW, null) },
      meta: Object.fromEntries([...defs].map(([id, d]) => [id, { author: d.author, tags: d.tags, pack: d.pack, base: isBase(id), prompt: d.tags.includes('prompt') || pm.has(id) }])), tags: MOD_TAGS }); },
    /** install mods from File objects or { path, blob } (zip, folder files, mod.js); takes effect after a reload */
    install: items => install(items),
    uninstall: id => uninstall(id),
    installed: () => installedIds(),
    /** how this start went (0.9.1): { data: phases, files, setups, extra files, stalls…, text } — times in ms since the page began to load */
    bootReport: () => bootReport(),
    /** the diagnostics log (0.9.3): Promise<{ data: env, errors, freezes, slow hooks, mods, earlier runs…, text }> */
    diagnostics: () => diagReport(),
    /** save the diagnostics log as a text file (what the manager's button does) → Promise (0.9.3) */
    saveDiagnostics: () => diagSave().then(r => r.text.length),
    /** read the files of the mods switched off at start (the manager does it when it opens) → Promise (0.9.1) */
    readAll: () => readAllMods(),
    /** localStorage use: { used, quota, percent, byKind, items (biggest first) } — sizes in characters */
    storage: () => { const u = storageUsage(); return u && { ...u, items: u.items.slice(0, 20) }; },
  });
  window.__WML__ = window.WML;
})();
