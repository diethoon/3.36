import { test, expect } from 'bun:test'
import * as fs from 'node:fs'
import * as os from 'node:os'
import * as path from 'node:path'
import { OutfitPackWriter, packKeyAllowed } from './outfitPack.ts'

// The supporting-cast pack ('extra'): tavern scenes of the original wives and the tavern husband,
// shared by every character's pack (game: src/faith/image/pack.js wfPackExtraFrames).
test('cast pack keys: only tavern scenes of the cast; character packs keep their own keys', () => {
  expect(packKeyAllowed('mara__s-wfo_tavern_hall__o-wf_tavern_work__p-vl__v-0', 'extra', 'extra')).toBe(true)
  expect(packKeyAllowed('tavern_husband__s-wfo_tavern_husband_in__o-wf_tavern_husband_clothes__p-vl__v-0', 'extra', 'extra')).toBe(true)
  expect(packKeyAllowed('elena__t-i__o-modest__p-bd__v-0', 'extra', 'extra')).toBe(false)
  expect(packKeyAllowed('wf_knight_visitor__t-i__o-wf_knight_helm__p-ch__v-0', 'extra', 'extra')).toBe(true)
  expect(packKeyAllowed('wf_knight_visitor__t-i__o-wf_knight_armor__p-ch__v-0', 'extra', 'extra')).toBe(false)
  // the secret shop's witch (one picture)
  expect(packKeyAllowed('wf_secret_shop__v-0', 'extra', 'extra')).toBe(true)
  expect(packKeyAllowed('wf_secret_shop__v-1', 'extra', 'extra')).toBe(true)
  expect(packKeyAllowed('wf_secret_shop__v-2', 'extra', 'extra')).toBe(false)
  expect(packKeyAllowed('wf_secret_shop__v-0', 'elena', 'basic')).toBe(false)
  expect(packKeyAllowed('mara__s-wfo_tavern_hall__o-wf_tavern_work__p-vl__v-0', 'mara', 'extra')).toBe(false)
  expect(packKeyAllowed('elena__t-i__o-modest__p-bd__v-0', 'elena', 'basic')).toBe(true)
  expect(packKeyAllowed('mara__s-wfo_tavern_hall__o-wf_tavern_work__p-vl__v-0', 'elena', 'basic')).toBe(false)
})

test('cast pack folder is <name>-extra and its catalogue is marked extra', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-extra-pack-'))
  try {
    const imagesDir = path.join(root, 'source'), out = path.join(root, 'image-packs')
    fs.mkdirSync(imagesDir, { recursive: true })
    fs.writeFileSync(path.join(imagesDir, 'a.png'), 'a')
    const writer = new OutfitPackWriter(path.join(root, 'state'), imagesDir, { character: 'extra', outfit: 'extra', name: 'default' }, true, out)
    expect(path.relative(out, writer.directory)).toBe(path.join('default-extra', 'base'))
    const key = 'pippa__s-wfo_tavern_wife__o-wf_tavern_work__p-vl__v-0'
    writer.add(key, { imagePath: 'a.png' })
    expect(() => writer.add('elena__t-i__o-modest__p-bd__v-0', { imagePath: 'a.png' })).toThrow()
    writer.flush()
    const source = fs.readFileSync(path.join(writer.directory, 'pack.js'), 'utf8')
    const pack = JSON.parse(source.match(/\]\s*=\s*(\{[\s\S]*\})\s*;?\s*$/)![1])
    expect(pack.wfImagePack).toEqual({ version: 2, character: 'extra', basic: false, extra: true, outfits: [] })
    expect(Object.keys(pack.entries)).toEqual([key])
    // Re-opening the same cast pack continues it instead of refusing the folder.
    const again = new OutfitPackWriter(path.join(root, 'state'), imagesDir, { character: 'extra', outfit: 'extra', name: 'default' }, false, out)
    expect(again.packId).toBe(writer.packId)
  } finally {
    fs.rmSync(root, { recursive: true, force: true })
  }
})
