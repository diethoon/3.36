import { test, expect } from 'bun:test'
import * as fs from 'node:fs'
import * as os from 'node:os'
import * as path from 'node:path'
import { knownImageSize, saveKnownImageSizes } from './imageSize.ts'

// A PNG header is enough for imageSize: signature, IHDR length/type, width, height.
const png = (w: number, h: number, pad = 0) => {
  const b = Buffer.alloc(33 + pad)
  b.write('\x89PNG\r\n\x1a\n', 0, 'latin1'); b.writeUInt32BE(13, 8); b.write('IHDR', 12); b.writeUInt32BE(w, 16); b.writeUInt32BE(h, 20)
  return b
}

// The maker's '이미 있는 그림 확인' opened every pack picture for its size — 12 s on a cold disk (user report 2026-10-20).
// The size is remembered in the state folder while the file stays the same.
test('a picture size is remembered across runs and read again only when the file changes', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-image-size-'))
  try {
    const state = path.join(root, 'state'), file = path.join(root, 'a.png')
    fs.writeFileSync(file, png(832, 1216))
    expect(knownImageSize(state, file)).toEqual([832, 1216])
    saveKnownImageSizes(state)
    const saved = JSON.parse(fs.readFileSync(path.join(state, 'image-sizes.json'), 'utf8'))
    expect(saved[file].slice(2)).toEqual([832, 1216])
    // Remembered: a wrong remembered value (same byte size and time) is what comes back, so the file is not reopened
    const stat = fs.statSync(file)
    saved[file] = [stat.size, Math.floor(stat.mtimeMs), 1, 2]
    const other = path.join(root, 'state2')
    fs.mkdirSync(other); fs.writeFileSync(path.join(other, 'image-sizes.json'), JSON.stringify(saved))
    expect(knownImageSize(other, file)).toEqual([1, 2])
    // A redrawn file (different bytes) is read again
    fs.writeFileSync(file, png(1024, 1024, 10))
    expect(knownImageSize(other, file)).toEqual([1024, 1024])
    expect(knownImageSize(other, path.join(root, 'missing.png'))).toBeNull()
  } finally { fs.rmSync(root, { recursive: true, force: true }) }
})
