import { test, expect } from 'bun:test'
import * as fs from 'node:fs'
import * as os from 'node:os'
import * as path from 'node:path'
import { BatchQueue, type BatchItem } from './queue.ts'
import type { Config } from '../config.ts'
import type { CacheStore } from '../cache/cacheStore.ts'
import type { JobRunner } from '../comfy/jobRunner.ts'

test('6024 image-pack items survive four upload chunks and a server restart', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-batch-chunks-'))
  try {
    const config = { stateDir: root } as Config
    const cache = { get: () => null } as unknown as CacheStore
    const jobs = {} as JobRunner
    const queue = new BatchQueue(config, cache, jobs)
    const items = Array.from({ length: 6024 }, (_, i) => ({ talentId: `mara__frame-${i}`, prompt: `frame ${i}` }))
    let jobId: string | undefined
    let accepted = 0
    const totals: number[] = []
    for (let i = 0; i < items.length; i += 2000) {
      const result = queue.enqueue(items.slice(i, i + 2000), jobId)
      jobId = result.jobId
      accepted += result.accepted
      totals.push(queue.status().total)
    }
    expect(accepted).toBe(6024)
    expect(queue.status().total).toBe(6024)
    expect(totals).toEqual([2000, 4000, 6000, 6024])
    const lines = fs.readFileSync(path.join(root, 'batch', `${jobId}.jsonl`), 'utf8').trim().split('\n')
    expect(lines.length).toBe(6024)
    expect(new Set(lines.map(l => JSON.parse(l).talentId)).size).toBe(6024)
    const restored = new BatchQueue(config, cache, jobs).resume()
    expect(restored.status().total).toBe(6024)
    expect(restored.status().paused).toBe(true)
    expect(restored.enqueue(items.slice(6000), jobId).accepted).toBe(0)
    expect(restored.status().total).toBe(6024)
    // A new pack while this job still has work left is added to it (it used to wipe the queue — user report 2026-10-20)
    const added = restored.enqueue([{ talentId: 'new-pack', prompt: 'new pack' }])
    expect(added.jobId).toBe(jobId!)
    expect(restored.status().total).toBe(6025)
    // After a clear, a new plan starts a new job
    restored.clear()
    restored.enqueue([{ talentId: 'new-pack', prompt: 'new pack' }])
    expect(restored.status().total).toBe(1)
  } finally { fs.rmSync(root, { recursive: true, force: true }) }
})

test('a pack added while a job runs is drawn after the earlier essentials, ahead of the earlier extras', async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-batch-add-running-'))
  try {
    const config = { stateDir: root } as Config
    const cache = { get: () => null } as unknown as CacheStore
    const queue = new BatchQueue(config, cache, {} as JobRunner)
    const rendered: string[] = []
    let added = false
    ;(queue as unknown as { renderOne(item: BatchItem): Promise<string> }).renderOne = async item => {
      rendered.push(item.talentId)
      // While the first job runs, the game adds another pack (no jobId — a fresh plan)
      if (!added) {
        added = true
        const r = queue.enqueue([{ talentId: 'kaguya__core', prompt: 'k', weight: 2, essential: true }, { talentId: 'kaguya__extra', prompt: 'k', weight: 0.5 }])
        expect(r.accepted).toBe(2)
      }
      return 'completed'
    }
    queue.enqueue([{ talentId: 'elena__core', prompt: 'e', weight: 2, essential: true }, { talentId: 'elena__extra1', prompt: 'e', weight: 1 }, { talentId: 'elena__extra2', prompt: 'e', weight: 1 }])
    queue.start()
    while (queue.status().running) await new Promise(r => setTimeout(r, 1))
    expect(rendered).toEqual(['elena__core', 'kaguya__core', 'elena__extra1', 'elena__extra2', 'kaguya__extra'])
    expect(queue.status().total).toBe(5)
    // A finished job is replaced by the next plan
    queue.enqueue([{ talentId: 'next', prompt: 'n' }])
    expect(queue.status().total).toBe(1)
  } finally { fs.rmSync(root, { recursive: true, force: true }) }
})

// A pack added later goes whole after the earlier packs' essentials — even its heavier special scenes —
// and its extras after theirs, the same order as the progress bars (user decision 2026-10-20).
test('essentials run pack by pack in the order the packs were added, then the extras', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-batch-pack-rank-'))
  try {
    const queue = new BatchQueue({ stateDir: root } as Config, { get: () => null } as unknown as CacheStore, {} as JobRunner)
    const item = (who: string, id: string, weight: number, essential = false): BatchItem =>
      ({ talentId: `${who}__${id}`, prompt: who, weight, ...(essential ? { essential } : {}), outfitPack: { character: who.replace(/d$/, ''), outfit: who.endsWith('2') ? 'nun' : 'basic', name: 'rank' } })
    const pack = (who: string) => [item(who, 'extra', 1), item(who, 'rep', 2, true), item(who, 'special', 3.5, true), item(who, 'face', 0.5)]
    const first = queue.enqueue([...pack('elena'), ...pack('mara')])
    queue.enqueue(pack('mara2'), first.jobId)
    // added later, with a heavier special scene than any earlier pack
    queue.enqueue([...pack('pippa'), item('pippa', 'single', 4, true)])
    const order = (queue as unknown as { items: BatchItem[] }).items.map(i => i.talentId)
    expect(order).toEqual([
      'elena__special', 'elena__rep', 'mara__special', 'mara__rep', 'mara2__special', 'mara2__rep', 'pippa__single', 'pippa__special', 'pippa__rep',
      'elena__extra', 'elena__face', 'mara__extra', 'mara__face', 'mara2__extra', 'mara2__face', 'pippa__extra', 'pippa__face',
    ])
  } finally { fs.rmSync(root, { recursive: true, force: true }) }
})

test('appending a chunk preserves completed work and filters cached and repeated items', async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-batch-append-'))
  try {
    const config = { stateDir: root } as Config
    const cache = { get: (key: string) => key === 'cached' ? {} : null } as unknown as CacheStore
    const queue = new BatchQueue(config, cache, {} as JobRunner)
    const rendered: string[] = []
    ;(queue as unknown as { renderOne(item: BatchItem): Promise<string> }).renderOne = async item => { rendered.push(item.talentId); return 'completed' }
    const first = queue.enqueue([{ talentId: 'first', prompt: 'first' }], 'append-test')
    queue.start()
    while (queue.status().running) await new Promise(resolve => setTimeout(resolve, 1))
    expect(queue.status().done).toBe(1)
    const result = queue.enqueue([
      { talentId: 'first', prompt: 'first' }, { talentId: 'cached', prompt: 'cached' },
      { talentId: 'second', prompt: 'second' }, { talentId: 'second', prompt: 'second' },
    ], first.jobId)
    expect(result.accepted).toBe(1)
    expect(result.alreadyCached).toBe(1)
    expect(queue.status().total).toBe(2)
    expect(queue.status().done).toBe(1)
    const restored = new BatchQueue(config, cache, {} as JobRunner).resume()
    expect(restored.status().total).toBe(2)
    expect(restored.status().done).toBe(1)
    queue.start()
    while (queue.status().running) await new Promise(resolve => setTimeout(resolve, 1))
    expect(rendered).toEqual(['first', 'second'])
    expect(queue.status().done).toBe(2)
  } finally { fs.rmSync(root, { recursive: true, force: true }) }
})
