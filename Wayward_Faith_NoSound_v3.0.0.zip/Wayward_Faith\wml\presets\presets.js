// 게임과 같이 넣어 주는 모드 프리셋이에요. 모드 관리자의 "프리셋" 목록에 "게임에 들어 있는 프리셋"으로 나와요.
// 프리셋 = 사용할 모드를 로드 순서대로 적은 목록이에요. 적용하면 목록에 없는 모드는 "사용 안 함"으로 가요. 모드 설정은 바꾸지 않아요.
// 모드 관리자의 "내보내기"로 만든 프리셋 파일(wml-preset-….json)의 내용을 아래 [ ] 안에 그대로 붙여 넣으면 돼요(여러 개면 쉼표로 이어요).
//
// Mod presets that come with the game. They show in the mod manager's preset list under "Came with the game".
// A preset is the list of mods to use, in load order; applying it moves every other mod to "not in use". Mod settings stay as they are.
// Paste the contents of a preset file made with the manager's "Export" (wml-preset-….json) inside the [ ] below (separate several with commas).
//
// 예 / example:
//   { "type": "wml-preset", "version": 1, "name": "기본 편의", "description": "…", "mods": ["addon-compat", "layer-fix", "touch-bar"] },
WML.presets([
]);
