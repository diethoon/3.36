/**
 * The generation lifecycle: submit, poll, save, cache.
 *
 * Four pieces of bookkeeping here look redundant and are not. Each covers a
 * race that produced duplicate renders or duplicate files in practice:
 *
 *  - `pendingSubmissions` covers the window between a cache miss and the job
 *    landing in the map. Without it two concurrent identical requests both see
 *    no in-flight job and queue two ComfyUI prompts.
 *  - `finalizing` is claimed SYNCHRONOUSLY before any await in the completion
 *    path, so two poll ticks cannot both save the same output.
 *  - `latestDesiredKey` lets a newer foreground request flush older queued ones.
 *    ComfyUI cannot cheaply preempt a running sampler, but it can be stopped
 *    from working through a backlog of states the player has already left.
 *  - `bulk` marks batch work as exempt from that flush, or one click in the game
 *    would cancel hundreds of queued overnight renders.
 *
 * Jobs live in memory only. A restart loses them, which is why the server is not
 * run under a file watcher by default — a reload mid-render leaves the client
 * polling a promptId that no longer exists.
 */

import type { Config, WorkflowType } from '../config.ts'
import type { ComfyClient, ComfyOutput } from './client.ts'
import type { CacheStore } from '../cache/cacheStore.ts'
import { jobKey, sanitizeName } from '../naming.ts'
import { buildComfyPrompt, type GenOverrides } from './workflows/index.ts'
import { saveImage, saveVideo, type SavedMedia } from './media.ts'
import { generateNovelAIImage } from '../nai/client.ts'
import { readNaiToken } from '../nai/token.ts'

export type JobStatus = 'queued' | 'processing' | 'completed' | 'error'

export interface GenerationJob {
  promptId: string
  talentId: string
  talentName: string
  imageType: string
  promptHash: string
  prompt: string
  /** Kept so the cache entry can record it — see CacheEntry.negativePrompt. */
  negativePrompt?: string
  /** Likewise: the hash folds these in, so an entry needs them to be checkable. */
  genParams?: GenOverrides
  workflow: WorkflowType
  status: JobStatus
  startedAt: number
  completedAt?: number
  mediaKind: 'image' | 'video'
  /** Set once saved. The client turns this into a URL; no base64 changes hands. */
  media?: SavedMedia
  error?: string
  cancelRequested?: boolean
  /** Batch work: exempt from foreground supersedence. */
  bulk?: boolean
  debug?: Record<string, unknown>
  /** Whose picture this is, as the client said. Picks the save folder. */
  characterId?: string
  presetName?: string
  styleName?: string
  /** Rendered by NovelAI instead of ComfyUI: the poller leaves it alone. */
  provider?: 'nai'
  /** NovelAI request already sent — too late to cancel. */
  naiStarted?: boolean
}

/**
 * Minimum gap between NovelAI requests. They still go one at a time (naiChain);
 * the 10-second wait was removed (Wayward Faith, user decision 2026-10-21) — image packs,
 * the only bulk source, are refused for NovelAI (batch/queue.ts enqueue).
 */
export const NAI_MIN_INTERVAL_MS = 0

/** Completed jobs linger this long so a client poll can still collect them. */
const JOB_TTL_MS = 60_000

export interface SubmitArgs {
  /** Internal batch destination; never taken from an HTTP generation request. */
  output?: { cache: CacheStore }
  talentId: string
  talentName: string
  imageType: string
  prompt: string
  negativePrompt: string
  workflow: WorkflowType
  promptHash: string
  seed?: number
  overrides?: GenOverrides
  referenceImagePath?: string
  bulk?: boolean
  debug?: Record<string, unknown>
  characterId?: string
  presetName?: string
  styleName?: string
}

export interface JobRunnerOptions {
  config: Config
  comfy: ComfyClient
  cache: CacheStore
  now?: () => number
  /** Spacing between NovelAI requests; tests shorten it. */
  naiIntervalMs?: number
}

export class JobRunner {
  private readonly outputs = new WeakMap<GenerationJob, NonNullable<SubmitArgs['output']>>()
  private readonly jobs = new Map<string, GenerationJob>()
  private readonly finalizing = new Set<string>()
  private readonly pendingSubmissions = new Map<string, Promise<string>>()
  /**
   * Batch prompts sent to ComfyUI whose job is not in the map yet. While any are,
   * supersede must not treat an unknown prompt of ours as a leftover: it may be one of these.
   */
  private bulkSubmitting = 0
  private latestDesiredKey: string | null = null
  private timer: ReturnType<typeof setTimeout> | null = null
  private stopped = false
  /** Completion timestamps in the current rolling hour, for the rate cap. */
  private recentCompletions: number[] = []
  /** NovelAI allows one request at a time per account, so its jobs run in a chain. */
  private naiChain: Promise<void> = Promise.resolve()
  /** When the last NovelAI request went out (this.now() clock). */
  private lastNaiRequestAt = -Infinity
  private readonly naiIntervalMs: number

  private readonly config: Config
  private readonly comfy: ComfyClient
  private readonly cache: CacheStore
  private readonly now: () => number
  private readonly pollIntervalMs: number

  constructor(opts: JobRunnerOptions) {
    this.config = opts.config
    this.comfy = opts.comfy
    this.cache = opts.cache
    this.now = opts.now ?? Date.now
    this.pollIntervalMs = opts.config.pollIntervalMs
    this.naiIntervalMs = opts.naiIntervalMs ?? NAI_MIN_INTERVAL_MS
  }

  get(promptId: string): GenerationJob | undefined {
    return this.jobs.get(promptId)
  }

  /** Jobs still queued or sampling. */
  activeJobs(): GenerationJob[] {
    return [...this.jobs.values()].filter(j => isActive(j))
  }

  /** How many interactive jobs are waiting — used to refuse an overlong queue. */
  queuedCount(): number {
    return this.activeJobs().filter(j => !j.bulk).length
  }

  /** Images finished in the last rolling hour, for the per-hour ceiling. */
  completionsThisHour(): number {
    const cutoff = this.now() - 3_600_000
    this.recentCompletions = this.recentCompletions.filter(t => t > cutoff)
    return this.recentCompletions.length
  }

  /**
   * Submit a render, or join one already in flight for the same state.
   *
   * The dedup key is (workflow, talentName, imageType, promptHash) — the same
   * identity the persistent cache uses, so "already rendering" and "already
   * rendered" agree on what sameness means.
   */
  async submit(args: SubmitArgs): Promise<GenerationJob> {
    const key = jobKey(args.talentName, args.imageType, args.promptHash, args.workflow) + (args.output ? '|' + args.output.cache.imagesDir : '')

    const inFlight = this.findActiveByKey(key)
    if (inFlight) return inFlight

    const pending = this.pendingSubmissions.get(key)
    if (pending) {
      const promptId = await pending
      const job = this.jobs.get(promptId)
      if (job) return job
    }

    // Claim the key SYNCHRONOUSLY, before any await. Everything below yields at
    // least once, and a concurrent request for the same state must join this
    // submission rather than start a second render of the same picture.
    let claimed!: (promptId: string) => void
    let failed!: (err: unknown) => void
    const submission = new Promise<string>((resolve, reject) => {
      claimed = resolve
      failed = reject
    })
    // Joiners await this promise, but when nobody joined, a rejection (for
    // example ComfyUI refusing a graph whose LoRA file does not exist) would be
    // unobserved — and Bun exits the whole server on an unhandled rejection.
    // Observe it here; joiners still receive the rejection through their own await.
    submission.catch(() => {})
    this.pendingSubmissions.set(key, submission)

    try {
      // NovelAI: no ComfyUI involved, so none of the ComfyUI queue handling below.
      if (args.overrides?.modelType === 'nai') {
        if (!args.bulk) {
          this.latestDesiredKey = key
          this.supersedeNai(key)
        }
        const job = this.makeJob(`nai_${crypto.randomUUID()}`, args)
        job.provider = 'nai'
        this.jobs.set(job.promptId, job)
        claimed(job.promptId)
        this.naiChain = this.naiChain.then(() => this.runNai(job, args)).catch(() => {})
        return job
      }

      if (!args.bulk) {
        this.latestDesiredKey = key
        // Flush queued foreground work the player has already moved past —
        // BEFORE submitting. Doing it concurrently is a self-cancel: a new
        // prompt reaches ComfyUI's queue before it reaches our job map, so the
        // sweep reads it as an unrecognised prompt of ours and drops the very
        // render it was called for.
        await this.supersede(key)
      }

      const graph = buildComfyPrompt(
        this.config,
        args.prompt,
        args.negativePrompt,
        filenamePrefixFor(args.talentName, args.imageType),
        args.workflow,
        args.seed,
        args.overrides,
        args.referenceImagePath,
      )

      // Foreground work jumps the queue; batch work waits its turn.
      if (args.bulk) this.bulkSubmitting++
      let promptId: string
      try {
        promptId = await this.comfy.submit(graph, !args.bulk)
      } finally {
        if (args.bulk) this.bulkSubmitting--
      }

      const job = this.makeJob(promptId, args)
      // Registered BEFORE the claim resolves, so a joiner always finds it.
      this.jobs.set(promptId, job)
      claimed(promptId)
      return job
    } catch (err) {
      failed(err)
      throw err
    } finally {
      this.pendingSubmissions.delete(key)
    }
  }

  private makeJob(promptId: string, args: SubmitArgs): GenerationJob {
    const job: GenerationJob = {
      promptId,
      talentId: args.talentId,
      talentName: args.talentName,
      imageType: args.imageType,
      promptHash: args.promptHash,
      prompt: args.prompt,
      negativePrompt: args.negativePrompt,
      genParams: args.overrides,
      workflow: args.workflow,
      status: 'queued',
      startedAt: this.now(),
      mediaKind: 'image',
      bulk: args.bulk,
      debug: args.debug,
      characterId: args.characterId,
      presetName: args.presetName,
      styleName: args.styleName,
    }
    if (args.output) this.outputs.set(job, args.output)
    return job
  }

  /** One NovelAI render, run in turn on `naiChain`. */
  private async runNai(job: GenerationJob, args: SubmitArgs): Promise<void> {
    if (job.cancelRequested || !isActive(job)) return
    const wait = this.lastNaiRequestAt + this.naiIntervalMs - this.now()
    if (wait > 0) await new Promise(resolve => setTimeout(resolve, wait))
    // The player may have moved on while this one waited its turn.
    if (job.cancelRequested || !isActive(job)) return
    this.lastNaiRequestAt = this.now()
    job.naiStarted = true
    job.status = 'processing'
    const o = args.overrides ?? {}
    try {
      const { bytes } = await generateNovelAIImage({
        token: readNaiToken(this.config.stateDir),
        model: o.checkpoint || 'nai-diffusion-4-5-full',
        prompt: args.prompt,
        negativePrompt: args.negativePrompt,
        width: o.width ?? 832,
        height: o.height ?? 1216,
        steps: o.steps ?? 28,
        scale: o.cfg ?? 5,
        sampler: o.sampler || 'k_euler_ancestral',
        noiseSchedule: o.noiseSchedule || 'karras',
        seed: args.seed,
      })
      // Saved even if the player has moved on: the picture is paid for and the state may come back.
      await this.storeImage(job, bytes)
    } catch (err) {
      job.status = 'error'
      job.error = (err as Error).message
      job.completedAt = this.now()
      console.error(`[jobs] ${job.promptId}: ${job.error}`)
    }
  }

  /** Drop NovelAI foreground jobs not yet sent, other than `exceptKey`. */
  private supersedeNai(exceptKey: string): void {
    for (const job of this.jobs.values()) {
      if (job.provider !== 'nai' || job.bulk || job.naiStarted || !isActive(job)) continue
      if (jobKey(job.talentName, job.imageType, job.promptHash, job.workflow) === exceptKey) continue
      this.markCancelled(job, 'superseded')
    }
  }

  /** Register an externally-submitted video job so the poller finalizes it. */
  trackVideo(job: Omit<GenerationJob, 'status' | 'startedAt' | 'mediaKind'>): GenerationJob {
    const full: GenerationJob = {
      ...job,
      status: 'queued',
      startedAt: this.now(),
      mediaKind: 'video',
    }
    this.jobs.set(job.promptId, full)
    return full
  }

  /**
   * Cancel one job if ComfyUI has not started sampling it. A running job is
   * left to finish — interrupting the sampler is not cheap — and its result is
   * simply ignored.
   */
  async cancel(promptId: string): Promise<{ cancelled: boolean; running: boolean; queueState: string }> {
    const job = this.jobs.get(promptId)
    if (!job || !isActive(job)) {
      return { cancelled: false, running: false, queueState: 'missing' }
    }
    if (job.provider === 'nai') {
      if (job.naiStarted) return { cancelled: false, running: true, queueState: 'running' }
      this.markCancelled(job, 'superseded by a newer request')
      return { cancelled: true, running: false, queueState: 'pending' }
    }
    job.cancelRequested = true

    const queueState = await this.comfy.queueStateOf(promptId)
    if (queueState !== 'pending') {
      return { cancelled: false, running: queueState === 'running', queueState }
    }
    if (!await this.comfy.deletePending([promptId])) {
      return { cancelled: false, running: false, queueState }
    }

    this.markCancelled(job, 'superseded by a newer request')
    return { cancelled: true, running: false, queueState }
  }

  /** Drop queued foreground prompts other than `exceptKey`. */
  private async supersede(exceptKey: string): Promise<number> {
    const { all, ours } = await this.comfy.pendingIds()
    if (all.size === 0) return 0

    const toCancel: string[] = []
    for (const [promptId, job] of this.jobs) {
      if (!isActive(job)) continue
      if (!all.has(promptId)) continue
      if (job.bulk) continue
      if (jobKey(job.talentName, job.imageType, job.promptHash, job.workflow) === exceptKey) continue
      job.cancelRequested = true
      toCancel.push(promptId)
    }

    // Prompts we recognise as ours but have no job record for — left over from
    // a previous run of this server. Safe to drop; still never anyone else's.
    // Not while a batch prompt is on its way into the map: it would look the same (they wait for a later sweep).
    for (const promptId of this.bulkSubmitting > 0 ? [] : ours) {
      if (toCancel.includes(promptId)) continue
      if (this.jobs.get(promptId)?.bulk) continue
      toCancel.push(promptId)
    }

    if (toCancel.length === 0) return 0
    if (!await this.comfy.deletePending(toCancel)) return 0

    for (const promptId of toCancel) {
      const job = this.jobs.get(promptId)
      if (job) this.markCancelled(job, 'superseded')
    }
    return toCancel.length
  }

  private markCancelled(job: GenerationJob, reason: string): void {
    job.cancelRequested = true
    job.status = 'error'
    job.error = reason
    job.completedAt = this.now()
  }

  private findActiveByKey(key: string): GenerationJob | null {
    for (const job of this.jobs.values()) {
      if (!isActive(job)) continue
      if (jobKey(job.talentName, job.imageType, job.promptHash, job.workflow) + (this.outputs.has(job) ? '|' + this.outputs.get(job)!.cache.imagesDir : '') === key) return job
    }
    return null
  }

  private reapStale(): void {
    const cutoff = this.now() - JOB_TTL_MS
    for (const [promptId, job] of this.jobs) {
      if (job.completedAt !== undefined && job.completedAt < cutoff) {
        this.jobs.delete(promptId)
      }
    }
  }

  /** One poll pass. Exposed so a test can drive it without the timer. */
  async tick(): Promise<void> {
    this.reapStale()

    const pending = [...this.jobs.entries()].filter(
      ([promptId, job]) => isActive(job) && job.provider !== 'nai' && !this.finalizing.has(promptId),
    )
    if (pending.length === 0) return

    for (const [promptId, job] of pending) {
      // Re-check: an earlier iteration's await may have let another tick in.
      if (this.finalizing.has(promptId) || !isActive(job)) continue

      try {
        const result = await this.comfy.history(promptId)
        if (this.finalizing.has(promptId) || !isActive(job)) continue

        if (result.error) {
          job.status = 'error'
          job.error = result.error
          job.completedAt = this.now()
          continue
        }
        if (!result.done) {
          job.status = 'processing'
          continue
        }

        // Claim synchronously, before any further await, so no other path can
        // enter the save.
        this.finalizing.add(promptId)
        try {
          await this.finalize(job, result.images ?? [], result.videos ?? [], result.report)
        } finally {
          this.finalizing.delete(promptId)
        }
      } catch (err) {
        console.error(`[jobs] error polling ${promptId}:`, (err as Error).message)
      }
    }
  }

  private async finalize(
    job: GenerationJob,
    images: ComfyOutput[],
    videos: ComfyOutput[],
    report?: string,
  ): Promise<void> {
    const outputs = job.mediaKind === 'video' ? videos : images
    if (outputs.length === 0) {
      // ComfyUI said the prompt finished and handed back nothing we can save.
      // The bare fact is useless to a player, so say what ComfyUI DID report:
      // it saw the wrong media kind, or it was cancelled, or it errored, or —
      // when there is genuinely nothing — where to go and look.
      const wrongKind = job.mediaKind === 'video' ? images : videos
      const detail =
        wrongKind.length > 0
          ? `it returned ${wrongKind.length} ${job.mediaKind === 'video' ? 'still' : 'animation'}(s) instead`
          : report
            ?? 'ComfyUI listed no outputs at all — the run was cancelled, or the graph no '
              + 'longer ends in a Save Image node'
      job.status = 'error'
      job.error = `completed without a readable ${job.mediaKind} output — ${detail}`
      job.completedAt = this.now()
      console.error(`[jobs] ${job.promptId}: ${job.error}`)
      console.error(`[jobs] what ComfyUI recorded: ${this.config.comfyUrl}/history/${job.promptId}`)
      return
    }

    const bytes = await this.comfy.view(outputs[0])
    if (!bytes) {
      job.status = 'error'
      job.error = 'could not read the rendered file from ComfyUI'
      job.completedAt = this.now()
      return
    }

    if (job.mediaKind === 'video') {
      job.media = saveVideo({
        imagesDir: this.config.imagesDir,
        bytes,
        talentId: job.talentId,
        promptHash: job.promptHash,
        sourceFilename: outputs[0].filename,
        now: this.now,
      })
    } else {
      await this.storeImage(job, bytes)
      return
    }

    job.status = 'completed'
    job.completedAt = this.now()
    // The hourly ceiling is for interactive work only (routes/image.ts): batch renders must not use it up,
    // or a fast pack run locks the game out of its own pictures (429 'hourly image limit').
    if (!job.bulk) this.recentCompletions.push(job.completedAt)
  }

  /** Save a rendered still and index it — ComfyUI and NovelAI alike. */
  private async storeImage(job: GenerationJob, bytes: Buffer): Promise<void> {
    const cache = this.outputs.get(job)?.cache ?? this.cache
    job.media = await saveImage({
      imagesDir: cache.imagesDir,
      bytes,
      talentName: job.talentName,
      imageType: job.imageType,
      workflow: job.workflow,
      characters: this.config.characterDirs,
      characterId: job.characterId,
      presetName: job.presetName,
      styleName: job.styleName,
      webp: this.config.webp,
      now: this.now,
      // An image pack's own folder: files sit directly in images/ (cache/outfitPack.ts)
      flat: this.outputs.has(job),
    })
    cache.add({
      talentName: job.talentName,
      imageType: job.imageType,
      promptHash: job.promptHash,
      imagePath: job.media.relativePath,
      prompt: job.prompt,
      negativePrompt: job.negativePrompt,
      genParams: job.genParams && {
        steps: job.genParams.steps,
        cfg: job.genParams.cfg,
        loraStrength: job.genParams.loraStrength,
        clipSkip: job.genParams.clipSkip,
        modelType: job.genParams.modelType,
        checkpoint: job.genParams.checkpoint,
        textEncoder: job.genParams.textEncoder,
        vae: job.genParams.vae,
        qualityLoras: job.genParams.qualityLoras,
        characterLoras: job.genParams.characterLoras,
        presetName: job.genParams.presetName,
        styleName: job.genParams.styleName,
      },
      workflow: job.workflow,
      debug: job.debug,
    })

    job.status = 'completed'
    job.completedAt = this.now()
    // The hourly ceiling is for interactive work only (routes/image.ts): batch renders must not use it up,
    // or a fast pack run locks the game out of its own pictures (429 'hourly image limit').
    if (!job.bulk) this.recentCompletions.push(job.completedAt)
  }

  start(): void {
    if (this.timer) return
    this.stopped = false
    this.timer = setTimeout(() => void this.loop(), this.pollIntervalMs)
  }

  stop(): void {
    this.stopped = true
    if (this.timer) {
      clearTimeout(this.timer)
      this.timer = null
    }
  }

  /**
   * Recurring timeout rather than an interval: the next tick is scheduled only
   * after the current one finishes, so a slow poll cannot pile up re-entrant runs.
   */
  private async loop(): Promise<void> {
    if (this.stopped) return
    try {
      await this.tick()
    } catch (err) {
      console.error('[jobs] poll threw:', (err as Error).message)
    }
    if (this.stopped) return
    this.timer = setTimeout(() => void this.loop(), this.pollIntervalMs)
  }
}

function isActive(job: GenerationJob): boolean {
  return job.status === 'queued' || job.status === 'processing'
}

/**
 * ComfyUI writes output files under this prefix. It must keep the
 * `<name>_<imageType>` shape: the cancel path identifies our own queued prompts
 * by matching it, and a change here would make us start flushing the player's
 * manual ComfyUI work instead.
 */
function filenamePrefixFor(talentName: string, imageType: string): string {
  return `${sanitizeName(talentName)}_${imageType}`
}
