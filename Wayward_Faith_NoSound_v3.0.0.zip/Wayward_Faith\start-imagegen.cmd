@echo off
rem Starts the image server (wayward-imagegen) with bun. Extra options are passed through, e.g. start-imagegen.cmd --port 8190
title Wayward Faith - imagegen
cd /d "%~dp0wayward-imagegen"

set "BUN=bun"
where bun >nul 2>nul
if errorlevel 1 set "BUN=%USERPROFILE%\.bun\bin\bun.exe"
if not "%BUN%"=="bun" if not exist "%BUN%" (
  echo bun was not found. Install it from https://bun.sh and run this again.
  pause
  exit /b 1
)

echo Starting the image server. Close this window to stop it.
"%BUN%" src/cli.ts %*
echo.
echo The image server has stopped.
pause
