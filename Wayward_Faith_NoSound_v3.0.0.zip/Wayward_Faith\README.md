# Wayward: Faith

중세 사이비 교단 경영 시뮬레이션. 선술집 생활 시뮬레이션 **Wayward**(Wayward-v2026-09-30_ko-v1.4)를 바탕으로 만든 비공식 개조 게임입니다.

> **⚠ 성인용 콘텐츠**
> 노골적인 성적 표현과 NTR, S/M, 스캇, 수간 등 민감한 소재가 들어 있습니다. 미성년자는 플레이할 수 없습니다.
> 페티시 대부분은 게임을 시작할 때 **교리**로 끌 수 있습니다.

---

## 1. 실행하기

1. 압축을 원하는 폴더에 풉니다.
2. `Wayward_Faith` 폴더 안의 **`Wayward_Faith_v버전.html`** 을 브라우저로 엽니다. 예를 들어 1.2.1 버전은 `Wayward_Faith_v1.2.1.html`입니다. Chrome이나 Edge, Whale을 권장합니다.

게임은 두 가지 zip으로 배포합니다. **하나만** 받으면 됩니다.

- **`Wayward_Faith_v버전.zip`** — 효과음 포함 (보통은 이것)
- **`Wayward_Faith_NoSound_v버전.zip`** — 효과음 없음 (용량이 작음)

받은 팩 zip(`Faith_Extra`·`Faith_Mods`·이미지팩)을 `Wayward_Faith` 폴더 안에 넣고 **`install-packs.cmd`** 를 실행하면 제자리에 풀립니다. 같은 팩이 여러 버전 있으면 가장 새것을 씁니다. 직접 풀어도 됩니다.

엘레나·마라·피파의 기본 이미지팩은 **`Faith_Basic_Elena_v버전.zip`** 처럼 인물마다 따로 배포합니다(실시간으로 그림을 그리지 않을 때 씁니다). 이것도 `install-packs.cmd`로 풀 수 있습니다.

다른 사람이 만든 이미지팩(기본팩·의상팩) zip도 같은 폴더에 넣고 `install-packs.cmd`를 실행하면 `image-packs/` 안에 풀립니다. zip 이름은 상관없고, 안에 든 `pack.js`로 이미지팩을 알아봅니다. 이미 설치한 같은 팩이면 그 폴더를 새 판으로 바꾸고, 이름만 같은 다른 팩이면 덮어쓰지 않고 `-2`처럼 번호를 붙인 폴더에 풉니다. 풀고 나면 게임의 이미지팩 설정에서 `image-packs` 폴더를 선택해 등록하세요.

효과음 없는 판을 받았다가 소리를 넣고 싶으면, 소리 포함 zip의 `sounds/` 폴더를 게임 폴더에 옮기면 됩니다.

신수 봉헌·스캇은 3.0.0부터 게임에 들어 있지 않고, 따로 **`Faith_Mods_v버전.zip`** 으로 배포하는 모드입니다. 이 zip을 게임 폴더에 넣고 `install-packs.cmd`를 실행하면 `wml/mods/`에 풀립니다. 모드는 게임 메뉴의 모드 설정(모드 관리자)에서 켜고 끕니다. 예전 세이브는 모드를 켜면 그대로 이어집니다.

선술집 안주인·남편 그림(조연팩)은 따로 **`Faith_Extra_v버전.zip`** 으로 배포합니다. 이미지팩을 쓸 때만 필요하고, 같은 곳에 풀어 `Wayward_Faith/image-packs/faith-extra/base/`가 생기면 게임이 따로 고르지 않아도 읽습니다. 조연팩과 기본 이미지팩은 담긴 파일이 바뀐 버전에서만 새로 나오므로 게임보다 버전이 낮을 수 있습니다.

모드 로더 **WML**(Wayward Mod Loader)이 게임 폴더의 `wml/`에 들어 있습니다. 게임 중 Esc(일시정지 메뉴) → 게임 설정 아래 **모드 설정** → 모드 관리자에서 모드를 켜고 끄거나 설치합니다. 기본 모드 "Faith 모바일 화면"과 폰 앱 사용법은 **`WML_사용법.txt`** 를 보세요. WML 없이 하고 싶으면 `wml` 폴더를 지우면 됩니다(게임은 그대로 돕니다).

설치는 필요 없습니다. 폴더를 옮길 때는 아래 구성을 그대로 함께 옮겨 주세요. `images`와 `sounds`가 버전이 적힌 HTML 파일 옆에 없으면 일부 그림과 효과음이 나오지 않습니다.

```text
Wayward_Faith/
├─ Wayward_Faith_v버전.html  게임
├─ i18n/                 영어 번역
├─ images/               임신 일지 등 게임에 들어 있는 그림
├─ sounds/               효과음 (소리 포함 zip에만)
├─ image-packs/faith-extra/base/  조연팩 (Faith_Extra zip, 선택)
├─ wayward-imagegen/     이미지 생성 서버 (선택)
├─ start-imagegen.cmd    이미지 생성 서버 실행 (선택)
├─ install-packs.cmd     받은 조연팩·이미지팩 zip 풀기
├─ wml/                  모드 로더 WML과 기본 모드
├─ 모바일로_묶기.cmd      폰 앱으로 옮길 게임 묶음 만들기 (WML)
├─ WML_사용법.txt         WML·폰 앱 사용법
├─ README.md             이 문서
└─ README_EN.md          영어 안내문
```

## 2. 저장

- 게임은 **브라우저 안에 자동으로 저장**됩니다. 같은 브라우저로 다시 열면 이어서 할 수 있습니다.
- 브라우저의 방문 기록이나 사이트 데이터를 지우면 세이브도 함께 지워질 수 있습니다.
- 원작 Wayward와 같은 저장 공간(Local Storage)을 쓰므로, 원작 세이브는 반드시 따로 백업해 두세요.
- 중요한 세이브는 저장 창의 **"현재 데이터 JSON으로 내보내기"** 로 파일을 받아 두세요. **"JSON에서 불러오기…"** 로 되살릴 수 있습니다.

## 3. 소리와 화면 점멸

- 브라우저 정책 때문에 화면을 한 번 클릭하기 전에는 소리가 나지 않을 수 있습니다.
- 효과음은 설정에서 전체 음량과 종류별(음성, 행위, 침대, 사정, 이동, 목욕)로 켜고 끌 수 있습니다.
- 채찍질 같은 일부 장면에서는 화면 전체가 하얗게 번쩍입니다. 광과민성 발작이 걱정되면 시작 화면이나 설정의 **"광과민성 발작 방지"** 에서 끄세요. 끄면 번쩍임 없이 소리만 납니다.

## 4. 이미지 생성 (선택)

이 게임은 장면 그림을 **실시간으로 생성**합니다. 이미지 서버를 켜지 않아도 게임은 텍스트로 끝까지 진행할 수 있습니다.

### 준비물

- **[ComfyUI](https://github.com/comfyanonymous/ComfyUI)** 실행 중일 것, 그리고 쓸 모델(체크포인트, LoRA). NovelAI로만 그린다면 ComfyUI와 커스텀 노드·GPU는 없어도 됩니다(아래 NovelAI 참고).
- **[Bun](https://bun.sh)** 서버 실행용
- ComfyUI 커스텀 노드 세 개. ComfyUI Manager로 설치합니다.
  - ComfyUI Impact Pack (ltdrdata)
  - ComfyUI Inspire Pack (ltdrdata)
  - KJ Nodes for ComfyUI (kijai)
- 모델을 돌릴 만한 GPU

### 실행

1. ComfyUI를 먼저 켭니다.
2. **`start-imagegen.cmd`** 를 더블클릭합니다. 창이 열려 있는 동안 서버가 켜져 있고, 창을 닫으면 꺼집니다.
3. 게임 메뉴의 **이미지 생성 설정**에서 연결 방식을 **자동 찾기**로 두면 서버를 스스로 찾아 "연결됨"이 됩니다.

- ComfyUI 주소가 기본(`http://127.0.0.1:8188`)과 다르면: `start-imagegen.cmd --comfy-url http://주소:포트`
- 8189 포트를 다른 프로그램이 쓰고 있으면: `start-imagegen.cmd --port 9000`으로 띄우고, 이미지 생성 설정에서 **주소 직접 지정**을 고르고 `http://127.0.0.1:9000`을 넣습니다.

### 프리셋과 모델 경로

메뉴의 **이미지 생성 설정 → 이미지 생성 프리셋**에서 체크포인트, 퀄리티 LoRA, Steps, CFG를 묶은 프리셋을 고릅니다. 처음에는 네 가지가 들어 있습니다.

| 프리셋 | 모델 | 특징 |
|---|---|---|
| IL 기본형 | WAI-Illustrious SDXL v17 | 처음 선택된 프리셋. 퀄리티 LoRA 없음 |
| IL Detailed | WAI-Illustrious SDXL v17 | 제작자의 개발 환경. 디테일 LoRA 두 개(ILDetailer V2, Face Detailed v2)를 0.5씩 추가 |
| Anima Turbo | Anima Turbo v1.1 | 10 Steps, CFG 1. 텍스트 인코더와 VAE가 따로 필요 |
| NovelAI | NAI Diffusion V4.5 Full | ComfyUI 없이 NovelAI로 그림. 토큰 필요 (아래) |

**경로를 꼭 확인하세요.** 기본 프리셋은 파일이 ComfyUI 모델 폴더(`models/checkpoints`, `models/loras` 등) **바로 아래**에 있다고 보고 파일 이름만 적혀 있습니다. 하위 폴더에 두셨다면 프리셋을 골라 **수정**을 누르고 `폴더\파일이름.safetensors`처럼 고쳐 주세요. 경로가 맞지 않으면 그림이 생성되지 않습니다.

**새 프리셋 추가**로 원하는 모델을 직접 등록할 수도 있습니다.

### NovelAI

1. NovelAI 웹사이트의 계정 설정에서 **Get Persistent API Token**으로 토큰(`pst-…`)을 받습니다.
2. `start-imagegen.cmd`를 켭니다. NovelAI만 쓴다면 ComfyUI는 켜지 않아도 됩니다.
3. 이미지 생성 프리셋에서 NovelAI 프리셋을 골라 **수정**을 누르거나 **+**로 새 프리셋을 만들고, 모델 유형을 **NovelAI**로 고릅니다. 바로 아래 토큰 칸에 토큰을 넣고 저장합니다. 구독 여부와 남은 Anlas가 표시됩니다.

- 토큰은 `wayward-imagegen/images/.state`에 저장되고 모든 NovelAI 프리셋이 함께 씁니다. 브라우저에는 남지 않습니다.
- 계정이 잠기지 않도록 요청은 10초에 한 번만 보냅니다. 장면이 빨리 바뀌면 아직 보내지 않은 이전 그림 요청은 버립니다.
- Opus 구독이 아니거나 Steps 28·832×1216을 넘으면 그림마다 Anlas가 듭니다.
- 예전 판의 서버 창이 켜져 있으면 NovelAI가 동작하지 않습니다. 창을 닫고 새 판의 `start-imagegen.cmd`로 다시 켜 주세요.
- 예전 판에서 프리셋을 고친 적이 있으면 NovelAI 프리셋이 목록에 없습니다. **+**로 새로 만드세요.

### 그림이 너무 오래 걸린다면

메뉴의 **프롬프트 설정**에서 그림에 반영할 상태(노출, 표정·기분, 취기, 흥분도, 날씨, 계절, 시간대, 정사 후 흔적)를 끌 수 있습니다. 끈 항목은 상태가 달라도 같은 그림을 다시 쓰니, 새 그림을 기다리는 횟수가 줄어듭니다.

생성된 그림은 `wayward-imagegen/images` 아래에 저장되고, 같은 상황이 오면 다시 쓰입니다.

## 5. 문제가 생겼을 때

| 증상 | 확인할 것 |
|---|---|
| 그림이 안 나옴 | ComfyUI와 `start-imagegen.cmd` 창이 둘 다 켜져 있는지, 이미지 생성 설정이 "연결됨"인지, 프리셋의 모델 경로가 맞는지 (NovelAI면 토큰이 저장되어 있는지) |
| 서버 창이 바로 닫힘 | Bun이 설치되어 있는지 |
| 일부 그림·소리만 안 나옴 | `images`, `sounds` 폴더가 버전이 적힌 HTML 파일 옆에 있는지 |
| 소리가 안 남 | 화면을 한 번 클릭했는지, 설정에서 효과음이 켜져 있는지 |

버그나 이상한 문장을 발견하면 배포 글에 달린 제작자 댓글에 대댓글로 남겨 주세요. 어떤 상황에서 생겼는지와 함께, 가능하면 **JSON으로 내보낸 세이브**를 첨부해 주시면 고치기가 훨씬 쉽습니다.

---

## 크레딧

- **원작:** Wayward
- **한국어판:** Wayward-v2026-09-30_ko-v1.4
- **이미지 생성 서버:** wayward-imagegen — sintention (MIT License). 이 게임에 맞게 고친 판이 들어 있습니다(캐릭터 LoRA, 프리셋, Anima 지원, 인물별 저장 폴더, NovelAI 연동). NovelAI 연동은 Wayward EasyGen 모드의 코드를 참고했습니다. 원본 라이선스는 `wayward-imagegen/LICENSE`에 있습니다.
- **모드 로더:** WML (Wayward Mod Loader) — 키모이맨. 제작자의 허락을 받아 Faith에 맞게 고친 판(일시정지 메뉴의 모드 설정)이 들어 있습니다.
- **효과음 모드**, **임신 모드:** 원작 한국어판의 커뮤니티 모드
- **글꼴:** 나눔손글씨 붓 (Nanum Brush Script), La Belle Aurore — Kimberly Geswein (임신 일지의 영문, Google Fonts · SIL Open Font License)
- **이미지:** 모든 이미지 에셋은 AI로 제작했습니다.
- **배경 음악:**
  - 1층 — "Byzantine (loop)" by AVGVSTA (CC-BY 3.0) — https://opengameart.org/content/byzantine-loop
  - 2층 — "Calm Relax 1 (Synthwave 421k)" by The Cynic Project / cynicmusic.com / pixelsphere.org (CC0) — MP3를 OGG로 변환
  - 지하 — "Wendale Abbey" by Yubatake, OpenGameArt (CC-BY 4.0) — https://opengameart.org/content/wendale-abbey
  - 집회 — "Dark Urban Church Theme Loop" by beardalaxy, OpenGameArt (CC0)
  - 마을·골목·헛간 — "Village of The Fallen" by Kaine Carrillo, OpenGameArt (CC-BY 4.0) — WAV를 OGG로 변환
  - 선술집 — "Pirate tavern loop" by Emma_MA, OpenGameArt (CC-BY 4.0) — WAV를 OGG로 변환
  - 비밀 상점 — "Light In The Dark Stem Set" (09_ambiance_loop) — Additional Music By Will Leamon, OpenGameArt (OGA-BY 3.0) — 음량을 키워 OGG로 변환
  - 앞뒤 무음 구간은 게임 안에서 건너뛰며, 곡 자체는 형식 변환(과 표시한 음량 조정) 말고는 고치지 않았습니다.
- **효과음:**
  - 채찍 — "Whip Crack" by SciFiSounds, Freesound (CC0) — https://freesound.org/s/529925/ — OGG로 변환
  - 예배당 종 — "Church-bell 8pm village 140804_01" by klankbeeld, Freesound (CC BY 4.0) — https://freesound.org/s/343419/ — 두 번·여덟 번 울리고 사라지게 잘라 OGG로 변환
- **음성:** 音声素材_Pincree — https://pincree.jp/
  - 성우분이 이 게임을 위해 녹음한 것이 아니라, Pincree가 배포·판매하는 R-18 음성 소재에서 골라 쓴 것입니다. 말투마다 소재 하나를 썼습니다(소재 이름은 그 소재의 캐릭터 이름입니다).
  - 공손함 — Nikomi Ryuzen — 音声素材_Pincree(CV:龍涎にこみ)
  - 소심함 — Marisa Tadai — 音声素材_Pincree(CV:逢坂成美)
  - 당돌함 — Aki Katagiri — 音声素材_Pincree(CV:片桐秋)
  - 쾌활함 — Kino Otosaka — 音声素材_Pincree(CV:いちくら)
  - 음탕함 — Tsubasa Kitakami — 音声素材_Pincree(CV:千夜)
  - 냉정함 — Satsuki Mikami — 音声素材_Pincree(CV:此花瑠璃)
  - 우직함 — Akira Shono — 音声素材_Pincree(CV:鳴宮なる)
  - 여왕님 — Hina Memeno — 音声素材_Pincree(CV:山田じぇみ子)
  - 츤데레 — Shirone Nekono — 音声素材_Pincree(CV:猫乃しろね)
  - 광신도 — Akari Kotone — 音声素材_Pincree(CV:琴音あかり)
