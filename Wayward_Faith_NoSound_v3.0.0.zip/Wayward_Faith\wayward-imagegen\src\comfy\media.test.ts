import { afterEach, describe, expect, it } from 'vitest'
import * as fs from 'node:fs'
import * as os from 'node:os'
import * as path from 'node:path'
import { saveImage } from './media.ts'

const roots: string[] = []
afterEach(() => {
  for (const root of roots.splice(0)) fs.rmSync(root, { recursive: true, force: true })
})

describe('saveImage style folders', () => {
  it('stores a named style as an extra path level', async () => {
    const imagesDir = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-style-'))
    roots.push(imagesDir)
    const saved = await saveImage({
      imagesDir,
      bytes: Buffer.from('png'),
      talentName: 'mara__task-idle__v-0',
      imageType: 'portrait',
      workflow: 'illustrious',
      characters: ['mara'],
      characterId: 'mara',
      presetName: 'IL Detailed',
      styleName: 'Soft Ink',
      now: () => 1,
    })
    expect(saved.relativePath).toMatch(/^il_detailed\/soft_ink\/characters\/mara\//)
  })

  it('uses default when the style name is empty', async () => {
    const imagesDir = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-style-'))
    roots.push(imagesDir)
    const saved = await saveImage({
      imagesDir,
      bytes: Buffer.from('png'),
      talentName: 'mara__task-idle__v-0',
      imageType: 'portrait',
      workflow: 'illustrious',
      characters: ['mara'],
      characterId: 'mara',
      presetName: 'Anima Turbo',
      styleName: '',
      now: () => 1,
    })
    expect(saved.relativePath).toMatch(/^anima_turbo\/default\/characters\/mara\//)
  })

  it('keeps a Korean style preset name as its folder', async () => {
    const imagesDir = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-style-'))
    roots.push(imagesDir)
    const saved = await saveImage({
      imagesDir,
      bytes: Buffer.from('png'),
      talentName: 'roxy__task-idle__v-0',
      imageType: 'portrait',
      workflow: 'illustrious',
      characters: ['roxy'],
      characterId: 'roxy',
      presetName: 'IL 기본형',
      styleName: '수채화',
      now: () => 1,
    })
    expect(saved.relativePath).toMatch(/^il_기본형\/수채화\/characters\/roxy\//)
  })
})
