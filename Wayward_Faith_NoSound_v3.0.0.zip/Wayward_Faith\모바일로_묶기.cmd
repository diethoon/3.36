@echo off
rem Double-click in the game folder: packs the game (html, wml with its mods, picture lists) and the pictures into
rem two files for the WML Player app on a phone. Uses tar.exe, which comes with Windows 10 (1803+) and 11.
rem The work is done by wml\tools\pack-for-mobile.ps1 (run as a file, nothing is pieced together at run time).
rem The same file named with Korean letters prints Korean messages; an ASCII file name prints English.
if not exist "%~dp0wml\tools\pack-for-mobile.ps1" goto missing
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0wml\tools\pack-for-mobile.ps1" "%~f0"
if not defined WML_NOPAUSE pause
exit /b
:missing
echo [ERROR] wml\tools\pack-for-mobile.ps1 was not found. Put this file in the game folder (next to wml) and
echo         copy the whole game package again if the wml folder is incomplete.
if not defined WML_NOPAUSE pause
exit /b 1
