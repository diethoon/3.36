import { test, expect } from 'bun:test'
import * as fs from 'node:fs'
import * as os from 'node:os'
import * as path from 'node:path'
import { resolveConfig } from '../config.ts'
import { CacheStore } from '../cache/cacheStore.ts'
import { OutfitPackWriter } from '../cache/outfitPack.ts'
import { BatchQueue } from './queue.ts'
import type { JobRunner } from '../comfy/jobRunner.ts'
import { derivePromptHash } from '../naming.ts'

test('server packs live at the exact file URL the game loads, migrating existing state-folder originals',()=>{
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'wf-pack-location-'))
  try{
    const game=path.join(root,'game'),server=path.join(game,'wayward-imagegen')
    fs.mkdirSync(server,{recursive:true})
    fs.writeFileSync(path.join(game,'index.html'),'game')
    const config=resolveConfig(['--images-dir',path.join(server,'images'),'--state-dir',path.join(server,'images','.state')],server)
    expect(config.imagePacksDir).toBe(path.join(game,'image-packs'))
    const target={name:'Nezit',character:'elena',outfit:'basic'}
    const item={talentId:'elena__t-i__o-modest__p-bd__v-0',prompt:'habit',outfitPack:target}
    const old=new OutfitPackWriter(config.stateDir,config.imagesDir,target)
    fs.mkdirSync(old.cache.imagesDir,{recursive:true})
    fs.writeFileSync(path.join(old.cache.imagesDir,'original.png'),'original')
    old.record(item.talentId,old.cache.add({talentName:item.talentId,imageType:'portrait',workflow:'illustrious',promptHash:derivePromptHash(item.prompt,'',item),prompt:item.prompt,imagePath:'original.png'}))
    old.flush()
    const queue=new BatchQueue(config,new CacheStore({imagesDir:config.imagesDir}),{} as JobRunner)
    const result=queue.enqueue([item])
    const destination=path.join(game,'image-packs','Nezit-elena', 'base')
    expect(result.packDirectory).toBe(destination)
    expect(result.accepted).toBe(0)
    expect(result.alreadyCached).toBe(1)
    expect(fs.existsSync(path.join(game,'image-packs','Nezit-elena', 'base','pack.js'))).toBe(true)
    expect(fs.readFileSync(path.join(destination,'images','original.png'),'utf8')).toBe('original')
    expect(fs.existsSync(old.directory)).toBe(false)
    const custom=resolveConfig(['--image-packs-dir','custom-packs'],server)
    expect(custom.imagePacksDir).toBe(path.join(server,'custom-packs'))
  }finally{fs.rmSync(root,{recursive:true,force:true})}
})
