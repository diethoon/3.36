import { test, expect } from 'bun:test'
import * as fs from 'node:fs'
import * as os from 'node:os'
import * as path from 'node:path'
import { OutfitPackWriter, validateOutfitPackTarget } from './outfitPack.ts'

// A tailor-made outfit's pack (game: 의상 주문, id wfc_…) carries the outfit's definition,
// so a player who installs the pack gets the outfit too (game: src/faith/image/pack.js wfPackValidate).
test('custom outfit pack writes its definition into pack.js', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-custom-pack-'))
  try {
    const imagesDir = path.join(root, 'source'), out = path.join(root, 'image-packs')
    fs.mkdirSync(imagesDir, { recursive: true })
    fs.writeFileSync(path.join(imagesDir, 'a.png'), 'a')
    const def = { id: 'wfc_abc', rev: 2, name: '붉은 드레스', imageTags: 'red dress', halves: true }
    const writer = new OutfitPackWriter(path.join(root, 'state'), imagesDir, { character: 'elena', outfit: 'wfc_abc', name: 'mine', outfitDef: def }, true, out)
    expect(path.relative(out, writer.directory)).toBe(path.join('mine-elena', 'outfits', 'wfc_abc'))
    writer.add('elena__t-i__o-wfc_abc_r2__p-bd__v-0', { imagePath: 'a.png' })
    writer.flush()
    const source = fs.readFileSync(path.join(writer.directory, 'pack.js'), 'utf8')
    const pack = JSON.parse(source.match(/\]\s*=\s*(\{[\s\S]*\})\s*;?\s*$/)![1])
    expect(pack.wfImagePack.outfits).toEqual(['wfc_abc'])
    expect(pack.wfImagePack.outfitDefs).toEqual({ wfc_abc: def })
  } finally {
    fs.rmSync(root, { recursive: true, force: true })
  }
})

test('outfit definition must be a small plain object', () => {
  const base = { character: 'elena', outfit: 'wfc_abc' }
  expect(() => validateOutfitPackTarget({ ...base, outfitDef: { id: 'wfc_abc' } })).not.toThrow()
  expect(() => validateOutfitPackTarget({ ...base, outfitDef: [] as unknown as Record<string, unknown> })).toThrow()
  expect(() => validateOutfitPackTarget({ ...base, outfitDef: { big: 'x'.repeat(30000) } })).toThrow()
})
