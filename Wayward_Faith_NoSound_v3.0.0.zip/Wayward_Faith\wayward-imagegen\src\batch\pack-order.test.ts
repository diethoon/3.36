import { test, expect } from 'bun:test'
import * as fs from 'node:fs'
import * as os from 'node:os'
import * as path from 'node:path'
import { CacheStore } from '../cache/cacheStore.ts'
import { OutfitPackWriter } from '../cache/outfitPack.ts'
import { BatchQueue } from './queue.ts'
import type { Config } from '../config.ts'
import type { JobRunner } from '../comfy/jobRunner.ts'

// The maker's order (src/faith/image/pack.js wfPackOrder): heavier first across every
// uploaded chunk, and per-pack progress that says when the essential images are in.
test('a chunked pack plan runs in weight order and reports when it can be shared', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-pack-order-'))
  try {
    const stateDir = path.join(root, 'state'), imagesDir = path.join(root, 'global'), imagePacksDir = path.join(root, 'image-packs')
    const target = { character: 'elena', outfit: 'basic', name: 'faith' }
    // One image is already in the pack.
    const writer = new OutfitPackWriter(stateDir, imagesDir, { ...target, presetName: 'IL' }, false, imagePacksDir)
    fs.mkdirSync(path.join(writer.directory, 'images'), { recursive: true })
    fs.writeFileSync(path.join(writer.directory, 'images', 'have.webp'), 'art')
    writer.record('elena__have', { talentName: 'elena__have', imagePath: 'have.webp', imageType: 'portrait', promptHash: 'h', createdAt: 1, prompt: '' })
    writer.flush()
    const queue = new BatchQueue({ stateDir, imagesDir, imagePacksDir } as Config, new CacheStore({ imagesDir }), {} as JobRunner)
    const item = (talentId: string, weight: number, essential = false) => ({ talentId, prompt: 'p', presetName: 'IL', outfitPack: target, weight, ...(essential ? { essential } : {}) })
    const first = queue.enqueue([item('elena__face', 0.5), item('elena__have', 2, true), item('elena__vary', 1)])
    queue.enqueue([item('elena__special', 3.2, true), item('elena__rep', 2, true)], first.jobId)
    const order = fs.readFileSync(path.join(stateDir, 'batch', first.jobId + '.jsonl'), 'utf8').trim().split('\n').map(l => JSON.parse(l).talentId)
    expect(order).toEqual(['elena__special', 'elena__rep', 'elena__vary', 'elena__face'])
    const status = queue.status()
    expect(status.packs).toHaveLength(1)
    expect(status.packs[0]).toMatchObject({ total: 5, done: 1, essentialTotal: 3, essentialDone: 1 })
    expect(status.packs[0].directory).toContain(path.join('faith-elena', 'base'))
    expect(status.essentialEtaSeconds).toBeNull()
  } finally { fs.rmSync(root, { recursive: true, force: true }) }
})
