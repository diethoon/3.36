import { test, expect } from 'bun:test'
import * as fs from 'node:fs'
import * as os from 'node:os'
import * as path from 'node:path'
import { OutfitPackWriter, migratePackFolders, splitModPacks } from './outfitPack.ts'

// 팩 폴더 구조 (사용자 결정 2026-10-26): image-packs/<이름>-<캐릭터>/<base | extension | outfits/<옷> | mods/<모드>>, 조연팩은 <이름>-extra/basic.
// 예전(한 단계) 폴더에 같은 팩이 있으면 새 자리로 옮긴다. 조연팩은 옛 폴더(faith-extra)의 하위 폴더(faith-extra/basic)로 옮긴다.
const write = (dir: string, packId: string, entries: Record<string, { imagePath: string }>, meta: object) => {
  fs.mkdirSync(path.join(dir, 'images'), { recursive: true })
  for (const e of Object.values(entries)) fs.writeFileSync(path.join(dir, e.imagePath), 'x')
  fs.writeFileSync(path.join(dir, 'pack.js'), `/* WAYWARD_FAITH_IMAGE_PACK */
(window.__WF_OUTFIT_PACKS__=window.__WF_OUTFIT_PACKS__||Object.create(null))[${JSON.stringify(packId)}]=${JSON.stringify({ packFormat: 1, packId, entries, wfImagePack: meta })};
`)
}

test('a pack in the old one-level folder moves to <name>-<character>/<kind>', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-pack-layout-'))
  try {
    const state = path.join(root, 'state'), packs = path.join(root, 'image-packs')
    const ids = path.join(state, 'outfit-pack-ids.json')
    fs.mkdirSync(state, { recursive: true })
    const basic = { character: 'elena', outfit: 'basic', name: 'faith' }, dress = { character: 'elena', outfit: 'serving_dress', name: 'faith' }, extra = { character: 'extra', outfit: 'extra', name: 'faith' }
    fs.writeFileSync(ids, JSON.stringify({ [JSON.stringify(['elena', 'basic', '', '', 'faith'])]: 'b1', [JSON.stringify(['elena', 'serving_dress', '', '', 'faith'])]: 'd1', [JSON.stringify(['extra', 'extra', '', '', 'faith'])]: 'x1' }))
    write(path.join(packs, 'faith-elena-basic'), 'b1', { a: { imagePath: 'images/a.webp' } }, { version: 2, character: 'elena', basic: true, outfits: ['modest'] })
    write(path.join(packs, 'faith-elena-serving_dress'), 'd1', { d: { imagePath: 'images/d.webp' } }, { version: 2, character: 'elena', basic: false, outfits: ['serving_dress'] })
    write(path.join(packs, 'faith-extra'), 'x1', { x: { imagePath: 'images/x.webp' } }, { version: 2, character: 'extra', basic: false, extra: true, outfits: [] })
    const b = new OutfitPackWriter(state, path.join(root, 'global'), basic, false, packs)
    const d = new OutfitPackWriter(state, path.join(root, 'global'), dress, false, packs)
    const x = new OutfitPackWriter(state, path.join(root, 'global'), extra, false, packs)
    expect(b.directory).toBe(path.join(packs, 'faith-elena', 'base'))
    expect(d.directory).toBe(path.join(packs, 'faith-elena', 'outfits', 'serving_dress'))
    expect(x.directory).toBe(path.join(packs, 'faith-extra', 'base'))
    for (const [w, img] of [[b, 'a.webp'], [d, 'd.webp'], [x, 'x.webp']] as const) expect(fs.existsSync(path.join(w.directory, 'images', img))).toBe(true)
    expect(fs.existsSync(path.join(packs, 'faith-elena-basic'))).toBe(false)
    expect(fs.existsSync(path.join(packs, 'faith-extra', 'pack.js'))).toBe(false)
    b.flush()
    const saved = fs.readFileSync(path.join(b.directory, 'pack.js'), 'utf8')
    expect(saved).toContain('"folderName":"faith-elena/base"')
  } finally { fs.rmSync(root, { recursive: true, force: true }) }
})

test('the basic pack extra part is its own pack in <name>-<character>/extension', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-pack-ext-'))
  try {
    const packs = path.join(root, 'image-packs'), src = path.join(root, 'global')
    fs.mkdirSync(src, { recursive: true })
    fs.writeFileSync(path.join(src, 'a.png'), 'a')
    const base = new OutfitPackWriter(path.join(root, 'state'), src, { character: 'elena', outfit: 'basic', name: 'faith' }, false, packs)
    const ext = new OutfitPackWriter(path.join(root, 'state'), src, { character: 'elena', outfit: 'basic', name: 'faith', part: 'extension' }, false, packs)
    expect(base.directory).toBe(path.join(packs, 'faith-elena', 'base'))
    expect(ext.directory).toBe(path.join(packs, 'faith-elena', 'extension'))
    expect(ext.packId).not.toBe(base.packId)
    ext.add('elena__t-i__o-modest__p-bd__v-1', { imagePath: 'a.png' })
    ext.flush()
    const js = fs.readFileSync(path.join(ext.directory, 'pack.js'), 'utf8')
    expect(js).toContain('"part":"extension"')
    expect(js).toContain('"folderName":"faith-elena/extension"')
    expect(() => new OutfitPackWriter(path.join(root, 'state'), src, { character: 'elena', outfit: 'serving_dress', name: 'faith', part: 'extension' }, false, packs)).toThrow()
  } finally { fs.rmSync(root, { recursive: true, force: true }) }
})

test('server start moves every old one-level pack folder (migratePackFolders)', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-pack-migrate-'))
  try {
    const packs = path.join(root, 'image-packs')
    write(path.join(packs, 'faith-elena-basic'), 'b1', { a: { imagePath: 'images/a.webp' } }, { version: 2, character: 'elena', basic: true, outfits: ['modest'] })
    write(path.join(packs, 'faith-elena-serving_dress'), 'd1', { d: { imagePath: 'images/d.webp' } }, { version: 2, character: 'elena', basic: false, outfits: ['serving_dress'] })
    write(path.join(packs, 'faith-extra'), 'x1', { x: { imagePath: 'images/x.webp' } }, { version: 2, character: 'extra', basic: false, extra: true, outfits: [] })
    // install-packs.cmd가 이름이 겹쳐 번호를 붙인 폴더: 예전 규칙이 아니면 pack.js의 name을 쓴다
    write(path.join(packs, 'mine-2'), 'm1', { m: { imagePath: 'images/m.webp' } }, { version: 2, character: 'mara', basic: true, outfits: ['modest'] })
    fs.writeFileSync(path.join(packs, 'mine-2', 'pack.js'), fs.readFileSync(path.join(packs, 'mine-2', 'pack.js'), 'utf8').replace('"packFormat":1', '"packFormat":1,"name":"mine"'))
    // 이미 새 자리에 있는 팩은 그대로
    write(path.join(packs, 'faith-pippa', 'base'), 'p1', { p: { imagePath: 'images/p.webp' } }, { version: 2, character: 'pippa', basic: true, outfits: ['modest'] })
    const moved = migratePackFolders(packs).map(([a, b]) => [path.basename(a), path.relative(packs, b)])
    expect(moved.sort()).toEqual([
      ['faith-elena-basic', path.join('faith-elena', 'base')],
      ['faith-elena-serving_dress', path.join('faith-elena', 'outfits', 'serving_dress')],
      ['faith-extra', path.join('faith-extra', 'base')],
      ['mine-2', path.join('mine-mara', 'base')],
    ].sort())
    expect(fs.existsSync(path.join(packs, 'faith-elena', 'base', 'images', 'a.webp'))).toBe(true)
    expect(fs.existsSync(path.join(packs, 'faith-extra', 'base', 'images', 'x.webp'))).toBe(true)
    expect(fs.existsSync(path.join(packs, 'faith-pippa', 'base', 'pack.js'))).toBe(true)
    expect(migratePackFolders(packs)).toEqual([]) // 두 번째는 할 일이 없다
  } finally { fs.rmSync(root, { recursive: true, force: true }) }
})

test('mod scenes leave the basic pack for <name>-<character>/mods/<id> (splitModPacks)', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-pack-mod-'))
  try {
    const packs = path.join(root, 'image-packs'), mods = path.join(root, 'wml', 'mods')
    fs.mkdirSync(path.join(mods, 'faith-divine-beast'), { recursive: true })
    fs.writeFileSync(path.join(mods, 'faith-divine-beast', 'pack-keys.json'), JSON.stringify({ id: 'faith-divine-beast', scenes: ['wfb_wolf_0', 'wf_birth_wolf'] }))
    const meta = { version: 2, character: 'elena', basic: true, outfits: ['modest', 'naked'] }
    write(path.join(packs, 'faith-elena', 'base'), 'eb', {
      'elena__t-i__o-modest__p-bd__v-0': { imagePath: 'images/a.webp' },
      'elena__s-wfb_wolf_0__o-naked__p-pr__v-0': { imagePath: 'images/w.webp' },
      'elena__s-wf_birth_human__o-nightshift__p-bd__v-0': { imagePath: 'images/h.webp' },
    }, meta)
    write(path.join(packs, 'faith-elena', 'extension'), 'ee', { 'elena__s-wf_birth_wolf__o-nightshift__p-bd__v-0': { imagePath: 'images/b.webp' } }, { ...meta, part: 'extension' })
    const moved = splitModPacks(packs, mods)
    expect(moved).toEqual({ 'faith-elena/mods/faith-divine-beast': 2 })
    const read = (dir: string) => JSON.parse(fs.readFileSync(path.join(dir, 'pack.js'), 'utf8').match(/\]\s*=\s*(\{[\s\S]*\})\s*;?\s*$/)![1])
    const base = read(path.join(packs, 'faith-elena', 'base')), mod = read(path.join(packs, 'faith-elena', 'mods', 'faith-divine-beast'))
    expect(Object.keys(base.entries).sort()).toEqual(['elena__s-wf_birth_human__o-nightshift__p-bd__v-0', 'elena__t-i__o-modest__p-bd__v-0'])
    expect(Object.keys(mod.entries).sort()).toEqual(['elena__s-wf_birth_wolf__o-nightshift__p-bd__v-0', 'elena__s-wfb_wolf_0__o-naked__p-pr__v-0'])
    expect(mod.wfImagePack).toMatchObject({ character: 'elena', basic: true, part: 'mod', mod: 'faith-divine-beast' })
    expect(base.entryCount).toBe(2)
    expect(fs.existsSync(path.join(packs, 'faith-elena', 'mods', 'faith-divine-beast', 'images', 'w.webp'))).toBe(true)
    expect(fs.existsSync(path.join(packs, 'faith-elena', 'base', 'images', 'w.webp'))).toBe(false)
    expect(splitModPacks(packs, mods)).toEqual({}) // 두 번째는 할 일이 없다
    // 그 뒤 제작은 같은 폴더의 팩을 이어 쓴다
    const writer = new OutfitPackWriter(path.join(root, 'state'), path.join(root, 'global'), { character: 'elena', outfit: 'basic', name: 'faith', part: 'mod', mod: 'faith-divine-beast' }, false, packs)
    expect(writer.directory).toBe(path.join(packs, 'faith-elena', 'mods', 'faith-divine-beast'))
    expect(writer.packId).toBe(mod.packId)
    expect(() => new OutfitPackWriter(path.join(root, 'state'), path.join(root, 'global'), { character: 'elena', outfit: 'basic', name: 'faith', part: 'mod' }, false, packs)).toThrow()
  } finally { fs.rmSync(root, { recursive: true, force: true }) }
})

test('the session-mid layout (<character>/outfit-*, mod-*) moves to outfits/ and mods/', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-pack-mid-'))
  try {
    const packs = path.join(root, 'image-packs')
    write(path.join(packs, 'faith-elena', 'outfit-serving_dress'), 'd1', { d: { imagePath: 'images/d.webp' } }, { version: 2, character: 'elena', basic: false, outfits: ['serving_dress'] })
    write(path.join(packs, 'faith-elena', 'mod-faith-divine-beast'), 'm1', { m: { imagePath: 'images/m.webp' } }, { version: 2, character: 'elena', basic: true, part: 'mod', mod: 'faith-divine-beast', outfits: [] })
    const moved = migratePackFolders(packs).map(([a, b]) => [path.relative(packs, a), path.relative(packs, b)])
    expect(moved.sort()).toEqual([
      [path.join('faith-elena', 'mod-faith-divine-beast'), path.join('faith-elena', 'mods', 'faith-divine-beast')],
      [path.join('faith-elena', 'outfit-serving_dress'), path.join('faith-elena', 'outfits', 'serving_dress')],
    ].sort())
    expect(fs.existsSync(path.join(packs, 'faith-elena', 'mods', 'faith-divine-beast', 'images', 'm.webp'))).toBe(true)
    expect(fs.existsSync(path.join(packs, 'faith-elena', 'outfits', 'serving_dress', 'pack.js'))).toBe(true)
    expect(migratePackFolders(packs)).toEqual([])
  } finally { fs.rmSync(root, { recursive: true, force: true }) }
})

test('pack-keys renames move an old key into the mod pack under its new scene (splitModPacks)', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-pack-rename-'))
  try {
    const packs = path.join(root, 'image-packs'), mods = path.join(root, 'wml', 'mods')
    fs.mkdirSync(path.join(mods, 'faith-scat'), { recursive: true })
    fs.writeFileSync(path.join(mods, 'faith-scat', 'pack-keys.json'), JSON.stringify({ id: 'faith-scat', scenes: ['wf_toilet_pee_up'],
      renames: [{ from: { scene: 'wfo_leash', variant: 5 }, to: { scene: 'wfo_leash_relieve', variant: 0 } }] }))
    write(path.join(packs, 'faith-elena', 'base'), 'eb', {
      'elena__s-wfo_leash__o-naked__p-vl__v-4': { imagePath: 'images/l4.webp' },
      'elena__s-wfo_leash__o-naked__p-vl__v-5': { imagePath: 'images/l5.webp' },
      'elena__s-wf_toilet_pee_up__o-modest__p-bt__v-0': { imagePath: 'images/u.webp' },
    }, { version: 2, character: 'elena', basic: true, outfits: ['modest', 'naked'] })
    expect(splitModPacks(packs, mods)).toEqual({ 'faith-elena/mods/faith-scat': 2 })
    const read = (dir: string) => JSON.parse(fs.readFileSync(path.join(dir, 'pack.js'), 'utf8').match(/\]\s*=\s*(\{[\s\S]*\})\s*;?\s*$/)![1])
    const base = read(path.join(packs, 'faith-elena', 'base')), mod = read(path.join(packs, 'faith-elena', 'mods', 'faith-scat'))
    expect(Object.keys(base.entries)).toEqual(['elena__s-wfo_leash__o-naked__p-vl__v-4'])
    expect(Object.keys(mod.entries).sort()).toEqual(['elena__s-wf_toilet_pee_up__o-modest__p-bt__v-0', 'elena__s-wfo_leash_relieve__o-naked__p-vl__v-0'])
    expect(mod.entries['elena__s-wfo_leash_relieve__o-naked__p-vl__v-0']).toMatchObject({ imagePath: 'images/l5.webp', talentName: 'elena__s-wfo_leash_relieve__o-naked__p-vl__v-0' })
    expect(fs.existsSync(path.join(packs, 'faith-elena', 'mods', 'faith-scat', 'images', 'l5.webp'))).toBe(true)
  } finally { fs.rmSync(root, { recursive: true, force: true }) }
})
