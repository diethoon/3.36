@echo off
rem Installs the separately downloaded packs into this game folder.
rem Put the zips next to this file and run it:
rem   Faith_Sound_v*.zip or Faith_Sound_Full_v*.zip (sounds), Faith_Extra_v*.zip (supporting-cast pack), Faith_Mods_v*.zip (mods: divine beast offering, scat),
rem   and image packs (basic / outfit packs: any zip holding a pack.js that starts with /* WAYWARD_FAITH_IMAGE_PACK */).
rem Faith_* zips hold Wayward_Faith\... paths; their contents go into this folder.
rem An image pack is recognised by its pack.js, never by the zip's name, and goes into image-packs\<maker>-<character>\<kind>\
rem   (kind: base = basic pack, extension = the basic pack's optional part, outfits\<outfit> = outfit pack, mods\<mod> = mod pack; the cast pack is <maker>-extra\base):
rem   the folder that already holds the same pack (same packId) - an update - or else that new place, with -2, -3 ... on the kind if another pack uses it.
rem Image packs still in the old one-level folders (image-packs\<maker>-<character>-<kind>) are moved to the new places first.
rem If one Faith_* pack has several versions here, the newest is used. Faith_Sound_Full already holds everything in Faith_Sound,
rem so when both are here only Faith_Sound_Full is installed. The zips are left as they are.
title Wayward Faith - install packs
set "WF_SELF=%~f0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s = [IO.File]::ReadAllText($env:WF_SELF); Invoke-Expression $s.Substring($s.LastIndexOf('#PS' + 'START'))"
echo.
pause
exit /b

#PSSTART
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$dir = Split-Path -Parent $env:WF_SELF
$found = 0
function Get-PackVersion([string]$name, [string]$prefix) {
    $parts = @(($name.Substring($prefix.Length + 2) -replace '\.zip$', '').Split('.') | ForEach-Object { [int]$_ })
    while ($parts.Count -lt 4) { $parts += 0 }
    return [version]::new($parts[0], $parts[1], $parts[2], $parts[3])
}
function Get-PackZips([string]$prefix) {
    $pattern = '^' + $prefix + '_v[0-9]+(\.[0-9]+)*\.zip$'
    return @(Get-ChildItem -LiteralPath $dir -File | Where-Object { $_.Name -match $pattern } | Sort-Object { Get-PackVersion $_.Name $prefix })
}
$hasFull = (Get-PackZips 'Faith_Sound_Full').Count -gt 0
foreach ($prefix in 'Faith_Sound', 'Faith_Sound_Full', 'Faith_Extra', 'Faith_Mods') {
    $zips = Get-PackZips $prefix
    if (-not $zips.Count) { continue }
    $zip = $zips[-1]
    if ($prefix -eq 'Faith_Sound' -and $hasFull) { Write-Host "Skipping $($zip.Name) (Faith_Sound_Full includes it)."; continue }
    $found++
    Write-Host "Installing $($zip.Name) ..."
    $tmp = Join-Path ([IO.Path]::GetTempPath()) ('wf-pack-' + [guid]::NewGuid().ToString('N'))
    try {
        [IO.Compression.ZipFile]::ExtractToDirectory($zip.FullName, $tmp)
        $from = Join-Path $tmp 'Wayward_Faith'
        if (-not (Test-Path -LiteralPath $from)) { $from = $tmp }
        Get-ChildItem -LiteralPath $from -Force | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $dir -Recurse -Force }
        Write-Host '  done.'
    } catch {
        Write-Host "  failed: $($_.Exception.Message)"
    } finally {
        if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Recurse -Force }
    }
}

# Image packs (basic / outfit packs). Any other zip here that holds an image-pack pack.js.
$marker = '/* WAYWARD_FAITH_IMAGE_PACK */'
$packsDir = Join-Path $dir 'image-packs'
$installedPacks = 0
# The pack's own id, from the top of its pack.js: (window.__WF_OUTFIT_PACKS__=...)["<packId>"]=
function Get-PackIdFromHead([string]$text) {
    if ($text -match '\)\["((?:[^"\\]|\\.)*)"\]\s*=') { return $Matches[1] }
    return $null
}
# Installed packs: folder (relative to image-packs, one or two levels) -> packId
function Get-InstalledPackIds {
    $ids = @{}
    if (-not (Test-Path -LiteralPath $packsDir)) { return $ids }
    $level2 = @(Get-ChildItem -LiteralPath $packsDir -Directory | ForEach-Object { Get-ChildItem -LiteralPath $_.FullName -Directory })
    $dirs = @(Get-ChildItem -LiteralPath $packsDir -Directory) + $level2 + @($level2 | ForEach-Object { Get-ChildItem -LiteralPath $_.FullName -Directory })
    foreach ($d in $dirs) {
        $js = Join-Path $d.FullName 'pack.js'
        if (-not (Test-Path -LiteralPath $js)) { continue }
        $reader = New-Object IO.StreamReader($js)
        try { $buf = New-Object char[] 2048; $n = $reader.Read($buf, 0, 2048); $head = New-Object string($buf, 0, $n) } finally { $reader.Dispose() }
        $id = Get-PackIdFromHead $head
        if ($id) { $ids[$d.FullName.Substring($packsDir.Length + 1)] = $id }
    }
    return $ids
}
# What a pack is, from its pack.js text (no JSON parse: Windows PowerShell cannot read JSON over 2 MB).
# Its new place: <prefix>-<who>\<kind>. prefix: the old folder name without its old tail (-<character>-<kind>, -extra), or else the pack name.
function Get-PackPlace([string]$text, [string]$oldFolder) {
    $i = $text.LastIndexOf('"wfImagePack":')
    if ($i -lt 0) { return $null }
    $m = $text.Substring($i)
    if ($m -notmatch '"character":"([^"]*)"') { return $null }
    $character = $Matches[1]
    $extra = $m -match '"extra":true'
    $basic = $m -match '"basic":true'
    $part = $m -match '"part":"extension"'
    $mod = ''
    if ($m -match '"part":"mod"' -and $m -match '"mod":"([a-z][a-z0-9._-]*)"') { $mod = $Matches[1] }
    $outfit = ''
    if ($m -match '"outfits":\[\s*"([^"]*)"') { $outfit = $Matches[1] }
    $name = ''
    if ($text -match '"name":"((?:[^"\\]|\\.)*)"') { $name = $Matches[1] }
    if ($extra) { $who = 'extra'; $kind = 'base'; $tail = '-extra' }
    elseif ($mod) { $who = $character; $kind = "mods\$mod"; $tail = "-$character-basic" }
    elseif ($basic) { $who = $character; $kind = 'base'; if ($part) { $kind = 'extension' }; $tail = "-$character-basic" }
    elseif ($outfit) { $who = $character; $kind = "outfits\$outfit"; $tail = "-$character-$outfit" }
    else { return $null }
    $prefix = $name
    if ($oldFolder -and $oldFolder.EndsWith($tail) -and $oldFolder.Length -gt $tail.Length) { $prefix = $oldFolder.Substring(0, $oldFolder.Length - $tail.Length) }
    if (-not $prefix) { $prefix = $oldFolder }
    if (-not $prefix -or $prefix -notmatch '^[^<>:"/\\|?*]+$' -or $prefix -match '^\.+$') { return $null }
    return [pscustomobject]@{ parent = "$prefix-$who"; kind = $kind }
}
function Set-PackFolderName([string]$js, [string]$rel) {
    $text = [IO.File]::ReadAllText($js)
    $new = ([regex]'"folderName":"[^"]*"').Replace($text, ('"folderName":"' + ($rel -replace '\\', '/') + '"'), 1)
    if ($new -ne $text) { [IO.File]::WriteAllText($js, $new, (New-Object Text.UTF8Encoding($false))) }
}
# Old one-level pack folders -> image-packs\<prefix>-<who>\<kind>. The same pack already at the new place takes the old folder's files.
function Move-OldPackFolders {
    if (-not (Test-Path -LiteralPath $packsDir)) { return }
    # Old one-level folders, and the short-lived <maker>-<character>\outfit-*, mod-* folders (now outfits\*, mods\*)
    $mids = @(Get-ChildItem -LiteralPath $packsDir -Directory | ForEach-Object { Get-ChildItem -LiteralPath $_.FullName -Directory | Where-Object { $_.Name -match '^(outfit|mod)-' } })
    foreach ($d in @(Get-ChildItem -LiteralPath $packsDir -Directory) + $mids) {
        $js = Join-Path $d.FullName 'pack.js'
        if (-not (Test-Path -LiteralPath $js)) { continue }
        try {
            $text = [IO.File]::ReadAllText($js)
            $place = Get-PackPlace $text $d.Name
            if (-not $place) { continue }
            if ($d.Parent.FullName -ne $packsDir) { $place.parent = $d.Parent.Name } # a mid folder stays in its own <maker>-<character>
            $rel = Join-Path $place.parent $place.kind
            $to = Join-Path $packsDir $rel
            if ($to -eq $d.FullName) { continue }
            $toJs = Join-Path $to 'pack.js'
            if (Test-Path -LiteralPath $toJs) {
                $there = [IO.File]::ReadAllText($toJs)
                if ((Get-PackIdFromHead $there) -ne (Get-PackIdFromHead $text)) { Write-Host "  kept $($d.Name): $rel holds another pack."; continue }
                # The same pack (an old zip unpacked over a moved one): its files go into the new place
                $img = Join-Path $d.FullName 'images'
                if (Test-Path -LiteralPath $img) {
                    New-Item -ItemType Directory -Path (Join-Path $to 'images') -Force | Out-Null
                    Get-ChildItem -LiteralPath $img -Force | ForEach-Object { Move-Item -LiteralPath $_.FullName -Destination (Join-Path $to 'images') -Force }
                    Remove-Item -LiteralPath $img -Recurse -Force
                }
                Move-Item -LiteralPath $js -Destination $toJs -Force
                Set-PackFolderName $toJs $rel
                if (-not @(Get-ChildItem -LiteralPath $d.FullName -Force).Count) { Remove-Item -LiteralPath $d.FullName -Force }
                Write-Host "  merged $($d.Name) into $rel"
                continue
            }
            if ($to.StartsWith($d.FullName + '\')) {
                # The new place is inside the old folder (faith-extra -> faith-extra\base): through a temporary name
                $tmp = $d.FullName + '.moving'
                Rename-Item -LiteralPath $d.FullName -NewName (Split-Path -Leaf $tmp)
                New-Item -ItemType Directory -Path (Split-Path -Parent $to) -Force | Out-Null
                Move-Item -LiteralPath $tmp -Destination $to
            } else {
                if (Test-Path -LiteralPath $to) { Remove-Item -LiteralPath $to -Recurse -Force } # an empty place
                New-Item -ItemType Directory -Path (Split-Path -Parent $to) -Force | Out-Null
                try { Move-Item -LiteralPath $d.FullName -Destination $to -ErrorAction Stop }
                catch {
                    # Only the folder itself is held (an Explorer window on it ...): move what is inside, pack.js last, and leave the empty folder
                    New-Item -ItemType Directory -Path $to -Force | Out-Null
                    Get-ChildItem -LiteralPath $d.FullName -Force | Where-Object { $_.Name -ne 'pack.js' } | ForEach-Object { Move-Item -LiteralPath $_.FullName -Destination $to -ErrorAction Stop }
                    Move-Item -LiteralPath $js -Destination $toJs -ErrorAction Stop
                    try { Remove-Item -LiteralPath $d.FullName -Force -ErrorAction Stop } catch { }
                }
            }
            Set-PackFolderName $toJs $rel
            Write-Host "  moved $($d.Name) to $rel"
        } catch {
            Write-Host "  could not move $($d.Name): $($_.Exception.Message)"
        }
    }
}
Move-OldPackFolders
$others = @(Get-ChildItem -LiteralPath $dir -File -Filter '*.zip' | Where-Object { $_.Name -notmatch '^(Faith_Sound|Faith_Sound_Full|Faith_Extra|Faith_Mods|Wayward_Faith|Wayward_Faith_AIO)_v[0-9.]+\.zip$' })
foreach ($zipFile in $others) {
    $zip = $null
    try {
        $zip = [IO.Compression.ZipFile]::OpenRead($zipFile.FullName)
        $roots = @()
        foreach ($entry in $zip.Entries) {
            $p = $entry.FullName -replace '\\', '/'
            if ($entry.Name -ne 'pack.js') { continue }
            $reader = New-Object IO.StreamReader($entry.Open())
            try { $all = $reader.ReadToEnd() } finally { $reader.Dispose() }
            if ($all.TrimStart().StartsWith($marker)) { $roots += [pscustomobject]@{ root = $p.Substring(0, $p.Length - 'pack.js'.Length); id = (Get-PackIdFromHead $all); text = $all } }
        }
        if (-not $roots.Count) { continue }
        foreach ($pack in $roots) {
            $root = $pack.root
            if (-not $pack.id) { Write-Host "Skipping a pack in $($zipFile.Name): its pack.js has no pack id."; continue }
            $installed = Get-InstalledPackIds
            # The same pack already here (same packId): update that folder
            $folder = @($installed.Keys | Where-Object { $installed[$_] -eq $pack.id }) | Select-Object -First 1
            if (-not $folder) {
                # The new place <maker>-<character>\<kind>. A zip in the new layout holds ...\<maker>-<character>\<kind>\pack.js, an old one ...\<maker>-<character>-<kind>\pack.js
                $segs = @($root.TrimEnd('/') -split '/' | Where-Object { $_ })
                $old = [IO.Path]::GetFileNameWithoutExtension($zipFile.Name)
                if ($segs.Count) { $old = $segs[-1] }
                $place = Get-PackPlace $pack.text $old
                if (-not $place) { Write-Host "Skipping a pack in $($zipFile.Name): could not tell what kind of pack it is."; continue }
                $kseg = @($place.kind -split '\\')
                if ($segs.Count -gt $kseg.Count -and ($segs[($segs.Count - $kseg.Count)..($segs.Count - 1)] -join '\') -eq $place.kind) {
                    $up = $segs[$segs.Count - $kseg.Count - 1]
                    if ($up -match '^[^<>:"/\\|?*]+$' -and $up -notmatch '^\.+$') { $place.parent = $up }
                }
                # Another pack uses that place: never overwrite it
                $folder = Join-Path $place.parent $place.kind; $k = 2
                while (Test-Path -LiteralPath (Join-Path (Join-Path $packsDir $folder) 'pack.js')) { $folder = Join-Path $place.parent "$($place.kind)-$k"; $k++ }
            }
            $target = Join-Path $packsDir $folder
            Write-Host "Installing image pack $folder from $($zipFile.Name) ..."
            $count = 0
            foreach ($entry in $zip.Entries) {
                $p = $entry.FullName -replace '\\', '/'
                if (-not $p.StartsWith($root) -or $p.EndsWith('/') -or $entry.Name -eq '.image-cache.json') { continue }
                $rel = $p.Substring($root.Length)
                if ($rel -match '(^|/)\.\.(/|$)' -or $rel.StartsWith('/')) { continue }
                $dest = Join-Path $target ($rel -replace '/', '\')
                New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force | Out-Null
                [IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $dest, $true)
                $count++
            }
            Set-PackFolderName (Join-Path $target 'pack.js') $folder
            Write-Host "  done ($count files)."
            $installedPacks++
            $found++
        }
    } catch {
        Write-Host "  failed ($($zipFile.Name)): $($_.Exception.Message)"
    } finally {
        if ($zip) { $zip.Dispose() }
    }
}

if (-not $found) { Write-Host 'No pack zips found next to this file (Faith_Sound / Faith_Sound_Full / Faith_Extra / Faith_Mods zips, or image pack zips).' }
else {
    if ($installedPacks) { Write-Host 'Image packs: in the game, open the image pack settings and choose the image-packs folder to register them.' }
    Write-Host 'Finished. Open the Wayward_Faith_v*.html file to play.'
}
