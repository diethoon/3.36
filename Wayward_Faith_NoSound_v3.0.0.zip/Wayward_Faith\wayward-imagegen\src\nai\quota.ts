/**
 * NovelAI subscription and Anlas, for the meter in the game's settings.
 * Adapted from Wayward EasyGen (nai/quota.ts).
 */

const SUBSCRIPTION_ENDPOINT = 'https://image.novelai.net/user/subscription'

interface SubscriptionResponse {
  active?: boolean
  tier?: number
  expiresAt?: number
  trainingStepsLeft?: { fixedTrainingStepsLeft?: number; purchasedTrainingSteps?: number }
}

export interface NovelAIQuota {
  configured: boolean
  active: boolean
  /** 0 Paper, 1 Tablet, 2 Scroll, 3 Opus. Opus renders normal sizes for free. */
  tier: number | null
  anlas: { subscription: number; purchased: number; total: number } | null
  expiresAt: number | null
  checkedAt: number
}

let cached: { token: string; expires: number; value: NovelAIQuota } | null = null

export async function getNovelAIQuota(token: string, force = false, fetchImpl: typeof fetch = fetch): Promise<NovelAIQuota> {
  const t = token.trim()
  if (!t) return { configured: false, active: false, tier: null, anlas: null, expiresAt: null, checkedAt: Date.now() }
  if (!force && cached && cached.token === t && cached.expires > Date.now()) return cached.value

  const response = await fetchImpl(SUBSCRIPTION_ENDPOINT, {
    headers: { Authorization: `Bearer ${t}`, Accept: 'application/json' },
    signal: AbortSignal.timeout(10_000),
  })
  if (!response.ok) {
    const detail = (await response.text()).slice(0, 300)
    throw new Error(`NovelAI subscription lookup failed (${response.status}): ${detail || response.statusText}`)
  }
  const s = (await response.json()) as SubscriptionResponse
  const subscription = Math.max(0, Number(s.trainingStepsLeft?.fixedTrainingStepsLeft) || 0)
  const purchased = Math.max(0, Number(s.trainingStepsLeft?.purchasedTrainingSteps) || 0)
  const value: NovelAIQuota = {
    configured: true,
    active: s.active === true,
    tier: Number.isFinite(Number(s.tier)) ? Number(s.tier) : null,
    anlas: { subscription, purchased, total: subscription + purchased },
    expiresAt: Number.isFinite(Number(s.expiresAt)) ? Number(s.expiresAt) : null,
    checkedAt: Date.now(),
  }
  cached = { token: t, expires: Date.now() + 4_000, value }
  return value
}
