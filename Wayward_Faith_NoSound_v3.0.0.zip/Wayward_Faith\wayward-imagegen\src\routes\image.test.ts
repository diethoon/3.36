import { describe, expect, test } from 'bun:test'
import { folderName, naiSize } from './image.ts'

describe('folderName', () => {
  // The refresh button drops entries of the selected preset/style. Migrated
  // entries store the sanitized folder name, new ones the raw name.
  test('raw and sanitized names land in the same folder', () => {
    expect(folderName('IL 기본형')).toBe(folderName('il_기본형'))
    expect(folderName('Anima Turbo')).toBe('anima_turbo')
  })
  test('missing or blank names are default', () => {
    expect(folderName(undefined)).toBe('default')
    expect(folderName('  ')).toBe('default')
  })
})

describe('naiSize', () => {
  // ComfyUI inverts the landscape preset, so NovelAI must draw the same portrait.
  test('the long side is the height, like the inverted ComfyUI preset', () => {
    expect(naiSize({ width: 1216, height: 832 })).toEqual({ width: 832, height: 1216 })
    expect(naiSize({ width: 832, height: 1216 })).toEqual({ width: 832, height: 1216 })
    expect(naiSize({})).toEqual({ width: 832, height: 1216 })
  })
})
