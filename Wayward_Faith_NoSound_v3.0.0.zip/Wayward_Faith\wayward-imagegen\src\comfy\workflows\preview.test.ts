import { describe, expect, test } from 'bun:test'
import { buildComfyPrompt } from './index.ts'
import { isOwnQueueEntry, workflowSaveImagePrefix } from '../client.ts'
import type { Config } from '../../config.ts'

// Renders end in PreviewImage (ComfyUI's temp folder) so ComfyUI's output folder
// does not keep a second copy of every picture this server already saves.
const config = { checkpoint: 'model.safetensors', steps: 20, cfg: 7, sampler: 'euler', scheduler: 'normal', detailerLora: '', faceDetailerLora: '', detailerLoraStrength: 0, faceDetailerLoraStrength: 0 } as unknown as Config

describe('output node', () => {
  for (const modelType of ['illustrious', 'anima'] as const) {
    test(`${modelType} graph has no SaveImage and one PreviewImage carrying our prefix`, () => {
      const graph = buildComfyPrompt(config, '1girl', 'lowres', 'elena_portrait', 'illustrious', 1, { modelType }) as Record<string, any>
      const nodes = Object.values(graph)
      expect(nodes.some(n => n.class_type === 'SaveImage')).toBe(false)
      const previews = nodes.filter(n => n.class_type === 'PreviewImage')
      expect(previews.length).toBe(1)
      expect(previews[0].inputs.filename_prefix).toBeUndefined()
      expect(workflowSaveImagePrefix(graph)).toBe('elena_portrait')
      // the cancel path still recognises our queued prompts, and only ours
      expect(isOwnQueueEntry([1, 'id', graph] as any)).toBe(true)
    })
  }
  test('a hand-made graph is not ours', () => {
    const graph = { '1': { class_type: 'PreviewImage', inputs: { images: ['2', 0] }, _meta: { title: 'Preview Image' } } }
    expect(isOwnQueueEntry([1, 'id', graph] as any)).toBe(false)
    expect(workflowSaveImagePrefix({ '1': { class_type: 'SaveImage', inputs: { filename_prefix: 'mara_portrait' } } })).toBe('mara_portrait')
  })
})
