import { afterEach, describe, expect, test } from 'bun:test'
import * as fs from 'node:fs'
import * as os from 'node:os'
import * as path from 'node:path'
import { toNaiPrompt } from './client.ts'
import { readNaiToken, writeNaiToken } from './token.ts'
import { JobRunner } from '../comfy/jobRunner.ts'
import type { Config } from '../config.ts'

describe('toNaiPrompt', () => {
  test('SD weights become NovelAI weights, escaped parentheses plain', () => {
    expect(toNaiPrompt('1girl, (smile:1.2), (blush:1), kisaragi chihaya \\(idolmaster\\)')).toBe(
      '1girl, 1.2::smile ::, blush, kisaragi chihaya (idolmaster)',
    )
  })
  test('a tag ending in a digit keeps a space before the closing ::', () => {
    expect(toNaiPrompt('(8d2suga9:1.2)')).toBe('1.2::8d2suga9 ::')
  })
})

describe('token store', () => {
  test('write, read, clear', () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'nai-'))
    expect(readNaiToken(dir)).toBe('')
    writeNaiToken(dir, ' pst-abc ')
    expect(readNaiToken(dir)).toBe('pst-abc')
    writeNaiToken(dir, '')
    expect(readNaiToken(dir)).toBe('')
  })
})

describe('NovelAI jobs', () => {
  const realFetch = globalThis.fetch
  afterEach(() => { globalThis.fetch = realFetch })

  function setup(intervalMs: number) {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'nai-jobs-'))
    writeNaiToken(path.join(dir, '.state'), 'pst-test')
    const calls: { at: number; body: any }[] = []
    globalThis.fetch = (async (_url: string, init: RequestInit) => {
      calls.push({ at: Date.now(), body: JSON.parse(String(init.body)) })
      // 1x1 PNG, as NovelAI's JSON response form
      const png = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=='
      return new Response(JSON.stringify({ images: [{ image: png, seed: 1 }] }), { headers: { 'content-type': 'application/json' } })
    }) as typeof fetch
    const added: unknown[] = []
    const config = { imagesDir: dir, stateDir: path.join(dir, '.state'), characterDirs: [], webp: false, pollIntervalMs: 1000 } as unknown as Config
    const comfy = { submit: () => { throw new Error('ComfyUI must not be used') }, pendingIds: async () => ({ all: new Set(), ours: [] }) } as any
    const cache = { imagesDir: dir, add: (e: unknown) => added.push(e) } as any
    const jobs = new JobRunner({ config, comfy, cache, naiIntervalMs: intervalMs })
    const submit = (hash: string, bulk = false) =>
      jobs.submit({
        talentId: 'elena', talentName: 'elena', imageType: 'portrait', prompt: '1girl, (smile:1.2)', negativePrompt: 'lowres',
        workflow: 'illustrious', promptHash: hash, bulk,
        overrides: { modelType: 'nai', checkpoint: 'nai-diffusion-4-5-full', steps: 23, cfg: 5, sampler: 'k_euler', noiseSchedule: 'karras', width: 832, height: 1216 },
      })
    const done = async (id: string) => {
      for (let i = 0; i < 200; i++) {
        const j = jobs.get(id)!
        if (j.status === 'completed' || j.status === 'error') return j
        await new Promise(r => setTimeout(r, 20))
      }
      throw new Error('timeout')
    }
    return { jobs, submit, done, calls, added }
  }

  test('renders through NovelAI, not ComfyUI, and saves to the cache', async () => {
    const t = setup(0)
    const job = await t.submit('h1')
    expect(job.provider).toBe('nai')
    const fin = await t.done(job.promptId)
    expect(fin.status).toBe('completed')
    expect(t.calls[0].body.model).toBe('nai-diffusion-4-5-full')
    expect(t.calls[0].body.input).toBe('1girl, 1.2::smile ::')
    expect(t.calls[0].body.parameters.steps).toBe(23)
    expect(t.added.length).toBe(1)
  })

  test('requests are spaced by the minimum interval', async () => {
    const t = setup(300)
    const a = await t.submit('a', true)
    const b = await t.submit('b', true)
    await t.done(a.promptId)
    await t.done(b.promptId)
    expect(t.calls.length).toBe(2)
    expect(t.calls[1].at - t.calls[0].at).toBeGreaterThanOrEqual(280)
  })

  // Wayward Faith: no wait between requests any more (NAI_MIN_INTERVAL_MS 0), but still one at a time —
  // the next request goes out only after the previous image has come back
  test('with no interval the next request still waits for the previous image', async () => {
    const t = setup(0)
    const inner = globalThis.fetch, ends: number[] = []
    globalThis.fetch = (async (url: string, init: RequestInit) => {
      const res = await inner(url, init)
      await new Promise(r => setTimeout(r, 120))
      ends.push(Date.now())
      return res
    }) as typeof fetch
    const a = await t.submit('a', true)
    const b = await t.submit('b', true)
    await t.done(a.promptId)
    await t.done(b.promptId)
    expect(t.calls.length).toBe(2)
    expect(t.calls[1].at).toBeGreaterThanOrEqual(ends[0])
  })

  test('a newer foreground request drops older ones still waiting', async () => {
    const t = setup(300)
    const a = await t.submit('a')
    const b = await t.submit('b') // waits behind a
    const c = await t.submit('c') // b has not been sent yet: superseded
    expect((await t.done(b.promptId)).status).toBe('error')
    expect((await t.done(a.promptId)).status).toBe('completed')
    expect((await t.done(c.promptId)).status).toBe('completed')
    expect(t.calls.length).toBe(2)
  })
})
