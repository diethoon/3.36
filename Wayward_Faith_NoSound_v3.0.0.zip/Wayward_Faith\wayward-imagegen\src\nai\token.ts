/**
 * The NovelAI API token lives on the server, in the state directory — not in
 * the game's browser storage, where it would ride along with exported settings
 * and every page script could read it. The game only ever learns whether one is set.
 */

import * as fs from 'node:fs'
import * as path from 'node:path'

function tokenFile(stateDir: string): string {
  return path.join(stateDir, 'nai-token.json')
}

export function readNaiToken(stateDir: string): string {
  try {
    const raw = JSON.parse(fs.readFileSync(tokenFile(stateDir), 'utf8')) as { token?: unknown }
    return typeof raw.token === 'string' ? raw.token.trim() : ''
  } catch {
    return ''
  }
}

/** An empty token removes the file. */
export function writeNaiToken(stateDir: string, token: string): void {
  const file = tokenFile(stateDir)
  const value = token.trim()
  if (!value) {
    try { fs.unlinkSync(file) } catch { /* already gone */ }
    return
  }
  fs.mkdirSync(stateDir, { recursive: true })
  fs.writeFileSync(file, JSON.stringify({ token: value }), { mode: 0o600 })
}
