/**
 * NovelAI settings the game can touch: set or clear the token, ask whether one
 * is set, and read the subscription meter. The token itself never goes back out.
 */

import type { Config } from '../config.ts'
import { Router, sendJson, HttpError } from '../http/router.ts'
import { readJson } from '../http/body.ts'
import { readNaiToken, writeNaiToken } from '../nai/token.ts'
import { getNovelAIQuota } from '../nai/quota.ts'
import { NAI_MODELS, NAI_NOISE_SCHEDULES, NAI_SAMPLERS } from '../nai/client.ts'

export function registerNaiRoutes(router: Router, deps: { config: Config }): void {
  const { config } = deps

  router.get('/api/nai/status', ctx => {
    sendJson(ctx.res, 200, {
      configured: !!readNaiToken(config.stateDir),
      models: NAI_MODELS,
      samplers: NAI_SAMPLERS,
      noiseSchedules: NAI_NOISE_SCHEDULES,
    })
  })

  router.post('/api/nai/token', async ctx => {
    const body = await readJson<{ token?: unknown }>(ctx.req)
    if (typeof body.token !== 'string') throw new HttpError(400, 'token must be a string')
    if (body.token.length > 4096) throw new HttpError(400, 'token is too long')
    writeNaiToken(config.stateDir, body.token)
    sendJson(ctx.res, 200, { configured: !!readNaiToken(config.stateDir) })
  })

  router.get('/api/nai/quota', async ctx => {
    try {
      sendJson(ctx.res, 200, await getNovelAIQuota(readNaiToken(config.stateDir), ctx.query.get('refresh') === '1'))
    } catch (err) {
      sendJson(ctx.res, 502, { configured: true, error: (err as Error).message })
    }
  })
}
