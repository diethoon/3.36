﻿# Packs the Wayward: Faith folder for the "Wayward : Faith" phone app: one game bundle (the html with WML, wml with
# its mods, images, sounds, i18n and the supporting-cast pack faith-extra). Image packs are not packed: the app reads
# the pack zips as they were downloaded. Run by 모바일로_묶기.cmd / pack-for-mobile.cmd in the game folder, which pass
# their own path: its folder is the game folder and its file name picks the language. Run on its own, it packs the
# game folder two levels up (this file lives in wml\tools).
param([string]$Launcher = '')
$f = if ($Launcher) { $Launcher } else { Join-Path (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)) 'pack-for-mobile.cmd' }
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$ErrorActionPreference = 'Stop'
$lang = if ([IO.Path]::GetFileName($f) -match '^[ -~]+$') { 'en' } else { 'ko' }
$txt = @{
  ko = @{
    title     = 'Faith 모바일용 묶음 만들기 (Wayward : Faith 앱)'
    notar     = 'Windows에 tar.exe 가 없어요. Windows 10(1803 이후)이나 11에서 실행해 주세요.'
    nohtml    = '게임 html 파일이 없어요: {0}  - 이 파일을 Wayward_Faith 폴더(html 옆)에 두고 실행해 주세요.'
    nowml     = 'WML이 연결된 html이 없어요. WML 배포 zip을 이 폴더에 풀었는지 확인해 주세요.'
    modlist   = '[1/3] 모드 목록(mods.js)을 폴더와 맞추는 중...'
    nolist    = '[1/3] 모드 목록 맞추기 파일이 없어서 건너뛰어요.'
    stateHit  = '[2/3] 세이브·설정 파일을 찾았어요: {0}  ({1})'
    stateAsk  = '      게임 묶음에 넣을까요? (폰에서 처음 시작할 때 들어가요) [Y/n]'
    stateNone = '[2/3] 세이브·설정 파일 없음 (옮기려면 WML 관리자 > 설정·백업 > 내보내기)'
    stateIn   = '      넣었어요.'
    game      = '[3/3] 게임 묶음 만드는 중... (효과음이 커서 1~2분 걸려요)'
    html      = '      html: {0}'
    extra     = '      조연팩: image-packs\faith-extra'
    gameDone  = '      {0}  ({1})'
    removed   = '      예전 묶음 지움: {0}'
    done      = '다 됐어요. 폰으로 옮길 파일은 이 폴더에 있어요: {0}'
    next1     = ' 1. 이 게임 묶음과, 받은 이미지팩 zip(풀지 않은 그대로)을 폰에 복사해요.'
    next2     = ' 2. 폰의 Wayward : Faith 앱에서 [게임 묶음 고르기]로 이 묶음을, [이미지팩 추가]로 이미지팩 zip을 골라요.'
    next3     = ' 3. 모드를 바꾸면 이 파일을 다시 실행하고, 새 게임 묶음만 다시 고르면 돼요.'
    failed    = '실패했어요: {0}'
  }
  en = @{
    title     = 'Packing Wayward: Faith for the phone app'
    notar     = 'tar.exe is missing. Run this on Windows 10 (1803 or later) or 11.'
    nohtml    = 'No game html file in this folder: {0}  - put this file in the Wayward_Faith folder (next to the html) and run it there.'
    nowml     = 'No html with WML. Check that the WML zip was extracted into this folder.'
    modlist   = '[1/3] Syncing the mod list (mods.js) with the folders...'
    nolist    = '[1/3] No mod list updater found; skipped.'
    stateHit  = '[2/3] Found a saves/settings file: {0}  ({1})'
    stateAsk  = '      Put it in the game bundle? (it goes in at the first start on the phone) [Y/n]'
    stateNone = '[2/3] No saves/settings file (to move saves: WML manager > Settings & backup > Export)'
    stateIn   = '      Added.'
    game      = '[3/3] Making the game bundle... (the sounds are big: a minute or two)'
    html      = '      html: {0}'
    extra     = '      supporting cast: image-packs\faith-extra'
    gameDone  = '      {0}  ({1})'
    removed   = '      Removed the older bundle: {0}'
    done      = 'Done. The files for the phone are in: {0}'
    next1     = ' 1. Copy this game bundle and the image pack zips you downloaded (as they are, not extracted) to the phone.'
    next2     = ' 2. In the Wayward : Faith app: [Pick a game bundle] for this bundle, [Add image packs] for the pack zips.'
    next3     = ' 3. After changing mods, run this again and pick only the new game bundle.'
    failed    = 'Failed: {0}'
  }
}[$lang]
function Say([string]$key, [object[]]$fill = @()) { Write-Host ($txt[$key] -f $fill) }
function Size([double]$n) { if ($n -ge 1GB) { '{0:N2}GB' -f ($n / 1GB) } elseif ($n -ge 1MB) { '{0:N1}MB' -f ($n / 1MB) } else { '{0:N0}KB' -f ($n / 1KB) } }

try {
  $root = Split-Path -Parent $f
  $tarExe = Join-Path $env:SystemRoot 'System32\tar.exe'
  Write-Host ''
  Write-Host $txt.title
  Write-Host '------------------------------------------'
  if (-not (Test-Path -LiteralPath $tarExe)) { Say 'notar'; return }
  $htmls = @(Get-ChildItem -LiteralPath $root -Filter '*.html' -File)
  if (-not $htmls.Count) { Say 'nohtml' @($root); return }
  # the html that loads WML: a WML copy (..._WML.html) beside the game's own html, or a game html that comes with the hook
  $hooked = @($htmls | Where-Object { [IO.File]::ReadAllText($_.FullName).Contains('wml/runtime/wml-core.js') })
  if (-not $hooked.Count) { Say 'nowml'; return }
  $outName = if ($lang -eq 'ko') { '모바일용' } else { 'for-mobile' }
  $out = Join-Path $root $outName
  New-Item -ItemType Directory -Force -Path $out | Out-Null
  $stamp = Get-Date -Format 'yyyy-MM-dd-HHmm'

  # 1. mods.js in step with the mod folders
  $updater = @('모드목록_자동갱신.cmd', 'update-mod-list.cmd') | ForEach-Object { Join-Path $root "wml\mods\$_" } | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
  if ($updater) {
    Say 'modlist'
    $env:WML_NOPAUSE = '1'
    & cmd.exe /d /c "`"$updater`"" | ForEach-Object { Write-Host "      $_" }
    Remove-Item Env:WML_NOPAUSE -ErrorAction SilentlyContinue
  } else { Say 'nolist' }

  # 2. saves/settings exported from the game (WML manager): the newest wml-state-faith-*.json in Downloads or here
  $downloads = try { (New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path } catch { Join-Path $env:USERPROFILE 'Downloads' }
  $state = @($root, $downloads) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } |
    ForEach-Object { Get-ChildItem -LiteralPath $_ -Filter 'wml-state-faith-*.json' -File -ErrorAction SilentlyContinue } |
    Sort-Object LastWriteTime -Descending | Select-Object -First 1
  $stateDir = $null
  if ($state) {
    Say 'stateHit' @($state.FullName, $state.LastWriteTime.ToString('yyyy-MM-dd HH:mm'))
    $ans = if ($env:WML_NOPAUSE) { 'n' } else { Read-Host $txt.stateAsk }
    if ($ans -eq '' -or $ans -match '^\s*[yY]') {
      $stateDir = Join-Path $env:TEMP "faith-mobile-$PID"
      New-Item -ItemType Directory -Force -Path $stateDir | Out-Null
      Copy-Item -LiteralPath $state.FullName -Destination (Join-Path $stateDir 'wml-state.json') -Force
      Say 'stateIn'
    }
  } else { Say 'stateNone' }

  # 3. the game bundle: the html with WML, the game's folders and the supporting-cast pack; not the other image packs
  #    (their zips are added in the app), the picture server, downloaded zips or tools for the PC
  Say 'game'
  $items = @($hooked | ForEach-Object { $_.Name })
  Say 'html' @($items -join ', ')
  foreach ($d in @('images', 'sounds', 'i18n', 'wml')) { if (Test-Path -LiteralPath (Join-Path $root $d) -PathType Container) { $items += $d } }
  if (Test-Path -LiteralPath (Join-Path $root 'image-packs\faith-extra\pack.js')) { $items += 'image-packs/faith-extra'; Say 'extra' }
  $gameTar = Join-Path $out "wayward-faith-game-$stamp.tar"
  $tarArgs = @('-c', '-f', $gameTar, '--exclude', '*.bak', '--exclude', '*.cmd', '--exclude', 'node_modules', '--exclude', 'wml/mcp', '-C', $root) + $items
  if ($stateDir) { $tarArgs += @('-C', $stateDir, 'wml-state.json') }
  & $tarExe @tarArgs
  if ($LASTEXITCODE -ne 0) { throw "tar ($LASTEXITCODE)" }
  if ($stateDir) { Remove-Item -LiteralPath $stateDir -Recurse -Force -ErrorAction SilentlyContinue }
  Say 'gameDone' @((Split-Path -Leaf $gameTar), (Size (Get-Item -LiteralPath $gameTar).Length))
  Get-ChildItem -LiteralPath $out -Filter 'wayward-faith-game-*.tar' -File | Where-Object { $_.FullName -ne $gameTar } | ForEach-Object { Remove-Item -LiteralPath $_.FullName -Force; Say 'removed' @($_.Name) }

  Write-Host ''
  Say 'done' @($out)
  Say 'next1'; Say 'next2'; Say 'next3'
  if (-not $env:WML_NOPAUSE) { Start-Process explorer.exe -ArgumentList "`"$out`"" }
} catch {
  Say 'failed' @($_.Exception.Message)
}
