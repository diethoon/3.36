import { test, expect } from 'bun:test'
import * as fs from 'node:fs'
import * as os from 'node:os'
import * as path from 'node:path'
import { resolveConfig } from '../config.ts'
import { CacheStore } from '../cache/cacheStore.ts'
import { JobRunner, type SubmitArgs } from './jobRunner.ts'

// A batch prompt already in ComfyUI but not yet in the job map looks like a leftover of ours. A player's click in that window
// used to drop it (supersede), leaving the batch to time out. The batch now keeps two in ComfyUI (batch/queue.ts BATCH_IN_FLIGHT),
// so that window comes round far more often.
test('a foreground request does not drop a batch prompt that is still on its way into the job map', async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-bulk-supersede-'))
  try {
    const config = resolveConfig([], root)
    const cache = new CacheStore({ imagesDir: config.imagesDir })
    const queued = new Set<string>(), deleted: string[] = []
    let release!: () => void
    const bulkSent = new Promise<void>(r => { release = r })
    const comfy = {
      submit: async (_graph: unknown, front: boolean) => {
        if (front) { queued.add('live'); return 'live' }
        queued.add('bulk') // ComfyUI has it ...
        await bulkSent // ... before the server hears back
        return 'bulk'
      },
      pendingIds: async () => ({ all: new Set(queued), ours: new Set(queued) }),
      deletePending: async (ids: string[]) => { deleted.push(...ids); for (const id of ids) queued.delete(id); return true },
    }
    const runner = new JobRunner({ config, cache, comfy: comfy as never })
    const args = (talentId: string, bulk: boolean): SubmitArgs => ({ talentId, talentName: talentId, imageType: 'portrait', prompt: talentId, negativePrompt: '', workflow: 'illustrious', promptHash: 'h-' + talentId, bulk })
    const pack = runner.submit(args('pack_1', true))
    await new Promise(r => setTimeout(r, 10))
    await runner.submit(args('live', false))
    expect(deleted).toEqual([])
    release()
    expect((await pack).promptId).toBe('bulk')
  } finally {
    fs.rmSync(root, { recursive: true, force: true })
  }
})
