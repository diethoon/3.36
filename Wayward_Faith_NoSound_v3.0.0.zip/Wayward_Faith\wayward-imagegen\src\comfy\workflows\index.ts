/**
 * ComfyUI graph builders.
 *
 * A "workflow" here is a recipe for turning a prompt pair into the node graph
 * ComfyUI's `/prompt` endpoint accepts. The game never sees these — it sends
 * prompt text and the server decides how to render it — which is exactly why
 * a player can point this at a different checkpoint or sampler without the
 * game knowing or caring.
 *
 * These graphs are behaviour-frozen against `test/fixtures/*.json`. A field
 * that changes renders a different picture into a cache cell the game treats
 * as authoritative, so the fixtures are byte-compared rather than eyeballed.
 */

import type { Config, WorkflowType } from '../../config.ts'

/**
 * A LoRA that belongs to one character (her face, hair, outfit), as opposed to
 * the detailer LoRAs in `Config` that every render gets. The game sends these
 * per request; they are chained right after the checkpoint so both the model
 * and the CLIP see them.
 */
export interface CharacterLora {
  /** File name as ComfyUI lists it under models/loras (subfolders allowed). */
  name: string
  /** Model strength. Defaults to 0.8. */
  strength?: number
  /** CLIP strength. Defaults to the model strength. */
  clipStrength?: number
}

/** A user-selected LoRA applied to every render in the active game preset. */
export interface QualityLora {
  name: string
  strength?: number
  clipStrength?: number
}

export interface GenOverrides {
  steps?: number
  cfg?: number
  loraStrength?: number
  clipSkip?: number | null
  modelType?: 'illustrious' | 'anima' | 'nai'
  checkpoint?: string
  textEncoder?: string
  vae?: string
  dimensions?: string
  qualityLoras?: QualityLora[]
  characterLoras?: CharacterLora[]
  /**
   * NovelAI: its sampler and noise schedule (the model id rides in `checkpoint`, cfg is NovelAI's scale).
   * ComfyUI (Illustrious, Anima): KSampler's sampler_name and scheduler when the preset chose them.
   */
  sampler?: string
  noiseSchedule?: string
  width?: number
  height?: number
  /** Cache and storage identity only; workflow builders ignore these. */
  presetName?: string
  styleName?: string
}

const CHARACTER_LORA_DEFAULT_STRENGTH = 0.8
/** Node ids for quality LoRAs: 1590…1597, immediately before character LoRAs. */
const QUALITY_LORA_FIRST_ID = 1590
/** Node ids for character LoRAs: 1600, 1601, … (clear of every fixed id above). */
const CHARACTER_LORA_FIRST_ID = 1600

/** Node-graph shape as ComfyUI's API expects it. */
export type ComfyGraph = Record<string, object>

/**
 * The output node of every still render.
 *
 * PreviewImage, not SaveImage: this server fetches the result and keeps its own
 * copy, so a SaveImage would leave a second copy in ComfyUI's output folder
 * (Stability Matrix's `Images/Text2Img`, for one). A preview goes to ComfyUI's
 * temp folder, which ComfyUI empties on start; `/view` serves it all the same.
 * PreviewImage takes no filename prefix, so ours rides in `_meta` — the cancel
 * path tells our queued prompts from the player's by it (client.ts isOwnQueueEntry).
 */
export function previewNode(filenamePrefix: string, images: [string, number]): object {
  return {
    inputs: { images },
    class_type: 'PreviewImage',
    _meta: { title: 'Preview Image', wfPrefix: filenamePrefix },
  }
}

/**
 * z-image is fully pinned rather than configurable: it is a second backend
 * kept around for comparison, and nothing in the shipped game selects it.
 * Promote fields to `Config` if that changes.
 */
const Z_IMAGE = {
  unet: 'zit\\moodyPornMix_zitV6.safetensors',
  clip: 'qwen_3_4b.safetensors',
  clipType: 'lumina2',
  vae: 'ae.safetensors',
  steps: 9,
  cfg: 1,
  sampler: 'dpmpp_2m_sde',
  scheduler: 'beta',
  defaultDimensions: '1024 x 1024 (1:1)',
} as const

/** IP-Adapter FaceID settings. Dormant unless a reference image is supplied. */
const FACE_ID = {
  preset: 'FACEID',
  loraStrength: 0.4,
  weight: 2,
  weightV2: 2,
} as const

const DEFAULT_DIMENSIONS = '1024 x 1024 (1:1)'

function randomSeed(): number {
  return Math.floor(Math.random() * 1000000000000000)
}

/** Dispatch to the workflow-specific builder. */
export function buildComfyPrompt(
  cfg: Config,
  textPrompt: string,
  negativePrompt: string,
  filenamePrefix: string,
  workflowType: WorkflowType = 'z-image',
  seed?: number,
  overrides?: GenOverrides,
  referenceImagePath?: string,
): ComfyGraph {
  if (workflowType === 'illustrious') {
    return buildIllustriousPrompt(cfg, textPrompt, negativePrompt, filenamePrefix, seed, overrides, referenceImagePath)
  }
  return buildZImagePrompt(textPrompt, filenamePrefix, seed, overrides)
}

/**
 * z-image workflow. Note the negative prompt is deliberately unused — this
 * workflow zeroes the negative conditioning (node 42) instead of encoding it.
 */
export function buildZImagePrompt(
  textPrompt: string,
  filenamePrefix: string,
  seed?: number,
  overrides?: Pick<GenOverrides, 'steps' | 'cfg'>,
): ComfyGraph {
  const actualSeed = seed ?? randomSeed()
  const steps = overrides?.steps ?? Z_IMAGE.steps
  const cfg = overrides?.cfg ?? Z_IMAGE.cfg

  return {
    '39': {
      inputs: { clip_name: Z_IMAGE.clip, type: Z_IMAGE.clipType },
      class_type: 'CLIPLoader',
      _meta: { title: 'Load CLIP' },
    },
    '40': {
      inputs: { vae_name: Z_IMAGE.vae },
      class_type: 'VAELoader',
      _meta: { title: 'Load VAE' },
    },
    '45': {
      inputs: { text: textPrompt, clip: ['39', 0] },
      class_type: 'CLIPTextEncode',
      _meta: { title: 'CLIP Text Encode (Prompt)' },
    },
    '61': {
      inputs: { dimensions: Z_IMAGE.defaultDimensions, invert: false, batch_size: 1 },
      class_type: 'EmptyLatentImagePresets',
      _meta: { title: 'Empty Latent Image Presets' },
    },
    '43': {
      inputs: { samples: ['44', 0], vae: ['40', 0] },
      class_type: 'VAEDecode',
      _meta: { title: 'VAE Decode' },
    },
    '9': previewNode(filenamePrefix, ['43', 0]),
    '62': {
      inputs: { unet_name: Z_IMAGE.unet, weight_dtype: 'default' },
      class_type: 'UNETLoader',
      _meta: { title: 'Load Diffusion Model' },
    },
    '47': {
      inputs: { shift: 1, model: ['62', 0] },
      class_type: 'ModelSamplingAuraFlow',
      _meta: { title: 'ModelSamplingAuraFlow' },
    },
    '42': {
      inputs: { conditioning: ['45', 0] },
      class_type: 'ConditioningZeroOut',
      _meta: { title: 'Conditioning Zero Out' },
    },
    '44': {
      inputs: {
        seed: actualSeed,
        steps,
        cfg,
        sampler_name: Z_IMAGE.sampler,
        scheduler: Z_IMAGE.scheduler,
        denoise: 1,
        model: ['47', 0],
        positive: ['45', 0],
        negative: ['42', 0],
        latent_image: ['61', 0],
      },
      class_type: 'KSampler',
      _meta: { title: 'KSampler' },
    },
  }
}

/**
 * Illustrious XL — the workflow the game actually ships against.
 *
 * The model chain is assembled by rebinding `modelOutput` as optional stages
 * are added (detailer LoRAs, character LoRAs, then FaceID), so the graph stays
 * valid whichever are present.
 */
export function buildIllustriousPrompt(
  config: Config,
  textPrompt: string,
  negativePrompt: string,
  filenamePrefix: string,
  seed?: number,
  overrides?: GenOverrides,
  referenceImagePath?: string,
): ComfyGraph {
  const actualSeed = seed ?? randomSeed()

  const steps = overrides?.steps ?? config.steps
  const cfg = overrides?.cfg ?? config.cfg
  // The game's per-request `loraStrength` (from its image settings) drives the detailer LoRA.
  const detailerStrength = overrides?.loraStrength ?? config.detailerLoraStrength ?? 1
  const checkpoint = overrides?.checkpoint?.trim() || config.checkpoint
  const modelType = overrides?.modelType === 'anima' ? 'anima' : 'illustrious'
  const isAnima = modelType === 'anima'
  const textEncoder = overrides?.textEncoder?.trim()
  const externalVae = overrides?.vae?.trim()
  const clipSkip = overrides?.clipSkip === undefined ? config.clipSkip ?? -2 : overrides.clipSkip

  const nodes: ComfyGraph = {
    '1407': {
      inputs: { ckpt_name: checkpoint },
      class_type: 'CheckpointLoaderSimple',
      _meta: { title: 'Load Checkpoint' },
    },
    '522': {
      inputs: { text: textPrompt, clip: ['1407', 1] },
      class_type: 'CLIPTextEncode',
      _meta: { title: 'Style' },
    },
    '1440': {
      inputs: { text: negativePrompt, clip: ['1407', 1] },
      class_type: 'CLIPTextEncode',
      _meta: { title: 'Negative' },
    },
    '1457': {
      inputs: {
        dimensions: overrides?.dimensions ?? DEFAULT_DIMENSIONS,
        invert: overrides?.dimensions ? true : false,
        batch_size: 1,
      },
      class_type: 'EmptyLatentImagePresets',
      _meta: { title: 'Empty Latent Image Presets' },
    },
    '1458': {
      inputs: {
        value: actualSeed,
        mode: true,
        action: 'increment',
        last_seed: String(actualSeed - 1),
      },
      class_type: 'GlobalSeed //Inspire',
      _meta: { title: 'GlobalSeed //Inspire' },
    },
    '1291': {
      inputs: { samples: ['1536', 1], vae: ['1536', 2] },
      class_type: 'VAEDecode',
      _meta: { title: 'VAE Decode' },
    },
    '1441': previewNode(filenamePrefix, ['1291', 0]),
  }

  let modelOutput: [string, number] = ['1407', 0]
  let clipOutput: [string, number]
  let vaeOutput: [string, number] = ['1407', 2]

  clipOutput = ['1407', 1]
  if (isAnima && textEncoder) {
    nodes['14'] = {
      inputs: { clip_name: textEncoder, type: 'stable_diffusion', device: 'default' },
      class_type: 'CLIPLoader',
      _meta: { title: 'Load Anima Text Encoder' },
    }
    clipOutput = ['14', 0]
  }
  if (isAnima) {
    if (externalVae) {
      nodes['16'] = {
        inputs: { vae_name: externalVae },
        class_type: 'VAELoader',
        _meta: { title: 'Load Anima VAE' },
      }
      vaeOutput = ['16', 0]
    }
  }

  if (Number.isFinite(clipSkip)) {
    nodes['15'] = {
      inputs: { stop_at_clip_layer: clipSkip, clip: clipOutput },
      class_type: 'CLIPSetLastLayer',
      _meta: { title: 'Clip Skip' },
    }
    clipOutput = ['15', 0]
  }

  // A request preset replaces the server defaults, including with an empty list.
  // Older clients omit qualityLoras and keep the two config-based defaults.
  const qualityLoras: (QualityLora & { title?: string })[] = (overrides?.qualityLoras === undefined
    ? [
        { name: config.detailerLora, strength: detailerStrength, title: 'Detailer LoRA' },
        { name: config.faceDetailerLora, strength: config.faceDetailerLoraStrength ?? 1, title: 'Face Detailer LoRA' },
      ]
    : overrides.qualityLoras).filter(l => l?.name?.trim()).slice(0, 8)
  qualityLoras.forEach((lora, i) => {
    const id = String(QUALITY_LORA_FIRST_ID + i)
    const strength = Number.isFinite(lora.strength) ? (lora.strength as number) : 1
    nodes[id] = {
      inputs: {
        lora_name: lora.name.trim(),
        strength_model: strength,
        strength_clip: Number.isFinite(lora.clipStrength) ? (lora.clipStrength as number) : strength,
        model: modelOutput,
        clip: clipOutput,
      },
      class_type: 'LoraLoader',
      _meta: { title: lora.title ?? `Quality LoRA ${i + 1}` },
    }
    modelOutput = [id, 0]
    clipOutput = [id, 1]
  })

  // Character LoRAs, chained model+CLIP after the detailer LoRAs.
  const characterLoras = (overrides?.characterLoras ?? []).filter(l => l?.name?.trim())
  characterLoras.forEach((lora, i) => {
    const id = String(CHARACTER_LORA_FIRST_ID + i)
    const strength = Number.isFinite(lora.strength) ? (lora.strength as number) : CHARACTER_LORA_DEFAULT_STRENGTH
    nodes[id] = {
      inputs: {
        lora_name: lora.name.trim(),
        strength_model: strength,
        strength_clip: Number.isFinite(lora.clipStrength) ? (lora.clipStrength as number) : strength,
        model: modelOutput,
        clip: clipOutput,
      },
      class_type: 'LoraLoader',
      _meta: { title: `Character LoRA ${i + 1}` },
    }
    modelOutput = [id, 0]
    clipOutput = [id, 1]
  })
  // Prompts are encoded with the CLIP after every LoRA above.
  ;(nodes['522'] as { inputs: { clip: [string, number] } }).inputs.clip = clipOutput
  ;(nodes['1440'] as { inputs: { clip: [string, number] } }).inputs.clip = clipOutput

  if (referenceImagePath) {
    nodes['1541'] = {
      inputs: { image: referenceImagePath, upload: 'image' },
      class_type: 'LoadImage',
      _meta: { title: 'Load Image' },
    }
    nodes['1539'] = {
      inputs: {
        preset: FACE_ID.preset,
        lora_strength: FACE_ID.loraStrength,
        provider: 'CPU',
        model: modelOutput,
      },
      class_type: 'IPAdapterUnifiedLoaderFaceID',
      _meta: { title: 'IPAdapterUnifiedLoaderFaceID' },
    }
    nodes['1540'] = {
      inputs: {
        weight: FACE_ID.weight,
        weight_faceidv2: FACE_ID.weightV2,
        weight_type: 'ease in',
        combine_embeds: 'concat',
        start_at: 0,
        end_at: 1,
        embeds_scaling: 'V only',
        model: ['1539', 0],
        ipadapter: ['1539', 1],
        image: ['1541', 0],
      },
      class_type: 'IPAdapterFaceID',
      _meta: { title: 'IPAdapterFaceID' },
    }
    modelOutput = ['1540', 0]
  }

  nodes['158'] = {
    inputs: {
      model: modelOutput,
      clip: clipOutput,
      vae: vaeOutput,
      positive: ['522', 0],
      negative: ['1440', 0],
    },
    class_type: 'ToBasicPipe',
    _meta: { title: 'ToBasicPipe' },
  }

  nodes['1536'] = {
    inputs: {
      seed: actualSeed,
      steps,
      cfg,
      sampler_name: overrides?.sampler || (isAnima ? 'euler' : config.sampler),
      scheduler: overrides?.noiseSchedule || (isAnima ? 'simple' : config.scheduler),
      denoise: 1,
      basic_pipe: ['158', 0],
      latent_image: ['1457', 0],
    },
    class_type: 'ImpactKSamplerBasicPipe',
    _meta: { title: 'ImpactKSamplerBasicPipe' },
  }

  return nodes
}

/**
 * Wan i2v video. Unlike the image workflows this patches a user-supplied
 * workflow JSON rather than building a graph from scratch, because the node
 * ids are whatever the player's exported workflow used. We only rewrite the
 * inputs we own; everything else is left exactly as they saved it.
 */
export function buildWanVideoPrompt(
  workflowJson: string,
  textPrompt: string,
  negativePrompt: string,
  sourceImagePath: string,
  filenamePrefix: string,
  seed?: number,
): ComfyGraph {
  const actualSeed = seed ?? randomSeed()
  const workflow = JSON.parse(workflowJson) as Record<string, { inputs?: Record<string, unknown> }>

  const patch = (id: string, inputs: Record<string, unknown>): void => {
    const node = workflow[id]
    if (!node) {
      throw new Error(
        `Wan video workflow is missing node "${id}". The bundled workflow expects `
        + `the node ids from ComfyUI_00033_.json; a differently-exported workflow `
        + `needs its ids remapped.`,
      )
    }
    node.inputs = { ...node.inputs, ...inputs }
  }

  patch('241', { image: sourceImagePath })
  patch('207:93', { text: textPrompt })
  patch('207:89', { text: negativePrompt })
  patch('216', { value: actualSeed, mode: true, action: 'fixed', last_seed: actualSeed })
  patch('207:86', { noise_seed: actualSeed, motion_amplitude: 1 })
  patch('207:178', { noise_seed: actualSeed })
  patch('221', { filename_prefix: filenamePrefix })

  return workflow as ComfyGraph
}
