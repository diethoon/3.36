import { test, expect } from 'bun:test'
import * as fs from 'node:fs'
import * as os from 'node:os'
import * as path from 'node:path'
import { CacheStore } from '../cache/cacheStore.ts'
import { OutfitPackWriter } from '../cache/outfitPack.ts'
import { imageSize } from '../cache/imageSize.ts'
import { BatchQueue } from './queue.ts'
import type { Config } from '../config.ts'
import type { JobRunner } from '../comfy/jobRunner.ts'

// Wayward Faith: pack renders used to come out 1024x1024 (the batch path never sent the size to ComfyUI).
// The maker's plan counts a picture of the wrong size as one to draw again, and drawing moves it out of the pack.
function png(width: number, height: number): Buffer {
  const b = Buffer.alloc(33)
  Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]).copy(b, 0)
  b.writeUInt32BE(13, 8); b.write('IHDR', 12, 'ascii'); b.writeUInt32BE(width, 16); b.writeUInt32BE(height, 20)
  return b
}

test('a pack picture of the wrong size is redrawn', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-pack-size-'))
  try {
    const stateDir = path.join(root, 'state'), imagesDir = path.join(root, 'global'), imagePacksDir = path.join(root, 'image-packs')
    const target = { character: 'extra', outfit: 'extra', name: 'faith' }
    const writer = new OutfitPackWriter(stateDir, imagesDir, { ...target, presetName: 'IL' }, false, imagePacksDir)
    fs.mkdirSync(path.join(writer.directory, 'images'), { recursive: true })
    fs.writeFileSync(path.join(writer.directory, 'images', 'square.png'), png(1024, 1024))
    fs.writeFileSync(path.join(writer.directory, 'images', 'tall.png'), png(832, 1216))
    writer.record('elena__s-wfo_tavern_hall__o-wf_tavern_work__p-vl__v-0', { talentName: 'elena__s-wfo_tavern_hall__o-wf_tavern_work__p-vl__v-0', imagePath: 'square.png', imageType: 'portrait', promptHash: 'h', createdAt: 1, prompt: '' })
    writer.record('mara__s-wfo_tavern_hall__o-wf_tavern_work__p-vl__v-0', { talentName: 'mara__s-wfo_tavern_hall__o-wf_tavern_work__p-vl__v-0', imagePath: 'tall.png', imageType: 'portrait', promptHash: 'h', createdAt: 1, prompt: '' })
    writer.flush()
    expect(imageSize(path.join(writer.directory, 'images', 'square.png'))).toEqual([1024, 1024])

    const queue = new BatchQueue({ stateDir, imagesDir, imagePacksDir } as Config, new CacheStore({ imagesDir }), {} as JobRunner)
    // The plan: without a size every picture counts; with the game's size the square one does not
    expect(queue.packExisting({ ...target, presetName: 'IL' }).sort()).toEqual(['elena__s-wfo_tavern_hall__o-wf_tavern_work__p-vl__v-0', 'mara__s-wfo_tavern_hall__o-wf_tavern_work__p-vl__v-0'].sort())
    expect(queue.packExisting({ ...target, presetName: 'IL' }, { width: 1216, height: 832 })).toEqual(['mara__s-wfo_tavern_hall__o-wf_tavern_work__p-vl__v-0'])

    // Drawing: the square one is queued again and leaves the pack (kept outside, not deleted); the right size stays
    const item = (talentId: string) => ({ talentId, prompt: 'p', presetName: 'IL', outfitPack: target, width: 1216, height: 832 })
    const result = queue.enqueue([item('elena__s-wfo_tavern_hall__o-wf_tavern_work__p-vl__v-0'), item('mara__s-wfo_tavern_hall__o-wf_tavern_work__p-vl__v-0')])
    expect(result.accepted).toBe(1)
    expect(result.alreadyCached).toBe(1)
    expect(fs.existsSync(path.join(writer.directory, 'images', 'square.png'))).toBe(false)
    expect(fs.existsSync(path.join(stateDir, 'replaced-pack-images', path.basename(writer.directory), 'square.png'))).toBe(true)
  } finally { fs.rmSync(root, { recursive: true, force: true }) }
})
