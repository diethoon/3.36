import { afterEach, describe, expect, it } from 'vitest'
import * as fs from 'node:fs'
import * as os from 'node:os'
import * as path from 'node:path'
import { CacheStore, type ImageCacheFile } from './cacheStore.ts'

const roots: string[] = []
afterEach(() => {
  for (const root of roots.splice(0)) fs.rmSync(root, { recursive: true, force: true })
})

describe('legacy image layout migration', () => {
  it('moves indexed and unindexed workflow images into preset/default folders', () => {
    const imagesDir = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-cache-migration-'))
    roots.push(imagesDir)
    const oldIndexed = path.join(imagesDir, 'illustrious', 'characters', 'mara', 'indexed.png')
    const oldLoose = path.join(imagesDir, 'illustrious', 'characters', 'elena', 'loose.png')
    fs.mkdirSync(path.dirname(oldIndexed), { recursive: true })
    fs.mkdirSync(path.dirname(oldLoose), { recursive: true })
    fs.writeFileSync(oldIndexed, 'indexed')
    fs.writeFileSync(oldLoose, 'loose')
    const cache: ImageCacheFile = {
      version: 1,
      entries: {
        old: {
          promptHash: 'hash',
          imagePath: 'illustrious/characters/mara/indexed.png',
          talentName: 'mara__task-idle__v-0',
          imageType: 'portrait',
          createdAt: 1,
          prompt: '1girl',
        },
      },
    }
    fs.writeFileSync(path.join(imagesDir, '.image-cache.json'), JSON.stringify(cache))

    const store = new CacheStore({ imagesDir }).load()
    expect(store.entries.old.imagePath).toBe('il_기본형/default/characters/mara/indexed.png')
    expect(store.entries.old.genParams?.presetName).toBe('il_기본형')
    expect(store.entries.old.genParams?.styleName).toBe('default')
    expect(fs.existsSync(path.join(imagesDir, 'il_기본형', 'default', 'characters', 'mara', 'indexed.png'))).toBe(true)
    expect(fs.existsSync(path.join(imagesDir, 'il_기본형', 'default', 'characters', 'elena', 'loose.png'))).toBe(true)
    expect(fs.existsSync(oldIndexed)).toBe(false)
  })

  it('uses generation settings to recover detailed and anima presets', () => {
    const imagesDir = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-cache-migration-'))
    roots.push(imagesDir)
    const detailed = path.join(imagesDir, 'illustrious', 'characters', 'mara', 'detailed.png')
    const anima = path.join(imagesDir, 'anima', 'characters', 'mara', 'anima.png')
    fs.mkdirSync(path.dirname(detailed), { recursive: true })
    fs.mkdirSync(path.dirname(anima), { recursive: true })
    fs.writeFileSync(detailed, 'detailed')
    fs.writeFileSync(anima, 'anima')
    const base = { talentName: 'mara__task-idle__v-0', imageType: 'portrait', createdAt: 1, prompt: '1girl' }
    const cache: ImageCacheFile = {
      version: 1,
      entries: {
        detailed: { ...base, promptHash: 'd', imagePath: 'illustrious/characters/mara/detailed.png', genParams: { qualityLoras: [{ name: 'detail.safetensors' }] } },
        anima: { ...base, promptHash: 'a', imagePath: 'anima/characters/mara/anima.png', genParams: { modelType: 'anima' } },
      },
    }
    fs.writeFileSync(path.join(imagesDir, '.image-cache.json'), JSON.stringify(cache))

    const store = new CacheStore({ imagesDir }).load()
    expect(store.entries.detailed.imagePath).toBe('il_detailed/default/characters/mara/detailed.png')
    expect(store.entries.anima.imagePath).toBe('anima_turbo/default/characters/mara/anima.png')
  })
})
