import { test, expect } from 'bun:test'
import * as fs from 'node:fs'
import * as os from 'node:os'
import * as path from 'node:path'
import { resolveConfig } from '../config.ts'
import { CacheStore } from '../cache/cacheStore.ts'
import { JobRunner, type SubmitArgs, type GenerationJob } from './jobRunner.ts'

// The hourly ceiling (routes/image.ts maxImagesPerHour) is for interactive work only. Batch renders used to be counted too,
// so a fast image-pack run locked the game out of its own pictures with 429 'hourly image limit reached'.
test('batch renders do not use up the hourly limit of interactive pictures', async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-hourly-'))
  try {
    const config = resolveConfig([], root)
    config.webp = false
    const cache = new CacheStore({ imagesDir: config.imagesDir })
    let n = 0
    const runner = new JobRunner({ config, cache, comfy: { submit: async () => 'job-' + (++n), pendingIds: async () => ({ all: [], ours: [] }), cancel: async () => {} } as never })
    const store = (job: GenerationJob) => (runner as unknown as { storeImage(job: GenerationJob, bytes: Buffer): Promise<void> }).storeImage(job, Buffer.from(job.promptId))
    const args = (talentId: string, bulk: boolean): SubmitArgs => ({ talentId, talentName: talentId, imageType: 'portrait', prompt: talentId, negativePrompt: '', workflow: 'illustrious', promptHash: 'h-' + talentId, bulk })
    for (let i = 0; i < 3; i++) await store(await runner.submit(args('pack_' + i, true)))
    expect(runner.completionsThisHour()).toBe(0)
    await store(await runner.submit(args('live', false)))
    expect(runner.completionsThisHour()).toBe(1)
  } finally {
    fs.rmSync(root, { recursive: true, force: true })
  }
})
