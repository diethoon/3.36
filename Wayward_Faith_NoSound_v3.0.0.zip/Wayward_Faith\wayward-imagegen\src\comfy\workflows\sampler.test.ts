import { describe, expect, test } from 'bun:test'
import { buildComfyPrompt } from './index.ts'
import { derivePromptHash } from '../../naming.ts'
import type { Config } from '../../config.ts'

// The game's Illustrious / Anima presets may choose KSampler's sampler and scheduler, like the NovelAI preset does
// (game: src/faith/image/image-gen.js wfComfySamplerFields · wfGenOverride).
const config = { checkpoint: 'model.safetensors', steps: 20, cfg: 7, sampler: 'euler', scheduler: 'normal', detailerLora: '', faceDetailerLora: '', detailerLoraStrength: 0, faceDetailerLoraStrength: 0 } as unknown as Config
const sampler = (graph: Record<string, any>) => Object.values(graph).find(n => n.class_type === 'ImpactKSamplerBasicPipe')!.inputs

describe('preset sampler and scheduler', () => {
  test('unchosen: the server config for Illustrious, euler/simple for Anima', () => {
    expect(sampler(buildComfyPrompt(config, '1girl', '', 'k', 'illustrious', 1, {}) as any)).toMatchObject({ sampler_name: 'euler', scheduler: 'normal' })
    expect(sampler(buildComfyPrompt(config, '1girl', '', 'k', 'illustrious', 1, { modelType: 'anima' }) as any)).toMatchObject({ sampler_name: 'euler', scheduler: 'simple' })
  })
  test('chosen: used for both model types', () => {
    for (const modelType of ['illustrious', 'anima'] as const)
      expect(sampler(buildComfyPrompt(config, '1girl', '', 'k', 'illustrious', 1, { modelType, sampler: 'dpmpp_2m', noiseSchedule: 'karras' }) as any)).toMatchObject({ sampler_name: 'dpmpp_2m', scheduler: 'karras' })
  })
  test('hash: unchanged when nothing is chosen and for NovelAI, different when chosen', () => {
    const base = { steps: 20, cfg: 7, checkpoint: 'model.safetensors' }
    const before = derivePromptHash('1girl', '', base)
    expect(derivePromptHash('1girl', '', { ...base, sampler: undefined, noiseSchedule: undefined })).toBe(before)
    expect(derivePromptHash('1girl', '', { ...base, sampler: 'dpmpp_2m' })).not.toBe(before)
    expect(derivePromptHash('1girl', '', { ...base, noiseSchedule: 'karras' })).not.toBe(before)
    const nai = { steps: 23, cfg: 5, modelType: 'nai' as const, checkpoint: 'nai-diffusion-4-5-full' }
    expect(derivePromptHash('1girl', '', { ...nai, sampler: 'k_euler', noiseSchedule: 'native' })).toBe(derivePromptHash('1girl', '', nai))
    // a name that is not a KSampler word is ignored, not hashed
    expect(derivePromptHash('1girl', '', { ...base, sampler: 'K Euler!' })).toBe(before)
  })
})
