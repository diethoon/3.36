import { test, expect } from 'bun:test'
import * as fs from 'node:fs'
import * as os from 'node:os'
import * as path from 'node:path'
import { BatchQueue, type BatchItem } from './queue.ts'
import { resolveConfig } from '../config.ts'
import type { CacheStore } from '../cache/cacheStore.ts'
import type { JobRunner } from '../comfy/jobRunner.ts'

// Each pack says how long until its last remaining picture is drawn, and which pack is being drawn now
// (game: src/faith/image/pack.js wfPackEta shows "현재 … · 전체 …" when there are several packs — user request 2026-10-20).
test('per-pack time left follows the weight-ordered queue across packs', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-pack-eta-'))
  try {
    const config = resolveConfig([], root)
    const cache = { get: () => null } as unknown as CacheStore
    const queue = new BatchQueue(config, cache, {} as JobRunner)
    const item = (who: string, i: number, weight: number): BatchItem => ({ talentId: `${who}__f-${i}`, prompt: who, weight, essential: weight >= 2, outfitPack: { character: who, outfit: 'basic', name: 'eta' } })
    // mara: 2 essentials + 2 extras, elena: 2 essentials + 2 extras -> order: m0 m1 e0 e1 (essentials, pack by pack) then m2 m3 e2 e3
    queue.enqueue([item('mara', 0, 2), item('mara', 1, 2), item('mara', 2, 1), item('mara', 3, 1)])
    queue.enqueue([item('elena', 0, 2), item('elena', 1, 2), item('elena', 2, 1), item('elena', 3, 1)])
    const q = queue as unknown as { running: boolean; startedAt: number; doneAtStart: number; currentKey: string | null; results: Map<string, unknown>; now: () => number }
    // 3 done in 30 s -> 10 s a picture; drawing elena__f-0 now
    const t = Date.now()
    q.now = () => t
    q.running = true; q.startedAt = t - 30_000; q.doneAtStart = 0
    for (const id of ['mara__f-0', 'mara__f-1', 'xx']) q.results.set(id, { talentId: id, outcome: 'completed', at: t })
    q.results.delete('xx'); q.results.set('elena__f-0', { talentId: 'elena__f-0', outcome: 'completed', at: t })
    q.currentKey = 'elena__f-1'
    const packs = queue.status().packs
    const mara = packs.find(p => p.name.includes('eta') && p.directory.includes('mara'))!, elena = packs.find(p => p.directory.includes('elena'))!
    // remaining in queue order: e1, m2, m3, e2, e3 -> mara's last remaining (m3) is 3rd, elena's (e3) 5th
    expect(mara.etaSeconds).toBe(30)
    expect(elena.etaSeconds).toBe(50)
    expect(elena.current).toBe(true)
    expect(mara.current).toBeUndefined()
    expect(queue.status().etaSeconds).toBe(50)
  } finally { fs.rmSync(root, { recursive: true, force: true }) }
})
