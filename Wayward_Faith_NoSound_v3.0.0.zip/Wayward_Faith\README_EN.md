# Wayward: Faith

A medieval cult management simulation. An unofficial modified game built on the tavern life simulation **Wayward**.

- Wayward: Faith is **not affiliated with Wayward or its author, Sintention**. It is a separate fan project, made by modifying Wayward with the original author's permission.
- It is **free**. If anyone charged you for it, you were scammed.

> **⚠ Adult content**
> Contains explicit sexual content and sensitive themes such as NTR, S/M, scat and bestiality. Minors may not play.
> Most fetishes can be turned off with **Doctrine** when you start a game.

---

## 1. Running the game

1. Extract the zip to any folder.
2. Open **`Wayward_Faith_v<version>.html`** inside the `Wayward_Faith` folder in your browser (for example `Wayward_Faith_v3.0.0.html`). Chrome or Edge is recommended.
3. To play in English, choose **English** under Language in **Game Settings**. The game reloads in English.

The game comes in two zips. You only need **one**.

- **`Wayward_Faith_v<version>.zip`** — with sound effects (usually this one)
- **`Wayward_Faith_NoSound_v<version>.zip`** — without sound effects (smaller)

Put any pack zips you downloaded (`Faith_Extra`, `Faith_Mods`, image packs) into the `Wayward_Faith` folder and run **`install-packs.cmd`** to unpack them in the right place. If there are several versions of the same pack, the newest is used. You can also unpack them yourself.

The basic image packs for Elena, Mara and Pippa are released separately per character, like **`Faith_Basic_Elena_v<version>.zip`** (used when you don't generate pictures live). They also unpack with `install-packs.cmd`.

Image pack zips made by other people (basic packs, outfit packs) work the same way: put them in the same folder and run `install-packs.cmd`, and they unpack into `image-packs/`. The zip name doesn't matter; the `pack.js` inside identifies the pack. Afterwards, choose the `image-packs` folder in the game's **Image pack settings** to register them.

If you got the build without sound and want sound later, copy the `sounds/` folder from the sound zip into the game folder.

From 3.0.0 the divine beast offering and scat are not part of the game; they are mods released as **`Faith_Mods_v<version>.zip`**. Put that zip in the game folder and run `install-packs.cmd`, and it unpacks into `wml/mods/`. Turn mods on and off in the game menu's mod settings (mod manager). Old saves carry on as before once the mods are on.

The tavern hostess and husband pictures (supporting-cast pack) come separately as **`Faith_Extra_v<version>.zip`**. You only need it when using image packs. Unpack it in the same place so that `Wayward_Faith/image-packs/faith-extra/base/` appears, and the game reads it automatically. The supporting-cast and basic packs are only re-released when their files change, so their version can be lower than the game's.

The mod loader **WML** (Wayward Mod Loader) is included in the game folder's `wml/`. In game, press Esc (pause menu) → **Mod settings** below Game Settings → Mod manager to turn mods on and off or install them. `WML_사용법.txt` explains the default mod "Faith mobile view" and the phone app (in Korean). If you'd rather play without WML, delete the `wml` folder (the game still runs).

No installation is needed. When you move the folder, keep the layout below together. If `images` and `sounds` are not next to the versioned HTML file, some pictures and sounds won't appear.

```text
Wayward_Faith/
├─ Wayward_Faith_v<version>.html  the game
├─ i18n/                 English translation
├─ images/               pictures built into the game (pregnancy journal, etc.)
├─ sounds/               sound effects (sound zip only)
├─ image-packs/faith-extra/base/  supporting-cast pack (Faith_Extra zip, optional)
├─ wayward-imagegen/     image generation server (optional)
├─ start-imagegen.cmd    starts the image generation server (optional)
├─ install-packs.cmd     unpacks downloaded pack zips
├─ wml/                  mod loader WML and default mods
├─ 모바일로_묶기.cmd      builds a game bundle for the phone app (WML)
├─ WML_사용법.txt         WML and phone app guide (Korean)
├─ README.md             Korean guide
└─ README_EN.md          this document
```

## 2. Saving

- The game **saves automatically inside your browser**. Open it again in the same browser to continue.
- Clearing your browser history or site data can delete your saves too.
- It uses the same storage (Local Storage) as the original Wayward, so back up your original Wayward saves separately.
- For important saves, use **Export current to JSON** in the save window to download a file. **Import from JSON…** restores it.

## 3. Sound and screen flashes

- Because of browser rules, sound may not play until you click the screen once.
- In **Sound settings** you can set the overall volume and turn each kind of sound on or off (voice, acts, bed, ejaculation, movement, bath), and preview the music and sound effects.
- Some scenes, such as whipping, flash the whole screen white. If you are worried about photosensitive seizures, turn it off with **Photosensitivity protection** on the title screen or in settings. With it off, you only hear the sound.

## 4. Image generation (optional)

This game **generates scene pictures live**. Without the image server, the game still plays to the end as text.

### Requirements

- **[ComfyUI](https://github.com/comfyanonymous/ComfyUI)** running, with the models you'll use (checkpoints, LoRAs). If you only draw with NovelAI, you don't need ComfyUI, custom nodes or a GPU (see NovelAI below).
- **[Bun](https://bun.sh)** to run the server
- Three ComfyUI custom nodes, installed with ComfyUI Manager:
  - ComfyUI Impact Pack (ltdrdata)
  - ComfyUI Inspire Pack (ltdrdata)
  - KJ Nodes for ComfyUI (kijai)
- A GPU that can run the model

### Starting it

1. Start ComfyUI first.
2. Double-click **`start-imagegen.cmd`**. The server runs while its window is open and stops when you close it.
3. In the game menu's **Image generation settings**, set the connection to **Automatic** and it finds the server and shows "connected".

- If your ComfyUI address isn't the default (`http://127.0.0.1:8188`): `start-imagegen.cmd --comfy-url http://address:port`
- If another program uses port 8189: start with `start-imagegen.cmd --port 9000`, then in Image generation settings choose **Specific address** and enter `http://127.0.0.1:9000`.

### Presets and model paths

In the menu, **Image generation settings → Image generation presets** lets you pick a preset that bundles the checkpoint, quality LoRAs, Steps and CFG. Four come with the game.

| Preset | Model | Notes |
|---|---|---|
| IL default | WAI-Illustrious SDXL v17 | Selected at first. No quality LoRA |
| IL Detailed | WAI-Illustrious SDXL v17 | The developer's setup. Adds two detail LoRAs (ILDetailer V2, Face Detailed v2) at 0.5 each |
| Anima Turbo | Anima Turbo v1.1 | 10 Steps, CFG 1. Needs a separate text encoder and VAE |
| NovelAI | NAI Diffusion V4.5 Full | Draws with NovelAI, no ComfyUI. Needs a token (below) |

**Check the paths.** The default presets assume the files sit **directly** in the ComfyUI model folders (`models/checkpoints`, `models/loras`, etc.) and list only the file names. If you keep them in subfolders, pick the preset, press **Edit** and change them to `folder\filename.safetensors`. If a path is wrong, no picture is generated.

You can also register any model yourself with **Add new preset**.

### NovelAI

1. In your NovelAI account settings, use **Get Persistent API Token** to get a token (`pst-…`).
2. Start `start-imagegen.cmd`. If you only use NovelAI, you don't need ComfyUI running.
3. In Image generation presets, pick the NovelAI preset and press **Edit** (or make a new one with **+**) and set the model type to **NovelAI**. Enter the token in the field right below and save. Your subscription and remaining Anlas are shown.

- The token is stored in `wayward-imagegen/images/.state` and shared by all NovelAI presets. It is not kept in the browser.
- To keep your account from being locked, requests go out at most once every 10 seconds. If scenes change quickly, older picture requests that haven't been sent yet are dropped.
- Without an Opus subscription, or above 28 Steps or 832×1216, each picture costs Anlas.
- If an older version's server window is still open, NovelAI won't work. Close it and start the new version's `start-imagegen.cmd`.
- If you edited presets in an older version, the NovelAI preset won't be in the list. Make a new one with **+**.

### If pictures take too long

In the menu's **Prompt settings**, you can turn off states that pictures reflect (exposure, expression and mood, intoxication, arousal, weather, season, time of day, traces after sex). Turned-off states reuse the same picture even when they differ, so you wait for new pictures less often.

Generated pictures are saved under `wayward-imagegen/images` and reused when the same situation comes up.

## 5. Troubleshooting

| Problem | What to check |
|---|---|
| No pictures | Both ComfyUI and the `start-imagegen.cmd` window are open, Image generation settings shows "connected", and the preset's model paths are right (for NovelAI, that the token is saved) |
| The server window closes right away | Bun is installed |
| Only some pictures or sounds are missing | The `images` and `sounds` folders are next to the versioned HTML file |
| No sound | You clicked the screen once, and sound effects are on in Sound settings |

If you find a bug or an odd sentence, report it where you downloaded the game. Say what you were doing, and if you can, attach a **save exported as JSON** — it makes fixing much easier.

---

## Credits

- **Original game:** Wayward — by Sintention. Wayward: Faith is a modification of Wayward and is not affiliated with it.
- **Korean edition (base):** Wayward-v2026-09-30_ko-v1.4
- **Image generation server:** wayward-imagegen — sintention (MIT License). A version adapted to this game is included (character LoRAs, presets, Anima support, per-character save folders, NovelAI). The NovelAI support referenced code from the Wayward EasyGen mod. The original license is in `wayward-imagegen/LICENSE`.
- **Mod loader:** WML (Wayward Mod Loader) — kiimoi. A version adapted to Faith with the author's permission (Mod settings in the pause menu) is included.
- **Sound effects mod** and **pregnancy mod:** community mods for the Korean edition of Wayward
- **Fonts:** Nanum Brush Script; La Belle Aurore by Kimberly Geswein (English text in the pregnancy journal) — Google Fonts, SIL Open Font License
- **Images:** All image assets were made with AI.
- **Music:**
  - Ground floor — "Byzantine (loop)" by AVGVSTA (CC-BY 3.0) — https://opengameart.org/content/byzantine-loop
  - Upper floor — "Calm Relax 1 (Synthwave 421k)" by The Cynic Project / cynicmusic.com / pixelsphere.org (CC0) — converted from MP3 to OGG
  - Basement — "Wendale Abbey" by Yubatake, OpenGameArt (CC-BY 4.0) — https://opengameart.org/content/wendale-abbey
  - Gathering — "Dark Urban Church Theme Loop" by beardalaxy, OpenGameArt (CC0)
  - Village, alley and barn — "Village of The Fallen" by Kaine Carrillo, OpenGameArt (CC-BY 4.0) — converted from WAV to OGG
  - Tavern — "Pirate tavern loop" by Emma_MA, OpenGameArt (CC-BY 4.0) — converted from WAV to OGG
  - Secret shop — "Light In The Dark Stem Set" (09_ambiance_loop) — Additional Music By Will Leamon, OpenGameArt (OGA-BY 3.0) — volume raised, converted to OGG
  - Silence at the start and end is skipped in game; the tracks are otherwise unchanged apart from format conversion (and the volume change noted).
- **Sound effects:**
  - Whip — "Whip Crack" by SciFiSounds, Freesound (CC0) — https://freesound.org/s/529925/ — converted to OGG
  - Chapel bell — "Church-bell 8pm village 140804_01" by klankbeeld, Freesound (CC BY 4.0) — https://freesound.org/s/343419/ — trimmed to two and eight strikes with a fade-out, converted to OGG
- **Voices:** 音声素材_Pincree — https://pincree.jp/
  - The voice actors did not record these for this game; they are chosen from R-18 voice material that Pincree distributes and sells. One set is used per voice (the set name is that set's character name).
  - Polite — Nikomi Ryuzen — 音声素材_Pincree(CV:龍涎にこみ)
  - Timid — Marisa Tadai — 音声素材_Pincree(CV:逢坂成美)
  - Cheeky — Aki Katagiri — 音声素材_Pincree(CV:片桐秋)
  - Cheerful — Kino Otosaka — 音声素材_Pincree(CV:いちくら)
  - Lustful — Tsubasa Kitakami — 音声素材_Pincree(CV:千夜)
  - Cool — Satsuki Mikami — 音声素材_Pincree(CV:此花瑠璃)
  - Stolid — Akira Shono — 音声素材_Pincree(CV:鳴宮なる)
  - Queen — Hina Memeno — 音声素材_Pincree(CV:山田じぇみ子)
  - Tsundere — Shirone Nekono — 音声素材_Pincree(CV:猫乃しろね)
  - Fanatic — Akari Kotone — 音声素材_Pincree(CV:琴音あかり)
