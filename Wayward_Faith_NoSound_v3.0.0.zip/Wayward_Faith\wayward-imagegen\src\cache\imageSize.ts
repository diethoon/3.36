/**
 * Pixel size of a stored render, read from the file header (PNG IHDR or WebP VP8/VP8L/VP8X).
 * Null when the file is missing or not one of these.
 *
 * Wayward Faith: pack renders used to come out at the workflow default 1024x1024 because the
 * batch path never passed the game's size to ComfyUI (batch/queue.ts). The pack maker uses this
 * to treat a picture of the wrong size as one to draw again.
 */
import * as fs from 'node:fs'
import * as path from 'node:path'

export function imageSize(file: string): [number, number] | null {
  let b: Buffer
  try {
    const fd = fs.openSync(file, 'r')
    try {
      b = Buffer.alloc(32)
      fs.readSync(fd, b, 0, 32, 0)
    } finally { fs.closeSync(fd) }
  } catch { return null }
  if (b.toString('ascii', 1, 4) === 'PNG') return [b.readUInt32BE(16), b.readUInt32BE(20)]
  if (b.toString('ascii', 0, 4) !== 'RIFF' || b.toString('ascii', 8, 12) !== 'WEBP') return null
  const kind = b.toString('ascii', 12, 16)
  if (kind === 'VP8 ') return [b.readUInt16LE(26) & 0x3fff, b.readUInt16LE(28) & 0x3fff]
  if (kind === 'VP8L') { const x = b.readUInt32LE(21); return [(x & 0x3fff) + 1, ((x >> 14) & 0x3fff) + 1] }
  if (kind === 'VP8X') return [1 + b.readUIntLE(24, 3), 1 + b.readUIntLE(27, 3)]
  return null
}

/**
 * imageSize, remembered in <stateDir>/image-sizes.json while the file's byte size and modified time stay the same.
 * Opening thousands of pack pictures for their header took 12 s on a cold disk (the maker's '이미 있는 그림 확인' —
 * user report 2026-10-20); a stat is cheap. Null when the file is missing.
 */
export function knownImageSize(stateDir: string, file: string): [number, number] | null {
  let stat: fs.Stats
  try { stat = fs.statSync(file) } catch { return null }
  const memo = sizeMemo(stateDir), hit = memo.sizes[file], mtime = Math.floor(stat.mtimeMs)
  if (hit && hit[0] === stat.size && hit[1] === mtime) return hit[2] ? [hit[2], hit[3]] : null
  const size = imageSize(file)
  memo.sizes[file] = [stat.size, mtime, size?.[0] ?? 0, size?.[1] ?? 0]
  memo.dirty = true
  return size
}

/** Write what knownImageSize learned (call once after a batch of lookups). */
export function saveKnownImageSizes(stateDir: string): void {
  const memo = memos.get(stateDir)
  if (!memo?.dirty) return
  try {
    fs.mkdirSync(stateDir, { recursive: true })
    const tmp = memo.file + '.tmp'
    fs.writeFileSync(tmp, JSON.stringify(memo.sizes))
    fs.renameSync(tmp, memo.file)
    memo.dirty = false
  } catch (err) { console.error('[image-size] could not save:', (err as Error).message) }
}

const memos = new Map<string, { file: string; sizes: Record<string, [number, number, number, number]>; dirty: boolean }>()
function sizeMemo(stateDir: string) {
  let memo = memos.get(stateDir)
  if (!memo) {
    const file = path.join(stateDir, 'image-sizes.json')
    let sizes = {}
    try { if (fs.existsSync(file)) sizes = JSON.parse(fs.readFileSync(file, 'utf8')) } catch { /* start fresh */ }
    memos.set(stateDir, memo = { file, sizes, dirty: false })
  }
  return memo
}

/** The game asks for 1216x832 and the picture is drawn portrait (832x1216) — compare by short/long side. */
export function sizeMatches(size: [number, number], want: { width?: number; height?: number }): boolean {
  if (!want.width || !want.height) return true
  return Math.min(...size) === Math.min(want.width, want.height) && Math.max(...size) === Math.max(want.width, want.height)
}
