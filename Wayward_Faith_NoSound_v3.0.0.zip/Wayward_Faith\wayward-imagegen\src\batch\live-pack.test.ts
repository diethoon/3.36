import { test, expect } from 'bun:test'
import * as fs from 'node:fs'
import * as os from 'node:os'
import * as path from 'node:path'
import { BatchQueue } from './queue.ts'
import { resolveConfig, type Config } from '../config.ts'
import { CacheStore } from '../cache/cacheStore.ts'
import { OutfitPackWriter } from '../cache/outfitPack.ts'
import { JobRunner, type SubmitArgs, type GenerationJob } from '../comfy/jobRunner.ts'
import { derivePromptHash } from '../naming.ts'

test('pack originals are saved directly, survive restart, and deletion regenerates despite a global cached copy', async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'wf-pack-originals-'))
  try {
    const imagesDir = path.join(root, 'cache'), stateDir = path.join(root, 'state')
    const config = { stateDir, imagesDir, characterDirs: ['mara'], webp: false } as Config
    const globalCache = new CacheStore({imagesDir})
    const target = { character: 'mara', outfit: 'basic', name: '마라 기본팩 A' }
    const items = ['cached', 'first', 'second'].map(k => ({ talentId: 'mara__'+k, prompt: k, presetName: 'IL', styleName: 'ink', outfitPack: target }))
    const writer = new OutfitPackWriter(stateDir, imagesDir, {...target,presetName:'IL',styleName:'ink'})
    for (const item of items) {
      const imagePath = item.talentId+'.png'
      fs.mkdirSync(imagesDir,{recursive:true}); fs.writeFileSync(path.join(imagesDir,imagePath),'old global')
      globalCache.add({talentName:item.talentId,imageType:'portrait',promptHash:derivePromptHash(item.prompt,'',item),workflow:'illustrious',prompt:item.prompt,imagePath})
    }
    fs.mkdirSync(writer.cache.imagesDir,{recursive:true})
    fs.writeFileSync(path.join(writer.cache.imagesDir,'cached.png'),'pack original')
    writer.record(items[0].talentId,writer.cache.add({talentName:items[0].talentId,imageType:'portrait',promptHash:derivePromptHash(items[0].prompt,'',items[0]),workflow:'illustrious',prompt:'cached',imagePath:'cached.png'}))
    writer.flush()
    const runner = new JobRunner({config,cache:globalCache,comfy:{} as never})
    const internal = runner as unknown as {makeJob(id:string,args:SubmitArgs):GenerationJob;storeImage(job:GenerationJob,bytes:Buffer):Promise<void>}
    const rendered = new Map<string,GenerationJob>(), submissions:string[]=[]
    let queue:BatchQueue
    const jobs = {submit:async(args:SubmitArgs)=>{
      submissions.push(args.talentId)
      expect(args.output?.cache.imagesDir).toBe(writer.cache.imagesDir)
      // Pause as this one is sent, so the run stops after it (the queue keeps BATCH_IN_FLIGHT in ComfyUI — a pause stops new ones, sent ones finish)
      queue.pause()
      const job=internal.makeJob('render-'+submissions.length,args)
      await internal.storeImage(job,Buffer.from('new '+args.talentId))
      rendered.set(job.promptId,job)
      return job
    },get:(id:string)=>rendered.get(id)} as unknown as JobRunner
    queue=new BatchQueue(config,globalCache,jobs)
    const initial=queue.enqueue(items)
    expect(initial.accepted).toBe(2)
    expect(initial.alreadyCached).toBe(1)
    expect(initial.packDirectory).toBe(path.join('image-packs','마라 기본팩 A-mara', 'base'))
    const folder=path.join(stateDir,initial.packDirectory!)
    const read=()=>JSON.parse(fs.readFileSync(path.join(folder,'pack.js'),'utf8').match(/\]\s*=\s*(\{[\s\S]*\})\s*;?\s*$/)![1])
    const packId=read().packId
    queue.start()
    while(queue.status().running)await new Promise(r=>setTimeout(r,1))
    expect(read().entryCount).toBe(2)
    queue=new BatchQueue(config,globalCache,jobs).resume()
    expect(queue.status().packDirectory).toBe(initial.packDirectory)
    queue.start()
    while(queue.status().running)await new Promise(r=>setTimeout(r,1))
    expect(read().entryCount).toBe(3)
    expect(read().packId).toBe(packId)
    expect(submissions).toEqual(['mara__first','mara__second'])
    for(const item of items)expect(fs.readFileSync(path.join(imagesDir,item.talentId+'.png'),'utf8')).toBe('old global')
    expect(fs.existsSync(path.join(imagesDir,'il'))).toBe(false)
    const deleted=path.join(folder,read().entries.mara__first.imagePath)
    fs.unlinkSync(deleted)
    const retry=queue.enqueue(items)
    expect(retry.accepted).toBe(1)
    expect(retry.alreadyCached).toBe(2)
    expect(read().entries.mara__first).toBeUndefined()
    queue.start()
    while(queue.status().running)await new Promise(r=>setTimeout(r,1))
    expect(read().entryCount).toBe(3)
    expect(submissions).toEqual(['mara__first','mara__second','mara__first'])
    expect(fs.readFileSync(path.join(folder,read().entries.mara__first.imagePath),'utf8')).toBe('new mara__first')
    fs.unlinkSync(path.join(folder,read().entries.mara__first.imagePath))
    queue=new BatchQueue(config,globalCache,jobs).resume()
    expect(queue.status().done).toBe(0)
    queue.start()
    while(queue.status().running)await new Promise(r=>setTimeout(r,1))
    expect(submissions.length).toBe(4)
    expect(read().entryCount).toBe(3)
  }finally{fs.rmSync(root,{recursive:true,force:true})}
})

test('same-key jobs keep separate direct destinations and ordinary generation still saves normally', async () => {
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'wf-pack-destinations-'))
  try {
    const config=resolveConfig([],root)
    config.webp=false
    const cache=new CacheStore({imagesDir:config.imagesDir})
    const a=new OutfitPackWriter(config.stateDir,config.imagesDir,{character:'mara',outfit:'basic',name:'Mara A'})
    const b=new OutfitPackWriter(config.stateDir,config.imagesDir,{character:'mara',outfit:'basic',name:'Mara B'})
    let submitted=0
    const runner=new JobRunner({config,cache,comfy:{submit:async()=> 'job-'+(++submitted)} as never})
    const args:SubmitArgs={talentId:'mara__same',talentName:'mara__same',imageType:'portrait',prompt:'portrait',negativePrompt:'',workflow:'illustrious',promptHash:'test-hash',bulk:true}
    const [first,again,second,ordinary]=await Promise.all([
      runner.submit({...args,output:{cache:a.cache}}),runner.submit({...args,output:{cache:a.cache}}),
      runner.submit({...args,output:{cache:b.cache}}),runner.submit(args),
    ])
    expect(first).toBe(again)
    expect(submitted).toBe(3)
    const internal=runner as unknown as {storeImage(job:GenerationJob,bytes:Buffer):Promise<void>}
    for(const job of [first,second,ordinary])await internal.storeImage(job,Buffer.from(job.promptId))
    expect(first.media!.absolutePath.startsWith(a.cache.imagesDir+path.sep)).toBe(true)
    expect(second.media!.absolutePath.startsWith(b.cache.imagesDir+path.sep)).toBe(true)
    expect(ordinary.media!.absolutePath.startsWith(cache.imagesDir+path.sep)).toBe(true)
    expect(a.cache.get(args.talentName,args.imageType,args.promptHash,args.workflow)).not.toBeNull()
    expect(b.cache.get(args.talentName,args.imageType,args.promptHash,args.workflow)).not.toBeNull()
    expect(JSON.stringify(first)).not.toContain('outfit-pack-ids')
  }finally{fs.rmSync(root,{recursive:true,force:true})}
})
